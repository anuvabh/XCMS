<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-08 04:35:55 --> Config Class Initialized
DEBUG - 2012-04-08 04:35:55 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:35:55 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:35:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:35:55 --> URI Class Initialized
DEBUG - 2012-04-08 04:35:55 --> Router Class Initialized
DEBUG - 2012-04-08 04:35:55 --> No URI present. Default controller set.
DEBUG - 2012-04-08 04:35:55 --> Output Class Initialized
DEBUG - 2012-04-08 04:35:55 --> Security Class Initialized
DEBUG - 2012-04-08 04:35:55 --> Input Class Initialized
DEBUG - 2012-04-08 04:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:35:55 --> Language Class Initialized
DEBUG - 2012-04-08 04:35:55 --> Loader Class Initialized
DEBUG - 2012-04-08 04:35:56 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:35:56 --> Database Driver Class Initialized
ERROR - 2012-04-08 04:35:56 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-08 04:35:56 --> Session Class Initialized
DEBUG - 2012-04-08 04:35:56 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:35:56 --> A session cookie was not found.
DEBUG - 2012-04-08 04:35:56 --> Session routines successfully run
DEBUG - 2012-04-08 04:35:57 --> Controller Class Initialized
DEBUG - 2012-04-08 04:35:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 04:35:57 --> Final output sent to browser
DEBUG - 2012-04-08 04:35:57 --> Total execution time: 2.3317
DEBUG - 2012-04-08 04:36:35 --> Config Class Initialized
DEBUG - 2012-04-08 04:36:35 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:36:35 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:36:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:36:35 --> URI Class Initialized
DEBUG - 2012-04-08 04:36:35 --> Router Class Initialized
DEBUG - 2012-04-08 04:36:35 --> Output Class Initialized
DEBUG - 2012-04-08 04:36:35 --> Security Class Initialized
DEBUG - 2012-04-08 04:36:35 --> Input Class Initialized
DEBUG - 2012-04-08 04:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:36:35 --> Language Class Initialized
DEBUG - 2012-04-08 04:36:35 --> Loader Class Initialized
DEBUG - 2012-04-08 04:36:36 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:36:36 --> Database Driver Class Initialized
ERROR - 2012-04-08 04:36:36 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-08 04:36:36 --> Session Class Initialized
DEBUG - 2012-04-08 04:36:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:36:36 --> Session routines successfully run
DEBUG - 2012-04-08 04:36:36 --> Controller Class Initialized
DEBUG - 2012-04-08 04:36:36 --> Model Class Initialized
DEBUG - 2012-04-08 04:36:36 --> Model Class Initialized
DEBUG - 2012-04-08 04:36:36 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 04:36:36 --> Final output sent to browser
DEBUG - 2012-04-08 04:36:36 --> Total execution time: 1.4291
DEBUG - 2012-04-08 04:37:03 --> Config Class Initialized
DEBUG - 2012-04-08 04:37:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:37:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:37:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:37:03 --> URI Class Initialized
DEBUG - 2012-04-08 04:37:03 --> Router Class Initialized
DEBUG - 2012-04-08 04:37:03 --> Output Class Initialized
DEBUG - 2012-04-08 04:37:03 --> Security Class Initialized
DEBUG - 2012-04-08 04:37:03 --> Input Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:37:04 --> Language Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Loader Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:37:04 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Session Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:37:04 --> Session routines successfully run
DEBUG - 2012-04-08 04:37:04 --> Controller Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Model Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Model Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Config Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:37:04 --> URI Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Router Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Output Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Security Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Input Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:37:04 --> Language Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Loader Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:37:04 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Session Class Initialized
DEBUG - 2012-04-08 04:37:04 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:37:04 --> Session routines successfully run
DEBUG - 2012-04-08 04:37:04 --> Controller Class Initialized
DEBUG - 2012-04-08 04:37:05 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 04:37:05 --> Final output sent to browser
DEBUG - 2012-04-08 04:37:05 --> Total execution time: 0.4960
DEBUG - 2012-04-08 04:38:22 --> Config Class Initialized
DEBUG - 2012-04-08 04:38:22 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:38:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:38:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:38:23 --> URI Class Initialized
DEBUG - 2012-04-08 04:38:23 --> Router Class Initialized
DEBUG - 2012-04-08 04:38:23 --> Output Class Initialized
DEBUG - 2012-04-08 04:38:23 --> Security Class Initialized
DEBUG - 2012-04-08 04:38:23 --> Input Class Initialized
DEBUG - 2012-04-08 04:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:38:23 --> Language Class Initialized
DEBUG - 2012-04-08 04:38:23 --> Loader Class Initialized
DEBUG - 2012-04-08 04:38:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:38:24 --> Database Driver Class Initialized
ERROR - 2012-04-08 04:38:24 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-08 04:38:24 --> Session Class Initialized
DEBUG - 2012-04-08 04:38:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:38:24 --> Session routines successfully run
DEBUG - 2012-04-08 04:38:24 --> Controller Class Initialized
DEBUG - 2012-04-08 04:38:24 --> Model Class Initialized
DEBUG - 2012-04-08 04:38:24 --> Model Class Initialized
DEBUG - 2012-04-08 04:38:24 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 04:38:24 --> Final output sent to browser
DEBUG - 2012-04-08 04:38:24 --> Total execution time: 1.8263
DEBUG - 2012-04-08 04:39:03 --> Config Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:39:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:39:03 --> URI Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Router Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Output Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Security Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Input Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:39:03 --> Language Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Loader Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:39:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Session Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:39:03 --> Session routines successfully run
DEBUG - 2012-04-08 04:39:03 --> Controller Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Model Class Initialized
DEBUG - 2012-04-08 04:39:03 --> Model Class Initialized
DEBUG - 2012-04-08 04:39:03 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 04:39:03 --> Final output sent to browser
DEBUG - 2012-04-08 04:39:03 --> Total execution time: 0.3990
DEBUG - 2012-04-08 04:39:26 --> Config Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:39:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:39:26 --> URI Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Router Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Output Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Security Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Input Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:39:26 --> Language Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Loader Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:39:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Session Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:39:26 --> Session routines successfully run
DEBUG - 2012-04-08 04:39:26 --> Controller Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Model Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Model Class Initialized
DEBUG - 2012-04-08 04:39:26 --> Model Class Initialized
DEBUG - 2012-04-08 04:39:26 --> DB Transaction Failure
ERROR - 2012-04-08 04:39:26 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`sxccms`.`blocksetsinfo`, CONSTRAINT `blocksetsinfo_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `blocksinfo` (`BlockID`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-04-08 04:39:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-08 04:41:54 --> Config Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:41:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:41:54 --> URI Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Router Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Output Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Security Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Input Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:41:54 --> Language Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Loader Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:41:54 --> Database Driver Class Initialized
ERROR - 2012-04-08 04:41:54 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-08 04:41:54 --> Session Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:41:54 --> Session routines successfully run
DEBUG - 2012-04-08 04:41:54 --> Controller Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Model Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Model Class Initialized
DEBUG - 2012-04-08 04:41:54 --> Model Class Initialized
DEBUG - 2012-04-08 04:41:55 --> Final output sent to browser
DEBUG - 2012-04-08 04:41:55 --> Total execution time: 1.1528
DEBUG - 2012-04-08 04:42:36 --> Config Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:42:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:42:36 --> URI Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Router Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Output Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Security Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Input Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:42:36 --> Language Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Loader Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:42:36 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Session Class Initialized
DEBUG - 2012-04-08 04:42:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:42:36 --> Session routines successfully run
DEBUG - 2012-04-08 04:42:36 --> Controller Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Config Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:42:37 --> URI Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Router Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Output Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Security Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Input Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:42:37 --> Language Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Loader Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:42:37 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Session Class Initialized
DEBUG - 2012-04-08 04:42:37 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:42:37 --> A session cookie was not found.
DEBUG - 2012-04-08 04:42:37 --> Session routines successfully run
DEBUG - 2012-04-08 04:42:37 --> Controller Class Initialized
DEBUG - 2012-04-08 04:42:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 04:42:37 --> Final output sent to browser
DEBUG - 2012-04-08 04:42:37 --> Total execution time: 0.3848
DEBUG - 2012-04-08 04:42:39 --> Config Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:42:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:42:39 --> URI Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Router Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Output Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Security Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Input Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:42:39 --> Language Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Loader Class Initialized
DEBUG - 2012-04-08 04:42:39 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:42:40 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:42:40 --> Session Class Initialized
DEBUG - 2012-04-08 04:42:40 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:42:40 --> Session routines successfully run
DEBUG - 2012-04-08 04:42:40 --> Controller Class Initialized
DEBUG - 2012-04-08 04:42:40 --> Model Class Initialized
DEBUG - 2012-04-08 04:42:40 --> Model Class Initialized
DEBUG - 2012-04-08 04:42:40 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 04:42:40 --> Final output sent to browser
DEBUG - 2012-04-08 04:42:40 --> Total execution time: 0.4325
DEBUG - 2012-04-08 04:42:59 --> Config Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:42:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:42:59 --> URI Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Router Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Output Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Security Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Input Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:42:59 --> Language Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Loader Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:42:59 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Session Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:42:59 --> Session routines successfully run
DEBUG - 2012-04-08 04:42:59 --> Controller Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Model Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Model Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Helper loaded: email_helper
DEBUG - 2012-04-08 04:42:59 --> Model Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Config Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:42:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:42:59 --> URI Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Router Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Output Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Security Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Input Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:42:59 --> Language Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Loader Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:42:59 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Session Class Initialized
DEBUG - 2012-04-08 04:42:59 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:42:59 --> Session routines successfully run
DEBUG - 2012-04-08 04:42:59 --> Controller Class Initialized
DEBUG - 2012-04-08 04:42:59 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 04:42:59 --> Final output sent to browser
DEBUG - 2012-04-08 04:42:59 --> Total execution time: 0.3212
DEBUG - 2012-04-08 04:43:02 --> Config Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:43:02 --> URI Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Router Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Output Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Security Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Input Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:43:02 --> Language Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Loader Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:43:02 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Session Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:43:02 --> Session routines successfully run
DEBUG - 2012-04-08 04:43:02 --> Controller Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Config Class Initialized
DEBUG - 2012-04-08 04:43:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:43:03 --> URI Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Router Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Output Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Security Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Input Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:43:03 --> Language Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Loader Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:43:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Session Class Initialized
DEBUG - 2012-04-08 04:43:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:43:03 --> A session cookie was not found.
DEBUG - 2012-04-08 04:43:03 --> Session routines successfully run
DEBUG - 2012-04-08 04:43:03 --> Controller Class Initialized
DEBUG - 2012-04-08 04:43:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 04:43:03 --> Final output sent to browser
DEBUG - 2012-04-08 04:43:03 --> Total execution time: 0.4058
DEBUG - 2012-04-08 04:44:22 --> Config Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:44:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:44:22 --> URI Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Router Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Output Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Security Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Input Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:44:22 --> Language Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Loader Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:44:22 --> Database Driver Class Initialized
ERROR - 2012-04-08 04:44:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-08 04:44:22 --> Session Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:44:22 --> Session routines successfully run
DEBUG - 2012-04-08 04:44:22 --> Controller Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Model Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Model Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Config Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:44:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:44:22 --> URI Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Router Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Output Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Security Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Input Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:44:22 --> Language Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Loader Class Initialized
DEBUG - 2012-04-08 04:44:22 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:44:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:44:23 --> Session Class Initialized
DEBUG - 2012-04-08 04:44:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:44:23 --> Session routines successfully run
DEBUG - 2012-04-08 04:44:23 --> Controller Class Initialized
DEBUG - 2012-04-08 04:44:23 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 04:44:23 --> Final output sent to browser
DEBUG - 2012-04-08 04:44:23 --> Total execution time: 0.3233
DEBUG - 2012-04-08 04:44:25 --> Config Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:44:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:44:25 --> URI Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Router Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Output Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Security Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Input Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:44:25 --> Language Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Loader Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:44:25 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Session Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:44:25 --> Session routines successfully run
DEBUG - 2012-04-08 04:44:25 --> Controller Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Model Class Initialized
DEBUG - 2012-04-08 04:44:25 --> Model Class Initialized
DEBUG - 2012-04-08 04:44:25 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 04:44:25 --> Final output sent to browser
DEBUG - 2012-04-08 04:44:25 --> Total execution time: 0.4391
DEBUG - 2012-04-08 04:44:40 --> Config Class Initialized
DEBUG - 2012-04-08 04:44:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 04:44:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 04:44:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 04:44:40 --> URI Class Initialized
DEBUG - 2012-04-08 04:44:40 --> Router Class Initialized
DEBUG - 2012-04-08 04:44:40 --> Output Class Initialized
DEBUG - 2012-04-08 04:44:40 --> Security Class Initialized
DEBUG - 2012-04-08 04:44:40 --> Input Class Initialized
DEBUG - 2012-04-08 04:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 04:44:40 --> Language Class Initialized
DEBUG - 2012-04-08 04:44:41 --> Loader Class Initialized
DEBUG - 2012-04-08 04:44:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 04:44:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 04:44:41 --> Session Class Initialized
DEBUG - 2012-04-08 04:44:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 04:44:41 --> Session routines successfully run
DEBUG - 2012-04-08 04:44:41 --> Controller Class Initialized
DEBUG - 2012-04-08 04:44:41 --> Model Class Initialized
DEBUG - 2012-04-08 04:44:41 --> Model Class Initialized
DEBUG - 2012-04-08 04:44:41 --> Model Class Initialized
DEBUG - 2012-04-08 04:44:41 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 04:44:41 --> Final output sent to browser
DEBUG - 2012-04-08 04:44:41 --> Total execution time: 0.3863
DEBUG - 2012-04-08 05:01:41 --> Config Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:01:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:01:41 --> URI Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Router Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Output Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Security Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Input Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:01:41 --> Language Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Loader Class Initialized
DEBUG - 2012-04-08 05:01:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:01:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Session Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:01:42 --> Session routines successfully run
DEBUG - 2012-04-08 05:01:42 --> Controller Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Config Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:01:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:01:42 --> URI Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Router Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Output Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Security Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Input Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:01:42 --> Language Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Loader Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:01:42 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Session Class Initialized
DEBUG - 2012-04-08 05:01:42 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:01:42 --> A session cookie was not found.
DEBUG - 2012-04-08 05:01:42 --> Session routines successfully run
DEBUG - 2012-04-08 05:01:42 --> Controller Class Initialized
DEBUG - 2012-04-08 05:01:42 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 05:01:42 --> Final output sent to browser
DEBUG - 2012-04-08 05:01:42 --> Total execution time: 0.6486
DEBUG - 2012-04-08 05:01:56 --> Config Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:01:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:01:56 --> URI Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Router Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Output Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Security Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Input Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:01:56 --> Language Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Loader Class Initialized
DEBUG - 2012-04-08 05:01:56 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:01:56 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Session Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:01:57 --> Session routines successfully run
DEBUG - 2012-04-08 05:01:57 --> Controller Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Model Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Model Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Config Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:01:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:01:57 --> URI Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Router Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Output Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Security Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Input Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:01:57 --> Language Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Loader Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:01:57 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Session Class Initialized
DEBUG - 2012-04-08 05:01:57 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:01:57 --> Session routines successfully run
DEBUG - 2012-04-08 05:01:57 --> Controller Class Initialized
DEBUG - 2012-04-08 05:01:57 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 05:01:57 --> Final output sent to browser
DEBUG - 2012-04-08 05:01:57 --> Total execution time: 0.3085
DEBUG - 2012-04-08 05:01:59 --> Config Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:01:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:01:59 --> URI Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Router Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Output Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Security Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Input Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:01:59 --> Language Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Loader Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:01:59 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Session Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:01:59 --> Session routines successfully run
DEBUG - 2012-04-08 05:01:59 --> Controller Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Model Class Initialized
DEBUG - 2012-04-08 05:01:59 --> Model Class Initialized
DEBUG - 2012-04-08 05:01:59 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:01:59 --> Final output sent to browser
DEBUG - 2012-04-08 05:01:59 --> Total execution time: 0.4323
DEBUG - 2012-04-08 05:02:09 --> Config Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:02:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:02:09 --> URI Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Router Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Output Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Security Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Input Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:02:09 --> Language Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Loader Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:02:09 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Session Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:02:09 --> Session routines successfully run
DEBUG - 2012-04-08 05:02:09 --> Controller Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Model Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Model Class Initialized
DEBUG - 2012-04-08 05:02:09 --> Model Class Initialized
DEBUG - 2012-04-08 05:02:09 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:02:09 --> Final output sent to browser
DEBUG - 2012-04-08 05:02:09 --> Total execution time: 0.4757
DEBUG - 2012-04-08 05:03:12 --> Config Class Initialized
DEBUG - 2012-04-08 05:03:12 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:03:12 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:03:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:03:12 --> URI Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Router Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Output Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Security Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Input Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:03:13 --> Language Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Loader Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:03:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Session Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:03:13 --> Session routines successfully run
DEBUG - 2012-04-08 05:03:13 --> Controller Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Model Class Initialized
DEBUG - 2012-04-08 05:03:13 --> Model Class Initialized
DEBUG - 2012-04-08 05:03:13 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:03:13 --> Final output sent to browser
DEBUG - 2012-04-08 05:03:13 --> Total execution time: 0.4142
DEBUG - 2012-04-08 05:03:23 --> Config Class Initialized
DEBUG - 2012-04-08 05:03:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:03:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:03:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:03:23 --> URI Class Initialized
DEBUG - 2012-04-08 05:03:23 --> Router Class Initialized
DEBUG - 2012-04-08 05:03:23 --> Output Class Initialized
DEBUG - 2012-04-08 05:03:23 --> Security Class Initialized
DEBUG - 2012-04-08 05:03:23 --> Input Class Initialized
DEBUG - 2012-04-08 05:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:03:23 --> Language Class Initialized
DEBUG - 2012-04-08 05:03:23 --> Loader Class Initialized
DEBUG - 2012-04-08 05:03:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:03:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:03:24 --> Session Class Initialized
DEBUG - 2012-04-08 05:03:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:03:24 --> Session routines successfully run
DEBUG - 2012-04-08 05:03:24 --> Controller Class Initialized
DEBUG - 2012-04-08 05:03:24 --> Model Class Initialized
DEBUG - 2012-04-08 05:03:24 --> Model Class Initialized
DEBUG - 2012-04-08 05:03:24 --> Model Class Initialized
DEBUG - 2012-04-08 05:03:24 --> DB Transaction Failure
ERROR - 2012-04-08 05:03:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`sxccms`.`blocksetsinfo`, CONSTRAINT `blocksetsinfo_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `blocksinfo` (`BlockID`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-04-08 05:03:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-08 05:03:34 --> Config Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:03:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:03:34 --> URI Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Router Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Output Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Security Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Input Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:03:34 --> Language Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Loader Class Initialized
DEBUG - 2012-04-08 05:03:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:03:35 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:03:35 --> Session Class Initialized
DEBUG - 2012-04-08 05:03:35 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:03:35 --> Session routines successfully run
DEBUG - 2012-04-08 05:03:35 --> Controller Class Initialized
DEBUG - 2012-04-08 05:03:35 --> Model Class Initialized
DEBUG - 2012-04-08 05:03:35 --> Model Class Initialized
DEBUG - 2012-04-08 05:03:35 --> Model Class Initialized
DEBUG - 2012-04-08 05:03:35 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:03:35 --> Final output sent to browser
DEBUG - 2012-04-08 05:03:35 --> Total execution time: 0.4657
DEBUG - 2012-04-08 05:03:45 --> Config Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:03:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:03:46 --> URI Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Router Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Output Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Security Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Input Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:03:46 --> Language Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Loader Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:03:46 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Session Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:03:46 --> Session routines successfully run
DEBUG - 2012-04-08 05:03:46 --> Controller Class Initialized
DEBUG - 2012-04-08 05:03:46 --> Final output sent to browser
DEBUG - 2012-04-08 05:03:46 --> Total execution time: 0.3248
DEBUG - 2012-04-08 05:05:07 --> Config Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:05:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:05:07 --> URI Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Router Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Output Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Security Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Input Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:05:07 --> Language Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Loader Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:05:07 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Session Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:05:07 --> Session routines successfully run
DEBUG - 2012-04-08 05:05:07 --> Controller Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Model Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Model Class Initialized
DEBUG - 2012-04-08 05:05:07 --> Model Class Initialized
DEBUG - 2012-04-08 05:05:07 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:05:07 --> Final output sent to browser
DEBUG - 2012-04-08 05:05:07 --> Total execution time: 0.4190
DEBUG - 2012-04-08 05:05:40 --> Config Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:05:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:05:40 --> URI Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Router Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Output Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Security Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Input Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:05:40 --> Language Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Loader Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:05:40 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Session Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:05:40 --> Session routines successfully run
DEBUG - 2012-04-08 05:05:40 --> Controller Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Model Class Initialized
DEBUG - 2012-04-08 05:05:40 --> Model Class Initialized
DEBUG - 2012-04-08 05:05:40 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:05:40 --> Final output sent to browser
DEBUG - 2012-04-08 05:05:40 --> Total execution time: 0.5113
DEBUG - 2012-04-08 05:06:21 --> Config Class Initialized
DEBUG - 2012-04-08 05:06:21 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:06:21 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:06:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:06:22 --> URI Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Router Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Output Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Security Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Input Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:06:22 --> Language Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Loader Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:06:22 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Session Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:06:22 --> Session routines successfully run
DEBUG - 2012-04-08 05:06:22 --> Controller Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Model Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Model Class Initialized
DEBUG - 2012-04-08 05:06:22 --> Model Class Initialized
DEBUG - 2012-04-08 05:06:22 --> DB Transaction Failure
ERROR - 2012-04-08 05:06:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`sxccms`.`blocksetsinfo`, CONSTRAINT `blocksetsinfo_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `blocksinfo` (`BlockID`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-04-08 05:06:22 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-08 05:06:50 --> Config Class Initialized
DEBUG - 2012-04-08 05:06:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:06:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:06:50 --> URI Class Initialized
DEBUG - 2012-04-08 05:06:50 --> Router Class Initialized
DEBUG - 2012-04-08 05:06:50 --> Output Class Initialized
DEBUG - 2012-04-08 05:06:50 --> Security Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Input Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:06:51 --> Language Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Loader Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:06:51 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Session Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:06:51 --> Session routines successfully run
DEBUG - 2012-04-08 05:06:51 --> Controller Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Model Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Model Class Initialized
DEBUG - 2012-04-08 05:06:51 --> Model Class Initialized
DEBUG - 2012-04-08 05:06:51 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:06:51 --> Final output sent to browser
DEBUG - 2012-04-08 05:06:51 --> Total execution time: 0.6381
DEBUG - 2012-04-08 05:10:37 --> Config Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:10:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:10:37 --> URI Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Router Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Output Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Security Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Input Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:10:37 --> Language Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Loader Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:10:37 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Session Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:10:37 --> Session routines successfully run
DEBUG - 2012-04-08 05:10:37 --> Controller Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Model Class Initialized
DEBUG - 2012-04-08 05:10:37 --> Model Class Initialized
DEBUG - 2012-04-08 05:10:37 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:10:37 --> Final output sent to browser
DEBUG - 2012-04-08 05:10:37 --> Total execution time: 0.4682
DEBUG - 2012-04-08 05:10:49 --> Config Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:10:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:10:49 --> URI Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Router Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Output Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Security Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Input Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:10:49 --> Language Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Loader Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:10:49 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Session Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:10:49 --> Session routines successfully run
DEBUG - 2012-04-08 05:10:49 --> Controller Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Model Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Model Class Initialized
DEBUG - 2012-04-08 05:10:49 --> Model Class Initialized
ERROR - 2012-04-08 05:10:49 --> Severity: Notice  --> Undefined variable: BlockSetID C:\xampp\htdocs\xcms\system\views\freeze_view.php 24
DEBUG - 2012-04-08 05:10:49 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:10:49 --> Final output sent to browser
DEBUG - 2012-04-08 05:10:49 --> Total execution time: 0.5470
DEBUG - 2012-04-08 05:11:27 --> Config Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:11:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:11:27 --> URI Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Router Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Output Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Security Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Input Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:11:27 --> Language Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Loader Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:11:27 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Session Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:11:27 --> Session routines successfully run
DEBUG - 2012-04-08 05:11:27 --> Controller Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Model Class Initialized
DEBUG - 2012-04-08 05:11:27 --> Model Class Initialized
DEBUG - 2012-04-08 05:11:27 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:11:27 --> Final output sent to browser
DEBUG - 2012-04-08 05:11:27 --> Total execution time: 0.4065
DEBUG - 2012-04-08 05:11:33 --> Config Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:11:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:11:34 --> URI Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Router Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Output Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Security Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Input Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:11:34 --> Language Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Loader Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:11:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Session Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:11:34 --> Session routines successfully run
DEBUG - 2012-04-08 05:11:34 --> Controller Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Model Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Model Class Initialized
DEBUG - 2012-04-08 05:11:34 --> Model Class Initialized
ERROR - 2012-04-08 05:11:34 --> Severity: Notice  --> Undefined variable: BlockSetID C:\xampp\htdocs\xcms\system\views\freeze_view.php 24
DEBUG - 2012-04-08 05:11:34 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:11:34 --> Final output sent to browser
DEBUG - 2012-04-08 05:11:34 --> Total execution time: 0.4814
DEBUG - 2012-04-08 05:12:00 --> Config Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:12:00 --> URI Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Router Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Output Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Security Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Input Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:12:00 --> Language Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Loader Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:12:00 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Session Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:12:00 --> Session routines successfully run
DEBUG - 2012-04-08 05:12:00 --> Controller Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:00 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:00 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:12:00 --> Final output sent to browser
DEBUG - 2012-04-08 05:12:00 --> Total execution time: 0.3979
DEBUG - 2012-04-08 05:12:02 --> Config Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:12:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:12:02 --> URI Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Router Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Output Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Security Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Input Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:12:02 --> Language Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Loader Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:12:02 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Session Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:12:02 --> Session routines successfully run
DEBUG - 2012-04-08 05:12:02 --> Controller Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:02 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:02 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:12:02 --> Final output sent to browser
DEBUG - 2012-04-08 05:12:02 --> Total execution time: 0.5384
DEBUG - 2012-04-08 05:12:37 --> Config Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:12:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:12:37 --> URI Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Router Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Output Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Security Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Input Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:12:37 --> Language Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Loader Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:12:37 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Session Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:12:37 --> Session routines successfully run
DEBUG - 2012-04-08 05:12:37 --> Controller Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:37 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:37 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:12:37 --> Final output sent to browser
DEBUG - 2012-04-08 05:12:37 --> Total execution time: 0.4316
DEBUG - 2012-04-08 05:12:38 --> Config Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:12:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:12:38 --> URI Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Router Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Output Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Security Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Input Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:12:38 --> Language Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Loader Class Initialized
DEBUG - 2012-04-08 05:12:38 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:12:39 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:12:39 --> Session Class Initialized
DEBUG - 2012-04-08 05:12:39 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:12:39 --> Session routines successfully run
DEBUG - 2012-04-08 05:12:39 --> Controller Class Initialized
DEBUG - 2012-04-08 05:12:39 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:39 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:39 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:12:39 --> Final output sent to browser
DEBUG - 2012-04-08 05:12:39 --> Total execution time: 0.5852
DEBUG - 2012-04-08 05:12:47 --> Config Class Initialized
DEBUG - 2012-04-08 05:12:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:12:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:12:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:12:47 --> URI Class Initialized
DEBUG - 2012-04-08 05:12:47 --> Router Class Initialized
DEBUG - 2012-04-08 05:12:47 --> Output Class Initialized
DEBUG - 2012-04-08 05:12:47 --> Security Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Input Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:12:48 --> Language Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Loader Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:12:48 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Session Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:12:48 --> Session routines successfully run
DEBUG - 2012-04-08 05:12:48 --> Controller Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:48 --> Model Class Initialized
DEBUG - 2012-04-08 05:12:48 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:12:48 --> Final output sent to browser
DEBUG - 2012-04-08 05:12:48 --> Total execution time: 0.5172
DEBUG - 2012-04-08 05:14:08 --> Config Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:14:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:14:08 --> URI Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Router Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Output Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Security Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Input Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:14:08 --> Language Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Loader Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:14:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Session Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:14:08 --> Session routines successfully run
DEBUG - 2012-04-08 05:14:08 --> Controller Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Model Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Model Class Initialized
DEBUG - 2012-04-08 05:14:08 --> Model Class Initialized
DEBUG - 2012-04-08 05:14:08 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:14:08 --> Final output sent to browser
DEBUG - 2012-04-08 05:14:08 --> Total execution time: 0.5891
DEBUG - 2012-04-08 05:15:56 --> Config Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:15:56 --> URI Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Router Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Output Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Security Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Input Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:15:56 --> Language Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Loader Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:15:56 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Session Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:15:56 --> Session routines successfully run
DEBUG - 2012-04-08 05:15:56 --> Controller Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Model Class Initialized
DEBUG - 2012-04-08 05:15:56 --> Model Class Initialized
DEBUG - 2012-04-08 05:15:56 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:15:56 --> Final output sent to browser
DEBUG - 2012-04-08 05:15:56 --> Total execution time: 0.3941
DEBUG - 2012-04-08 05:16:05 --> Config Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:16:05 --> URI Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Router Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Output Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Security Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Input Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:16:05 --> Language Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Loader Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:16:05 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Session Class Initialized
DEBUG - 2012-04-08 05:16:05 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:16:05 --> Session routines successfully run
DEBUG - 2012-04-08 05:16:06 --> Controller Class Initialized
DEBUG - 2012-04-08 05:16:06 --> Model Class Initialized
DEBUG - 2012-04-08 05:16:06 --> Model Class Initialized
DEBUG - 2012-04-08 05:16:06 --> Model Class Initialized
DEBUG - 2012-04-08 05:16:06 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:16:06 --> Final output sent to browser
DEBUG - 2012-04-08 05:16:06 --> Total execution time: 0.5447
DEBUG - 2012-04-08 05:16:18 --> Config Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:16:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:16:19 --> URI Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Router Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Output Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Security Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Input Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:16:19 --> Language Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Loader Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:16:19 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Session Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:16:19 --> Session routines successfully run
DEBUG - 2012-04-08 05:16:19 --> Controller Class Initialized
DEBUG - 2012-04-08 05:16:19 --> Final output sent to browser
DEBUG - 2012-04-08 05:16:19 --> Total execution time: 0.6254
DEBUG - 2012-04-08 05:16:54 --> Config Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:16:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:16:54 --> URI Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Router Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Output Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Security Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Input Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:16:54 --> Language Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Loader Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:16:54 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Session Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:16:54 --> Session routines successfully run
DEBUG - 2012-04-08 05:16:54 --> Controller Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Model Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Model Class Initialized
DEBUG - 2012-04-08 05:16:54 --> Model Class Initialized
DEBUG - 2012-04-08 05:16:54 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:16:54 --> Final output sent to browser
DEBUG - 2012-04-08 05:16:54 --> Total execution time: 0.5915
DEBUG - 2012-04-08 05:17:33 --> Config Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:17:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:17:33 --> URI Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Router Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Output Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Security Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Input Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:17:33 --> Language Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Loader Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:17:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Session Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:17:33 --> Session routines successfully run
DEBUG - 2012-04-08 05:17:33 --> Controller Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Model Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Model Class Initialized
DEBUG - 2012-04-08 05:17:33 --> Model Class Initialized
DEBUG - 2012-04-08 05:17:33 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:17:33 --> Final output sent to browser
DEBUG - 2012-04-08 05:17:33 --> Total execution time: 0.5567
DEBUG - 2012-04-08 05:17:43 --> Config Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:17:43 --> URI Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Router Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Output Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Security Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Input Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:17:43 --> Language Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Loader Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:17:43 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Session Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:17:43 --> Session routines successfully run
DEBUG - 2012-04-08 05:17:43 --> Controller Class Initialized
DEBUG - 2012-04-08 05:17:43 --> Final output sent to browser
DEBUG - 2012-04-08 05:17:43 --> Total execution time: 0.4432
DEBUG - 2012-04-08 05:22:49 --> Config Class Initialized
DEBUG - 2012-04-08 05:22:49 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:22:49 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:22:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:22:49 --> URI Class Initialized
DEBUG - 2012-04-08 05:22:49 --> Router Class Initialized
DEBUG - 2012-04-08 05:22:49 --> No URI present. Default controller set.
DEBUG - 2012-04-08 05:22:49 --> Output Class Initialized
DEBUG - 2012-04-08 05:22:49 --> Security Class Initialized
DEBUG - 2012-04-08 05:22:49 --> Input Class Initialized
DEBUG - 2012-04-08 05:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:22:49 --> Language Class Initialized
DEBUG - 2012-04-08 05:22:50 --> Loader Class Initialized
DEBUG - 2012-04-08 05:22:50 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:22:50 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:22:50 --> Session Class Initialized
DEBUG - 2012-04-08 05:22:50 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:22:50 --> Session routines successfully run
DEBUG - 2012-04-08 05:22:50 --> Controller Class Initialized
DEBUG - 2012-04-08 05:22:50 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 05:22:50 --> Final output sent to browser
DEBUG - 2012-04-08 05:22:51 --> Total execution time: 2.1023
DEBUG - 2012-04-08 05:22:54 --> Config Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:22:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:22:54 --> URI Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Router Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Output Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Security Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Input Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:22:54 --> Language Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Loader Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:22:54 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Session Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:22:54 --> Session routines successfully run
DEBUG - 2012-04-08 05:22:54 --> Controller Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Model Class Initialized
DEBUG - 2012-04-08 05:22:54 --> Model Class Initialized
DEBUG - 2012-04-08 05:22:54 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:22:54 --> Final output sent to browser
DEBUG - 2012-04-08 05:22:54 --> Total execution time: 0.5724
DEBUG - 2012-04-08 05:23:09 --> Config Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:23:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:23:09 --> URI Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Router Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Output Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Security Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Input Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:23:09 --> Language Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Loader Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:23:09 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Session Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:23:09 --> Session routines successfully run
DEBUG - 2012-04-08 05:23:09 --> Controller Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Model Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Model Class Initialized
DEBUG - 2012-04-08 05:23:09 --> Model Class Initialized
DEBUG - 2012-04-08 05:23:09 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:23:09 --> Final output sent to browser
DEBUG - 2012-04-08 05:23:09 --> Total execution time: 0.4462
DEBUG - 2012-04-08 05:23:12 --> Config Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:23:12 --> URI Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Router Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Output Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Security Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Input Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:23:12 --> Language Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Loader Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:23:12 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Session Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:23:12 --> Session routines successfully run
DEBUG - 2012-04-08 05:23:12 --> Controller Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Model Class Initialized
DEBUG - 2012-04-08 05:23:12 --> Model Class Initialized
DEBUG - 2012-04-08 05:23:13 --> DB Transaction Failure
ERROR - 2012-04-08 05:23:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'TABLE blocksetsinfo SET status=0 WHERE BlockSetID=1' at line 1
DEBUG - 2012-04-08 05:23:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-08 05:24:46 --> Config Class Initialized
DEBUG - 2012-04-08 05:24:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:24:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:24:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:24:46 --> URI Class Initialized
DEBUG - 2012-04-08 05:24:46 --> Router Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Output Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Security Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Input Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:24:47 --> Language Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Loader Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:24:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Session Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:24:47 --> Session routines successfully run
DEBUG - 2012-04-08 05:24:47 --> Controller Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Model Class Initialized
DEBUG - 2012-04-08 05:24:47 --> Model Class Initialized
DEBUG - 2012-04-08 05:24:47 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:24:47 --> Final output sent to browser
DEBUG - 2012-04-08 05:24:47 --> Total execution time: 0.3956
DEBUG - 2012-04-08 05:24:54 --> Config Class Initialized
DEBUG - 2012-04-08 05:24:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:24:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:24:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:24:54 --> URI Class Initialized
DEBUG - 2012-04-08 05:24:54 --> Router Class Initialized
DEBUG - 2012-04-08 05:24:54 --> Output Class Initialized
DEBUG - 2012-04-08 05:24:54 --> Security Class Initialized
DEBUG - 2012-04-08 05:24:54 --> Input Class Initialized
DEBUG - 2012-04-08 05:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:24:54 --> Language Class Initialized
DEBUG - 2012-04-08 05:24:55 --> Loader Class Initialized
DEBUG - 2012-04-08 05:24:55 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:24:55 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:24:55 --> Session Class Initialized
DEBUG - 2012-04-08 05:24:55 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:24:55 --> Session routines successfully run
DEBUG - 2012-04-08 05:24:55 --> Controller Class Initialized
DEBUG - 2012-04-08 05:24:55 --> Model Class Initialized
DEBUG - 2012-04-08 05:24:55 --> Model Class Initialized
DEBUG - 2012-04-08 05:24:55 --> Model Class Initialized
DEBUG - 2012-04-08 05:24:55 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:24:55 --> Final output sent to browser
DEBUG - 2012-04-08 05:24:55 --> Total execution time: 0.4958
DEBUG - 2012-04-08 05:25:02 --> Config Class Initialized
DEBUG - 2012-04-08 05:25:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:25:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:25:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:25:02 --> URI Class Initialized
DEBUG - 2012-04-08 05:25:02 --> Router Class Initialized
DEBUG - 2012-04-08 05:25:02 --> Output Class Initialized
DEBUG - 2012-04-08 05:25:02 --> Security Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Input Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:25:03 --> Language Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Loader Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:25:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Session Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:25:03 --> Session routines successfully run
DEBUG - 2012-04-08 05:25:03 --> Controller Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Config Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:25:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:25:03 --> URI Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Router Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Output Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Security Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Input Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:25:03 --> Language Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Loader Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:25:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Session Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:25:03 --> Session routines successfully run
DEBUG - 2012-04-08 05:25:03 --> Controller Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:03 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:03 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:25:03 --> Final output sent to browser
DEBUG - 2012-04-08 05:25:03 --> Total execution time: 0.4661
DEBUG - 2012-04-08 05:25:24 --> Config Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:25:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:25:24 --> URI Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Router Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Output Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Security Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Input Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:25:24 --> Language Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Loader Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:25:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Session Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:25:24 --> Session routines successfully run
DEBUG - 2012-04-08 05:25:24 --> Controller Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:24 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:24 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:25:24 --> Final output sent to browser
DEBUG - 2012-04-08 05:25:24 --> Total execution time: 0.4089
DEBUG - 2012-04-08 05:25:26 --> Config Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:25:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:25:26 --> URI Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Router Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Output Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Security Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Input Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:25:26 --> Language Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Loader Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:25:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Session Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:25:26 --> Session routines successfully run
DEBUG - 2012-04-08 05:25:26 --> Controller Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Config Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:25:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:25:26 --> URI Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Router Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Output Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Security Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Input Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:25:26 --> Language Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Loader Class Initialized
DEBUG - 2012-04-08 05:25:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:25:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:25:27 --> Session Class Initialized
DEBUG - 2012-04-08 05:25:27 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:25:27 --> Session routines successfully run
DEBUG - 2012-04-08 05:25:27 --> Controller Class Initialized
DEBUG - 2012-04-08 05:25:27 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:27 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:27 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:25:27 --> Final output sent to browser
DEBUG - 2012-04-08 05:25:27 --> Total execution time: 0.5524
DEBUG - 2012-04-08 05:25:45 --> Config Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:25:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:25:45 --> URI Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Router Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Output Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Security Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Input Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:25:45 --> Language Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Loader Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:25:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Session Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:25:45 --> Session routines successfully run
DEBUG - 2012-04-08 05:25:45 --> Controller Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:45 --> Model Class Initialized
DEBUG - 2012-04-08 05:25:45 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:25:45 --> Final output sent to browser
DEBUG - 2012-04-08 05:25:45 --> Total execution time: 0.3699
DEBUG - 2012-04-08 05:28:53 --> Config Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:28:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:28:53 --> URI Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Router Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Output Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Security Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Input Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:28:53 --> Language Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Loader Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:28:53 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Session Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:28:53 --> Session routines successfully run
DEBUG - 2012-04-08 05:28:53 --> Controller Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Model Class Initialized
DEBUG - 2012-04-08 05:28:53 --> Model Class Initialized
DEBUG - 2012-04-08 05:28:53 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:28:53 --> Final output sent to browser
DEBUG - 2012-04-08 05:28:53 --> Total execution time: 0.3808
DEBUG - 2012-04-08 05:28:58 --> Config Class Initialized
DEBUG - 2012-04-08 05:28:58 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:28:58 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:28:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:28:58 --> URI Class Initialized
DEBUG - 2012-04-08 05:28:58 --> Router Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Output Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Security Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Input Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:28:59 --> Language Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Loader Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:28:59 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Session Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:28:59 --> Session routines successfully run
DEBUG - 2012-04-08 05:28:59 --> Controller Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Model Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Model Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Model Class Initialized
DEBUG - 2012-04-08 05:28:59 --> Final output sent to browser
DEBUG - 2012-04-08 05:28:59 --> Total execution time: 0.7494
DEBUG - 2012-04-08 05:29:45 --> Config Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:29:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:29:45 --> URI Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Router Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Output Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Security Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Input Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:29:45 --> Language Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Loader Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:29:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Session Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:29:45 --> Session routines successfully run
DEBUG - 2012-04-08 05:29:45 --> Controller Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Model Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Model Class Initialized
DEBUG - 2012-04-08 05:29:45 --> Model Class Initialized
DEBUG - 2012-04-08 05:29:45 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 05:29:45 --> Final output sent to browser
DEBUG - 2012-04-08 05:29:45 --> Total execution time: 0.4216
DEBUG - 2012-04-08 05:29:47 --> Config Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:29:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:29:47 --> URI Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Router Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Output Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Security Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Input Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:29:47 --> Language Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Loader Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:29:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Session Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:29:47 --> Session routines successfully run
DEBUG - 2012-04-08 05:29:47 --> Controller Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Model Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Model Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Config Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:29:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:29:47 --> URI Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Router Class Initialized
DEBUG - 2012-04-08 05:29:47 --> Output Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Security Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Input Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:29:48 --> Language Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Loader Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:29:48 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Session Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:29:48 --> Session routines successfully run
DEBUG - 2012-04-08 05:29:48 --> Controller Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Model Class Initialized
DEBUG - 2012-04-08 05:29:48 --> Model Class Initialized
DEBUG - 2012-04-08 05:29:48 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:29:48 --> Final output sent to browser
DEBUG - 2012-04-08 05:29:48 --> Total execution time: 0.4495
DEBUG - 2012-04-08 05:30:36 --> Config Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:30:36 --> URI Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Router Class Initialized
DEBUG - 2012-04-08 05:30:36 --> No URI present. Default controller set.
DEBUG - 2012-04-08 05:30:36 --> Output Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Security Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Input Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:30:36 --> Language Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Loader Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:30:36 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Session Class Initialized
DEBUG - 2012-04-08 05:30:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:30:36 --> Session routines successfully run
DEBUG - 2012-04-08 05:30:36 --> Controller Class Initialized
DEBUG - 2012-04-08 05:30:36 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 05:30:36 --> Final output sent to browser
DEBUG - 2012-04-08 05:30:36 --> Total execution time: 0.3101
DEBUG - 2012-04-08 05:30:39 --> Config Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:30:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:30:39 --> URI Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Router Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Output Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Security Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Input Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:30:39 --> Language Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Loader Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:30:39 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Session Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:30:39 --> Session routines successfully run
DEBUG - 2012-04-08 05:30:39 --> Controller Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Config Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:30:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:30:39 --> URI Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Router Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Output Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Security Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Input Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:30:39 --> Language Class Initialized
DEBUG - 2012-04-08 05:30:39 --> Loader Class Initialized
DEBUG - 2012-04-08 05:30:40 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:30:40 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:30:40 --> Session Class Initialized
DEBUG - 2012-04-08 05:30:40 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:30:40 --> A session cookie was not found.
DEBUG - 2012-04-08 05:30:40 --> Session routines successfully run
DEBUG - 2012-04-08 05:30:40 --> Controller Class Initialized
DEBUG - 2012-04-08 05:30:40 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 05:30:40 --> Final output sent to browser
DEBUG - 2012-04-08 05:30:40 --> Total execution time: 0.3536
DEBUG - 2012-04-08 05:30:46 --> Config Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:30:46 --> URI Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Router Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Output Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Security Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Input Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:30:46 --> Language Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Loader Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:30:46 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Session Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:30:46 --> Session routines successfully run
DEBUG - 2012-04-08 05:30:46 --> Controller Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Model Class Initialized
DEBUG - 2012-04-08 05:30:46 --> Model Class Initialized
DEBUG - 2012-04-08 05:30:46 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 05:30:46 --> Final output sent to browser
DEBUG - 2012-04-08 05:30:46 --> Total execution time: 0.3982
DEBUG - 2012-04-08 05:31:33 --> Config Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:31:33 --> URI Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Router Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Output Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Security Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Input Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:31:33 --> Language Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Loader Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:31:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Session Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:31:33 --> Session routines successfully run
DEBUG - 2012-04-08 05:31:33 --> Controller Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Model Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Model Class Initialized
DEBUG - 2012-04-08 05:31:33 --> Helper loaded: email_helper
DEBUG - 2012-04-08 05:31:33 --> Model Class Initialized
DEBUG - 2012-04-08 05:31:33 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 05:31:33 --> Final output sent to browser
DEBUG - 2012-04-08 05:31:33 --> Total execution time: 0.4611
DEBUG - 2012-04-08 05:32:55 --> Config Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:32:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:32:55 --> URI Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Router Class Initialized
DEBUG - 2012-04-08 05:32:55 --> No URI present. Default controller set.
DEBUG - 2012-04-08 05:32:55 --> Output Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Security Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Input Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:32:55 --> Language Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Loader Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:32:55 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Session Class Initialized
DEBUG - 2012-04-08 05:32:55 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:32:55 --> Session routines successfully run
DEBUG - 2012-04-08 05:32:55 --> Controller Class Initialized
DEBUG - 2012-04-08 05:32:55 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 05:32:55 --> Final output sent to browser
DEBUG - 2012-04-08 05:32:55 --> Total execution time: 0.3772
DEBUG - 2012-04-08 05:33:03 --> Config Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:33:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:33:03 --> URI Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Router Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Output Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Security Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Input Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:33:03 --> Language Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Loader Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:33:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Session Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:33:03 --> Session routines successfully run
DEBUG - 2012-04-08 05:33:03 --> Controller Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Config Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:33:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:33:03 --> URI Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Router Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Output Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Security Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Input Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:33:03 --> Language Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Loader Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:33:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Session Class Initialized
DEBUG - 2012-04-08 05:33:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:33:03 --> Session routines successfully run
DEBUG - 2012-04-08 05:33:03 --> Controller Class Initialized
DEBUG - 2012-04-08 05:33:03 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 05:33:03 --> Final output sent to browser
DEBUG - 2012-04-08 05:33:03 --> Total execution time: 0.3247
DEBUG - 2012-04-08 05:33:05 --> Config Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:33:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:33:05 --> URI Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Router Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Output Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Security Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Input Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:33:05 --> Language Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Loader Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:33:05 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Session Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:33:05 --> Session routines successfully run
DEBUG - 2012-04-08 05:33:05 --> Controller Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:05 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:05 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:33:05 --> Final output sent to browser
DEBUG - 2012-04-08 05:33:06 --> Total execution time: 0.5511
DEBUG - 2012-04-08 05:33:10 --> Config Class Initialized
DEBUG - 2012-04-08 05:33:10 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:33:10 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:33:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:33:10 --> URI Class Initialized
DEBUG - 2012-04-08 05:33:10 --> Router Class Initialized
DEBUG - 2012-04-08 05:33:10 --> Output Class Initialized
DEBUG - 2012-04-08 05:33:10 --> Security Class Initialized
DEBUG - 2012-04-08 05:33:10 --> Input Class Initialized
DEBUG - 2012-04-08 05:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:33:11 --> Language Class Initialized
DEBUG - 2012-04-08 05:33:11 --> Loader Class Initialized
DEBUG - 2012-04-08 05:33:11 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:33:11 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:33:11 --> Session Class Initialized
DEBUG - 2012-04-08 05:33:11 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:33:11 --> Session routines successfully run
DEBUG - 2012-04-08 05:33:11 --> Controller Class Initialized
DEBUG - 2012-04-08 05:33:11 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:11 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:11 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:33:11 --> Final output sent to browser
DEBUG - 2012-04-08 05:33:11 --> Total execution time: 0.4751
DEBUG - 2012-04-08 05:33:19 --> Config Class Initialized
DEBUG - 2012-04-08 05:33:19 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:33:19 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:33:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:33:19 --> URI Class Initialized
DEBUG - 2012-04-08 05:33:19 --> Router Class Initialized
DEBUG - 2012-04-08 05:33:19 --> Output Class Initialized
DEBUG - 2012-04-08 05:33:19 --> Security Class Initialized
DEBUG - 2012-04-08 05:33:19 --> Input Class Initialized
DEBUG - 2012-04-08 05:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:33:19 --> Language Class Initialized
DEBUG - 2012-04-08 05:33:20 --> Loader Class Initialized
DEBUG - 2012-04-08 05:33:20 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:33:20 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:33:20 --> Session Class Initialized
DEBUG - 2012-04-08 05:33:20 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:33:20 --> Session routines successfully run
DEBUG - 2012-04-08 05:33:20 --> Controller Class Initialized
DEBUG - 2012-04-08 05:33:20 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:20 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:20 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:33:20 --> Final output sent to browser
DEBUG - 2012-04-08 05:33:20 --> Total execution time: 0.3874
DEBUG - 2012-04-08 05:33:30 --> Config Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:33:30 --> URI Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Router Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Output Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Security Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Input Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:33:30 --> Language Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Loader Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:33:30 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Session Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:33:30 --> Session routines successfully run
DEBUG - 2012-04-08 05:33:30 --> Controller Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:30 --> Model Class Initialized
DEBUG - 2012-04-08 05:33:30 --> DB Transaction Failure
ERROR - 2012-04-08 05:33:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`sxccms`.`blocksetsinfo`, CONSTRAINT `blocksetsinfo_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `blocksinfo` (`BlockID`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-04-08 05:33:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-08 05:41:40 --> Config Class Initialized
DEBUG - 2012-04-08 05:41:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:41:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:41:40 --> URI Class Initialized
DEBUG - 2012-04-08 05:41:40 --> Router Class Initialized
DEBUG - 2012-04-08 05:41:40 --> Output Class Initialized
DEBUG - 2012-04-08 05:41:40 --> Security Class Initialized
DEBUG - 2012-04-08 05:41:40 --> Input Class Initialized
DEBUG - 2012-04-08 05:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:41:40 --> Language Class Initialized
DEBUG - 2012-04-08 05:43:57 --> Config Class Initialized
DEBUG - 2012-04-08 05:43:57 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:43:57 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:43:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:43:57 --> URI Class Initialized
DEBUG - 2012-04-08 05:43:57 --> Router Class Initialized
DEBUG - 2012-04-08 05:43:57 --> Output Class Initialized
DEBUG - 2012-04-08 05:43:57 --> Security Class Initialized
DEBUG - 2012-04-08 05:43:57 --> Input Class Initialized
DEBUG - 2012-04-08 05:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:43:57 --> Language Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Config Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:44:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:44:52 --> URI Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Router Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Output Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Security Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Input Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:44:52 --> Language Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Loader Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:44:52 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Session Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:44:52 --> Session routines successfully run
DEBUG - 2012-04-08 05:44:52 --> Controller Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Model Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Model Class Initialized
DEBUG - 2012-04-08 05:44:52 --> Model Class Initialized
DEBUG - 2012-04-08 05:44:53 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:44:53 --> Final output sent to browser
DEBUG - 2012-04-08 05:44:53 --> Total execution time: 0.4714
DEBUG - 2012-04-08 05:45:59 --> Config Class Initialized
DEBUG - 2012-04-08 05:45:59 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:45:59 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:45:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:45:59 --> URI Class Initialized
DEBUG - 2012-04-08 05:45:59 --> Router Class Initialized
DEBUG - 2012-04-08 05:45:59 --> Output Class Initialized
DEBUG - 2012-04-08 05:45:59 --> Security Class Initialized
DEBUG - 2012-04-08 05:45:59 --> Input Class Initialized
DEBUG - 2012-04-08 05:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:45:59 --> Language Class Initialized
DEBUG - 2012-04-08 05:46:00 --> Loader Class Initialized
DEBUG - 2012-04-08 05:46:00 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:46:00 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:46:00 --> Session Class Initialized
DEBUG - 2012-04-08 05:46:00 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:46:00 --> Session routines successfully run
DEBUG - 2012-04-08 05:46:00 --> Controller Class Initialized
DEBUG - 2012-04-08 05:46:00 --> Model Class Initialized
DEBUG - 2012-04-08 05:46:00 --> Model Class Initialized
DEBUG - 2012-04-08 05:46:00 --> Model Class Initialized
DEBUG - 2012-04-08 05:46:00 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:46:00 --> Final output sent to browser
DEBUG - 2012-04-08 05:46:00 --> Total execution time: 0.4403
DEBUG - 2012-04-08 05:47:18 --> Config Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:47:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:47:18 --> URI Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Router Class Initialized
DEBUG - 2012-04-08 05:47:18 --> No URI present. Default controller set.
DEBUG - 2012-04-08 05:47:18 --> Output Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Security Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Input Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:47:18 --> Language Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Loader Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:47:18 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Session Class Initialized
DEBUG - 2012-04-08 05:47:18 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:47:18 --> Session routines successfully run
DEBUG - 2012-04-08 05:47:18 --> Controller Class Initialized
DEBUG - 2012-04-08 05:47:18 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 05:47:18 --> Final output sent to browser
DEBUG - 2012-04-08 05:47:18 --> Total execution time: 0.4080
DEBUG - 2012-04-08 05:47:22 --> Config Class Initialized
DEBUG - 2012-04-08 05:47:22 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:47:22 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:47:23 --> URI Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Router Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Output Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Security Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Input Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:47:23 --> Language Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Loader Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:47:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Session Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:47:23 --> Session routines successfully run
DEBUG - 2012-04-08 05:47:23 --> Controller Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Model Class Initialized
DEBUG - 2012-04-08 05:47:23 --> Model Class Initialized
DEBUG - 2012-04-08 05:47:23 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:47:23 --> Final output sent to browser
DEBUG - 2012-04-08 05:47:23 --> Total execution time: 0.5792
DEBUG - 2012-04-08 05:53:52 --> Config Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:53:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:53:52 --> URI Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Router Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Output Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Security Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Input Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:53:52 --> Language Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Loader Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:53:52 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Session Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:53:52 --> Session routines successfully run
DEBUG - 2012-04-08 05:53:52 --> Controller Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Model Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Model Class Initialized
DEBUG - 2012-04-08 05:53:52 --> Model Class Initialized
DEBUG - 2012-04-08 05:53:52 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:53:52 --> Final output sent to browser
DEBUG - 2012-04-08 05:53:52 --> Total execution time: 0.4612
DEBUG - 2012-04-08 05:54:08 --> Config Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:54:08 --> URI Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Router Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Output Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Security Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Input Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:54:08 --> Language Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Loader Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:54:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Session Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:54:08 --> Session routines successfully run
DEBUG - 2012-04-08 05:54:08 --> Controller Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Model Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Model Class Initialized
DEBUG - 2012-04-08 05:54:08 --> Model Class Initialized
DEBUG - 2012-04-08 05:54:08 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:54:08 --> Final output sent to browser
DEBUG - 2012-04-08 05:54:08 --> Total execution time: 0.4521
DEBUG - 2012-04-08 05:54:13 --> Config Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:54:13 --> URI Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Router Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Output Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Security Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Input Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:54:13 --> Language Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Loader Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:54:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Session Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:54:13 --> Session routines successfully run
DEBUG - 2012-04-08 05:54:13 --> Controller Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Model Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Model Class Initialized
DEBUG - 2012-04-08 05:54:13 --> Model Class Initialized
DEBUG - 2012-04-08 05:54:13 --> DB Transaction Failure
ERROR - 2012-04-08 05:54:13 --> Query error: Unknown column 'a' in 'where clause'
DEBUG - 2012-04-08 05:54:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-08 05:55:24 --> Config Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:55:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:55:24 --> URI Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Router Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Output Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Security Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Input Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:55:24 --> Language Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Loader Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:55:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Session Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:55:24 --> Session routines successfully run
DEBUG - 2012-04-08 05:55:24 --> Controller Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Model Class Initialized
DEBUG - 2012-04-08 05:55:24 --> Model Class Initialized
DEBUG - 2012-04-08 05:55:24 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:55:24 --> Final output sent to browser
DEBUG - 2012-04-08 05:55:24 --> Total execution time: 0.3647
DEBUG - 2012-04-08 05:55:35 --> Config Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:55:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:55:35 --> URI Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Router Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Output Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Security Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Input Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:55:35 --> Language Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Loader Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:55:35 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Session Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:55:35 --> Session routines successfully run
DEBUG - 2012-04-08 05:55:35 --> Controller Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Model Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Model Class Initialized
DEBUG - 2012-04-08 05:55:35 --> Model Class Initialized
DEBUG - 2012-04-08 05:55:35 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:55:35 --> Final output sent to browser
DEBUG - 2012-04-08 05:55:35 --> Total execution time: 0.4871
DEBUG - 2012-04-08 05:55:40 --> Config Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:55:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:55:40 --> URI Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Router Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Output Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Security Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Input Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:55:40 --> Language Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Loader Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:55:40 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Session Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:55:40 --> Session routines successfully run
DEBUG - 2012-04-08 05:55:40 --> Controller Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Model Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Model Class Initialized
DEBUG - 2012-04-08 05:55:40 --> Model Class Initialized
DEBUG - 2012-04-08 05:55:40 --> DB Transaction Failure
ERROR - 2012-04-08 05:55:40 --> Query error: Unknown column 'w' in 'where clause'
DEBUG - 2012-04-08 05:55:40 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-08 05:56:43 --> Config Class Initialized
DEBUG - 2012-04-08 05:56:43 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:56:43 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:56:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:56:43 --> URI Class Initialized
DEBUG - 2012-04-08 05:56:43 --> Router Class Initialized
DEBUG - 2012-04-08 05:56:43 --> Output Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Security Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Input Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:56:44 --> Language Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Loader Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:56:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Session Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:56:44 --> Session routines successfully run
DEBUG - 2012-04-08 05:56:44 --> Controller Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Model Class Initialized
DEBUG - 2012-04-08 05:56:44 --> Model Class Initialized
DEBUG - 2012-04-08 05:56:44 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:56:44 --> Final output sent to browser
DEBUG - 2012-04-08 05:56:44 --> Total execution time: 0.6241
DEBUG - 2012-04-08 05:56:49 --> Config Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:56:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:56:49 --> URI Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Router Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Output Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Security Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Input Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:56:49 --> Language Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Loader Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:56:49 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Session Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:56:49 --> Session routines successfully run
DEBUG - 2012-04-08 05:56:49 --> Controller Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Model Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Model Class Initialized
DEBUG - 2012-04-08 05:56:49 --> Model Class Initialized
DEBUG - 2012-04-08 05:56:49 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:56:49 --> Final output sent to browser
DEBUG - 2012-04-08 05:56:49 --> Total execution time: 0.5730
DEBUG - 2012-04-08 05:57:00 --> Config Class Initialized
DEBUG - 2012-04-08 05:57:00 --> Hooks Class Initialized
DEBUG - 2012-04-08 05:57:00 --> Utf8 Class Initialized
DEBUG - 2012-04-08 05:57:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 05:57:00 --> URI Class Initialized
DEBUG - 2012-04-08 05:57:00 --> Router Class Initialized
DEBUG - 2012-04-08 05:57:00 --> Output Class Initialized
DEBUG - 2012-04-08 05:57:00 --> Security Class Initialized
DEBUG - 2012-04-08 05:57:00 --> Input Class Initialized
DEBUG - 2012-04-08 05:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 05:57:00 --> Language Class Initialized
DEBUG - 2012-04-08 05:57:01 --> Loader Class Initialized
DEBUG - 2012-04-08 05:57:01 --> Helper loaded: url_helper
DEBUG - 2012-04-08 05:57:01 --> Database Driver Class Initialized
DEBUG - 2012-04-08 05:57:01 --> Session Class Initialized
DEBUG - 2012-04-08 05:57:01 --> Helper loaded: string_helper
DEBUG - 2012-04-08 05:57:01 --> Session routines successfully run
DEBUG - 2012-04-08 05:57:01 --> Controller Class Initialized
DEBUG - 2012-04-08 05:57:01 --> Model Class Initialized
DEBUG - 2012-04-08 05:57:01 --> Model Class Initialized
DEBUG - 2012-04-08 05:57:01 --> Model Class Initialized
DEBUG - 2012-04-08 05:57:01 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 05:57:01 --> Final output sent to browser
DEBUG - 2012-04-08 05:57:01 --> Total execution time: 0.4893
DEBUG - 2012-04-08 06:08:34 --> Config Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:08:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:08:34 --> URI Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Router Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Output Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Security Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Input Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:08:34 --> Language Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Loader Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:08:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Session Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:08:34 --> Session routines successfully run
DEBUG - 2012-04-08 06:08:34 --> Controller Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Model Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Model Class Initialized
DEBUG - 2012-04-08 06:08:34 --> Model Class Initialized
ERROR - 2012-04-08 06:08:34 --> Severity: Notice  --> Undefined variable: username C:\xampp\htdocs\xcms\system\models\user.php 100
DEBUG - 2012-04-08 06:08:34 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:08:34 --> Final output sent to browser
DEBUG - 2012-04-08 06:08:34 --> Total execution time: 0.5637
DEBUG - 2012-04-08 06:08:54 --> Config Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:08:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:08:54 --> URI Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Router Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Output Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Security Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Input Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:08:54 --> Language Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Loader Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:08:54 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Session Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:08:54 --> Session routines successfully run
DEBUG - 2012-04-08 06:08:54 --> Controller Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Model Class Initialized
DEBUG - 2012-04-08 06:08:54 --> Model Class Initialized
DEBUG - 2012-04-08 06:08:54 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:08:54 --> Final output sent to browser
DEBUG - 2012-04-08 06:08:54 --> Total execution time: 0.3844
DEBUG - 2012-04-08 06:09:06 --> Config Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:09:06 --> URI Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Router Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Output Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Security Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Input Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:09:06 --> Language Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Loader Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:09:06 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Session Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:09:06 --> Session routines successfully run
DEBUG - 2012-04-08 06:09:06 --> Controller Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Model Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Model Class Initialized
DEBUG - 2012-04-08 06:09:06 --> Model Class Initialized
DEBUG - 2012-04-08 06:09:06 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:09:06 --> Final output sent to browser
DEBUG - 2012-04-08 06:09:06 --> Total execution time: 0.4647
DEBUG - 2012-04-08 06:10:00 --> Config Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:10:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:10:00 --> URI Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Router Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Output Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Security Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Input Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:10:00 --> Language Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Loader Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:10:00 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Session Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:10:00 --> Session routines successfully run
DEBUG - 2012-04-08 06:10:00 --> Controller Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Model Class Initialized
DEBUG - 2012-04-08 06:10:00 --> Model Class Initialized
DEBUG - 2012-04-08 06:10:00 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:10:00 --> Final output sent to browser
DEBUG - 2012-04-08 06:10:00 --> Total execution time: 0.3898
DEBUG - 2012-04-08 06:10:09 --> Config Class Initialized
DEBUG - 2012-04-08 06:10:09 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:10:09 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:10:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:10:09 --> URI Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Router Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Output Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Security Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Input Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:10:10 --> Language Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Loader Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:10:10 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Session Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:10:10 --> Session routines successfully run
DEBUG - 2012-04-08 06:10:10 --> Controller Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Model Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Model Class Initialized
DEBUG - 2012-04-08 06:10:10 --> Model Class Initialized
DEBUG - 2012-04-08 06:10:10 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:10:10 --> Final output sent to browser
DEBUG - 2012-04-08 06:10:10 --> Total execution time: 0.5266
DEBUG - 2012-04-08 06:11:51 --> Config Class Initialized
DEBUG - 2012-04-08 06:11:51 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:11:51 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:11:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:11:51 --> URI Class Initialized
DEBUG - 2012-04-08 06:11:51 --> Router Class Initialized
DEBUG - 2012-04-08 06:11:51 --> Output Class Initialized
DEBUG - 2012-04-08 06:11:51 --> Security Class Initialized
DEBUG - 2012-04-08 06:11:51 --> Input Class Initialized
DEBUG - 2012-04-08 06:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:11:51 --> Language Class Initialized
DEBUG - 2012-04-08 06:11:51 --> Loader Class Initialized
DEBUG - 2012-04-08 06:11:52 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:11:52 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:11:52 --> Session Class Initialized
DEBUG - 2012-04-08 06:11:52 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:11:52 --> Session routines successfully run
DEBUG - 2012-04-08 06:11:52 --> Controller Class Initialized
DEBUG - 2012-04-08 06:11:52 --> Model Class Initialized
DEBUG - 2012-04-08 06:11:52 --> Model Class Initialized
DEBUG - 2012-04-08 06:11:52 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:11:52 --> Final output sent to browser
DEBUG - 2012-04-08 06:11:52 --> Total execution time: 0.5446
DEBUG - 2012-04-08 06:12:02 --> Config Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:12:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:12:02 --> URI Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Router Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Output Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Security Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Input Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:12:02 --> Language Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Loader Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:12:02 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Session Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:12:02 --> Session routines successfully run
DEBUG - 2012-04-08 06:12:02 --> Controller Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Model Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Model Class Initialized
DEBUG - 2012-04-08 06:12:02 --> Model Class Initialized
DEBUG - 2012-04-08 06:12:02 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:12:02 --> Final output sent to browser
DEBUG - 2012-04-08 06:12:02 --> Total execution time: 0.4031
DEBUG - 2012-04-08 06:12:26 --> Config Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:12:26 --> URI Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Router Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Output Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Security Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Input Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:12:26 --> Language Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Loader Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:12:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Session Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:12:26 --> Session routines successfully run
DEBUG - 2012-04-08 06:12:26 --> Controller Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Model Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Model Class Initialized
DEBUG - 2012-04-08 06:12:26 --> Model Class Initialized
DEBUG - 2012-04-08 06:12:26 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:12:26 --> Final output sent to browser
DEBUG - 2012-04-08 06:12:26 --> Total execution time: 0.4240
DEBUG - 2012-04-08 06:13:36 --> Config Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:13:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:13:36 --> URI Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Router Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Output Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Security Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Input Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:13:36 --> Language Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Loader Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:13:36 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Session Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:13:36 --> Session routines successfully run
DEBUG - 2012-04-08 06:13:36 --> Controller Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Model Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Model Class Initialized
DEBUG - 2012-04-08 06:13:36 --> Model Class Initialized
DEBUG - 2012-04-08 06:13:36 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:13:36 --> Final output sent to browser
DEBUG - 2012-04-08 06:13:36 --> Total execution time: 0.4211
DEBUG - 2012-04-08 06:13:44 --> Config Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:13:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:13:44 --> URI Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Router Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Output Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Security Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Input Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:13:44 --> Language Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Loader Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:13:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Session Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:13:44 --> Session routines successfully run
DEBUG - 2012-04-08 06:13:44 --> Controller Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Model Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Model Class Initialized
DEBUG - 2012-04-08 06:13:44 --> Model Class Initialized
DEBUG - 2012-04-08 06:13:44 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:13:44 --> Final output sent to browser
DEBUG - 2012-04-08 06:13:44 --> Total execution time: 0.3920
DEBUG - 2012-04-08 06:14:13 --> Config Class Initialized
DEBUG - 2012-04-08 06:14:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:14:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:14:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:14:13 --> URI Class Initialized
DEBUG - 2012-04-08 06:14:13 --> Router Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Output Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Security Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Input Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:14:14 --> Language Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Loader Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:14:14 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Session Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:14:14 --> Session routines successfully run
DEBUG - 2012-04-08 06:14:14 --> Controller Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Model Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Model Class Initialized
DEBUG - 2012-04-08 06:14:14 --> Model Class Initialized
DEBUG - 2012-04-08 06:14:14 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:14:14 --> Final output sent to browser
DEBUG - 2012-04-08 06:14:14 --> Total execution time: 0.4708
DEBUG - 2012-04-08 06:14:36 --> Config Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:14:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:14:36 --> URI Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Router Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Output Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Security Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Input Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:14:36 --> Language Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Loader Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:14:36 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Session Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:14:36 --> Session routines successfully run
DEBUG - 2012-04-08 06:14:36 --> Controller Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Model Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Model Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Model Class Initialized
DEBUG - 2012-04-08 06:14:36 --> Final output sent to browser
DEBUG - 2012-04-08 06:14:36 --> Total execution time: 0.5565
DEBUG - 2012-04-08 06:15:17 --> Config Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:15:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:15:17 --> URI Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Router Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Output Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Security Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Input Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:15:17 --> Language Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Loader Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:15:17 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Session Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:15:17 --> Session routines successfully run
DEBUG - 2012-04-08 06:15:17 --> Controller Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Model Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Model Class Initialized
DEBUG - 2012-04-08 06:15:17 --> Model Class Initialized
DEBUG - 2012-04-08 06:15:17 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:15:17 --> Final output sent to browser
DEBUG - 2012-04-08 06:15:17 --> Total execution time: 0.5771
DEBUG - 2012-04-08 06:15:23 --> Config Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:15:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:15:23 --> URI Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Router Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Output Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Security Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Input Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:15:23 --> Language Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Loader Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:15:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Session Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:15:23 --> Session routines successfully run
DEBUG - 2012-04-08 06:15:23 --> Controller Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Model Class Initialized
DEBUG - 2012-04-08 06:15:23 --> Model Class Initialized
DEBUG - 2012-04-08 06:15:23 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:15:23 --> Final output sent to browser
DEBUG - 2012-04-08 06:15:23 --> Total execution time: 0.4443
DEBUG - 2012-04-08 06:15:29 --> Config Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:15:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:15:29 --> URI Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Router Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Output Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Security Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Input Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:15:29 --> Language Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Loader Class Initialized
DEBUG - 2012-04-08 06:15:29 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:15:30 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:15:30 --> Session Class Initialized
DEBUG - 2012-04-08 06:15:30 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:15:30 --> Session routines successfully run
DEBUG - 2012-04-08 06:15:30 --> Controller Class Initialized
DEBUG - 2012-04-08 06:15:30 --> Model Class Initialized
DEBUG - 2012-04-08 06:15:30 --> Model Class Initialized
DEBUG - 2012-04-08 06:15:30 --> Model Class Initialized
DEBUG - 2012-04-08 06:15:30 --> DB Transaction Failure
ERROR - 2012-04-08 06:15:30 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`sxccms`.`blocksetsinfo`, CONSTRAINT `blocksetsinfo_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `blocksinfo` (`BlockID`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-04-08 06:15:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-08 06:17:05 --> Config Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:17:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:17:05 --> URI Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Router Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Output Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Security Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Input Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:17:05 --> Language Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Loader Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:17:05 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Session Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:17:05 --> Session routines successfully run
DEBUG - 2012-04-08 06:17:05 --> Controller Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Model Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Model Class Initialized
DEBUG - 2012-04-08 06:17:05 --> Model Class Initialized
DEBUG - 2012-04-08 06:17:05 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 06:17:05 --> Final output sent to browser
DEBUG - 2012-04-08 06:17:05 --> Total execution time: 0.5054
DEBUG - 2012-04-08 06:21:51 --> Config Class Initialized
DEBUG - 2012-04-08 06:21:51 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:21:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:21:52 --> URI Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Router Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Output Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Security Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Input Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:21:52 --> Language Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Loader Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:21:52 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Session Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:21:52 --> Session routines successfully run
DEBUG - 2012-04-08 06:21:52 --> Controller Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Model Class Initialized
DEBUG - 2012-04-08 06:21:52 --> Model Class Initialized
DEBUG - 2012-04-08 06:21:52 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:21:52 --> Final output sent to browser
DEBUG - 2012-04-08 06:21:52 --> Total execution time: 0.5028
DEBUG - 2012-04-08 06:22:04 --> Config Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:22:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:22:04 --> URI Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Router Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Output Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Security Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Input Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:22:04 --> Language Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Loader Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:22:04 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Session Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:22:04 --> Session routines successfully run
DEBUG - 2012-04-08 06:22:04 --> Controller Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Model Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Model Class Initialized
DEBUG - 2012-04-08 06:22:04 --> Model Class Initialized
DEBUG - 2012-04-08 06:22:04 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:22:04 --> Final output sent to browser
DEBUG - 2012-04-08 06:22:04 --> Total execution time: 0.3921
DEBUG - 2012-04-08 06:23:21 --> Config Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:23:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:23:21 --> URI Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Router Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Output Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Security Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Input Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:23:21 --> Language Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Loader Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:23:21 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Session Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:23:21 --> Session routines successfully run
DEBUG - 2012-04-08 06:23:21 --> Controller Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Model Class Initialized
DEBUG - 2012-04-08 06:23:21 --> Model Class Initialized
DEBUG - 2012-04-08 06:23:21 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:23:21 --> Final output sent to browser
DEBUG - 2012-04-08 06:23:21 --> Total execution time: 0.5086
DEBUG - 2012-04-08 06:23:40 --> Config Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:23:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:23:40 --> URI Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Router Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Output Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Security Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Input Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:23:40 --> Language Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Loader Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:23:40 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Session Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:23:40 --> Session routines successfully run
DEBUG - 2012-04-08 06:23:40 --> Controller Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Model Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Model Class Initialized
DEBUG - 2012-04-08 06:23:40 --> Model Class Initialized
DEBUG - 2012-04-08 06:23:40 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:23:40 --> Final output sent to browser
DEBUG - 2012-04-08 06:23:40 --> Total execution time: 0.4003
DEBUG - 2012-04-08 06:24:09 --> Config Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:24:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:24:09 --> URI Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Router Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Output Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Security Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Input Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:24:09 --> Language Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Loader Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:24:09 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Session Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:24:09 --> Session routines successfully run
DEBUG - 2012-04-08 06:24:09 --> Controller Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:09 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:09 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:24:09 --> Final output sent to browser
DEBUG - 2012-04-08 06:24:09 --> Total execution time: 0.3421
DEBUG - 2012-04-08 06:24:15 --> Config Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:24:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:24:15 --> URI Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Router Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Output Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Security Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Input Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:24:15 --> Language Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Loader Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:24:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Session Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:24:15 --> Session routines successfully run
DEBUG - 2012-04-08 06:24:15 --> Controller Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:15 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:15 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:24:15 --> Final output sent to browser
DEBUG - 2012-04-08 06:24:15 --> Total execution time: 0.7476
DEBUG - 2012-04-08 06:24:25 --> Config Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:24:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:24:25 --> URI Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Router Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Output Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Security Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Input Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:24:25 --> Language Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Loader Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:24:25 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Session Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:24:25 --> Session routines successfully run
DEBUG - 2012-04-08 06:24:25 --> Controller Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:25 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:25 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:24:25 --> Final output sent to browser
DEBUG - 2012-04-08 06:24:25 --> Total execution time: 0.3982
DEBUG - 2012-04-08 06:24:42 --> Config Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:24:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:24:42 --> URI Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Router Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Output Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Security Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Input Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:24:42 --> Language Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Loader Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:24:42 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Session Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:24:42 --> Session routines successfully run
DEBUG - 2012-04-08 06:24:42 --> Controller Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:42 --> Model Class Initialized
DEBUG - 2012-04-08 06:24:42 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:24:42 --> Final output sent to browser
DEBUG - 2012-04-08 06:24:42 --> Total execution time: 0.3849
DEBUG - 2012-04-08 06:26:23 --> Config Class Initialized
DEBUG - 2012-04-08 06:26:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:26:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:26:24 --> URI Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Router Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Output Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Security Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Input Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:26:24 --> Language Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Loader Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:26:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Session Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:26:24 --> Session routines successfully run
DEBUG - 2012-04-08 06:26:24 --> Controller Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Model Class Initialized
DEBUG - 2012-04-08 06:26:24 --> Model Class Initialized
DEBUG - 2012-04-08 06:26:24 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:26:24 --> Final output sent to browser
DEBUG - 2012-04-08 06:26:24 --> Total execution time: 0.3110
DEBUG - 2012-04-08 06:26:32 --> Config Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:26:32 --> URI Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Router Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Output Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Security Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Input Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:26:32 --> Language Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Loader Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:26:32 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Session Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:26:32 --> Session routines successfully run
DEBUG - 2012-04-08 06:26:32 --> Controller Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Model Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Model Class Initialized
DEBUG - 2012-04-08 06:26:32 --> Model Class Initialized
DEBUG - 2012-04-08 06:26:32 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:26:32 --> Final output sent to browser
DEBUG - 2012-04-08 06:26:32 --> Total execution time: 0.3936
DEBUG - 2012-04-08 06:27:15 --> Config Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:27:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:27:15 --> URI Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Router Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Output Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Security Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Input Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:27:15 --> Language Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Loader Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:27:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Session Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:27:15 --> Session routines successfully run
DEBUG - 2012-04-08 06:27:15 --> Controller Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Model Class Initialized
DEBUG - 2012-04-08 06:27:15 --> Model Class Initialized
DEBUG - 2012-04-08 06:27:15 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:27:15 --> Final output sent to browser
DEBUG - 2012-04-08 06:27:15 --> Total execution time: 0.3075
DEBUG - 2012-04-08 06:27:21 --> Config Class Initialized
DEBUG - 2012-04-08 06:27:21 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:27:21 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:27:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:27:21 --> URI Class Initialized
DEBUG - 2012-04-08 06:27:21 --> Router Class Initialized
DEBUG - 2012-04-08 06:27:21 --> Output Class Initialized
DEBUG - 2012-04-08 06:27:21 --> Security Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Input Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:27:22 --> Language Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Loader Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:27:22 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Session Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:27:22 --> Session routines successfully run
DEBUG - 2012-04-08 06:27:22 --> Controller Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Model Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Model Class Initialized
DEBUG - 2012-04-08 06:27:22 --> Model Class Initialized
DEBUG - 2012-04-08 06:27:22 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:27:22 --> Final output sent to browser
DEBUG - 2012-04-08 06:27:22 --> Total execution time: 0.3383
DEBUG - 2012-04-08 06:27:26 --> Config Class Initialized
DEBUG - 2012-04-08 06:27:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:27:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:27:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:27:26 --> URI Class Initialized
DEBUG - 2012-04-08 06:27:26 --> Router Class Initialized
DEBUG - 2012-04-08 06:27:26 --> Output Class Initialized
DEBUG - 2012-04-08 06:27:26 --> Security Class Initialized
DEBUG - 2012-04-08 06:27:26 --> Input Class Initialized
DEBUG - 2012-04-08 06:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:27:27 --> Language Class Initialized
DEBUG - 2012-04-08 06:27:27 --> Loader Class Initialized
DEBUG - 2012-04-08 06:27:27 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:27:27 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:27:27 --> Session Class Initialized
DEBUG - 2012-04-08 06:27:27 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:27:27 --> Session routines successfully run
DEBUG - 2012-04-08 06:27:27 --> Controller Class Initialized
DEBUG - 2012-04-08 06:27:27 --> Model Class Initialized
DEBUG - 2012-04-08 06:27:27 --> Model Class Initialized
DEBUG - 2012-04-08 06:27:27 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:27:27 --> Final output sent to browser
DEBUG - 2012-04-08 06:27:27 --> Total execution time: 0.3097
DEBUG - 2012-04-08 06:32:33 --> Config Class Initialized
DEBUG - 2012-04-08 06:32:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:32:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:32:33 --> URI Class Initialized
DEBUG - 2012-04-08 06:32:33 --> Router Class Initialized
DEBUG - 2012-04-08 06:32:33 --> Output Class Initialized
DEBUG - 2012-04-08 06:32:33 --> Security Class Initialized
DEBUG - 2012-04-08 06:32:33 --> Input Class Initialized
DEBUG - 2012-04-08 06:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:32:33 --> Language Class Initialized
DEBUG - 2012-04-08 06:32:34 --> Loader Class Initialized
DEBUG - 2012-04-08 06:32:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:32:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:32:34 --> Session Class Initialized
DEBUG - 2012-04-08 06:32:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:32:34 --> Session routines successfully run
DEBUG - 2012-04-08 06:32:34 --> Controller Class Initialized
DEBUG - 2012-04-08 06:32:34 --> Model Class Initialized
DEBUG - 2012-04-08 06:32:34 --> Model Class Initialized
DEBUG - 2012-04-08 06:32:34 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:32:34 --> Final output sent to browser
DEBUG - 2012-04-08 06:32:34 --> Total execution time: 0.3531
DEBUG - 2012-04-08 06:32:41 --> Config Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:32:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:32:41 --> URI Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Router Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Output Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Security Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Input Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:32:41 --> Language Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Loader Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:32:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Session Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:32:41 --> Session routines successfully run
DEBUG - 2012-04-08 06:32:41 --> Controller Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Model Class Initialized
DEBUG - 2012-04-08 06:32:41 --> Model Class Initialized
DEBUG - 2012-04-08 06:32:42 --> Model Class Initialized
DEBUG - 2012-04-08 06:32:42 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:32:42 --> Final output sent to browser
DEBUG - 2012-04-08 06:32:42 --> Total execution time: 0.3832
DEBUG - 2012-04-08 06:32:48 --> Config Class Initialized
DEBUG - 2012-04-08 06:32:48 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:32:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:32:49 --> URI Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Router Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Output Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Security Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Input Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:32:49 --> Language Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Loader Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:32:49 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Session Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:32:49 --> Session routines successfully run
DEBUG - 2012-04-08 06:32:49 --> Controller Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Model Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Model Class Initialized
DEBUG - 2012-04-08 06:32:49 --> Model Class Initialized
DEBUG - 2012-04-08 06:32:49 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 06:32:49 --> Final output sent to browser
DEBUG - 2012-04-08 06:32:49 --> Total execution time: 0.4216
DEBUG - 2012-04-08 06:33:25 --> Config Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:33:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:33:25 --> URI Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Router Class Initialized
DEBUG - 2012-04-08 06:33:25 --> No URI present. Default controller set.
DEBUG - 2012-04-08 06:33:25 --> Output Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Security Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Input Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:33:25 --> Language Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Loader Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:33:25 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Session Class Initialized
DEBUG - 2012-04-08 06:33:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:33:25 --> Session routines successfully run
DEBUG - 2012-04-08 06:33:25 --> Controller Class Initialized
DEBUG - 2012-04-08 06:33:26 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 06:33:26 --> Final output sent to browser
DEBUG - 2012-04-08 06:33:26 --> Total execution time: 0.2955
DEBUG - 2012-04-08 06:33:27 --> Config Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:33:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:33:27 --> URI Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Router Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Output Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Security Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Input Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:33:27 --> Language Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Loader Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:33:27 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Session Class Initialized
DEBUG - 2012-04-08 06:33:27 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:33:27 --> Session routines successfully run
DEBUG - 2012-04-08 06:33:27 --> Controller Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Config Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:33:28 --> URI Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Router Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Output Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Security Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Input Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:33:28 --> Language Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Loader Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:33:28 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Session Class Initialized
DEBUG - 2012-04-08 06:33:28 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:33:28 --> A session cookie was not found.
DEBUG - 2012-04-08 06:33:28 --> Session routines successfully run
DEBUG - 2012-04-08 06:33:28 --> Controller Class Initialized
DEBUG - 2012-04-08 06:33:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 06:33:28 --> Final output sent to browser
DEBUG - 2012-04-08 06:33:28 --> Total execution time: 0.3953
DEBUG - 2012-04-08 06:33:47 --> Config Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:33:47 --> URI Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Router Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Output Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Security Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Input Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:33:47 --> Language Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Loader Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:33:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Session Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:33:47 --> Session routines successfully run
DEBUG - 2012-04-08 06:33:47 --> Controller Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Model Class Initialized
DEBUG - 2012-04-08 06:33:47 --> Model Class Initialized
DEBUG - 2012-04-08 06:33:47 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 06:33:47 --> Final output sent to browser
DEBUG - 2012-04-08 06:33:47 --> Total execution time: 0.3488
DEBUG - 2012-04-08 06:34:32 --> Config Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:34:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:34:32 --> URI Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Router Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Output Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Security Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Input Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:34:32 --> Language Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Loader Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:34:32 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Session Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:34:32 --> Session routines successfully run
DEBUG - 2012-04-08 06:34:32 --> Controller Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Model Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Model Class Initialized
DEBUG - 2012-04-08 06:34:32 --> Helper loaded: email_helper
DEBUG - 2012-04-08 06:34:32 --> Model Class Initialized
DEBUG - 2012-04-08 06:34:32 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 06:34:32 --> Final output sent to browser
DEBUG - 2012-04-08 06:34:32 --> Total execution time: 0.3972
DEBUG - 2012-04-08 06:39:48 --> Config Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:39:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:39:48 --> URI Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Router Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Output Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Security Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Input Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:39:48 --> Language Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Loader Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:39:48 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Session Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:39:48 --> Session routines successfully run
DEBUG - 2012-04-08 06:39:48 --> Controller Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Model Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Model Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Config Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:39:48 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:39:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:39:49 --> URI Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Router Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Output Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Security Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Input Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:39:49 --> Language Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Loader Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:39:49 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Session Class Initialized
DEBUG - 2012-04-08 06:39:49 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:39:49 --> Session routines successfully run
DEBUG - 2012-04-08 06:39:49 --> Controller Class Initialized
DEBUG - 2012-04-08 06:39:49 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 06:39:49 --> Final output sent to browser
DEBUG - 2012-04-08 06:39:49 --> Total execution time: 0.2399
DEBUG - 2012-04-08 06:39:50 --> Config Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:39:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:39:50 --> URI Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Router Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Output Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Security Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Input Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:39:50 --> Language Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Loader Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:39:50 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Session Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:39:50 --> Session routines successfully run
DEBUG - 2012-04-08 06:39:50 --> Controller Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Model Class Initialized
DEBUG - 2012-04-08 06:39:50 --> Model Class Initialized
DEBUG - 2012-04-08 06:39:51 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:39:51 --> Final output sent to browser
DEBUG - 2012-04-08 06:39:51 --> Total execution time: 0.5421
DEBUG - 2012-04-08 06:40:03 --> Config Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:40:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:40:03 --> URI Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Router Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Output Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Security Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Input Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:40:03 --> Language Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Loader Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:40:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Session Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:40:03 --> Session routines successfully run
DEBUG - 2012-04-08 06:40:03 --> Controller Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:03 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:03 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 06:40:03 --> Final output sent to browser
DEBUG - 2012-04-08 06:40:03 --> Total execution time: 0.4688
DEBUG - 2012-04-08 06:40:05 --> Config Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:40:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:40:05 --> URI Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Router Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Output Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Security Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Input Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:40:05 --> Language Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Loader Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:40:05 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Session Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:40:05 --> Session routines successfully run
DEBUG - 2012-04-08 06:40:05 --> Controller Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:05 --> Final output sent to browser
DEBUG - 2012-04-08 06:40:05 --> Total execution time: 0.4434
DEBUG - 2012-04-08 06:40:26 --> Config Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:40:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:40:26 --> URI Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Router Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Output Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Security Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Input Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:40:26 --> Language Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Loader Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:40:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Session Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:40:26 --> Session routines successfully run
DEBUG - 2012-04-08 06:40:26 --> Controller Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:26 --> Final output sent to browser
DEBUG - 2012-04-08 06:40:26 --> Total execution time: 0.5339
DEBUG - 2012-04-08 06:40:35 --> Config Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:40:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:40:35 --> URI Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Router Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Output Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Security Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Input Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:40:35 --> Language Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Loader Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:40:35 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Session Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:40:35 --> Session routines successfully run
DEBUG - 2012-04-08 06:40:35 --> Controller Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:35 --> Final output sent to browser
DEBUG - 2012-04-08 06:40:35 --> Total execution time: 0.6948
DEBUG - 2012-04-08 06:40:41 --> Config Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:40:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:40:41 --> URI Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Router Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Output Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Security Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Input Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:40:41 --> Language Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Loader Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:40:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Session Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:40:41 --> Session routines successfully run
DEBUG - 2012-04-08 06:40:41 --> Controller Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:41 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:41 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 06:40:41 --> Final output sent to browser
DEBUG - 2012-04-08 06:40:41 --> Total execution time: 0.3769
DEBUG - 2012-04-08 06:40:43 --> Config Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:40:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:40:43 --> URI Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Router Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Output Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Security Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Input Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:40:43 --> Language Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Loader Class Initialized
DEBUG - 2012-04-08 06:40:43 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:40:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:40:44 --> Session Class Initialized
DEBUG - 2012-04-08 06:40:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:40:44 --> Session routines successfully run
DEBUG - 2012-04-08 06:40:44 --> Controller Class Initialized
DEBUG - 2012-04-08 06:40:44 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:44 --> Model Class Initialized
DEBUG - 2012-04-08 06:40:44 --> Final output sent to browser
DEBUG - 2012-04-08 06:40:44 --> Total execution time: 0.4469
DEBUG - 2012-04-08 06:46:10 --> Config Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:46:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:46:10 --> URI Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Router Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Output Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Security Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Input Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:46:10 --> Language Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Loader Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:46:10 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Session Class Initialized
DEBUG - 2012-04-08 06:46:10 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:46:11 --> Session routines successfully run
DEBUG - 2012-04-08 06:46:11 --> Controller Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Config Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:46:11 --> URI Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Router Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Output Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Security Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Input Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:46:11 --> Language Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Loader Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:46:11 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Session Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:46:11 --> Session routines successfully run
DEBUG - 2012-04-08 06:46:11 --> Controller Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:11 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:11 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:46:11 --> Final output sent to browser
DEBUG - 2012-04-08 06:46:11 --> Total execution time: 0.3687
DEBUG - 2012-04-08 06:46:14 --> Config Class Initialized
DEBUG - 2012-04-08 06:46:14 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:46:14 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:46:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:46:14 --> URI Class Initialized
DEBUG - 2012-04-08 06:46:14 --> Router Class Initialized
DEBUG - 2012-04-08 06:46:14 --> Output Class Initialized
DEBUG - 2012-04-08 06:46:14 --> Security Class Initialized
DEBUG - 2012-04-08 06:46:14 --> Input Class Initialized
DEBUG - 2012-04-08 06:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:46:15 --> Language Class Initialized
DEBUG - 2012-04-08 06:46:15 --> Loader Class Initialized
DEBUG - 2012-04-08 06:46:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:46:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:46:15 --> Session Class Initialized
DEBUG - 2012-04-08 06:46:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:46:15 --> Session routines successfully run
DEBUG - 2012-04-08 06:46:15 --> Controller Class Initialized
DEBUG - 2012-04-08 06:46:15 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:15 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:15 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:46:15 --> Final output sent to browser
DEBUG - 2012-04-08 06:46:15 --> Total execution time: 0.2826
DEBUG - 2012-04-08 06:46:23 --> Config Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:46:23 --> URI Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Router Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Output Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Security Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Input Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:46:23 --> Language Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Loader Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:46:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Session Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:46:23 --> Session routines successfully run
DEBUG - 2012-04-08 06:46:23 --> Controller Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:23 --> Final output sent to browser
DEBUG - 2012-04-08 06:46:23 --> Total execution time: 0.4747
DEBUG - 2012-04-08 06:46:26 --> Config Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:46:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:46:26 --> URI Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Router Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Output Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Security Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Input Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:46:26 --> Language Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Loader Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:46:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Session Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:46:26 --> Session routines successfully run
DEBUG - 2012-04-08 06:46:26 --> Controller Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:26 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:26 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:46:26 --> Final output sent to browser
DEBUG - 2012-04-08 06:46:26 --> Total execution time: 0.3976
DEBUG - 2012-04-08 06:46:35 --> Config Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:46:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:46:35 --> URI Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Router Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Output Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Security Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Input Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:46:35 --> Language Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Loader Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:46:35 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Session Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:46:35 --> Session routines successfully run
DEBUG - 2012-04-08 06:46:35 --> Controller Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:35 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:35 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 06:46:35 --> Final output sent to browser
DEBUG - 2012-04-08 06:46:35 --> Total execution time: 0.3900
DEBUG - 2012-04-08 06:46:38 --> Config Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:46:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:46:38 --> URI Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Router Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Output Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Security Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Input Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:46:38 --> Language Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Loader Class Initialized
DEBUG - 2012-04-08 06:46:38 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:46:38 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:46:39 --> Session Class Initialized
DEBUG - 2012-04-08 06:46:39 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:46:39 --> Session routines successfully run
DEBUG - 2012-04-08 06:46:39 --> Controller Class Initialized
DEBUG - 2012-04-08 06:46:39 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:39 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:39 --> Final output sent to browser
DEBUG - 2012-04-08 06:46:39 --> Total execution time: 0.3535
DEBUG - 2012-04-08 06:46:45 --> Config Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Hooks Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Utf8 Class Initialized
DEBUG - 2012-04-08 06:46:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 06:46:45 --> URI Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Router Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Output Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Security Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Input Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 06:46:45 --> Language Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Loader Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 06:46:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Session Class Initialized
DEBUG - 2012-04-08 06:46:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 06:46:45 --> Session routines successfully run
DEBUG - 2012-04-08 06:46:45 --> Controller Class Initialized
DEBUG - 2012-04-08 06:46:46 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:46 --> Model Class Initialized
DEBUG - 2012-04-08 06:46:46 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 06:46:46 --> Final output sent to browser
DEBUG - 2012-04-08 06:46:46 --> Total execution time: 0.3184
DEBUG - 2012-04-08 07:36:34 --> Config Class Initialized
DEBUG - 2012-04-08 07:36:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:36:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:36:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:36:34 --> URI Class Initialized
DEBUG - 2012-04-08 07:36:34 --> Router Class Initialized
DEBUG - 2012-04-08 07:36:34 --> No URI present. Default controller set.
DEBUG - 2012-04-08 07:36:34 --> Output Class Initialized
DEBUG - 2012-04-08 07:36:35 --> Security Class Initialized
DEBUG - 2012-04-08 07:36:35 --> Input Class Initialized
DEBUG - 2012-04-08 07:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:36:35 --> Language Class Initialized
DEBUG - 2012-04-08 07:36:35 --> Loader Class Initialized
DEBUG - 2012-04-08 07:36:35 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:36:35 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:36:36 --> Session Class Initialized
DEBUG - 2012-04-08 07:36:37 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:36:37 --> Session routines successfully run
DEBUG - 2012-04-08 07:36:37 --> Controller Class Initialized
DEBUG - 2012-04-08 07:36:37 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 07:36:37 --> Final output sent to browser
DEBUG - 2012-04-08 07:36:37 --> Total execution time: 3.3712
DEBUG - 2012-04-08 07:36:44 --> Config Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:36:44 --> URI Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Router Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Output Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Security Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Input Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:36:44 --> Language Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Loader Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:36:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Session Class Initialized
DEBUG - 2012-04-08 07:36:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:36:44 --> Session routines successfully run
DEBUG - 2012-04-08 07:36:44 --> Controller Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Config Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:36:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:36:45 --> URI Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Router Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Output Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Security Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Input Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:36:45 --> Language Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Loader Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:36:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Session Class Initialized
DEBUG - 2012-04-08 07:36:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:36:45 --> A session cookie was not found.
DEBUG - 2012-04-08 07:36:45 --> Session routines successfully run
DEBUG - 2012-04-08 07:36:45 --> Controller Class Initialized
DEBUG - 2012-04-08 07:36:45 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:36:45 --> Final output sent to browser
DEBUG - 2012-04-08 07:36:45 --> Total execution time: 0.3484
DEBUG - 2012-04-08 07:36:52 --> Config Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:36:52 --> URI Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Router Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Output Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Security Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Input Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:36:52 --> Language Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Loader Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:36:52 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Session Class Initialized
DEBUG - 2012-04-08 07:36:52 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:36:52 --> Session routines successfully run
DEBUG - 2012-04-08 07:36:52 --> Controller Class Initialized
DEBUG - 2012-04-08 07:36:52 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:36:52 --> Final output sent to browser
DEBUG - 2012-04-08 07:36:52 --> Total execution time: 0.4532
DEBUG - 2012-04-08 07:37:08 --> Config Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:37:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:37:08 --> URI Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Router Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Output Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Security Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Input Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:37:08 --> Language Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Loader Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:37:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Session Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:37:08 --> Session routines successfully run
DEBUG - 2012-04-08 07:37:08 --> Controller Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Model Class Initialized
DEBUG - 2012-04-08 07:37:08 --> Model Class Initialized
DEBUG - 2012-04-08 07:37:09 --> Config Class Initialized
DEBUG - 2012-04-08 07:37:09 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:37:09 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:37:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:37:09 --> URI Class Initialized
DEBUG - 2012-04-08 07:37:09 --> Router Class Initialized
DEBUG - 2012-04-08 07:37:10 --> Output Class Initialized
DEBUG - 2012-04-08 07:37:10 --> Security Class Initialized
DEBUG - 2012-04-08 07:37:10 --> Input Class Initialized
DEBUG - 2012-04-08 07:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:37:10 --> Language Class Initialized
DEBUG - 2012-04-08 07:37:10 --> Loader Class Initialized
DEBUG - 2012-04-08 07:37:10 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:37:10 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:37:10 --> Session Class Initialized
DEBUG - 2012-04-08 07:37:10 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:37:10 --> Session routines successfully run
DEBUG - 2012-04-08 07:37:10 --> Controller Class Initialized
DEBUG - 2012-04-08 07:37:10 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 07:37:10 --> Final output sent to browser
DEBUG - 2012-04-08 07:37:10 --> Total execution time: 0.4247
DEBUG - 2012-04-08 07:37:20 --> Config Class Initialized
DEBUG - 2012-04-08 07:37:20 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:37:20 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:37:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:37:20 --> URI Class Initialized
DEBUG - 2012-04-08 07:37:20 --> Router Class Initialized
DEBUG - 2012-04-08 07:37:20 --> Output Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Security Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Input Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:37:21 --> Language Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Loader Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:37:21 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Session Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:37:21 --> Session routines successfully run
DEBUG - 2012-04-08 07:37:21 --> Controller Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Model Class Initialized
DEBUG - 2012-04-08 07:37:21 --> Model Class Initialized
DEBUG - 2012-04-08 07:37:21 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 07:37:21 --> Final output sent to browser
DEBUG - 2012-04-08 07:37:21 --> Total execution time: 0.4933
DEBUG - 2012-04-08 07:38:24 --> Config Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:38:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:38:24 --> URI Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Router Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Output Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Security Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Input Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:38:24 --> Language Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Loader Class Initialized
DEBUG - 2012-04-08 07:38:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:38:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:38:25 --> Session Class Initialized
DEBUG - 2012-04-08 07:38:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:38:25 --> Session routines successfully run
DEBUG - 2012-04-08 07:38:25 --> Controller Class Initialized
DEBUG - 2012-04-08 07:38:25 --> Model Class Initialized
DEBUG - 2012-04-08 07:38:25 --> Model Class Initialized
DEBUG - 2012-04-08 07:38:25 --> Model Class Initialized
DEBUG - 2012-04-08 07:38:26 --> Final output sent to browser
DEBUG - 2012-04-08 07:38:26 --> Total execution time: 1.7991
DEBUG - 2012-04-08 07:39:37 --> Config Class Initialized
DEBUG - 2012-04-08 07:39:37 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:39:37 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:39:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:39:37 --> URI Class Initialized
DEBUG - 2012-04-08 07:39:37 --> Router Class Initialized
DEBUG - 2012-04-08 07:39:37 --> No URI present. Default controller set.
DEBUG - 2012-04-08 07:39:37 --> Output Class Initialized
DEBUG - 2012-04-08 07:39:37 --> Security Class Initialized
DEBUG - 2012-04-08 07:39:37 --> Input Class Initialized
DEBUG - 2012-04-08 07:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:39:37 --> Language Class Initialized
DEBUG - 2012-04-08 07:39:38 --> Loader Class Initialized
DEBUG - 2012-04-08 07:39:38 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:39:38 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:39:38 --> Session Class Initialized
DEBUG - 2012-04-08 07:39:39 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:39:39 --> A session cookie was not found.
DEBUG - 2012-04-08 07:39:39 --> Session routines successfully run
DEBUG - 2012-04-08 07:39:39 --> Controller Class Initialized
DEBUG - 2012-04-08 07:39:39 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:39:39 --> Final output sent to browser
DEBUG - 2012-04-08 07:39:39 --> Total execution time: 2.2837
DEBUG - 2012-04-08 07:39:48 --> Config Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:39:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:39:48 --> URI Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Router Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Output Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Security Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Input Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:39:48 --> Language Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Loader Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:39:48 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Session Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:39:48 --> Session routines successfully run
DEBUG - 2012-04-08 07:39:48 --> Controller Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Model Class Initialized
DEBUG - 2012-04-08 07:39:48 --> Model Class Initialized
DEBUG - 2012-04-08 07:39:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:39:48 --> Final output sent to browser
DEBUG - 2012-04-08 07:39:48 --> Total execution time: 0.6260
DEBUG - 2012-04-08 07:40:51 --> Config Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:40:51 --> URI Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Router Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Output Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Security Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Input Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:40:51 --> Language Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Loader Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:40:51 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Session Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:40:51 --> Session routines successfully run
DEBUG - 2012-04-08 07:40:51 --> Controller Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Model Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Model Class Initialized
DEBUG - 2012-04-08 07:40:51 --> Helper loaded: email_helper
DEBUG - 2012-04-08 07:40:51 --> Model Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Config Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:40:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:40:52 --> URI Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Router Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Output Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Security Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Input Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:40:52 --> Language Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Loader Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:40:52 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Session Class Initialized
DEBUG - 2012-04-08 07:40:52 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:40:52 --> Session routines successfully run
DEBUG - 2012-04-08 07:40:52 --> Controller Class Initialized
DEBUG - 2012-04-08 07:40:52 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 07:40:52 --> Final output sent to browser
DEBUG - 2012-04-08 07:40:52 --> Total execution time: 0.2794
DEBUG - 2012-04-08 07:40:56 --> Config Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:40:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:40:56 --> URI Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Router Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Output Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Security Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Input Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:40:56 --> Language Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Loader Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:40:56 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Session Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:40:56 --> Session routines successfully run
DEBUG - 2012-04-08 07:40:56 --> Controller Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Config Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:40:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:40:56 --> URI Class Initialized
DEBUG - 2012-04-08 07:40:56 --> Router Class Initialized
DEBUG - 2012-04-08 07:40:57 --> Output Class Initialized
DEBUG - 2012-04-08 07:40:57 --> Security Class Initialized
DEBUG - 2012-04-08 07:40:57 --> Input Class Initialized
DEBUG - 2012-04-08 07:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:40:57 --> Language Class Initialized
DEBUG - 2012-04-08 07:40:57 --> Loader Class Initialized
DEBUG - 2012-04-08 07:40:57 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:40:57 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:40:57 --> Session Class Initialized
DEBUG - 2012-04-08 07:40:57 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:40:57 --> A session cookie was not found.
DEBUG - 2012-04-08 07:40:57 --> Session routines successfully run
DEBUG - 2012-04-08 07:40:57 --> Controller Class Initialized
DEBUG - 2012-04-08 07:40:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:40:57 --> Final output sent to browser
DEBUG - 2012-04-08 07:40:57 --> Total execution time: 0.4110
DEBUG - 2012-04-08 07:40:59 --> Config Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:40:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:40:59 --> URI Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Router Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Output Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Security Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Input Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:40:59 --> Language Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Loader Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:40:59 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Session Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:40:59 --> Session routines successfully run
DEBUG - 2012-04-08 07:40:59 --> Controller Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Model Class Initialized
DEBUG - 2012-04-08 07:40:59 --> Model Class Initialized
DEBUG - 2012-04-08 07:40:59 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:40:59 --> Final output sent to browser
DEBUG - 2012-04-08 07:40:59 --> Total execution time: 0.3806
DEBUG - 2012-04-08 07:41:48 --> Config Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:41:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:41:48 --> URI Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Router Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Output Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Security Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Input Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:41:48 --> Language Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Loader Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:41:48 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Session Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:41:48 --> Session routines successfully run
DEBUG - 2012-04-08 07:41:48 --> Controller Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Model Class Initialized
DEBUG - 2012-04-08 07:41:48 --> Model Class Initialized
DEBUG - 2012-04-08 07:41:49 --> Helper loaded: email_helper
DEBUG - 2012-04-08 07:41:49 --> Model Class Initialized
DEBUG - 2012-04-08 07:41:49 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:41:49 --> Final output sent to browser
DEBUG - 2012-04-08 07:41:49 --> Total execution time: 0.4143
DEBUG - 2012-04-08 07:42:08 --> Config Class Initialized
DEBUG - 2012-04-08 07:42:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:42:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:42:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:42:08 --> URI Class Initialized
DEBUG - 2012-04-08 07:42:08 --> Router Class Initialized
DEBUG - 2012-04-08 07:42:08 --> Output Class Initialized
DEBUG - 2012-04-08 07:42:08 --> Security Class Initialized
DEBUG - 2012-04-08 07:42:08 --> Input Class Initialized
DEBUG - 2012-04-08 07:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:42:08 --> Language Class Initialized
DEBUG - 2012-04-08 07:42:08 --> Loader Class Initialized
DEBUG - 2012-04-08 07:42:09 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:42:09 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:42:09 --> Session Class Initialized
DEBUG - 2012-04-08 07:42:09 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:42:09 --> Session routines successfully run
DEBUG - 2012-04-08 07:42:09 --> Controller Class Initialized
DEBUG - 2012-04-08 07:42:09 --> Model Class Initialized
DEBUG - 2012-04-08 07:42:09 --> Model Class Initialized
DEBUG - 2012-04-08 07:42:09 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:42:09 --> Final output sent to browser
DEBUG - 2012-04-08 07:42:09 --> Total execution time: 0.3887
DEBUG - 2012-04-08 07:42:24 --> Config Class Initialized
DEBUG - 2012-04-08 07:42:24 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:42:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:42:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:42:24 --> URI Class Initialized
DEBUG - 2012-04-08 07:42:24 --> Router Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Output Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Security Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Input Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:42:25 --> Language Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Loader Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:42:25 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Session Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:42:25 --> Session routines successfully run
DEBUG - 2012-04-08 07:42:25 --> Controller Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Model Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Model Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Helper loaded: email_helper
DEBUG - 2012-04-08 07:42:25 --> Model Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Config Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:42:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:42:25 --> URI Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Router Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Output Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Security Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Input Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:42:25 --> Language Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Loader Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:42:25 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Session Class Initialized
DEBUG - 2012-04-08 07:42:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:42:25 --> Session routines successfully run
DEBUG - 2012-04-08 07:42:25 --> Controller Class Initialized
DEBUG - 2012-04-08 07:42:25 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 07:42:25 --> Final output sent to browser
DEBUG - 2012-04-08 07:42:25 --> Total execution time: 0.2860
DEBUG - 2012-04-08 07:42:28 --> Config Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:42:28 --> URI Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Router Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Output Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Security Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Input Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:42:28 --> Language Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Loader Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:42:28 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Session Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:42:28 --> Session routines successfully run
DEBUG - 2012-04-08 07:42:28 --> Controller Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Config Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:42:28 --> URI Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Router Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Output Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Security Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Input Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:42:28 --> Language Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Loader Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:42:28 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Session Class Initialized
DEBUG - 2012-04-08 07:42:28 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:42:28 --> A session cookie was not found.
DEBUG - 2012-04-08 07:42:28 --> Session routines successfully run
DEBUG - 2012-04-08 07:42:28 --> Controller Class Initialized
DEBUG - 2012-04-08 07:42:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:42:28 --> Final output sent to browser
DEBUG - 2012-04-08 07:42:28 --> Total execution time: 0.2962
DEBUG - 2012-04-08 07:42:32 --> Config Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:42:32 --> URI Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Router Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Output Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Security Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Input Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:42:32 --> Language Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Loader Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:42:32 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Session Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:42:32 --> Session routines successfully run
DEBUG - 2012-04-08 07:42:32 --> Controller Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Model Class Initialized
DEBUG - 2012-04-08 07:42:32 --> Model Class Initialized
DEBUG - 2012-04-08 07:42:32 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:42:32 --> Final output sent to browser
DEBUG - 2012-04-08 07:42:32 --> Total execution time: 0.4424
DEBUG - 2012-04-08 07:43:11 --> Config Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:43:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:43:11 --> URI Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Router Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Output Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Security Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Input Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:43:11 --> Language Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Loader Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:43:11 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Session Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:43:11 --> Session routines successfully run
DEBUG - 2012-04-08 07:43:11 --> Controller Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Model Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Model Class Initialized
DEBUG - 2012-04-08 07:43:11 --> Helper loaded: email_helper
DEBUG - 2012-04-08 07:43:11 --> Model Class Initialized
DEBUG - 2012-04-08 07:43:11 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:43:11 --> Final output sent to browser
DEBUG - 2012-04-08 07:43:11 --> Total execution time: 0.3021
DEBUG - 2012-04-08 07:45:19 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:19 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:19 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:19 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:19 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:19 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Model Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Model Class Initialized
DEBUG - 2012-04-08 07:45:19 --> Helper loaded: email_helper
DEBUG - 2012-04-08 07:45:19 --> Model Class Initialized
DEBUG - 2012-04-08 07:45:19 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:45:19 --> Final output sent to browser
DEBUG - 2012-04-08 07:45:19 --> Total execution time: 0.3206
DEBUG - 2012-04-08 07:45:37 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:37 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:37 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:37 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:37 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:37 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Model Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Model Class Initialized
DEBUG - 2012-04-08 07:45:37 --> Helper loaded: email_helper
DEBUG - 2012-04-08 07:45:37 --> Model Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:38 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:38 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:38 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:38 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:38 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:38 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:38 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 07:45:38 --> Final output sent to browser
DEBUG - 2012-04-08 07:45:38 --> Total execution time: 0.2498
DEBUG - 2012-04-08 07:45:39 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:39 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:39 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:39 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:39 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:39 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:40 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:40 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:40 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:40 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:40 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:40 --> A session cookie was not found.
DEBUG - 2012-04-08 07:45:40 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:40 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:40 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:45:40 --> Final output sent to browser
DEBUG - 2012-04-08 07:45:40 --> Total execution time: 0.3007
DEBUG - 2012-04-08 07:45:50 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:50 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:50 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:50 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:50 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:50 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Model Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Model Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:50 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:50 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:50 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:50 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:50 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:50 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:50 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 07:45:50 --> Final output sent to browser
DEBUG - 2012-04-08 07:45:51 --> Total execution time: 0.2432
DEBUG - 2012-04-08 07:45:52 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:52 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:52 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:52 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:53 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:53 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:53 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Config Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:45:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:45:53 --> URI Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Router Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Output Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Security Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Input Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:45:53 --> Language Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Loader Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:45:53 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Session Class Initialized
DEBUG - 2012-04-08 07:45:53 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:45:53 --> A session cookie was not found.
DEBUG - 2012-04-08 07:45:53 --> Session routines successfully run
DEBUG - 2012-04-08 07:45:53 --> Controller Class Initialized
DEBUG - 2012-04-08 07:45:53 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:45:53 --> Final output sent to browser
DEBUG - 2012-04-08 07:45:53 --> Total execution time: 0.2794
DEBUG - 2012-04-08 07:46:08 --> Config Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:46:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:46:08 --> URI Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Router Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Output Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Security Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Input Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:46:08 --> Language Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Loader Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:46:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Session Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:46:08 --> Session routines successfully run
DEBUG - 2012-04-08 07:46:08 --> Controller Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Model Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Model Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Config Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:46:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:46:08 --> URI Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Router Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Output Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Security Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Input Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:46:08 --> Language Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Loader Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:46:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Session Class Initialized
DEBUG - 2012-04-08 07:46:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:46:08 --> Session routines successfully run
DEBUG - 2012-04-08 07:46:08 --> Controller Class Initialized
DEBUG - 2012-04-08 07:46:08 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 07:46:08 --> Final output sent to browser
DEBUG - 2012-04-08 07:46:08 --> Total execution time: 0.2449
DEBUG - 2012-04-08 07:46:11 --> Config Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:46:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:46:11 --> URI Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Router Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Output Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Security Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Input Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:46:11 --> Language Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Loader Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:46:11 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Session Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:46:11 --> Session routines successfully run
DEBUG - 2012-04-08 07:46:11 --> Controller Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Model Class Initialized
DEBUG - 2012-04-08 07:46:11 --> Model Class Initialized
DEBUG - 2012-04-08 07:46:11 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 07:46:11 --> Final output sent to browser
DEBUG - 2012-04-08 07:46:11 --> Total execution time: 0.4890
DEBUG - 2012-04-08 07:46:43 --> Config Class Initialized
DEBUG - 2012-04-08 07:46:43 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:46:43 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:46:43 --> URI Class Initialized
DEBUG - 2012-04-08 07:46:43 --> Router Class Initialized
DEBUG - 2012-04-08 07:46:43 --> No URI present. Default controller set.
DEBUG - 2012-04-08 07:46:43 --> Output Class Initialized
DEBUG - 2012-04-08 07:46:43 --> Security Class Initialized
DEBUG - 2012-04-08 07:46:43 --> Input Class Initialized
DEBUG - 2012-04-08 07:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:46:43 --> Language Class Initialized
DEBUG - 2012-04-08 07:46:43 --> Loader Class Initialized
DEBUG - 2012-04-08 07:46:43 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:46:43 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:46:44 --> Session Class Initialized
DEBUG - 2012-04-08 07:46:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:46:44 --> Session routines successfully run
DEBUG - 2012-04-08 07:46:44 --> Controller Class Initialized
DEBUG - 2012-04-08 07:46:44 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 07:46:44 --> Final output sent to browser
DEBUG - 2012-04-08 07:46:44 --> Total execution time: 0.3647
DEBUG - 2012-04-08 07:46:46 --> Config Class Initialized
DEBUG - 2012-04-08 07:46:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:46:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:46:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:46:46 --> URI Class Initialized
DEBUG - 2012-04-08 07:46:46 --> Router Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Output Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Security Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Input Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:46:47 --> Language Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Loader Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:46:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Session Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:46:47 --> Session routines successfully run
DEBUG - 2012-04-08 07:46:47 --> Controller Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Config Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:46:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:46:47 --> URI Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Router Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Output Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Security Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Input Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:46:47 --> Language Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Loader Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:46:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Session Class Initialized
DEBUG - 2012-04-08 07:46:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:46:47 --> A session cookie was not found.
DEBUG - 2012-04-08 07:46:47 --> Session routines successfully run
DEBUG - 2012-04-08 07:46:47 --> Controller Class Initialized
DEBUG - 2012-04-08 07:46:47 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:46:47 --> Final output sent to browser
DEBUG - 2012-04-08 07:46:47 --> Total execution time: 0.4350
DEBUG - 2012-04-08 07:46:54 --> Config Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:46:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:46:54 --> URI Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Router Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Output Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Security Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Input Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:46:54 --> Language Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Loader Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:46:54 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Session Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:46:54 --> Session routines successfully run
DEBUG - 2012-04-08 07:46:54 --> Controller Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Model Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Model Class Initialized
DEBUG - 2012-04-08 07:46:54 --> Model Class Initialized
DEBUG - 2012-04-08 07:46:54 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 07:46:54 --> Final output sent to browser
DEBUG - 2012-04-08 07:46:54 --> Total execution time: 0.5239
DEBUG - 2012-04-08 07:47:09 --> Config Class Initialized
DEBUG - 2012-04-08 07:47:09 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:47:09 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:47:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:47:10 --> URI Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Router Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Output Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Security Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Input Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:47:10 --> Language Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Loader Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:47:10 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Session Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:47:10 --> Session routines successfully run
DEBUG - 2012-04-08 07:47:10 --> Controller Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:10 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:10 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 07:47:10 --> Final output sent to browser
DEBUG - 2012-04-08 07:47:10 --> Total execution time: 0.3970
DEBUG - 2012-04-08 07:47:21 --> Config Class Initialized
DEBUG - 2012-04-08 07:47:21 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:47:21 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:47:21 --> URI Class Initialized
DEBUG - 2012-04-08 07:47:21 --> Router Class Initialized
DEBUG - 2012-04-08 07:47:21 --> Output Class Initialized
DEBUG - 2012-04-08 07:47:21 --> Security Class Initialized
DEBUG - 2012-04-08 07:47:21 --> Input Class Initialized
DEBUG - 2012-04-08 07:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:47:21 --> Language Class Initialized
DEBUG - 2012-04-08 07:47:21 --> Loader Class Initialized
DEBUG - 2012-04-08 07:47:22 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:47:22 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:47:22 --> Session Class Initialized
DEBUG - 2012-04-08 07:47:22 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:47:22 --> Session routines successfully run
DEBUG - 2012-04-08 07:47:22 --> Controller Class Initialized
DEBUG - 2012-04-08 07:47:22 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:22 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:22 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:22 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 07:47:22 --> Final output sent to browser
DEBUG - 2012-04-08 07:47:22 --> Total execution time: 0.3819
DEBUG - 2012-04-08 07:47:34 --> Config Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:47:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:47:34 --> URI Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Router Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Output Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Security Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Input Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:47:34 --> Language Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Loader Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:47:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Session Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:47:34 --> Session routines successfully run
DEBUG - 2012-04-08 07:47:34 --> Controller Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:34 --> Final output sent to browser
DEBUG - 2012-04-08 07:47:34 --> Total execution time: 0.3612
DEBUG - 2012-04-08 07:47:40 --> Config Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:47:40 --> URI Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Router Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Output Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Security Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Input Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:47:40 --> Language Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Loader Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:47:40 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Session Class Initialized
DEBUG - 2012-04-08 07:47:40 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:47:41 --> Session routines successfully run
DEBUG - 2012-04-08 07:47:41 --> Controller Class Initialized
DEBUG - 2012-04-08 07:47:41 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:41 --> Model Class Initialized
DEBUG - 2012-04-08 07:47:41 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 07:47:41 --> Final output sent to browser
DEBUG - 2012-04-08 07:47:41 --> Total execution time: 0.3256
DEBUG - 2012-04-08 07:48:07 --> Config Class Initialized
DEBUG - 2012-04-08 07:48:07 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:48:07 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:48:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:48:07 --> URI Class Initialized
DEBUG - 2012-04-08 07:48:07 --> Router Class Initialized
DEBUG - 2012-04-08 07:48:07 --> Output Class Initialized
DEBUG - 2012-04-08 07:48:07 --> Security Class Initialized
DEBUG - 2012-04-08 07:48:08 --> Input Class Initialized
DEBUG - 2012-04-08 07:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:48:08 --> Language Class Initialized
DEBUG - 2012-04-08 07:48:08 --> Loader Class Initialized
DEBUG - 2012-04-08 07:48:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:48:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:48:08 --> Session Class Initialized
DEBUG - 2012-04-08 07:48:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:48:08 --> Session routines successfully run
DEBUG - 2012-04-08 07:48:08 --> Controller Class Initialized
DEBUG - 2012-04-08 07:48:08 --> Model Class Initialized
DEBUG - 2012-04-08 07:48:08 --> Model Class Initialized
DEBUG - 2012-04-08 07:48:08 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:48:08 --> Final output sent to browser
DEBUG - 2012-04-08 07:48:08 --> Total execution time: 0.3522
DEBUG - 2012-04-08 07:48:39 --> Config Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:48:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:48:39 --> URI Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Router Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Output Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Security Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Input Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:48:39 --> Language Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Loader Class Initialized
DEBUG - 2012-04-08 07:48:39 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:48:40 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:48:40 --> Session Class Initialized
DEBUG - 2012-04-08 07:48:40 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:48:40 --> Session routines successfully run
DEBUG - 2012-04-08 07:48:40 --> Controller Class Initialized
DEBUG - 2012-04-08 07:48:40 --> Model Class Initialized
DEBUG - 2012-04-08 07:48:40 --> Model Class Initialized
DEBUG - 2012-04-08 07:48:40 --> Helper loaded: email_helper
DEBUG - 2012-04-08 07:48:40 --> Model Class Initialized
DEBUG - 2012-04-08 07:48:40 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:48:40 --> Final output sent to browser
DEBUG - 2012-04-08 07:48:40 --> Total execution time: 0.3609
DEBUG - 2012-04-08 07:48:45 --> Config Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:48:45 --> URI Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Router Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Output Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Security Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Input Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:48:45 --> Language Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Loader Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:48:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Session Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:48:45 --> Session routines successfully run
DEBUG - 2012-04-08 07:48:45 --> Controller Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Model Class Initialized
DEBUG - 2012-04-08 07:48:45 --> Model Class Initialized
DEBUG - 2012-04-08 07:48:45 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 07:48:45 --> Final output sent to browser
DEBUG - 2012-04-08 07:48:45 --> Total execution time: 0.2905
DEBUG - 2012-04-08 07:50:33 --> Config Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:50:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:50:33 --> URI Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Router Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Output Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Security Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Input Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:50:33 --> Language Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Loader Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:50:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Session Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:50:33 --> Session routines successfully run
DEBUG - 2012-04-08 07:50:33 --> Controller Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:33 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:33 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 07:50:33 --> Final output sent to browser
DEBUG - 2012-04-08 07:50:34 --> Total execution time: 0.3706
DEBUG - 2012-04-08 07:50:41 --> Config Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:50:41 --> URI Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Router Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Output Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Security Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Input Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:50:41 --> Language Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Loader Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:50:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Session Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:50:41 --> Session routines successfully run
DEBUG - 2012-04-08 07:50:41 --> Controller Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:41 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:41 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 07:50:41 --> Final output sent to browser
DEBUG - 2012-04-08 07:50:41 --> Total execution time: 0.4007
DEBUG - 2012-04-08 07:50:51 --> Config Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:50:51 --> URI Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Router Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Output Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Security Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Input Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:50:51 --> Language Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Loader Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:50:51 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Session Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:50:51 --> Session routines successfully run
DEBUG - 2012-04-08 07:50:51 --> Controller Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Model Class Initialized
DEBUG - 2012-04-08 07:50:51 --> Final output sent to browser
DEBUG - 2012-04-08 07:50:51 --> Total execution time: 0.4860
DEBUG - 2012-04-08 07:51:20 --> Config Class Initialized
DEBUG - 2012-04-08 07:51:20 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:51:21 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:51:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:51:21 --> URI Class Initialized
DEBUG - 2012-04-08 07:51:21 --> Router Class Initialized
DEBUG - 2012-04-08 07:51:22 --> Output Class Initialized
DEBUG - 2012-04-08 07:51:22 --> Security Class Initialized
DEBUG - 2012-04-08 07:51:22 --> Input Class Initialized
DEBUG - 2012-04-08 07:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:51:22 --> Language Class Initialized
DEBUG - 2012-04-08 07:51:23 --> Loader Class Initialized
DEBUG - 2012-04-08 07:51:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:51:25 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:51:25 --> Session Class Initialized
DEBUG - 2012-04-08 07:51:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:51:25 --> Session routines successfully run
DEBUG - 2012-04-08 07:51:25 --> Controller Class Initialized
DEBUG - 2012-04-08 07:51:26 --> Model Class Initialized
DEBUG - 2012-04-08 07:51:27 --> Model Class Initialized
DEBUG - 2012-04-08 07:51:27 --> Helper loaded: email_helper
DEBUG - 2012-04-08 07:51:27 --> Model Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Config Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:51:28 --> URI Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Router Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Output Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Security Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Input Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:51:28 --> Language Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Loader Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:51:28 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Session Class Initialized
DEBUG - 2012-04-08 07:51:28 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:51:28 --> Session routines successfully run
DEBUG - 2012-04-08 07:51:28 --> Controller Class Initialized
DEBUG - 2012-04-08 07:51:28 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 07:51:28 --> Final output sent to browser
DEBUG - 2012-04-08 07:51:28 --> Total execution time: 0.2898
DEBUG - 2012-04-08 07:51:35 --> Config Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:51:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:51:35 --> URI Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Router Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Output Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Security Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Input Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:51:35 --> Language Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Loader Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:51:35 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Session Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:51:35 --> Session routines successfully run
DEBUG - 2012-04-08 07:51:35 --> Controller Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Config Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Hooks Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Utf8 Class Initialized
DEBUG - 2012-04-08 07:51:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 07:51:35 --> URI Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Router Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Output Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Security Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Input Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 07:51:35 --> Language Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Loader Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Helper loaded: url_helper
DEBUG - 2012-04-08 07:51:35 --> Database Driver Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Session Class Initialized
DEBUG - 2012-04-08 07:51:35 --> Helper loaded: string_helper
DEBUG - 2012-04-08 07:51:35 --> A session cookie was not found.
DEBUG - 2012-04-08 07:51:35 --> Session routines successfully run
DEBUG - 2012-04-08 07:51:35 --> Controller Class Initialized
DEBUG - 2012-04-08 07:51:35 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 07:51:35 --> Final output sent to browser
DEBUG - 2012-04-08 07:51:35 --> Total execution time: 0.2546
DEBUG - 2012-04-08 08:08:03 --> Config Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:08:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:08:03 --> URI Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Router Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Output Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Security Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Input Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:08:03 --> Language Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Loader Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:08:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Session Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:08:03 --> Session routines successfully run
DEBUG - 2012-04-08 08:08:03 --> Controller Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Model Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Model Class Initialized
DEBUG - 2012-04-08 08:08:03 --> Model Class Initialized
DEBUG - 2012-04-08 08:08:04 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 08:08:04 --> Final output sent to browser
DEBUG - 2012-04-08 08:08:04 --> Total execution time: 0.9259
DEBUG - 2012-04-08 08:09:22 --> Config Class Initialized
DEBUG - 2012-04-08 08:09:22 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:09:22 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:09:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:09:22 --> URI Class Initialized
DEBUG - 2012-04-08 08:09:22 --> Router Class Initialized
DEBUG - 2012-04-08 08:09:22 --> No URI present. Default controller set.
DEBUG - 2012-04-08 08:09:22 --> Output Class Initialized
DEBUG - 2012-04-08 08:09:22 --> Security Class Initialized
DEBUG - 2012-04-08 08:09:22 --> Input Class Initialized
DEBUG - 2012-04-08 08:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:09:22 --> Language Class Initialized
DEBUG - 2012-04-08 08:09:22 --> Loader Class Initialized
DEBUG - 2012-04-08 08:09:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:09:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:09:23 --> Session Class Initialized
DEBUG - 2012-04-08 08:09:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:09:23 --> Session routines successfully run
DEBUG - 2012-04-08 08:09:23 --> Controller Class Initialized
DEBUG - 2012-04-08 08:09:23 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 08:09:23 --> Final output sent to browser
DEBUG - 2012-04-08 08:09:23 --> Total execution time: 0.4639
DEBUG - 2012-04-08 08:09:27 --> Config Class Initialized
DEBUG - 2012-04-08 08:09:27 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:09:27 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:09:27 --> URI Class Initialized
DEBUG - 2012-04-08 08:09:27 --> Router Class Initialized
DEBUG - 2012-04-08 08:09:27 --> Output Class Initialized
DEBUG - 2012-04-08 08:09:27 --> Security Class Initialized
DEBUG - 2012-04-08 08:09:27 --> Input Class Initialized
DEBUG - 2012-04-08 08:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:09:27 --> Language Class Initialized
DEBUG - 2012-04-08 08:09:27 --> Loader Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:09:28 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Session Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:09:28 --> Session routines successfully run
DEBUG - 2012-04-08 08:09:28 --> Controller Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Config Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:09:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:09:28 --> URI Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Router Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Output Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Security Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Input Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:09:28 --> Language Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Loader Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:09:28 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Session Class Initialized
DEBUG - 2012-04-08 08:09:28 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:09:28 --> A session cookie was not found.
DEBUG - 2012-04-08 08:09:28 --> Session routines successfully run
DEBUG - 2012-04-08 08:09:28 --> Controller Class Initialized
DEBUG - 2012-04-08 08:09:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:09:28 --> Final output sent to browser
DEBUG - 2012-04-08 08:09:28 --> Total execution time: 0.3591
DEBUG - 2012-04-08 08:09:30 --> Config Class Initialized
DEBUG - 2012-04-08 08:09:30 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:09:30 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:09:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:09:31 --> URI Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Router Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Output Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Security Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Input Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:09:31 --> Language Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Loader Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:09:31 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Session Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:09:31 --> Session routines successfully run
DEBUG - 2012-04-08 08:09:31 --> Controller Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Model Class Initialized
DEBUG - 2012-04-08 08:09:31 --> Model Class Initialized
DEBUG - 2012-04-08 08:09:31 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:09:31 --> Final output sent to browser
DEBUG - 2012-04-08 08:09:31 --> Total execution time: 0.4613
DEBUG - 2012-04-08 08:10:19 --> Config Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:10:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:10:19 --> URI Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Router Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Output Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Security Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Input Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:10:19 --> Language Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Loader Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:10:19 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Session Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:10:19 --> Session routines successfully run
DEBUG - 2012-04-08 08:10:19 --> Controller Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:10:19 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:10:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Config Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:10:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:10:20 --> URI Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Router Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Output Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Security Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Input Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:10:20 --> Language Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Loader Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:10:20 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Session Class Initialized
DEBUG - 2012-04-08 08:10:20 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:10:20 --> Session routines successfully run
DEBUG - 2012-04-08 08:10:20 --> Controller Class Initialized
DEBUG - 2012-04-08 08:10:20 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:10:20 --> Final output sent to browser
DEBUG - 2012-04-08 08:10:20 --> Total execution time: 0.2761
DEBUG - 2012-04-08 08:10:23 --> Config Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:10:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:10:23 --> URI Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Router Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Output Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Security Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Input Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:10:23 --> Language Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Loader Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:10:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:10:23 --> Session Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:10:24 --> Session routines successfully run
DEBUG - 2012-04-08 08:10:24 --> Controller Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Config Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:10:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:10:24 --> URI Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Router Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Output Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Security Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Input Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:10:24 --> Language Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Loader Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:10:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Session Class Initialized
DEBUG - 2012-04-08 08:10:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:10:24 --> A session cookie was not found.
DEBUG - 2012-04-08 08:10:24 --> Session routines successfully run
DEBUG - 2012-04-08 08:10:24 --> Controller Class Initialized
DEBUG - 2012-04-08 08:10:24 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:10:24 --> Final output sent to browser
DEBUG - 2012-04-08 08:10:24 --> Total execution time: 0.3533
DEBUG - 2012-04-08 08:10:54 --> Config Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:10:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:10:54 --> URI Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Router Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Output Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Security Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Input Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:10:54 --> Language Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Loader Class Initialized
DEBUG - 2012-04-08 08:10:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:10:55 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:10:55 --> Session Class Initialized
DEBUG - 2012-04-08 08:10:55 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:10:55 --> Session routines successfully run
DEBUG - 2012-04-08 08:10:55 --> Controller Class Initialized
DEBUG - 2012-04-08 08:10:55 --> Model Class Initialized
DEBUG - 2012-04-08 08:10:55 --> Model Class Initialized
DEBUG - 2012-04-08 08:10:55 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:10:55 --> Final output sent to browser
DEBUG - 2012-04-08 08:10:55 --> Total execution time: 0.4287
DEBUG - 2012-04-08 08:11:23 --> Config Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:11:23 --> URI Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Router Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Output Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Security Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Input Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:11:23 --> Language Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Loader Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:11:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Session Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:11:23 --> Session routines successfully run
DEBUG - 2012-04-08 08:11:23 --> Controller Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Model Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Model Class Initialized
DEBUG - 2012-04-08 08:11:23 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:11:23 --> Model Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Config Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:11:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:11:24 --> URI Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Router Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Output Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Security Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Input Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:11:24 --> Language Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Loader Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:11:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Session Class Initialized
DEBUG - 2012-04-08 08:11:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:11:24 --> Session routines successfully run
DEBUG - 2012-04-08 08:11:24 --> Controller Class Initialized
DEBUG - 2012-04-08 08:11:24 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:11:24 --> Final output sent to browser
DEBUG - 2012-04-08 08:11:24 --> Total execution time: 0.3576
DEBUG - 2012-04-08 08:11:25 --> Config Class Initialized
DEBUG - 2012-04-08 08:11:25 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:11:25 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:11:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:11:25 --> URI Class Initialized
DEBUG - 2012-04-08 08:11:25 --> Router Class Initialized
DEBUG - 2012-04-08 08:11:25 --> Output Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Security Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Input Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:11:26 --> Language Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Loader Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:11:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Session Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:11:26 --> Session routines successfully run
DEBUG - 2012-04-08 08:11:26 --> Controller Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Config Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:11:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:11:26 --> URI Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Router Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Output Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Security Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Input Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:11:26 --> Language Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Loader Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:11:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Session Class Initialized
DEBUG - 2012-04-08 08:11:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:11:26 --> A session cookie was not found.
DEBUG - 2012-04-08 08:11:26 --> Session routines successfully run
DEBUG - 2012-04-08 08:11:26 --> Controller Class Initialized
DEBUG - 2012-04-08 08:11:26 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:11:27 --> Final output sent to browser
DEBUG - 2012-04-08 08:11:27 --> Total execution time: 0.6356
DEBUG - 2012-04-08 08:11:50 --> Config Class Initialized
DEBUG - 2012-04-08 08:11:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:11:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:11:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:11:51 --> URI Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Router Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Output Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Security Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Input Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:11:51 --> Language Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Loader Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:11:51 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Session Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:11:51 --> Session routines successfully run
DEBUG - 2012-04-08 08:11:51 --> Controller Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Model Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Model Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Config Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:11:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:11:51 --> URI Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Router Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Output Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Security Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Input Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:11:51 --> Language Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Loader Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:11:51 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Session Class Initialized
DEBUG - 2012-04-08 08:11:51 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:11:51 --> Session routines successfully run
DEBUG - 2012-04-08 08:11:51 --> Controller Class Initialized
DEBUG - 2012-04-08 08:11:51 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 08:11:51 --> Final output sent to browser
DEBUG - 2012-04-08 08:11:51 --> Total execution time: 0.2761
DEBUG - 2012-04-08 08:11:53 --> Config Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:11:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:11:53 --> URI Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Router Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Output Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Security Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Input Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:11:53 --> Language Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Loader Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:11:53 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Session Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:11:53 --> Session routines successfully run
DEBUG - 2012-04-08 08:11:53 --> Controller Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Model Class Initialized
DEBUG - 2012-04-08 08:11:53 --> Model Class Initialized
DEBUG - 2012-04-08 08:11:53 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:11:53 --> Final output sent to browser
DEBUG - 2012-04-08 08:11:53 --> Total execution time: 0.5701
DEBUG - 2012-04-08 08:12:05 --> Config Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:12:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:12:05 --> URI Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Router Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Output Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Security Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Input Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:12:05 --> Language Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Loader Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:12:05 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Session Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:12:05 --> Session routines successfully run
DEBUG - 2012-04-08 08:12:05 --> Controller Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:05 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:05 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 08:12:05 --> Final output sent to browser
DEBUG - 2012-04-08 08:12:05 --> Total execution time: 0.3911
DEBUG - 2012-04-08 08:12:07 --> Config Class Initialized
DEBUG - 2012-04-08 08:12:07 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:12:07 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:12:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:12:07 --> URI Class Initialized
DEBUG - 2012-04-08 08:12:07 --> Router Class Initialized
DEBUG - 2012-04-08 08:12:07 --> Output Class Initialized
DEBUG - 2012-04-08 08:12:07 --> Security Class Initialized
DEBUG - 2012-04-08 08:12:07 --> Input Class Initialized
DEBUG - 2012-04-08 08:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:12:07 --> Language Class Initialized
DEBUG - 2012-04-08 08:12:08 --> Loader Class Initialized
DEBUG - 2012-04-08 08:12:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:12:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:12:08 --> Session Class Initialized
DEBUG - 2012-04-08 08:12:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:12:08 --> Session routines successfully run
DEBUG - 2012-04-08 08:12:08 --> Controller Class Initialized
DEBUG - 2012-04-08 08:12:08 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:08 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:08 --> Final output sent to browser
DEBUG - 2012-04-08 08:12:08 --> Total execution time: 0.4388
DEBUG - 2012-04-08 08:12:10 --> Config Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:12:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:12:10 --> URI Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Router Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Output Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Security Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Input Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:12:10 --> Language Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Loader Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:12:10 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Session Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:12:10 --> Session routines successfully run
DEBUG - 2012-04-08 08:12:10 --> Controller Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:10 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:10 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:12:10 --> Final output sent to browser
DEBUG - 2012-04-08 08:12:10 --> Total execution time: 0.4450
DEBUG - 2012-04-08 08:12:19 --> Config Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:12:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:12:19 --> URI Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Router Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Output Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Security Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Input Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:12:19 --> Language Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Loader Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:12:19 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Session Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:12:19 --> Session routines successfully run
DEBUG - 2012-04-08 08:12:19 --> Controller Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:12:19 --> Model Class Initialized
ERROR - 2012-04-08 08:12:19 --> Severity: Notice  --> Undefined variable: BlockID C:\xampp\htdocs\xcms\system\views\codes_view.php 7
ERROR - 2012-04-08 08:12:19 --> Severity: Notice  --> Undefined variable: BlockSetID C:\xampp\htdocs\xcms\system\views\codes_view.php 7
DEBUG - 2012-04-08 08:12:19 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-08 08:12:19 --> Final output sent to browser
DEBUG - 2012-04-08 08:12:19 --> Total execution time: 0.5636
DEBUG - 2012-04-08 08:13:29 --> Config Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:13:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:13:29 --> URI Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Router Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Output Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Security Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Input Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:13:29 --> Language Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Loader Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:13:29 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Session Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:13:29 --> Session routines successfully run
DEBUG - 2012-04-08 08:13:29 --> Controller Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:29 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:29 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 08:13:29 --> Final output sent to browser
DEBUG - 2012-04-08 08:13:29 --> Total execution time: 0.6254
DEBUG - 2012-04-08 08:13:34 --> Config Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:13:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:13:34 --> URI Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Router Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Output Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Security Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Input Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:13:34 --> Language Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Loader Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:13:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Session Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:13:34 --> Session routines successfully run
DEBUG - 2012-04-08 08:13:34 --> Controller Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:34 --> Final output sent to browser
DEBUG - 2012-04-08 08:13:34 --> Total execution time: 0.3376
DEBUG - 2012-04-08 08:13:35 --> Config Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:13:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:13:35 --> URI Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Router Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Output Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Security Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Input Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:13:35 --> Language Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Loader Class Initialized
DEBUG - 2012-04-08 08:13:35 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:13:36 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:13:36 --> Session Class Initialized
DEBUG - 2012-04-08 08:13:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:13:36 --> Session routines successfully run
DEBUG - 2012-04-08 08:13:36 --> Controller Class Initialized
DEBUG - 2012-04-08 08:13:36 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:36 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:36 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:13:36 --> Final output sent to browser
DEBUG - 2012-04-08 08:13:36 --> Total execution time: 0.5001
DEBUG - 2012-04-08 08:13:46 --> Config Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:13:46 --> URI Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Router Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Output Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Security Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Input Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:13:46 --> Language Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Loader Class Initialized
DEBUG - 2012-04-08 08:13:46 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:13:46 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:13:47 --> Session Class Initialized
DEBUG - 2012-04-08 08:13:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:13:47 --> Session routines successfully run
DEBUG - 2012-04-08 08:13:47 --> Controller Class Initialized
DEBUG - 2012-04-08 08:13:47 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:47 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:47 --> Model Class Initialized
DEBUG - 2012-04-08 08:13:47 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-08 08:13:47 --> Final output sent to browser
DEBUG - 2012-04-08 08:13:47 --> Total execution time: 0.4607
DEBUG - 2012-04-08 08:13:56 --> Config Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:13:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:13:56 --> URI Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Router Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Output Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Security Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Input Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:13:56 --> Language Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Loader Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:13:56 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Session Class Initialized
DEBUG - 2012-04-08 08:13:56 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:13:56 --> Session routines successfully run
DEBUG - 2012-04-08 08:13:56 --> Controller Class Initialized
DEBUG - 2012-04-08 08:13:56 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 08:13:56 --> Final output sent to browser
DEBUG - 2012-04-08 08:13:56 --> Total execution time: 0.2913
DEBUG - 2012-04-08 08:18:06 --> Config Class Initialized
DEBUG - 2012-04-08 08:18:06 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:18:06 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:18:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:18:06 --> URI Class Initialized
DEBUG - 2012-04-08 08:18:06 --> Router Class Initialized
DEBUG - 2012-04-08 08:18:06 --> Output Class Initialized
DEBUG - 2012-04-08 08:18:06 --> Security Class Initialized
DEBUG - 2012-04-08 08:18:06 --> Input Class Initialized
DEBUG - 2012-04-08 08:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:18:06 --> Language Class Initialized
DEBUG - 2012-04-08 08:18:07 --> Loader Class Initialized
DEBUG - 2012-04-08 08:18:07 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:18:07 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:18:07 --> Session Class Initialized
DEBUG - 2012-04-08 08:18:07 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:18:07 --> Session routines successfully run
DEBUG - 2012-04-08 08:18:07 --> Controller Class Initialized
DEBUG - 2012-04-08 08:18:07 --> Model Class Initialized
DEBUG - 2012-04-08 08:18:07 --> Model Class Initialized
DEBUG - 2012-04-08 08:18:07 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:18:07 --> Final output sent to browser
DEBUG - 2012-04-08 08:18:07 --> Total execution time: 1.3035
DEBUG - 2012-04-08 08:19:12 --> Config Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:19:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:19:12 --> URI Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Router Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Output Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Security Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Input Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:19:12 --> Language Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Loader Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:19:12 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Session Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:19:12 --> Session routines successfully run
DEBUG - 2012-04-08 08:19:12 --> Controller Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Model Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Model Class Initialized
DEBUG - 2012-04-08 08:19:12 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:19:12 --> Model Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Config Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:19:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:19:13 --> URI Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Router Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Output Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Security Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Input Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:19:13 --> Language Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Loader Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:19:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Session Class Initialized
DEBUG - 2012-04-08 08:19:13 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:19:13 --> Session routines successfully run
DEBUG - 2012-04-08 08:19:13 --> Controller Class Initialized
DEBUG - 2012-04-08 08:19:13 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:19:13 --> Final output sent to browser
DEBUG - 2012-04-08 08:19:13 --> Total execution time: 0.2575
DEBUG - 2012-04-08 08:19:14 --> Config Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:19:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:19:14 --> URI Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Router Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Output Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Security Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Input Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:19:14 --> Language Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Loader Class Initialized
DEBUG - 2012-04-08 08:19:14 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:19:14 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Session Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:19:15 --> Session routines successfully run
DEBUG - 2012-04-08 08:19:15 --> Controller Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Config Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:19:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:19:15 --> URI Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Router Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Output Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Security Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Input Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:19:15 --> Language Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Loader Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:19:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Session Class Initialized
DEBUG - 2012-04-08 08:19:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:19:15 --> A session cookie was not found.
DEBUG - 2012-04-08 08:19:15 --> Session routines successfully run
DEBUG - 2012-04-08 08:19:15 --> Controller Class Initialized
DEBUG - 2012-04-08 08:19:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:19:15 --> Final output sent to browser
DEBUG - 2012-04-08 08:19:15 --> Total execution time: 0.4266
DEBUG - 2012-04-08 08:26:05 --> Config Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:26:05 --> URI Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Router Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Output Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Security Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Input Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:26:05 --> Language Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Loader Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:26:05 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Session Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:26:05 --> Session routines successfully run
DEBUG - 2012-04-08 08:26:05 --> Controller Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:05 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:05 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:26:05 --> Final output sent to browser
DEBUG - 2012-04-08 08:26:05 --> Total execution time: 0.4134
DEBUG - 2012-04-08 08:26:15 --> Config Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:26:15 --> URI Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Router Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Output Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Security Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Input Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:26:15 --> Language Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Loader Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:26:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Session Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:26:15 --> Session routines successfully run
DEBUG - 2012-04-08 08:26:15 --> Controller Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:15 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:15 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 08:26:15 --> Final output sent to browser
DEBUG - 2012-04-08 08:26:15 --> Total execution time: 0.5022
DEBUG - 2012-04-08 08:26:17 --> Config Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:26:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:26:17 --> URI Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Router Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Output Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Security Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Input Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:26:17 --> Language Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Loader Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:26:17 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Session Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:26:17 --> Session routines successfully run
DEBUG - 2012-04-08 08:26:17 --> Controller Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:17 --> Final output sent to browser
DEBUG - 2012-04-08 08:26:17 --> Total execution time: 0.3881
DEBUG - 2012-04-08 08:26:18 --> Config Class Initialized
DEBUG - 2012-04-08 08:26:18 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:26:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:26:19 --> URI Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Router Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Output Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Security Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Input Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:26:19 --> Language Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Loader Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:26:19 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Session Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:26:19 --> Session routines successfully run
DEBUG - 2012-04-08 08:26:19 --> Controller Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:19 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:26:19 --> Final output sent to browser
DEBUG - 2012-04-08 08:26:19 --> Total execution time: 0.5812
DEBUG - 2012-04-08 08:26:28 --> Config Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:26:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:26:28 --> URI Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Router Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Output Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Security Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Input Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:26:28 --> Language Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Loader Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:26:28 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Session Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:26:28 --> Session routines successfully run
DEBUG - 2012-04-08 08:26:28 --> Controller Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:28 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:29 --> Final output sent to browser
DEBUG - 2012-04-08 08:26:29 --> Total execution time: 0.5256
DEBUG - 2012-04-08 08:26:50 --> Config Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:26:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:26:50 --> URI Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Router Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Output Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Security Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Input Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:26:50 --> Language Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Loader Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:26:50 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Session Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:26:50 --> Session routines successfully run
DEBUG - 2012-04-08 08:26:50 --> Controller Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:50 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:50 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 08:26:50 --> Final output sent to browser
DEBUG - 2012-04-08 08:26:50 --> Total execution time: 0.4575
DEBUG - 2012-04-08 08:26:51 --> Config Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:26:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:26:51 --> URI Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Router Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Output Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Security Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Input Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:26:51 --> Language Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Loader Class Initialized
DEBUG - 2012-04-08 08:26:51 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:26:52 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:26:52 --> Session Class Initialized
DEBUG - 2012-04-08 08:26:52 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:26:52 --> Session routines successfully run
DEBUG - 2012-04-08 08:26:52 --> Controller Class Initialized
DEBUG - 2012-04-08 08:26:52 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:52 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:52 --> Final output sent to browser
DEBUG - 2012-04-08 08:26:52 --> Total execution time: 0.4089
DEBUG - 2012-04-08 08:26:53 --> Config Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:26:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:26:53 --> URI Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Router Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Output Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Security Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Input Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:26:53 --> Language Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Loader Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:26:53 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Session Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:26:53 --> Session routines successfully run
DEBUG - 2012-04-08 08:26:53 --> Controller Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:53 --> Model Class Initialized
DEBUG - 2012-04-08 08:26:53 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:26:53 --> Final output sent to browser
DEBUG - 2012-04-08 08:26:53 --> Total execution time: 0.5150
DEBUG - 2012-04-08 08:27:02 --> Config Class Initialized
DEBUG - 2012-04-08 08:27:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:27:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:27:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:27:02 --> URI Class Initialized
DEBUG - 2012-04-08 08:27:02 --> Router Class Initialized
DEBUG - 2012-04-08 08:27:02 --> Output Class Initialized
DEBUG - 2012-04-08 08:27:02 --> Security Class Initialized
DEBUG - 2012-04-08 08:27:02 --> Input Class Initialized
DEBUG - 2012-04-08 08:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:27:02 --> Language Class Initialized
DEBUG - 2012-04-08 08:27:03 --> Loader Class Initialized
DEBUG - 2012-04-08 08:27:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:27:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:27:03 --> Session Class Initialized
DEBUG - 2012-04-08 08:27:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:27:03 --> Session routines successfully run
DEBUG - 2012-04-08 08:27:03 --> Controller Class Initialized
DEBUG - 2012-04-08 08:27:03 --> Model Class Initialized
DEBUG - 2012-04-08 08:27:03 --> Model Class Initialized
DEBUG - 2012-04-08 08:27:03 --> Model Class Initialized
DEBUG - 2012-04-08 08:27:03 --> Final output sent to browser
DEBUG - 2012-04-08 08:27:03 --> Total execution time: 0.4501
DEBUG - 2012-04-08 08:34:13 --> Config Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:34:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:34:13 --> URI Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Router Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Output Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Security Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Input Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:34:13 --> Language Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Loader Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:34:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Session Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:34:13 --> Session routines successfully run
DEBUG - 2012-04-08 08:34:13 --> Controller Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:13 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:13 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 08:34:13 --> Final output sent to browser
DEBUG - 2012-04-08 08:34:13 --> Total execution time: 0.3749
DEBUG - 2012-04-08 08:34:14 --> Config Class Initialized
DEBUG - 2012-04-08 08:34:14 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:34:14 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:34:14 --> URI Class Initialized
DEBUG - 2012-04-08 08:34:14 --> Router Class Initialized
DEBUG - 2012-04-08 08:34:14 --> Output Class Initialized
DEBUG - 2012-04-08 08:34:14 --> Security Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Input Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:34:15 --> Language Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Loader Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:34:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Session Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:34:15 --> Session routines successfully run
DEBUG - 2012-04-08 08:34:15 --> Controller Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:15 --> Final output sent to browser
DEBUG - 2012-04-08 08:34:15 --> Total execution time: 0.3871
DEBUG - 2012-04-08 08:34:16 --> Config Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:34:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:34:16 --> URI Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Router Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Output Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Security Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Input Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:34:16 --> Language Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Loader Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:34:16 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Session Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:34:16 --> Session routines successfully run
DEBUG - 2012-04-08 08:34:16 --> Controller Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:16 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:16 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:34:16 --> Final output sent to browser
DEBUG - 2012-04-08 08:34:16 --> Total execution time: 0.5436
DEBUG - 2012-04-08 08:34:26 --> Config Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:34:26 --> URI Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Router Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Output Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Security Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Input Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:34:26 --> Language Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Loader Class Initialized
DEBUG - 2012-04-08 08:34:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:34:27 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:34:27 --> Session Class Initialized
DEBUG - 2012-04-08 08:34:27 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:34:27 --> Session routines successfully run
DEBUG - 2012-04-08 08:34:27 --> Controller Class Initialized
DEBUG - 2012-04-08 08:34:27 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:27 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:27 --> Model Class Initialized
DEBUG - 2012-04-08 08:34:27 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-08 08:34:27 --> Final output sent to browser
DEBUG - 2012-04-08 08:34:27 --> Total execution time: 0.4996
DEBUG - 2012-04-08 08:35:10 --> Config Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:35:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:35:10 --> URI Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Router Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Output Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Security Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Input Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:35:10 --> Language Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Loader Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:35:10 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Session Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:35:10 --> Session routines successfully run
DEBUG - 2012-04-08 08:35:10 --> Controller Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:10 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:10 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 08:35:10 --> Final output sent to browser
DEBUG - 2012-04-08 08:35:10 --> Total execution time: 0.4817
DEBUG - 2012-04-08 08:35:11 --> Config Class Initialized
DEBUG - 2012-04-08 08:35:11 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:35:11 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:35:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:35:11 --> URI Class Initialized
DEBUG - 2012-04-08 08:35:11 --> Router Class Initialized
DEBUG - 2012-04-08 08:35:11 --> Output Class Initialized
DEBUG - 2012-04-08 08:35:11 --> Security Class Initialized
DEBUG - 2012-04-08 08:35:11 --> Input Class Initialized
DEBUG - 2012-04-08 08:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:35:11 --> Language Class Initialized
DEBUG - 2012-04-08 08:35:12 --> Loader Class Initialized
DEBUG - 2012-04-08 08:35:12 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:35:12 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:35:12 --> Session Class Initialized
DEBUG - 2012-04-08 08:35:12 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:35:12 --> Session routines successfully run
DEBUG - 2012-04-08 08:35:12 --> Controller Class Initialized
DEBUG - 2012-04-08 08:35:12 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:12 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:12 --> Final output sent to browser
DEBUG - 2012-04-08 08:35:12 --> Total execution time: 0.3710
DEBUG - 2012-04-08 08:35:13 --> Config Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:35:13 --> URI Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Router Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Output Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Security Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Input Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:35:13 --> Language Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Loader Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:35:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Session Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:35:13 --> Session routines successfully run
DEBUG - 2012-04-08 08:35:13 --> Controller Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:13 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:13 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:35:13 --> Final output sent to browser
DEBUG - 2012-04-08 08:35:13 --> Total execution time: 0.5335
DEBUG - 2012-04-08 08:35:18 --> Config Class Initialized
DEBUG - 2012-04-08 08:35:18 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:35:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:35:19 --> URI Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Router Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Output Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Security Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Input Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:35:19 --> Language Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Loader Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:35:19 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Session Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:35:19 --> Session routines successfully run
DEBUG - 2012-04-08 08:35:19 --> Controller Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:19 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:19 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:35:19 --> Final output sent to browser
DEBUG - 2012-04-08 08:35:19 --> Total execution time: 0.4826
DEBUG - 2012-04-08 08:35:23 --> Config Class Initialized
DEBUG - 2012-04-08 08:35:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:35:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:35:24 --> URI Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Router Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Output Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Security Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Input Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:35:24 --> Language Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Loader Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:35:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Session Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:35:24 --> Session routines successfully run
DEBUG - 2012-04-08 08:35:24 --> Controller Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:24 --> Model Class Initialized
DEBUG - 2012-04-08 08:35:24 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-08 08:35:24 --> Final output sent to browser
DEBUG - 2012-04-08 08:35:24 --> Total execution time: 0.3839
DEBUG - 2012-04-08 08:37:08 --> Config Class Initialized
DEBUG - 2012-04-08 08:37:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:37:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:37:08 --> URI Class Initialized
DEBUG - 2012-04-08 08:37:08 --> Router Class Initialized
DEBUG - 2012-04-08 08:37:09 --> Output Class Initialized
DEBUG - 2012-04-08 08:37:09 --> Security Class Initialized
DEBUG - 2012-04-08 08:37:09 --> Input Class Initialized
DEBUG - 2012-04-08 08:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:37:09 --> Language Class Initialized
DEBUG - 2012-04-08 08:37:09 --> Loader Class Initialized
DEBUG - 2012-04-08 08:37:09 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:37:09 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:37:09 --> Session Class Initialized
DEBUG - 2012-04-08 08:37:09 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:37:09 --> Session routines successfully run
DEBUG - 2012-04-08 08:37:09 --> Controller Class Initialized
DEBUG - 2012-04-08 08:37:09 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 08:37:09 --> Final output sent to browser
DEBUG - 2012-04-08 08:37:09 --> Total execution time: 0.4023
DEBUG - 2012-04-08 08:43:41 --> Config Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:43:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:43:41 --> URI Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Router Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Output Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Security Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Input Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:43:41 --> Language Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Loader Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:43:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Session Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:43:41 --> Session routines successfully run
DEBUG - 2012-04-08 08:43:41 --> Controller Class Initialized
DEBUG - 2012-04-08 08:43:41 --> Model Class Initialized
DEBUG - 2012-04-08 08:43:42 --> Model Class Initialized
DEBUG - 2012-04-08 08:43:42 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:43:42 --> Final output sent to browser
DEBUG - 2012-04-08 08:43:42 --> Total execution time: 1.1238
DEBUG - 2012-04-08 08:44:33 --> Config Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:44:33 --> URI Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Router Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Output Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Security Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Input Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:44:33 --> Language Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Loader Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:44:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Session Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:44:33 --> Session routines successfully run
DEBUG - 2012-04-08 08:44:33 --> Controller Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Model Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Model Class Initialized
DEBUG - 2012-04-08 08:44:33 --> Model Class Initialized
DEBUG - 2012-04-08 08:44:33 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-08 08:44:33 --> Final output sent to browser
DEBUG - 2012-04-08 08:44:33 --> Total execution time: 0.4835
DEBUG - 2012-04-08 08:44:48 --> Config Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:44:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:44:48 --> URI Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Router Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Output Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Security Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Input Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:44:48 --> Language Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Loader Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:44:48 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Session Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:44:48 --> Session routines successfully run
DEBUG - 2012-04-08 08:44:48 --> Controller Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Model Class Initialized
DEBUG - 2012-04-08 08:44:48 --> Model Class Initialized
DEBUG - 2012-04-08 08:44:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:44:48 --> Final output sent to browser
DEBUG - 2012-04-08 08:44:48 --> Total execution time: 0.3820
DEBUG - 2012-04-08 08:45:26 --> Config Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:45:26 --> URI Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Router Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Output Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Security Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Input Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:45:26 --> Language Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Loader Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:45:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Session Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:45:26 --> Session routines successfully run
DEBUG - 2012-04-08 08:45:26 --> Controller Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Model Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Model Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:45:26 --> Model Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Config Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:45:26 --> URI Class Initialized
DEBUG - 2012-04-08 08:45:26 --> Router Class Initialized
DEBUG - 2012-04-08 08:45:27 --> Output Class Initialized
DEBUG - 2012-04-08 08:45:27 --> Security Class Initialized
DEBUG - 2012-04-08 08:45:27 --> Input Class Initialized
DEBUG - 2012-04-08 08:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:45:27 --> Language Class Initialized
DEBUG - 2012-04-08 08:45:27 --> Loader Class Initialized
DEBUG - 2012-04-08 08:45:27 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:45:27 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:45:27 --> Session Class Initialized
DEBUG - 2012-04-08 08:45:27 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:45:27 --> Session routines successfully run
DEBUG - 2012-04-08 08:45:27 --> Controller Class Initialized
DEBUG - 2012-04-08 08:45:27 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:45:27 --> Final output sent to browser
DEBUG - 2012-04-08 08:45:27 --> Total execution time: 0.2526
DEBUG - 2012-04-08 08:45:29 --> Config Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:45:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:45:29 --> URI Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Router Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Output Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Security Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Input Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:45:29 --> Language Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Loader Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:45:29 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Session Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:45:29 --> Session routines successfully run
DEBUG - 2012-04-08 08:45:29 --> Controller Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Config Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:45:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:45:29 --> URI Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Router Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Output Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Security Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Input Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:45:29 --> Language Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Loader Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:45:29 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Session Class Initialized
DEBUG - 2012-04-08 08:45:29 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:45:29 --> A session cookie was not found.
DEBUG - 2012-04-08 08:45:29 --> Session routines successfully run
DEBUG - 2012-04-08 08:45:29 --> Controller Class Initialized
DEBUG - 2012-04-08 08:45:29 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:45:29 --> Final output sent to browser
DEBUG - 2012-04-08 08:45:29 --> Total execution time: 0.3254
DEBUG - 2012-04-08 08:45:37 --> Config Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:45:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:45:37 --> URI Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Router Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Output Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Security Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Input Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:45:37 --> Language Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Loader Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:45:37 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Session Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:45:37 --> Session routines successfully run
DEBUG - 2012-04-08 08:45:37 --> Controller Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Model Class Initialized
DEBUG - 2012-04-08 08:45:37 --> Model Class Initialized
DEBUG - 2012-04-08 08:45:37 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:45:37 --> Final output sent to browser
DEBUG - 2012-04-08 08:45:37 --> Total execution time: 0.2982
DEBUG - 2012-04-08 08:46:02 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:02 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:02 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:02 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:02 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:02 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Model Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Model Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:46:02 --> Model Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:02 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:02 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:02 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:03 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:03 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:03 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:03 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:46:03 --> Final output sent to browser
DEBUG - 2012-04-08 08:46:03 --> Total execution time: 0.2606
DEBUG - 2012-04-08 08:46:04 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:04 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:04 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:04 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:04 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:04 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:04 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:04 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:04 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:04 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:04 --> A session cookie was not found.
DEBUG - 2012-04-08 08:46:04 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:05 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:05 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:46:05 --> Final output sent to browser
DEBUG - 2012-04-08 08:46:05 --> Total execution time: 0.3101
DEBUG - 2012-04-08 08:46:31 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:31 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:31 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:31 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:31 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:31 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Model Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Model Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:31 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:31 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:32 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:32 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:32 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:32 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:32 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:32 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:32 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:32 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:32 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:32 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:32 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:32 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:46:32 --> Final output sent to browser
DEBUG - 2012-04-08 08:46:32 --> Total execution time: 0.2866
DEBUG - 2012-04-08 08:46:34 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:34 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:34 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:34 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:34 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:34 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:34 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:35 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:35 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:35 --> A session cookie was not found.
DEBUG - 2012-04-08 08:46:35 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:35 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:35 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:46:35 --> Final output sent to browser
DEBUG - 2012-04-08 08:46:35 --> Total execution time: 0.3851
DEBUG - 2012-04-08 08:46:41 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:41 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:41 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:41 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:41 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:41 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 08:46:41 --> Final output sent to browser
DEBUG - 2012-04-08 08:46:41 --> Total execution time: 0.2623
DEBUG - 2012-04-08 08:46:43 --> Config Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:46:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:46:43 --> URI Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Router Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Output Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Security Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Input Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:46:43 --> Language Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Loader Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:46:43 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Session Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:46:43 --> Session routines successfully run
DEBUG - 2012-04-08 08:46:43 --> Controller Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Model Class Initialized
DEBUG - 2012-04-08 08:46:43 --> Model Class Initialized
DEBUG - 2012-04-08 08:46:43 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:46:43 --> Final output sent to browser
DEBUG - 2012-04-08 08:46:43 --> Total execution time: 0.4734
DEBUG - 2012-04-08 08:47:06 --> Config Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:47:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:47:06 --> URI Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Router Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Output Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Security Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Input Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:47:06 --> Language Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Loader Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:47:06 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Session Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:47:06 --> Session routines successfully run
DEBUG - 2012-04-08 08:47:06 --> Controller Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Model Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Model Class Initialized
DEBUG - 2012-04-08 08:47:06 --> Model Class Initialized
DEBUG - 2012-04-08 08:47:07 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-08 08:47:07 --> Final output sent to browser
DEBUG - 2012-04-08 08:47:07 --> Total execution time: 0.4153
DEBUG - 2012-04-08 08:47:15 --> Config Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:47:15 --> URI Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Router Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Output Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Security Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Input Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:47:15 --> Language Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Loader Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:47:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Session Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:47:15 --> Session routines successfully run
DEBUG - 2012-04-08 08:47:15 --> Controller Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Model Class Initialized
DEBUG - 2012-04-08 08:47:15 --> Model Class Initialized
DEBUG - 2012-04-08 08:47:15 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:47:15 --> Final output sent to browser
DEBUG - 2012-04-08 08:47:15 --> Total execution time: 0.2869
DEBUG - 2012-04-08 08:47:54 --> Config Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:47:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:47:54 --> URI Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Router Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Output Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Security Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Input Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:47:54 --> Language Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Loader Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:47:54 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Session Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:47:54 --> Session routines successfully run
DEBUG - 2012-04-08 08:47:54 --> Controller Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Model Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Model Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:47:54 --> Model Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Config Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:47:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:47:54 --> URI Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Router Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Output Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Security Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Input Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:47:54 --> Language Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Loader Class Initialized
DEBUG - 2012-04-08 08:47:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:47:54 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:47:55 --> Session Class Initialized
DEBUG - 2012-04-08 08:47:55 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:47:55 --> Session routines successfully run
DEBUG - 2012-04-08 08:47:55 --> Controller Class Initialized
DEBUG - 2012-04-08 08:47:55 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:47:55 --> Final output sent to browser
DEBUG - 2012-04-08 08:47:55 --> Total execution time: 0.2327
DEBUG - 2012-04-08 08:47:56 --> Config Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:47:56 --> URI Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Router Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Output Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Security Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Input Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:47:56 --> Language Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Loader Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:47:56 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Session Class Initialized
DEBUG - 2012-04-08 08:47:56 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:47:56 --> Session routines successfully run
DEBUG - 2012-04-08 08:47:56 --> Controller Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Config Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:47:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:47:57 --> URI Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Router Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Output Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Security Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Input Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:47:57 --> Language Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Loader Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:47:57 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Session Class Initialized
DEBUG - 2012-04-08 08:47:57 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:47:57 --> A session cookie was not found.
DEBUG - 2012-04-08 08:47:57 --> Session routines successfully run
DEBUG - 2012-04-08 08:47:57 --> Controller Class Initialized
DEBUG - 2012-04-08 08:47:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:47:57 --> Final output sent to browser
DEBUG - 2012-04-08 08:47:57 --> Total execution time: 0.3449
DEBUG - 2012-04-08 08:48:01 --> Config Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:48:01 --> URI Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Router Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Output Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Security Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Input Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:48:01 --> Language Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Loader Class Initialized
DEBUG - 2012-04-08 08:48:01 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:48:02 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:48:02 --> Session Class Initialized
DEBUG - 2012-04-08 08:48:02 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:48:02 --> Session routines successfully run
DEBUG - 2012-04-08 08:48:02 --> Controller Class Initialized
DEBUG - 2012-04-08 08:48:02 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 08:48:02 --> Final output sent to browser
DEBUG - 2012-04-08 08:48:02 --> Total execution time: 0.4090
DEBUG - 2012-04-08 08:48:03 --> Config Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:48:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:48:03 --> URI Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Router Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Output Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Security Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Input Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:48:03 --> Language Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Loader Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:48:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Session Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:48:03 --> Session routines successfully run
DEBUG - 2012-04-08 08:48:03 --> Controller Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Model Class Initialized
DEBUG - 2012-04-08 08:48:03 --> Model Class Initialized
DEBUG - 2012-04-08 08:48:03 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:48:03 --> Final output sent to browser
DEBUG - 2012-04-08 08:48:03 --> Total execution time: 0.6112
DEBUG - 2012-04-08 08:48:44 --> Config Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:48:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:48:44 --> URI Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Router Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Output Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Security Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Input Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:48:44 --> Language Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Loader Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:48:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Session Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:48:44 --> Session routines successfully run
DEBUG - 2012-04-08 08:48:44 --> Controller Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Model Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Model Class Initialized
DEBUG - 2012-04-08 08:48:44 --> Model Class Initialized
DEBUG - 2012-04-08 08:48:44 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:48:44 --> Final output sent to browser
DEBUG - 2012-04-08 08:48:44 --> Total execution time: 0.3417
DEBUG - 2012-04-08 08:48:50 --> Config Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:48:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:48:50 --> URI Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Router Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Output Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Security Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Input Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:48:50 --> Language Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Loader Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:48:50 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Session Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:48:50 --> Session routines successfully run
DEBUG - 2012-04-08 08:48:50 --> Controller Class Initialized
DEBUG - 2012-04-08 08:48:50 --> Model Class Initialized
DEBUG - 2012-04-08 08:48:51 --> Model Class Initialized
DEBUG - 2012-04-08 08:48:51 --> Model Class Initialized
DEBUG - 2012-04-08 08:48:51 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-08 08:48:51 --> Final output sent to browser
DEBUG - 2012-04-08 08:48:51 --> Total execution time: 0.3905
DEBUG - 2012-04-08 08:49:01 --> Config Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:49:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:49:01 --> URI Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Router Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Output Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Security Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Input Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:49:01 --> Language Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Loader Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:49:01 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Session Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:49:01 --> Session routines successfully run
DEBUG - 2012-04-08 08:49:01 --> Controller Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Model Class Initialized
DEBUG - 2012-04-08 08:49:01 --> Model Class Initialized
DEBUG - 2012-04-08 08:49:01 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:49:01 --> Final output sent to browser
DEBUG - 2012-04-08 08:49:01 --> Total execution time: 0.2867
DEBUG - 2012-04-08 08:49:42 --> Config Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:49:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:49:42 --> URI Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Router Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Output Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Security Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Input Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:49:42 --> Language Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Loader Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:49:42 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Session Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:49:42 --> Session routines successfully run
DEBUG - 2012-04-08 08:49:42 --> Controller Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Model Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Model Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:49:42 --> Model Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Config Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:49:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:49:42 --> URI Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Router Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Output Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Security Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Input Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:49:42 --> Language Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Loader Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:49:42 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Session Class Initialized
DEBUG - 2012-04-08 08:49:42 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:49:42 --> Session routines successfully run
DEBUG - 2012-04-08 08:49:42 --> Controller Class Initialized
DEBUG - 2012-04-08 08:49:42 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:49:42 --> Final output sent to browser
DEBUG - 2012-04-08 08:49:42 --> Total execution time: 0.2600
DEBUG - 2012-04-08 08:49:44 --> Config Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:49:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:49:44 --> URI Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Router Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Output Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Security Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Input Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:49:44 --> Language Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Loader Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:49:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Session Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:49:44 --> Session routines successfully run
DEBUG - 2012-04-08 08:49:44 --> Controller Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Config Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:49:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:49:44 --> URI Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Router Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Output Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Security Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Input Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:49:44 --> Language Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Loader Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:49:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Session Class Initialized
DEBUG - 2012-04-08 08:49:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:49:44 --> A session cookie was not found.
DEBUG - 2012-04-08 08:49:44 --> Session routines successfully run
DEBUG - 2012-04-08 08:49:44 --> Controller Class Initialized
DEBUG - 2012-04-08 08:49:44 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:49:45 --> Final output sent to browser
DEBUG - 2012-04-08 08:49:45 --> Total execution time: 0.3594
DEBUG - 2012-04-08 08:49:55 --> Config Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:49:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:49:55 --> URI Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Router Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Output Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Security Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Input Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:49:55 --> Language Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Loader Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:49:55 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Session Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:49:55 --> Session routines successfully run
DEBUG - 2012-04-08 08:49:55 --> Controller Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Model Class Initialized
DEBUG - 2012-04-08 08:49:55 --> Model Class Initialized
DEBUG - 2012-04-08 08:49:56 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:49:56 --> Final output sent to browser
DEBUG - 2012-04-08 08:49:56 --> Total execution time: 0.2854
DEBUG - 2012-04-08 08:50:54 --> Config Class Initialized
DEBUG - 2012-04-08 08:50:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:50:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:50:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:50:54 --> URI Class Initialized
DEBUG - 2012-04-08 08:50:54 --> Router Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Output Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Security Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Input Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:50:55 --> Language Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Loader Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:50:55 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Session Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:50:55 --> Session routines successfully run
DEBUG - 2012-04-08 08:50:55 --> Controller Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Model Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Model Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:50:55 --> Model Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Config Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:50:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:50:55 --> URI Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Router Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Output Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Security Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Input Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:50:55 --> Language Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Loader Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:50:55 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Session Class Initialized
DEBUG - 2012-04-08 08:50:55 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:50:55 --> Session routines successfully run
DEBUG - 2012-04-08 08:50:55 --> Controller Class Initialized
DEBUG - 2012-04-08 08:50:55 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:50:55 --> Final output sent to browser
DEBUG - 2012-04-08 08:50:55 --> Total execution time: 0.2568
DEBUG - 2012-04-08 08:50:57 --> Config Class Initialized
DEBUG - 2012-04-08 08:50:57 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:50:57 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:50:57 --> URI Class Initialized
DEBUG - 2012-04-08 08:50:57 --> Router Class Initialized
DEBUG - 2012-04-08 08:50:57 --> Output Class Initialized
DEBUG - 2012-04-08 08:50:57 --> Security Class Initialized
DEBUG - 2012-04-08 08:50:57 --> Input Class Initialized
DEBUG - 2012-04-08 08:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:50:57 --> Language Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Loader Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:50:58 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Session Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:50:58 --> Session routines successfully run
DEBUG - 2012-04-08 08:50:58 --> Controller Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Config Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:50:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:50:58 --> URI Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Router Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Output Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Security Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Input Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:50:58 --> Language Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Loader Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:50:58 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Session Class Initialized
DEBUG - 2012-04-08 08:50:58 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:50:58 --> A session cookie was not found.
DEBUG - 2012-04-08 08:50:58 --> Session routines successfully run
DEBUG - 2012-04-08 08:50:58 --> Controller Class Initialized
DEBUG - 2012-04-08 08:50:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:50:58 --> Final output sent to browser
DEBUG - 2012-04-08 08:50:58 --> Total execution time: 0.3109
DEBUG - 2012-04-08 08:51:01 --> Config Class Initialized
DEBUG - 2012-04-08 08:51:01 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:51:01 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:51:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:51:01 --> URI Class Initialized
DEBUG - 2012-04-08 08:51:01 --> Router Class Initialized
DEBUG - 2012-04-08 08:51:01 --> Output Class Initialized
DEBUG - 2012-04-08 08:51:01 --> Security Class Initialized
DEBUG - 2012-04-08 08:51:01 --> Input Class Initialized
DEBUG - 2012-04-08 08:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:51:01 --> Language Class Initialized
DEBUG - 2012-04-08 08:51:02 --> Loader Class Initialized
DEBUG - 2012-04-08 08:51:02 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:51:02 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:51:02 --> Session Class Initialized
DEBUG - 2012-04-08 08:51:02 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:51:02 --> Session routines successfully run
DEBUG - 2012-04-08 08:51:02 --> Controller Class Initialized
DEBUG - 2012-04-08 08:51:02 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 08:51:02 --> Final output sent to browser
DEBUG - 2012-04-08 08:51:02 --> Total execution time: 0.5854
DEBUG - 2012-04-08 08:51:13 --> Config Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:51:13 --> URI Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Router Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Output Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Security Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Input Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:51:13 --> Language Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Loader Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:51:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Session Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:51:13 --> Session routines successfully run
DEBUG - 2012-04-08 08:51:13 --> Controller Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Model Class Initialized
DEBUG - 2012-04-08 08:51:13 --> Model Class Initialized
DEBUG - 2012-04-08 08:51:13 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:51:13 --> Final output sent to browser
DEBUG - 2012-04-08 08:51:13 --> Total execution time: 0.3531
DEBUG - 2012-04-08 08:51:39 --> Config Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:51:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:51:39 --> URI Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Router Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Output Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Security Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Input Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:51:39 --> Language Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Loader Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:51:39 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Session Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:51:39 --> Session routines successfully run
DEBUG - 2012-04-08 08:51:39 --> Controller Class Initialized
DEBUG - 2012-04-08 08:51:39 --> Model Class Initialized
DEBUG - 2012-04-08 08:51:40 --> Model Class Initialized
DEBUG - 2012-04-08 08:51:40 --> Model Class Initialized
DEBUG - 2012-04-08 08:51:40 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-08 08:51:40 --> Final output sent to browser
DEBUG - 2012-04-08 08:51:40 --> Total execution time: 0.4013
DEBUG - 2012-04-08 08:51:50 --> Config Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:51:50 --> URI Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Router Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Output Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Security Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Input Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:51:50 --> Language Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Loader Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:51:50 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Session Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:51:50 --> Session routines successfully run
DEBUG - 2012-04-08 08:51:50 --> Controller Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Model Class Initialized
DEBUG - 2012-04-08 08:51:50 --> Model Class Initialized
DEBUG - 2012-04-08 08:51:50 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 08:51:50 --> Final output sent to browser
DEBUG - 2012-04-08 08:51:50 --> Total execution time: 0.3415
DEBUG - 2012-04-08 08:52:30 --> Config Class Initialized
DEBUG - 2012-04-08 08:52:30 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:52:30 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:52:30 --> URI Class Initialized
DEBUG - 2012-04-08 08:52:30 --> Router Class Initialized
DEBUG - 2012-04-08 08:52:30 --> Output Class Initialized
DEBUG - 2012-04-08 08:52:30 --> Security Class Initialized
DEBUG - 2012-04-08 08:52:30 --> Input Class Initialized
DEBUG - 2012-04-08 08:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:52:30 --> Language Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Loader Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:52:31 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Session Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:52:31 --> Session routines successfully run
DEBUG - 2012-04-08 08:52:31 --> Controller Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Model Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Model Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Helper loaded: email_helper
DEBUG - 2012-04-08 08:52:31 --> Model Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Config Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:52:31 --> URI Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Router Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Output Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Security Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Input Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:52:31 --> Language Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Loader Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:52:31 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Session Class Initialized
DEBUG - 2012-04-08 08:52:31 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:52:31 --> Session routines successfully run
DEBUG - 2012-04-08 08:52:31 --> Controller Class Initialized
DEBUG - 2012-04-08 08:52:31 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:52:31 --> Final output sent to browser
DEBUG - 2012-04-08 08:52:31 --> Total execution time: 0.2372
DEBUG - 2012-04-08 08:52:32 --> Config Class Initialized
DEBUG - 2012-04-08 08:52:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:52:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:52:32 --> URI Class Initialized
DEBUG - 2012-04-08 08:52:32 --> Router Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Output Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Security Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Input Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:52:33 --> Language Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Loader Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:52:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Session Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:52:33 --> Session routines successfully run
DEBUG - 2012-04-08 08:52:33 --> Controller Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Config Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:52:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:52:33 --> URI Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Router Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Output Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Security Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Input Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:52:33 --> Language Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Loader Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:52:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Session Class Initialized
DEBUG - 2012-04-08 08:52:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:52:33 --> A session cookie was not found.
DEBUG - 2012-04-08 08:52:33 --> Session routines successfully run
DEBUG - 2012-04-08 08:52:33 --> Controller Class Initialized
DEBUG - 2012-04-08 08:52:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:52:33 --> Final output sent to browser
DEBUG - 2012-04-08 08:52:33 --> Total execution time: 0.3275
DEBUG - 2012-04-08 08:52:43 --> Config Class Initialized
DEBUG - 2012-04-08 08:52:43 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:52:43 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:52:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:52:43 --> URI Class Initialized
DEBUG - 2012-04-08 08:52:43 --> Router Class Initialized
DEBUG - 2012-04-08 08:52:43 --> Output Class Initialized
DEBUG - 2012-04-08 08:52:44 --> Security Class Initialized
DEBUG - 2012-04-08 08:52:44 --> Input Class Initialized
DEBUG - 2012-04-08 08:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:52:44 --> Language Class Initialized
DEBUG - 2012-04-08 08:52:44 --> Loader Class Initialized
DEBUG - 2012-04-08 08:52:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:52:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:52:44 --> Session Class Initialized
DEBUG - 2012-04-08 08:52:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:52:44 --> Session routines successfully run
DEBUG - 2012-04-08 08:52:44 --> Controller Class Initialized
DEBUG - 2012-04-08 08:52:44 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 08:52:44 --> Final output sent to browser
DEBUG - 2012-04-08 08:52:44 --> Total execution time: 0.3555
DEBUG - 2012-04-08 08:52:45 --> Config Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:52:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:52:45 --> URI Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Router Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Output Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Security Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Input Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:52:45 --> Language Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Loader Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:52:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Session Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:52:45 --> Session routines successfully run
DEBUG - 2012-04-08 08:52:45 --> Controller Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Model Class Initialized
DEBUG - 2012-04-08 08:52:45 --> Model Class Initialized
DEBUG - 2012-04-08 08:52:45 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:52:45 --> Final output sent to browser
DEBUG - 2012-04-08 08:52:45 --> Total execution time: 0.4072
DEBUG - 2012-04-08 08:52:58 --> Config Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:52:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:52:58 --> URI Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Router Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Output Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Security Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Input Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:52:58 --> Language Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Loader Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:52:58 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Session Class Initialized
DEBUG - 2012-04-08 08:52:58 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:52:58 --> Session routines successfully run
DEBUG - 2012-04-08 08:52:58 --> Controller Class Initialized
DEBUG - 2012-04-08 08:52:59 --> Model Class Initialized
DEBUG - 2012-04-08 08:52:59 --> Model Class Initialized
DEBUG - 2012-04-08 08:52:59 --> Model Class Initialized
DEBUG - 2012-04-08 08:52:59 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 08:52:59 --> Final output sent to browser
DEBUG - 2012-04-08 08:52:59 --> Total execution time: 0.3924
DEBUG - 2012-04-08 08:53:00 --> Config Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:53:00 --> URI Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Router Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Output Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Security Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Input Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:53:00 --> Language Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Loader Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:53:00 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Session Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:53:00 --> Session routines successfully run
DEBUG - 2012-04-08 08:53:00 --> Controller Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Model Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Model Class Initialized
DEBUG - 2012-04-08 08:53:00 --> Final output sent to browser
DEBUG - 2012-04-08 08:53:00 --> Total execution time: 0.3586
DEBUG - 2012-04-08 08:53:02 --> Config Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:53:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:53:02 --> URI Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Router Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Output Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Security Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Input Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:53:02 --> Language Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Loader Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:53:02 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Session Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:53:02 --> Session routines successfully run
DEBUG - 2012-04-08 08:53:02 --> Controller Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Model Class Initialized
DEBUG - 2012-04-08 08:53:02 --> Model Class Initialized
DEBUG - 2012-04-08 08:53:02 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 08:53:02 --> Final output sent to browser
DEBUG - 2012-04-08 08:53:02 --> Total execution time: 0.4683
DEBUG - 2012-04-08 08:53:29 --> Config Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:53:29 --> URI Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Router Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Output Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Security Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Input Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:53:29 --> Language Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Loader Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:53:29 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Session Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:53:29 --> Session routines successfully run
DEBUG - 2012-04-08 08:53:29 --> Controller Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Model Class Initialized
DEBUG - 2012-04-08 08:53:29 --> Model Class Initialized
DEBUG - 2012-04-08 08:53:29 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 08:53:29 --> Final output sent to browser
DEBUG - 2012-04-08 08:53:29 --> Total execution time: 0.2608
DEBUG - 2012-04-08 08:53:58 --> Config Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:53:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:53:58 --> URI Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Router Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Output Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Security Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Input Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:53:58 --> Language Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Loader Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:53:58 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Session Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:53:58 --> Session routines successfully run
DEBUG - 2012-04-08 08:53:58 --> Controller Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Model Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Model Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Config Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Hooks Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Utf8 Class Initialized
DEBUG - 2012-04-08 08:53:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 08:53:58 --> URI Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Router Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Output Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Security Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Input Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 08:53:58 --> Language Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Loader Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Helper loaded: url_helper
DEBUG - 2012-04-08 08:53:58 --> Database Driver Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Session Class Initialized
DEBUG - 2012-04-08 08:53:58 --> Helper loaded: string_helper
DEBUG - 2012-04-08 08:53:58 --> Session routines successfully run
DEBUG - 2012-04-08 08:53:58 --> Controller Class Initialized
DEBUG - 2012-04-08 08:53:58 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 08:53:58 --> Final output sent to browser
DEBUG - 2012-04-08 08:53:58 --> Total execution time: 0.2361
DEBUG - 2012-04-08 09:24:09 --> Config Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:24:09 --> URI Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Router Class Initialized
DEBUG - 2012-04-08 09:24:09 --> No URI present. Default controller set.
DEBUG - 2012-04-08 09:24:09 --> Output Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Security Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Input Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:24:09 --> Language Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Loader Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:24:09 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Session Class Initialized
DEBUG - 2012-04-08 09:24:09 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:24:09 --> Session routines successfully run
DEBUG - 2012-04-08 09:24:09 --> Controller Class Initialized
DEBUG - 2012-04-08 09:24:10 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 09:24:10 --> Final output sent to browser
DEBUG - 2012-04-08 09:24:10 --> Total execution time: 0.9354
DEBUG - 2012-04-08 09:24:12 --> Config Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:24:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:24:12 --> URI Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Router Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Output Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Security Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Input Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:24:12 --> Language Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Loader Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:24:12 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Session Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:24:12 --> Session routines successfully run
DEBUG - 2012-04-08 09:24:12 --> Controller Class Initialized
DEBUG - 2012-04-08 09:24:12 --> Config Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:24:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:24:13 --> URI Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Router Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Output Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Security Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Input Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:24:13 --> Language Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Loader Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:24:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Session Class Initialized
DEBUG - 2012-04-08 09:24:13 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:24:13 --> A session cookie was not found.
DEBUG - 2012-04-08 09:24:13 --> Session routines successfully run
DEBUG - 2012-04-08 09:24:13 --> Controller Class Initialized
DEBUG - 2012-04-08 09:24:13 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:24:13 --> Final output sent to browser
DEBUG - 2012-04-08 09:24:13 --> Total execution time: 0.4238
DEBUG - 2012-04-08 09:24:27 --> Config Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:24:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:24:27 --> URI Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Router Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Output Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Security Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Input Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:24:27 --> Language Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Loader Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:24:27 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Session Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:24:27 --> Session routines successfully run
DEBUG - 2012-04-08 09:24:27 --> Controller Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Model Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Model Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Config Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:24:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:24:27 --> URI Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Router Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Output Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Security Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Input Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:24:27 --> Language Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Loader Class Initialized
DEBUG - 2012-04-08 09:24:27 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:24:28 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:24:28 --> Session Class Initialized
DEBUG - 2012-04-08 09:24:28 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:24:28 --> Session routines successfully run
DEBUG - 2012-04-08 09:24:28 --> Controller Class Initialized
DEBUG - 2012-04-08 09:24:28 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 09:24:28 --> Final output sent to browser
DEBUG - 2012-04-08 09:24:28 --> Total execution time: 0.2633
DEBUG - 2012-04-08 09:24:30 --> Config Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:24:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:24:30 --> URI Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Router Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Output Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Security Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Input Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:24:30 --> Language Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Loader Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:24:30 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Session Class Initialized
DEBUG - 2012-04-08 09:24:30 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:24:30 --> Session routines successfully run
DEBUG - 2012-04-08 09:24:30 --> Controller Class Initialized
DEBUG - 2012-04-08 09:24:30 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:24:30 --> Final output sent to browser
DEBUG - 2012-04-08 09:24:30 --> Total execution time: 0.4173
DEBUG - 2012-04-08 09:25:53 --> Config Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:25:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:25:53 --> URI Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Router Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Output Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Security Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Input Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:25:53 --> Language Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Loader Class Initialized
DEBUG - 2012-04-08 09:25:53 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:25:54 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:25:54 --> Session Class Initialized
DEBUG - 2012-04-08 09:25:54 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:25:54 --> Session routines successfully run
DEBUG - 2012-04-08 09:25:54 --> Controller Class Initialized
DEBUG - 2012-04-08 09:25:54 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:25:54 --> Final output sent to browser
DEBUG - 2012-04-08 09:25:54 --> Total execution time: 0.2986
DEBUG - 2012-04-08 09:26:02 --> Config Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:26:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:26:02 --> URI Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Router Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Output Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Security Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Input Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:26:02 --> Language Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Loader Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:26:02 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Session Class Initialized
DEBUG - 2012-04-08 09:26:02 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:26:02 --> Session routines successfully run
DEBUG - 2012-04-08 09:26:02 --> Controller Class Initialized
ERROR - 2012-04-08 09:26:02 --> 404 Page Not Found --> accounts/changePassoword
DEBUG - 2012-04-08 09:29:47 --> Config Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:29:47 --> URI Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Router Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Output Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Security Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Input Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:29:47 --> Language Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Loader Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:29:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Session Class Initialized
DEBUG - 2012-04-08 09:29:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:29:47 --> Session routines successfully run
DEBUG - 2012-04-08 09:29:48 --> Controller Class Initialized
ERROR - 2012-04-08 09:29:48 --> 404 Page Not Found --> accounts/changePassoword
DEBUG - 2012-04-08 09:30:36 --> Config Class Initialized
DEBUG - 2012-04-08 09:30:36 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:30:36 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:30:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:30:36 --> URI Class Initialized
DEBUG - 2012-04-08 09:30:36 --> Router Class Initialized
DEBUG - 2012-04-08 09:30:36 --> Output Class Initialized
DEBUG - 2012-04-08 09:30:37 --> Security Class Initialized
DEBUG - 2012-04-08 09:30:37 --> Input Class Initialized
DEBUG - 2012-04-08 09:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:30:37 --> Language Class Initialized
DEBUG - 2012-04-08 09:30:37 --> Loader Class Initialized
DEBUG - 2012-04-08 09:30:37 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:30:37 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:30:37 --> Session Class Initialized
DEBUG - 2012-04-08 09:30:37 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:30:37 --> Session routines successfully run
DEBUG - 2012-04-08 09:30:37 --> Controller Class Initialized
DEBUG - 2012-04-08 09:30:37 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:30:37 --> Final output sent to browser
DEBUG - 2012-04-08 09:30:37 --> Total execution time: 0.4748
DEBUG - 2012-04-08 09:30:44 --> Config Class Initialized
DEBUG - 2012-04-08 09:30:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:30:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:30:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:30:44 --> URI Class Initialized
DEBUG - 2012-04-08 09:30:44 --> Router Class Initialized
DEBUG - 2012-04-08 09:30:44 --> Output Class Initialized
DEBUG - 2012-04-08 09:30:44 --> Security Class Initialized
DEBUG - 2012-04-08 09:30:44 --> Input Class Initialized
DEBUG - 2012-04-08 09:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:30:44 --> Language Class Initialized
DEBUG - 2012-04-08 09:30:45 --> Loader Class Initialized
DEBUG - 2012-04-08 09:30:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:30:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:30:45 --> Session Class Initialized
DEBUG - 2012-04-08 09:30:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:30:45 --> Session routines successfully run
DEBUG - 2012-04-08 09:30:45 --> Controller Class Initialized
DEBUG - 2012-04-08 09:30:45 --> Model Class Initialized
DEBUG - 2012-04-08 09:30:45 --> Model Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Config Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:30:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:30:46 --> URI Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Router Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Output Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Security Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Input Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:30:46 --> Language Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Loader Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:30:46 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Session Class Initialized
DEBUG - 2012-04-08 09:30:46 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:30:46 --> Session routines successfully run
DEBUG - 2012-04-08 09:30:46 --> Controller Class Initialized
DEBUG - 2012-04-08 09:30:46 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 09:30:46 --> Final output sent to browser
DEBUG - 2012-04-08 09:30:46 --> Total execution time: 0.4281
DEBUG - 2012-04-08 09:35:43 --> Config Class Initialized
DEBUG - 2012-04-08 09:35:43 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:35:43 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:35:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:35:43 --> URI Class Initialized
DEBUG - 2012-04-08 09:35:43 --> Router Class Initialized
DEBUG - 2012-04-08 09:35:43 --> Output Class Initialized
DEBUG - 2012-04-08 09:35:43 --> Security Class Initialized
DEBUG - 2012-04-08 09:35:43 --> Input Class Initialized
DEBUG - 2012-04-08 09:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:35:43 --> Language Class Initialized
DEBUG - 2012-04-08 09:35:44 --> Loader Class Initialized
DEBUG - 2012-04-08 09:35:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:35:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:35:44 --> Session Class Initialized
DEBUG - 2012-04-08 09:35:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:35:44 --> Session routines successfully run
DEBUG - 2012-04-08 09:35:44 --> Controller Class Initialized
DEBUG - 2012-04-08 09:35:44 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:35:44 --> Final output sent to browser
DEBUG - 2012-04-08 09:35:44 --> Total execution time: 0.7377
DEBUG - 2012-04-08 09:35:58 --> Config Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:35:58 --> URI Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Router Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Output Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Security Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Input Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:35:58 --> Language Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Loader Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:35:58 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Session Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:35:58 --> Session routines successfully run
DEBUG - 2012-04-08 09:35:58 --> Controller Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Model Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Model Class Initialized
DEBUG - 2012-04-08 09:35:58 --> Final output sent to browser
DEBUG - 2012-04-08 09:35:58 --> Total execution time: 0.4298
DEBUG - 2012-04-08 09:36:01 --> Config Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:36:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:36:01 --> URI Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Router Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Output Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Security Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Input Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:36:01 --> Language Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Loader Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:36:01 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Session Class Initialized
DEBUG - 2012-04-08 09:36:01 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:36:01 --> Session routines successfully run
DEBUG - 2012-04-08 09:36:01 --> Controller Class Initialized
DEBUG - 2012-04-08 09:36:01 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 09:36:01 --> Final output sent to browser
DEBUG - 2012-04-08 09:36:01 --> Total execution time: 0.3322
DEBUG - 2012-04-08 09:39:14 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:14 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:14 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:14 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:14 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:14 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:14 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:14 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:14 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:15 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:15 --> A session cookie was not found.
DEBUG - 2012-04-08 09:39:15 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:15 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:39:15 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:15 --> Total execution time: 0.3405
DEBUG - 2012-04-08 09:39:22 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:22 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:22 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:22 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:22 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:22 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Model Class Initialized
DEBUG - 2012-04-08 09:39:22 --> Model Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:23 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:23 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:23 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:23 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:23 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 09:39:23 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:23 --> Total execution time: 0.2651
DEBUG - 2012-04-08 09:39:25 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:25 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:25 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:25 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:25 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:25 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:25 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:39:25 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:25 --> Total execution time: 0.6057
DEBUG - 2012-04-08 09:39:33 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:33 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:33 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:34 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:34 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:34 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:34 --> Model Class Initialized
DEBUG - 2012-04-08 09:39:34 --> Model Class Initialized
DEBUG - 2012-04-08 09:39:34 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:34 --> Total execution time: 0.3563
DEBUG - 2012-04-08 09:39:36 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:36 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:36 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:36 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:36 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:36 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:36 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 09:39:36 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:36 --> Total execution time: 0.5268
DEBUG - 2012-04-08 09:39:40 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:40 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:40 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:40 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:40 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:40 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:40 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:40 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:41 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:41 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:41 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:41 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:39:41 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:41 --> Total execution time: 0.3603
DEBUG - 2012-04-08 09:39:47 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:47 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:47 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:48 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:48 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:48 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:48 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Model Class Initialized
DEBUG - 2012-04-08 09:39:48 --> Model Class Initialized
DEBUG - 2012-04-08 09:39:48 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:39:48 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:48 --> Total execution time: 0.3472
DEBUG - 2012-04-08 09:39:55 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:55 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:55 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:55 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:56 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:56 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:56 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:56 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Model Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Model Class Initialized
DEBUG - 2012-04-08 09:39:56 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:56 --> Total execution time: 0.4668
DEBUG - 2012-04-08 09:39:58 --> Config Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:39:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:39:58 --> URI Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Router Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Output Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Security Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Input Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:39:58 --> Language Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Loader Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:39:58 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Session Class Initialized
DEBUG - 2012-04-08 09:39:58 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:39:58 --> Session routines successfully run
DEBUG - 2012-04-08 09:39:59 --> Controller Class Initialized
DEBUG - 2012-04-08 09:39:59 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 09:39:59 --> Final output sent to browser
DEBUG - 2012-04-08 09:39:59 --> Total execution time: 0.4410
DEBUG - 2012-04-08 09:40:00 --> Config Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:40:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:40:00 --> URI Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Router Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Output Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Security Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Input Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:40:00 --> Language Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Loader Class Initialized
DEBUG - 2012-04-08 09:40:00 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:40:01 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Session Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:40:01 --> Session routines successfully run
DEBUG - 2012-04-08 09:40:01 --> Controller Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Config Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:40:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:40:01 --> URI Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Router Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Output Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Security Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Input Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:40:01 --> Language Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Loader Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:40:01 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Session Class Initialized
DEBUG - 2012-04-08 09:40:01 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:40:01 --> A session cookie was not found.
DEBUG - 2012-04-08 09:40:01 --> Session routines successfully run
DEBUG - 2012-04-08 09:40:01 --> Controller Class Initialized
DEBUG - 2012-04-08 09:40:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:40:01 --> Final output sent to browser
DEBUG - 2012-04-08 09:40:01 --> Total execution time: 0.2766
DEBUG - 2012-04-08 09:42:44 --> Config Class Initialized
DEBUG - 2012-04-08 09:42:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:42:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:42:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:42:45 --> URI Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Router Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Output Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Security Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Input Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:42:45 --> Language Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Loader Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:42:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Session Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:42:45 --> Session routines successfully run
DEBUG - 2012-04-08 09:42:45 --> Controller Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Model Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Model Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Config Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:42:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:42:45 --> URI Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Router Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Output Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Security Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Input Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:42:45 --> Language Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Loader Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:42:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Session Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:42:45 --> Session routines successfully run
DEBUG - 2012-04-08 09:42:45 --> Controller Class Initialized
DEBUG - 2012-04-08 09:42:45 --> Final output sent to browser
DEBUG - 2012-04-08 09:42:45 --> Total execution time: 0.3556
DEBUG - 2012-04-08 09:43:40 --> Config Class Initialized
DEBUG - 2012-04-08 09:43:40 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:43:40 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:43:40 --> URI Class Initialized
DEBUG - 2012-04-08 09:43:40 --> Router Class Initialized
DEBUG - 2012-04-08 09:43:40 --> Output Class Initialized
DEBUG - 2012-04-08 09:43:41 --> Security Class Initialized
DEBUG - 2012-04-08 09:43:41 --> Input Class Initialized
DEBUG - 2012-04-08 09:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:43:41 --> Language Class Initialized
DEBUG - 2012-04-08 09:43:41 --> Loader Class Initialized
DEBUG - 2012-04-08 09:43:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:43:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:43:41 --> Session Class Initialized
DEBUG - 2012-04-08 09:43:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:43:41 --> Session routines successfully run
DEBUG - 2012-04-08 09:43:41 --> Controller Class Initialized
DEBUG - 2012-04-08 09:43:41 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-08 09:43:41 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:43:41 --> Final output sent to browser
DEBUG - 2012-04-08 09:43:41 --> Total execution time: 0.2861
DEBUG - 2012-04-08 09:43:47 --> Config Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:43:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:43:47 --> URI Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Router Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Output Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Security Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Input Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:43:47 --> Language Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Loader Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:43:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Session Class Initialized
DEBUG - 2012-04-08 09:43:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:43:47 --> Session routines successfully run
DEBUG - 2012-04-08 09:43:47 --> Controller Class Initialized
DEBUG - 2012-04-08 09:43:47 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:43:47 --> Final output sent to browser
DEBUG - 2012-04-08 09:43:47 --> Total execution time: 0.3190
DEBUG - 2012-04-08 09:43:54 --> Config Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:43:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:43:54 --> URI Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Router Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Output Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Security Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Input Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:43:54 --> Language Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Loader Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:43:54 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Session Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:43:54 --> Session routines successfully run
DEBUG - 2012-04-08 09:43:54 --> Controller Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Model Class Initialized
DEBUG - 2012-04-08 09:43:54 --> Model Class Initialized
DEBUG - 2012-04-08 09:43:55 --> Final output sent to browser
DEBUG - 2012-04-08 09:43:55 --> Total execution time: 0.4636
DEBUG - 2012-04-08 09:43:57 --> Config Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:43:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:43:57 --> URI Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Router Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Output Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Security Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Input Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:43:57 --> Language Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Loader Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:43:57 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Session Class Initialized
DEBUG - 2012-04-08 09:43:57 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:43:57 --> Session routines successfully run
DEBUG - 2012-04-08 09:43:57 --> Controller Class Initialized
DEBUG - 2012-04-08 09:43:57 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-08 09:43:57 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:43:57 --> Final output sent to browser
DEBUG - 2012-04-08 09:43:57 --> Total execution time: 0.4572
DEBUG - 2012-04-08 09:44:00 --> Config Class Initialized
DEBUG - 2012-04-08 09:44:00 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:44:00 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:44:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:44:00 --> URI Class Initialized
DEBUG - 2012-04-08 09:44:00 --> Router Class Initialized
DEBUG - 2012-04-08 09:44:00 --> Output Class Initialized
DEBUG - 2012-04-08 09:44:00 --> Security Class Initialized
DEBUG - 2012-04-08 09:44:00 --> Input Class Initialized
DEBUG - 2012-04-08 09:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:44:00 --> Language Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Loader Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:44:01 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Session Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:44:01 --> Session routines successfully run
DEBUG - 2012-04-08 09:44:01 --> Controller Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Config Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:44:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:44:01 --> URI Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Router Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Output Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Security Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Input Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:44:01 --> Language Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Loader Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:44:01 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Session Class Initialized
DEBUG - 2012-04-08 09:44:01 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:44:01 --> A session cookie was not found.
DEBUG - 2012-04-08 09:44:01 --> Session routines successfully run
DEBUG - 2012-04-08 09:44:01 --> Controller Class Initialized
DEBUG - 2012-04-08 09:44:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:44:01 --> Final output sent to browser
DEBUG - 2012-04-08 09:44:01 --> Total execution time: 0.4223
DEBUG - 2012-04-08 09:44:08 --> Config Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:44:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:44:08 --> URI Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Router Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Output Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Security Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Input Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:44:08 --> Language Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Loader Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:44:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Session Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:44:08 --> Session routines successfully run
DEBUG - 2012-04-08 09:44:08 --> Controller Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Model Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Model Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Config Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:44:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:44:08 --> URI Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Router Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Output Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Security Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Input Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:44:08 --> Language Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Loader Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:44:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Session Class Initialized
DEBUG - 2012-04-08 09:44:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:44:08 --> Session routines successfully run
DEBUG - 2012-04-08 09:44:08 --> Controller Class Initialized
DEBUG - 2012-04-08 09:44:08 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-08 09:44:08 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:44:08 --> Final output sent to browser
DEBUG - 2012-04-08 09:44:08 --> Total execution time: 0.3769
DEBUG - 2012-04-08 09:44:10 --> Config Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:44:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:44:10 --> URI Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Router Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Output Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Security Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Input Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:44:10 --> Language Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Loader Class Initialized
DEBUG - 2012-04-08 09:44:10 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:44:11 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:44:11 --> Session Class Initialized
DEBUG - 2012-04-08 09:44:11 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:44:11 --> Session routines successfully run
DEBUG - 2012-04-08 09:44:11 --> Controller Class Initialized
DEBUG - 2012-04-08 09:44:11 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:44:11 --> Final output sent to browser
DEBUG - 2012-04-08 09:44:11 --> Total execution time: 0.4908
DEBUG - 2012-04-08 09:44:17 --> Config Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:44:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:44:17 --> URI Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Router Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Output Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Security Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Input Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:44:17 --> Language Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Loader Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:44:17 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Session Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:44:17 --> Session routines successfully run
DEBUG - 2012-04-08 09:44:17 --> Controller Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Model Class Initialized
DEBUG - 2012-04-08 09:44:17 --> Model Class Initialized
DEBUG - 2012-04-08 09:44:18 --> Final output sent to browser
DEBUG - 2012-04-08 09:44:18 --> Total execution time: 0.4228
DEBUG - 2012-04-08 09:44:20 --> Config Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:44:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:44:20 --> URI Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Router Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Output Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Security Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Input Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:44:20 --> Language Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Loader Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:44:20 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Session Class Initialized
DEBUG - 2012-04-08 09:44:20 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:44:20 --> Session routines successfully run
DEBUG - 2012-04-08 09:44:20 --> Controller Class Initialized
DEBUG - 2012-04-08 09:44:20 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-08 09:44:20 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:44:20 --> Final output sent to browser
DEBUG - 2012-04-08 09:44:20 --> Total execution time: 0.4674
DEBUG - 2012-04-08 09:45:32 --> Config Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:45:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:45:32 --> URI Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Router Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Output Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Security Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Input Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:45:32 --> Language Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Loader Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:45:32 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Session Class Initialized
DEBUG - 2012-04-08 09:45:32 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:45:32 --> Session routines successfully run
DEBUG - 2012-04-08 09:45:32 --> Controller Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Config Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:45:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:45:33 --> URI Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Router Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Output Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Security Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Input Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:45:33 --> Language Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Loader Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:45:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Session Class Initialized
DEBUG - 2012-04-08 09:45:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:45:33 --> A session cookie was not found.
DEBUG - 2012-04-08 09:45:33 --> Session routines successfully run
DEBUG - 2012-04-08 09:45:33 --> Controller Class Initialized
DEBUG - 2012-04-08 09:45:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:45:33 --> Final output sent to browser
DEBUG - 2012-04-08 09:45:33 --> Total execution time: 0.3053
DEBUG - 2012-04-08 09:45:34 --> Config Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:45:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:45:34 --> URI Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Router Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Output Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Security Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Input Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:45:34 --> Language Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Loader Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:45:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Session Class Initialized
DEBUG - 2012-04-08 09:45:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:45:34 --> Session routines successfully run
DEBUG - 2012-04-08 09:45:34 --> Controller Class Initialized
DEBUG - 2012-04-08 09:45:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:45:34 --> Final output sent to browser
DEBUG - 2012-04-08 09:45:34 --> Total execution time: 0.3202
DEBUG - 2012-04-08 09:45:41 --> Config Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:45:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:45:41 --> URI Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Router Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Output Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Security Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Input Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:45:41 --> Language Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Loader Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:45:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Session Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:45:41 --> Session routines successfully run
DEBUG - 2012-04-08 09:45:41 --> Controller Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Model Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Model Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Config Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:45:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:45:41 --> URI Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Router Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Output Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Security Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Input Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:45:41 --> Language Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Loader Class Initialized
DEBUG - 2012-04-08 09:45:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:45:42 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:45:42 --> Session Class Initialized
DEBUG - 2012-04-08 09:45:42 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:45:42 --> Session routines successfully run
DEBUG - 2012-04-08 09:45:42 --> Controller Class Initialized
DEBUG - 2012-04-08 09:45:42 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-08 09:45:42 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:45:42 --> Final output sent to browser
DEBUG - 2012-04-08 09:45:42 --> Total execution time: 0.3409
DEBUG - 2012-04-08 09:45:53 --> Config Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:45:53 --> URI Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Router Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Output Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Security Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Input Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:45:53 --> Language Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Loader Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:45:53 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Session Class Initialized
DEBUG - 2012-04-08 09:45:53 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:45:53 --> Session routines successfully run
DEBUG - 2012-04-08 09:45:53 --> Controller Class Initialized
DEBUG - 2012-04-08 09:45:53 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-08 09:45:53 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:45:53 --> Final output sent to browser
DEBUG - 2012-04-08 09:45:53 --> Total execution time: 0.3640
DEBUG - 2012-04-08 09:45:57 --> Config Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:45:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:45:57 --> URI Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Router Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Output Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Security Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Input Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:45:57 --> Language Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Loader Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:45:57 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Session Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:45:57 --> Session routines successfully run
DEBUG - 2012-04-08 09:45:57 --> Controller Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Config Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:45:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:45:57 --> URI Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Router Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Output Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Security Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Input Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:45:57 --> Language Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Loader Class Initialized
DEBUG - 2012-04-08 09:45:57 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:45:58 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:45:58 --> Session Class Initialized
DEBUG - 2012-04-08 09:45:58 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:45:58 --> A session cookie was not found.
DEBUG - 2012-04-08 09:45:58 --> Session routines successfully run
DEBUG - 2012-04-08 09:45:58 --> Controller Class Initialized
DEBUG - 2012-04-08 09:45:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:45:58 --> Final output sent to browser
DEBUG - 2012-04-08 09:45:58 --> Total execution time: 0.5623
DEBUG - 2012-04-08 09:46:32 --> Config Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:46:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:46:32 --> URI Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Router Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Output Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Security Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Input Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:46:32 --> Language Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Loader Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:46:32 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Session Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:46:32 --> Session routines successfully run
DEBUG - 2012-04-08 09:46:32 --> Controller Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Model Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Model Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Config Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:46:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:46:32 --> URI Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Router Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Output Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Security Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Input Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:46:32 --> Language Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Loader Class Initialized
DEBUG - 2012-04-08 09:46:32 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:46:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:46:33 --> Session Class Initialized
DEBUG - 2012-04-08 09:46:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:46:33 --> Session routines successfully run
DEBUG - 2012-04-08 09:46:33 --> Controller Class Initialized
DEBUG - 2012-04-08 09:46:33 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 09:46:33 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:46:33 --> Final output sent to browser
DEBUG - 2012-04-08 09:46:33 --> Total execution time: 0.3151
DEBUG - 2012-04-08 09:46:38 --> Config Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:46:38 --> URI Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Router Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Output Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Security Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Input Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:46:38 --> Language Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Loader Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:46:38 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Session Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:46:38 --> Session routines successfully run
DEBUG - 2012-04-08 09:46:38 --> Controller Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Config Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:46:38 --> URI Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Router Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Output Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Security Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Input Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:46:38 --> Language Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Loader Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:46:38 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Session Class Initialized
DEBUG - 2012-04-08 09:46:38 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:46:38 --> A session cookie was not found.
DEBUG - 2012-04-08 09:46:38 --> Session routines successfully run
DEBUG - 2012-04-08 09:46:38 --> Controller Class Initialized
DEBUG - 2012-04-08 09:46:38 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:46:38 --> Final output sent to browser
DEBUG - 2012-04-08 09:46:38 --> Total execution time: 0.2871
DEBUG - 2012-04-08 09:47:03 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:03 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:03 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:03 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:03 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:03 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:03 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:04 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:04 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:04 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:04 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:04 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:04 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:04 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:04 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:04 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:04 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 09:47:04 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:47:04 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:04 --> Total execution time: 0.2854
DEBUG - 2012-04-08 09:47:06 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:06 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:06 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:06 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:06 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:07 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:07 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:07 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:07 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:07 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:07 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:07 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:07 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:07 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:07 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:07 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:07 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:47:07 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:07 --> Total execution time: 0.3874
DEBUG - 2012-04-08 09:47:13 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:13 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:13 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:13 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:13 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:13 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:13 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:47:13 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:13 --> Total execution time: 0.3243
DEBUG - 2012-04-08 09:47:21 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:21 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:21 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:21 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:21 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:21 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:21 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:21 --> Total execution time: 0.3766
DEBUG - 2012-04-08 09:47:24 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:24 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:24 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:24 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:24 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:24 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 09:47:24 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:47:24 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:24 --> Total execution time: 0.6563
DEBUG - 2012-04-08 09:47:25 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:25 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:25 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:25 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:25 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:25 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:25 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:26 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:26 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:26 --> A session cookie was not found.
DEBUG - 2012-04-08 09:47:26 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:26 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:26 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:47:26 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:26 --> Total execution time: 0.4690
DEBUG - 2012-04-08 09:47:32 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:33 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:33 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:33 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:33 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:33 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:33 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:34 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:34 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:34 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:34 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:34 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 09:47:34 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:47:34 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:34 --> Total execution time: 0.5124
DEBUG - 2012-04-08 09:47:35 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:35 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:35 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:35 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:36 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:36 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:36 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:36 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:36 --> File loaded: system/views/changePassword.php
DEBUG - 2012-04-08 09:47:36 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:36 --> Total execution time: 0.4237
DEBUG - 2012-04-08 09:47:42 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:42 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:42 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:42 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:42 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:42 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:42 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:42 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:42 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:43 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:43 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:43 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:43 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:43 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:43 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:43 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:43 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:43 --> Model Class Initialized
DEBUG - 2012-04-08 09:47:43 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:43 --> Total execution time: 0.3262
DEBUG - 2012-04-08 09:47:45 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:45 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:45 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:45 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:45 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:45 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 09:47:46 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:47:46 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:46 --> Total execution time: 0.6169
DEBUG - 2012-04-08 09:47:46 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:46 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:46 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:46 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:46 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:46 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:46 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:47 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:47 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Config Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:47:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:47:47 --> URI Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Router Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Output Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Security Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Input Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:47:47 --> Language Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Loader Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:47:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Session Class Initialized
DEBUG - 2012-04-08 09:47:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:47:47 --> A session cookie was not found.
DEBUG - 2012-04-08 09:47:47 --> Session routines successfully run
DEBUG - 2012-04-08 09:47:47 --> Controller Class Initialized
DEBUG - 2012-04-08 09:47:47 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:47:47 --> Final output sent to browser
DEBUG - 2012-04-08 09:47:47 --> Total execution time: 0.3888
DEBUG - 2012-04-08 09:49:07 --> Config Class Initialized
DEBUG - 2012-04-08 09:49:07 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:49:07 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:49:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:49:07 --> URI Class Initialized
DEBUG - 2012-04-08 09:49:07 --> Router Class Initialized
DEBUG - 2012-04-08 09:49:07 --> Output Class Initialized
DEBUG - 2012-04-08 09:49:07 --> Security Class Initialized
DEBUG - 2012-04-08 09:49:07 --> Input Class Initialized
DEBUG - 2012-04-08 09:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:49:07 --> Language Class Initialized
DEBUG - 2012-04-08 09:49:08 --> Loader Class Initialized
DEBUG - 2012-04-08 09:49:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:49:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:49:08 --> Session Class Initialized
DEBUG - 2012-04-08 09:49:08 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:49:08 --> Session routines successfully run
DEBUG - 2012-04-08 09:49:08 --> Controller Class Initialized
DEBUG - 2012-04-08 09:49:08 --> Model Class Initialized
DEBUG - 2012-04-08 09:49:08 --> Model Class Initialized
DEBUG - 2012-04-08 09:49:08 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 09:49:08 --> Final output sent to browser
DEBUG - 2012-04-08 09:49:08 --> Total execution time: 1.6365
DEBUG - 2012-04-08 09:50:13 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:13 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:13 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:13 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:13 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:14 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:14 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Helper loaded: email_helper
DEBUG - 2012-04-08 09:50:14 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:14 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:14 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:14 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:14 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:14 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:14 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:14 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-08 09:50:14 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:50:14 --> Final output sent to browser
DEBUG - 2012-04-08 09:50:14 --> Total execution time: 0.3428
DEBUG - 2012-04-08 09:50:19 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:19 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:19 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:19 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:19 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:20 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:20 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:20 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:20 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:20 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:20 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:20 --> A session cookie was not found.
DEBUG - 2012-04-08 09:50:20 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:20 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:20 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:50:20 --> Final output sent to browser
DEBUG - 2012-04-08 09:50:20 --> Total execution time: 0.3442
DEBUG - 2012-04-08 09:50:30 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:30 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:30 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:30 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:30 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:30 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:30 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:30 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:30 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:30 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:30 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:30 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:30 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 09:50:30 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:50:30 --> Final output sent to browser
DEBUG - 2012-04-08 09:50:30 --> Total execution time: 0.3174
DEBUG - 2012-04-08 09:50:32 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:32 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:32 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:32 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:32 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:32 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:32 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:32 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:32 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:33 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:33 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:33 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:33 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:33 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:33 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:33 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:33 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:33 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:33 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 09:50:33 --> Final output sent to browser
DEBUG - 2012-04-08 09:50:33 --> Total execution time: 0.7620
DEBUG - 2012-04-08 09:50:44 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:44 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:44 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:44 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:44 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:44 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:44 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:44 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-08 09:50:44 --> Final output sent to browser
DEBUG - 2012-04-08 09:50:44 --> Total execution time: 0.3664
DEBUG - 2012-04-08 09:50:47 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:47 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:47 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:47 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:47 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:47 --> Final output sent to browser
DEBUG - 2012-04-08 09:50:47 --> Total execution time: 0.6015
DEBUG - 2012-04-08 09:50:48 --> Config Class Initialized
DEBUG - 2012-04-08 09:50:48 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:50:48 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:50:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:50:48 --> URI Class Initialized
DEBUG - 2012-04-08 09:50:48 --> Router Class Initialized
DEBUG - 2012-04-08 09:50:48 --> Output Class Initialized
DEBUG - 2012-04-08 09:50:48 --> Security Class Initialized
DEBUG - 2012-04-08 09:50:48 --> Input Class Initialized
DEBUG - 2012-04-08 09:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:50:48 --> Language Class Initialized
DEBUG - 2012-04-08 09:50:48 --> Loader Class Initialized
DEBUG - 2012-04-08 09:50:49 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:50:49 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:50:49 --> Session Class Initialized
DEBUG - 2012-04-08 09:50:49 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:50:49 --> Session routines successfully run
DEBUG - 2012-04-08 09:50:49 --> Controller Class Initialized
DEBUG - 2012-04-08 09:50:49 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:49 --> Model Class Initialized
DEBUG - 2012-04-08 09:50:49 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 09:50:49 --> Final output sent to browser
DEBUG - 2012-04-08 09:50:49 --> Total execution time: 0.5118
DEBUG - 2012-04-08 09:54:06 --> Config Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:54:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:54:06 --> URI Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Router Class Initialized
DEBUG - 2012-04-08 09:54:06 --> No URI present. Default controller set.
DEBUG - 2012-04-08 09:54:06 --> Output Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Security Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Input Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:54:06 --> Language Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Loader Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:54:06 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Session Class Initialized
DEBUG - 2012-04-08 09:54:06 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:54:06 --> Session routines successfully run
DEBUG - 2012-04-08 09:54:06 --> Controller Class Initialized
DEBUG - 2012-04-08 09:54:06 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 09:54:06 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:54:06 --> Final output sent to browser
DEBUG - 2012-04-08 09:54:06 --> Total execution time: 0.3094
DEBUG - 2012-04-08 09:54:09 --> Config Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:54:09 --> URI Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Router Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Output Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Security Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Input Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:54:09 --> Language Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Loader Class Initialized
DEBUG - 2012-04-08 09:54:09 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:54:10 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:54:10 --> Session Class Initialized
DEBUG - 2012-04-08 09:54:10 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:54:10 --> Session routines successfully run
DEBUG - 2012-04-08 09:54:10 --> Controller Class Initialized
DEBUG - 2012-04-08 09:54:10 --> Model Class Initialized
DEBUG - 2012-04-08 09:54:10 --> Model Class Initialized
DEBUG - 2012-04-08 09:54:10 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-08 09:54:10 --> Final output sent to browser
DEBUG - 2012-04-08 09:54:10 --> Total execution time: 0.4474
DEBUG - 2012-04-08 09:54:15 --> Config Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:54:15 --> URI Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Router Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Output Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Security Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Input Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:54:15 --> Language Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Loader Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:54:15 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Session Class Initialized
DEBUG - 2012-04-08 09:54:15 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:54:15 --> Session routines successfully run
DEBUG - 2012-04-08 09:54:15 --> Controller Class Initialized
DEBUG - 2012-04-08 09:54:15 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 09:54:15 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 09:54:15 --> Final output sent to browser
DEBUG - 2012-04-08 09:54:15 --> Total execution time: 0.3496
DEBUG - 2012-04-08 09:54:23 --> Config Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:54:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:54:23 --> URI Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Router Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Output Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Security Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Input Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:54:23 --> Language Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Loader Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:54:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Session Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:54:23 --> Session routines successfully run
DEBUG - 2012-04-08 09:54:23 --> Controller Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Config Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 09:54:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 09:54:23 --> URI Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Router Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Output Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Security Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Input Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 09:54:23 --> Language Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Loader Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 09:54:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Session Class Initialized
DEBUG - 2012-04-08 09:54:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 09:54:23 --> A session cookie was not found.
DEBUG - 2012-04-08 09:54:23 --> Session routines successfully run
DEBUG - 2012-04-08 09:54:23 --> Controller Class Initialized
DEBUG - 2012-04-08 09:54:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-08 09:54:23 --> Final output sent to browser
DEBUG - 2012-04-08 09:54:23 --> Total execution time: 0.2895
DEBUG - 2012-04-08 10:13:02 --> Config Class Initialized
DEBUG - 2012-04-08 10:13:02 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:13:02 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:13:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:13:02 --> URI Class Initialized
DEBUG - 2012-04-08 10:13:02 --> Router Class Initialized
DEBUG - 2012-04-08 10:13:02 --> Output Class Initialized
DEBUG - 2012-04-08 10:13:02 --> Security Class Initialized
DEBUG - 2012-04-08 10:13:02 --> Input Class Initialized
DEBUG - 2012-04-08 10:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:13:02 --> Language Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Loader Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:13:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Session Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:13:03 --> Session routines successfully run
DEBUG - 2012-04-08 10:13:03 --> Controller Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Model Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Model Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Config Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:13:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:13:03 --> URI Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Router Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Output Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Security Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Input Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:13:03 --> Language Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Loader Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:13:03 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Session Class Initialized
DEBUG - 2012-04-08 10:13:03 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:13:03 --> Session routines successfully run
DEBUG - 2012-04-08 10:13:03 --> Controller Class Initialized
DEBUG - 2012-04-08 10:13:04 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 10:13:04 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 10:13:04 --> Final output sent to browser
DEBUG - 2012-04-08 10:13:04 --> Total execution time: 0.3660
DEBUG - 2012-04-08 10:13:08 --> Config Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:13:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:13:08 --> URI Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Router Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Output Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Security Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Input Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:13:08 --> Language Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Loader Class Initialized
DEBUG - 2012-04-08 10:13:08 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:13:08 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:13:09 --> Session Class Initialized
DEBUG - 2012-04-08 10:13:09 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:13:09 --> Session routines successfully run
DEBUG - 2012-04-08 10:13:09 --> Controller Class Initialized
ERROR - 2012-04-08 10:13:09 --> Severity: Notice  --> Undefined variable: dept C:\xampp\htdocs\xcms\system\views\register_view.php 15
ERROR - 2012-04-08 10:13:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\xcms\system\views\register_view.php 15
DEBUG - 2012-04-08 10:13:09 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-08 10:13:09 --> Final output sent to browser
DEBUG - 2012-04-08 10:13:09 --> Total execution time: 0.3735
DEBUG - 2012-04-08 10:14:41 --> Config Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:14:41 --> URI Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Router Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Output Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Security Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Input Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:14:41 --> Language Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Loader Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:14:41 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Session Class Initialized
DEBUG - 2012-04-08 10:14:41 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:14:41 --> Session routines successfully run
DEBUG - 2012-04-08 10:14:41 --> Controller Class Initialized
ERROR - 2012-04-08 10:14:41 --> Severity: Notice  --> Undefined variable: dept C:\xampp\htdocs\xcms\system\views\createCR_view.php 12
ERROR - 2012-04-08 10:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\xcms\system\views\createCR_view.php 12
DEBUG - 2012-04-08 10:14:41 --> File loaded: system/views/createCR_view.php
DEBUG - 2012-04-08 10:14:41 --> Final output sent to browser
DEBUG - 2012-04-08 10:14:41 --> Total execution time: 0.3668
DEBUG - 2012-04-08 10:18:58 --> Config Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:18:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:18:58 --> URI Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Router Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Output Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Security Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Input Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:18:58 --> Language Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Loader Class Initialized
DEBUG - 2012-04-08 10:18:58 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:18:59 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:18:59 --> Session Class Initialized
DEBUG - 2012-04-08 10:18:59 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:18:59 --> Session routines successfully run
DEBUG - 2012-04-08 10:18:59 --> Controller Class Initialized
ERROR - 2012-04-08 10:18:59 --> Severity: Notice  --> Undefined property: Accounts::$user C:\xampp\htdocs\xcms\system\controllers\accounts.php 208
DEBUG - 2012-04-08 10:20:44 --> Config Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:20:44 --> URI Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Router Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Output Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Security Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Input Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:20:44 --> Language Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Loader Class Initialized
DEBUG - 2012-04-08 10:20:44 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:20:45 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:20:45 --> Session Class Initialized
DEBUG - 2012-04-08 10:20:45 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:20:45 --> Session routines successfully run
DEBUG - 2012-04-08 10:20:45 --> Controller Class Initialized
DEBUG - 2012-04-08 10:20:45 --> Model Class Initialized
DEBUG - 2012-04-08 10:20:45 --> Model Class Initialized
DEBUG - 2012-04-08 10:20:45 --> File loaded: system/views/createCR_view.php
DEBUG - 2012-04-08 10:20:45 --> Final output sent to browser
DEBUG - 2012-04-08 10:20:45 --> Total execution time: 0.5336
DEBUG - 2012-04-08 10:21:05 --> Config Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:21:05 --> URI Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Router Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Output Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Security Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Input Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:21:05 --> Language Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Loader Class Initialized
DEBUG - 2012-04-08 10:21:05 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:21:05 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:21:06 --> Session Class Initialized
DEBUG - 2012-04-08 10:21:06 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:21:06 --> Session routines successfully run
DEBUG - 2012-04-08 10:21:06 --> Controller Class Initialized
ERROR - 2012-04-08 10:21:06 --> 404 Page Not Found --> accounts/newCR
DEBUG - 2012-04-08 10:23:24 --> Config Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:23:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:23:24 --> URI Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Router Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Output Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Security Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Input Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:23:24 --> Language Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Loader Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:23:24 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Session Class Initialized
DEBUG - 2012-04-08 10:23:24 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:23:24 --> Session routines successfully run
DEBUG - 2012-04-08 10:23:24 --> Controller Class Initialized
ERROR - 2012-04-08 10:23:24 --> 404 Page Not Found --> accounts/newCR
DEBUG - 2012-04-08 10:24:23 --> Config Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:24:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:24:23 --> URI Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Router Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Output Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Security Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Input Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:24:23 --> Language Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Loader Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:24:23 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Session Class Initialized
DEBUG - 2012-04-08 10:24:23 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:24:23 --> Session routines successfully run
DEBUG - 2012-04-08 10:24:23 --> Controller Class Initialized
ERROR - 2012-04-08 10:24:23 --> 404 Page Not Found --> accounts/newCR
DEBUG - 2012-04-08 10:24:26 --> Config Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:24:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:24:26 --> URI Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Router Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Output Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Security Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Input Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:24:26 --> Language Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Loader Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:24:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Session Class Initialized
DEBUG - 2012-04-08 10:24:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:24:26 --> Session routines successfully run
DEBUG - 2012-04-08 10:24:26 --> Controller Class Initialized
ERROR - 2012-04-08 10:24:26 --> 404 Page Not Found --> accounts/newCR
DEBUG - 2012-04-08 10:24:34 --> Config Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:24:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:24:34 --> URI Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Router Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Output Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Security Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Input Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:24:34 --> Language Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Loader Class Initialized
DEBUG - 2012-04-08 10:24:34 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:24:34 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:24:35 --> Session Class Initialized
DEBUG - 2012-04-08 10:24:35 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:24:35 --> Session routines successfully run
DEBUG - 2012-04-08 10:24:35 --> Controller Class Initialized
ERROR - 2012-04-08 10:24:35 --> 404 Page Not Found --> accounts/index
DEBUG - 2012-04-08 10:24:42 --> Config Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:24:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:24:42 --> URI Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Router Class Initialized
DEBUG - 2012-04-08 10:24:42 --> No URI present. Default controller set.
DEBUG - 2012-04-08 10:24:42 --> Output Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Security Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Input Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:24:42 --> Language Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Loader Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:24:42 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Session Class Initialized
DEBUG - 2012-04-08 10:24:42 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:24:42 --> Session routines successfully run
DEBUG - 2012-04-08 10:24:42 --> Controller Class Initialized
DEBUG - 2012-04-08 10:24:42 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 10:24:42 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 10:24:42 --> Final output sent to browser
DEBUG - 2012-04-08 10:24:42 --> Total execution time: 0.2889
DEBUG - 2012-04-08 10:24:46 --> Config Class Initialized
DEBUG - 2012-04-08 10:24:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:24:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:24:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:24:46 --> URI Class Initialized
DEBUG - 2012-04-08 10:24:46 --> Router Class Initialized
DEBUG - 2012-04-08 10:24:46 --> Output Class Initialized
DEBUG - 2012-04-08 10:24:46 --> Security Class Initialized
DEBUG - 2012-04-08 10:24:46 --> Input Class Initialized
DEBUG - 2012-04-08 10:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:24:46 --> Language Class Initialized
DEBUG - 2012-04-08 10:24:46 --> Loader Class Initialized
DEBUG - 2012-04-08 10:24:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:24:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:24:47 --> Session Class Initialized
DEBUG - 2012-04-08 10:24:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:24:47 --> Session routines successfully run
DEBUG - 2012-04-08 10:24:47 --> Controller Class Initialized
DEBUG - 2012-04-08 10:24:47 --> Model Class Initialized
DEBUG - 2012-04-08 10:24:47 --> Model Class Initialized
DEBUG - 2012-04-08 10:24:47 --> File loaded: system/views/createCR_view.php
DEBUG - 2012-04-08 10:24:47 --> Final output sent to browser
DEBUG - 2012-04-08 10:24:47 --> Total execution time: 0.3867
DEBUG - 2012-04-08 10:24:59 --> Config Class Initialized
DEBUG - 2012-04-08 10:24:59 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:24:59 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:24:59 --> URI Class Initialized
DEBUG - 2012-04-08 10:24:59 --> Router Class Initialized
DEBUG - 2012-04-08 10:24:59 --> Output Class Initialized
DEBUG - 2012-04-08 10:24:59 --> Security Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Input Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:25:00 --> Language Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Loader Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:25:00 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Session Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:25:00 --> Session routines successfully run
DEBUG - 2012-04-08 10:25:00 --> Controller Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Model Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Model Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Helper loaded: email_helper
DEBUG - 2012-04-08 10:25:00 --> Model Class Initialized
ERROR - 2012-04-08 10:25:00 --> Severity: Notice  --> Undefined variable: Code C:\xampp\htdocs\xcms\system\controllers\accounts.php 268
DEBUG - 2012-04-08 10:25:00 --> Config Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:25:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:25:00 --> URI Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Router Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Output Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Security Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Input Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:25:00 --> Language Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Loader Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:25:00 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Session Class Initialized
DEBUG - 2012-04-08 10:25:00 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:25:00 --> Session routines successfully run
DEBUG - 2012-04-08 10:25:00 --> Controller Class Initialized
DEBUG - 2012-04-08 10:25:00 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 10:25:00 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 10:25:00 --> Final output sent to browser
DEBUG - 2012-04-08 10:25:00 --> Total execution time: 0.2922
DEBUG - 2012-04-08 10:27:14 --> Config Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:27:14 --> URI Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Router Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Output Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Security Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Input Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:27:14 --> Language Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Loader Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:27:14 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Session Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:27:14 --> Session routines successfully run
DEBUG - 2012-04-08 10:27:14 --> Controller Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Model Class Initialized
DEBUG - 2012-04-08 10:27:14 --> Model Class Initialized
DEBUG - 2012-04-08 10:27:14 --> File loaded: system/views/createCR_view.php
DEBUG - 2012-04-08 10:27:14 --> Final output sent to browser
DEBUG - 2012-04-08 10:27:14 --> Total execution time: 0.4560
DEBUG - 2012-04-08 10:27:52 --> Config Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:27:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:27:52 --> URI Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Router Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Output Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Security Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Input Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:27:52 --> Language Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Loader Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:27:52 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Session Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:27:52 --> Session routines successfully run
DEBUG - 2012-04-08 10:27:52 --> Controller Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Model Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Model Class Initialized
DEBUG - 2012-04-08 10:27:52 --> Helper loaded: email_helper
DEBUG - 2012-04-08 10:27:52 --> Model Class Initialized
ERROR - 2012-04-08 10:27:52 --> Severity: Notice  --> Undefined variable: Code C:\xampp\htdocs\xcms\system\controllers\accounts.php 268
DEBUG - 2012-04-08 10:27:52 --> Final output sent to browser
DEBUG - 2012-04-08 10:27:52 --> Total execution time: 0.4309
DEBUG - 2012-04-08 10:27:54 --> Config Class Initialized
DEBUG - 2012-04-08 10:27:54 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:27:54 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:27:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:27:55 --> URI Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Router Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Output Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Security Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Input Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:27:55 --> Language Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Loader Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:27:55 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Session Class Initialized
DEBUG - 2012-04-08 10:27:55 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:27:55 --> Session routines successfully run
DEBUG - 2012-04-08 10:27:55 --> Controller Class Initialized
DEBUG - 2012-04-08 10:27:55 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 10:27:55 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 10:27:55 --> Final output sent to browser
DEBUG - 2012-04-08 10:27:55 --> Total execution time: 0.5241
DEBUG - 2012-04-08 10:28:22 --> Config Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:28:22 --> URI Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Router Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Output Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Security Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Input Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:28:22 --> Language Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Loader Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:28:22 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Session Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:28:22 --> Session routines successfully run
DEBUG - 2012-04-08 10:28:22 --> Controller Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Model Class Initialized
DEBUG - 2012-04-08 10:28:22 --> Model Class Initialized
DEBUG - 2012-04-08 10:28:22 --> File loaded: system/views/createCR_view.php
DEBUG - 2012-04-08 10:28:22 --> Final output sent to browser
DEBUG - 2012-04-08 10:28:22 --> Total execution time: 0.8246
DEBUG - 2012-04-08 10:28:46 --> Config Class Initialized
DEBUG - 2012-04-08 10:28:46 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:28:46 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:28:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:28:46 --> URI Class Initialized
DEBUG - 2012-04-08 10:28:46 --> Router Class Initialized
DEBUG - 2012-04-08 10:28:46 --> Output Class Initialized
DEBUG - 2012-04-08 10:28:46 --> Security Class Initialized
DEBUG - 2012-04-08 10:28:46 --> Input Class Initialized
DEBUG - 2012-04-08 10:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:28:46 --> Language Class Initialized
DEBUG - 2012-04-08 10:28:47 --> Loader Class Initialized
DEBUG - 2012-04-08 10:28:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:28:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:28:47 --> Session Class Initialized
DEBUG - 2012-04-08 10:28:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:28:47 --> Session routines successfully run
DEBUG - 2012-04-08 10:28:47 --> Controller Class Initialized
DEBUG - 2012-04-08 10:28:47 --> Model Class Initialized
DEBUG - 2012-04-08 10:28:47 --> Model Class Initialized
DEBUG - 2012-04-08 10:28:47 --> Helper loaded: email_helper
DEBUG - 2012-04-08 10:28:47 --> Model Class Initialized
ERROR - 2012-04-08 10:28:47 --> Severity: Notice  --> Undefined variable: Code C:\xampp\htdocs\xcms\system\controllers\accounts.php 268
DEBUG - 2012-04-08 10:28:47 --> Final output sent to browser
DEBUG - 2012-04-08 10:28:47 --> Total execution time: 0.4677
DEBUG - 2012-04-08 10:28:49 --> Config Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:28:49 --> URI Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Router Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Output Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Security Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Input Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:28:49 --> Language Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Loader Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:28:49 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Session Class Initialized
DEBUG - 2012-04-08 10:28:49 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:28:49 --> Session routines successfully run
DEBUG - 2012-04-08 10:28:49 --> Controller Class Initialized
DEBUG - 2012-04-08 10:28:50 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 10:28:50 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 10:28:50 --> Final output sent to browser
DEBUG - 2012-04-08 10:28:50 --> Total execution time: 0.6028
DEBUG - 2012-04-08 10:30:26 --> Config Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:30:26 --> URI Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Router Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Output Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Security Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Input Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:30:26 --> Language Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Loader Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:30:26 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Session Class Initialized
DEBUG - 2012-04-08 10:30:26 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:30:27 --> Session routines successfully run
DEBUG - 2012-04-08 10:30:27 --> Controller Class Initialized
DEBUG - 2012-04-08 10:30:27 --> Model Class Initialized
DEBUG - 2012-04-08 10:30:27 --> Model Class Initialized
DEBUG - 2012-04-08 10:30:27 --> File loaded: system/views/createCR_view.php
DEBUG - 2012-04-08 10:30:27 --> Final output sent to browser
DEBUG - 2012-04-08 10:30:27 --> Total execution time: 0.4297
DEBUG - 2012-04-08 10:30:47 --> Config Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:30:47 --> URI Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Router Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Output Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Security Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Input Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:30:47 --> Language Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Loader Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:30:47 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Session Class Initialized
DEBUG - 2012-04-08 10:30:47 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:30:47 --> Session routines successfully run
DEBUG - 2012-04-08 10:30:47 --> Controller Class Initialized
DEBUG - 2012-04-08 10:30:48 --> Model Class Initialized
DEBUG - 2012-04-08 10:30:48 --> Model Class Initialized
DEBUG - 2012-04-08 10:30:48 --> Helper loaded: email_helper
DEBUG - 2012-04-08 10:30:48 --> Model Class Initialized
ERROR - 2012-04-08 10:30:48 --> Severity: Notice  --> Undefined variable: Code C:\xampp\htdocs\xcms\system\controllers\accounts.php 268
DEBUG - 2012-04-08 10:30:48 --> Final output sent to browser
DEBUG - 2012-04-08 10:30:48 --> Total execution time: 0.3758
DEBUG - 2012-04-08 10:30:50 --> Config Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:30:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:30:50 --> URI Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Router Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Output Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Security Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Input Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:30:50 --> Language Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Loader Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:30:50 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Session Class Initialized
DEBUG - 2012-04-08 10:30:50 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:30:50 --> Session routines successfully run
DEBUG - 2012-04-08 10:30:50 --> Controller Class Initialized
DEBUG - 2012-04-08 10:30:50 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 10:30:50 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 10:30:50 --> Final output sent to browser
DEBUG - 2012-04-08 10:30:50 --> Total execution time: 0.4395
DEBUG - 2012-04-08 10:34:10 --> Config Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:34:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:34:10 --> URI Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Router Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Output Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Security Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Input Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:34:10 --> Language Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Loader Class Initialized
DEBUG - 2012-04-08 10:34:10 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:34:11 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:34:11 --> Session Class Initialized
DEBUG - 2012-04-08 10:34:11 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:34:11 --> Session routines successfully run
DEBUG - 2012-04-08 10:34:11 --> Controller Class Initialized
DEBUG - 2012-04-08 10:34:11 --> Model Class Initialized
DEBUG - 2012-04-08 10:34:11 --> Model Class Initialized
DEBUG - 2012-04-08 10:34:11 --> File loaded: system/views/createCR_view.php
DEBUG - 2012-04-08 10:34:11 --> Final output sent to browser
DEBUG - 2012-04-08 10:34:11 --> Total execution time: 0.4071
DEBUG - 2012-04-08 10:34:36 --> Config Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:34:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:34:36 --> URI Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Router Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Output Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Security Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Input Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:34:36 --> Language Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Loader Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:34:36 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Session Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:34:36 --> Session routines successfully run
DEBUG - 2012-04-08 10:34:36 --> Controller Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Model Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Model Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Helper loaded: email_helper
DEBUG - 2012-04-08 10:34:36 --> Model Class Initialized
DEBUG - 2012-04-08 10:34:36 --> Final output sent to browser
DEBUG - 2012-04-08 10:34:36 --> Total execution time: 0.4071
DEBUG - 2012-04-08 10:34:38 --> Config Class Initialized
DEBUG - 2012-04-08 10:34:38 --> Hooks Class Initialized
DEBUG - 2012-04-08 10:34:38 --> Utf8 Class Initialized
DEBUG - 2012-04-08 10:34:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-08 10:34:38 --> URI Class Initialized
DEBUG - 2012-04-08 10:34:38 --> Router Class Initialized
DEBUG - 2012-04-08 10:34:38 --> Output Class Initialized
DEBUG - 2012-04-08 10:34:39 --> Security Class Initialized
DEBUG - 2012-04-08 10:34:39 --> Input Class Initialized
DEBUG - 2012-04-08 10:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-08 10:34:39 --> Language Class Initialized
DEBUG - 2012-04-08 10:34:39 --> Loader Class Initialized
DEBUG - 2012-04-08 10:34:39 --> Helper loaded: url_helper
DEBUG - 2012-04-08 10:34:39 --> Database Driver Class Initialized
DEBUG - 2012-04-08 10:34:39 --> Session Class Initialized
DEBUG - 2012-04-08 10:34:39 --> Helper loaded: string_helper
DEBUG - 2012-04-08 10:34:39 --> Session routines successfully run
DEBUG - 2012-04-08 10:34:39 --> Controller Class Initialized
DEBUG - 2012-04-08 10:34:39 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-08 10:34:39 --> File loaded: system/views/links.php
DEBUG - 2012-04-08 10:34:39 --> Final output sent to browser
DEBUG - 2012-04-08 10:34:39 --> Total execution time: 0.5552
