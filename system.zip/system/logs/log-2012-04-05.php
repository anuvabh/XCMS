<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-05 12:48:58 --> Config Class Initialized
DEBUG - 2012-04-05 12:48:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:48:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:48:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:48:58 --> URI Class Initialized
DEBUG - 2012-04-05 12:48:59 --> Router Class Initialized
DEBUG - 2012-04-05 12:48:59 --> No URI present. Default controller set.
DEBUG - 2012-04-05 12:48:59 --> Output Class Initialized
DEBUG - 2012-04-05 12:48:59 --> Security Class Initialized
DEBUG - 2012-04-05 12:48:59 --> Input Class Initialized
DEBUG - 2012-04-05 12:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:48:59 --> Language Class Initialized
DEBUG - 2012-04-05 12:48:59 --> Loader Class Initialized
DEBUG - 2012-04-05 12:48:59 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:48:59 --> Database Driver Class Initialized
ERROR - 2012-04-05 12:48:59 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-05 12:49:00 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:00 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:00 --> A session cookie was not found.
DEBUG - 2012-04-05 12:49:00 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:00 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:00 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 12:49:00 --> Final output sent to browser
DEBUG - 2012-04-05 12:49:00 --> Total execution time: 1.6351
DEBUG - 2012-04-05 12:49:09 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:09 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:09 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:09 --> Database Driver Class Initialized
ERROR - 2012-04-05 12:49:09 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-05 12:49:09 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:09 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:09 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:09 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 12:49:09 --> Final output sent to browser
DEBUG - 2012-04-05 12:49:09 --> Total execution time: 0.3083
DEBUG - 2012-04-05 12:49:20 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:20 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:20 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:20 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:20 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:20 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Model Class Initialized
DEBUG - 2012-04-05 12:49:20 --> Model Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:21 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:21 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:21 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:21 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:21 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:21 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:21 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 12:49:21 --> Final output sent to browser
DEBUG - 2012-04-05 12:49:21 --> Total execution time: 0.2560
DEBUG - 2012-04-05 12:49:24 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:24 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:24 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:24 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:24 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:24 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:24 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:24 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:24 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:24 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:24 --> A session cookie was not found.
DEBUG - 2012-04-05 12:49:24 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:24 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:24 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 12:49:24 --> Final output sent to browser
DEBUG - 2012-04-05 12:49:24 --> Total execution time: 0.2291
DEBUG - 2012-04-05 12:49:32 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:32 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:32 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:32 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:33 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:33 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:33 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:33 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Model Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Model Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:33 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:33 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:33 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:33 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:33 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:33 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:33 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-05 12:49:33 --> Final output sent to browser
DEBUG - 2012-04-05 12:49:33 --> Total execution time: 0.2424
DEBUG - 2012-04-05 12:49:46 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:46 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:46 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:46 --> Database Driver Class Initialized
ERROR - 2012-04-05 12:49:46 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-05 12:49:46 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:46 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:46 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Config Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:49:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:49:46 --> URI Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Router Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Output Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Security Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Input Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:49:46 --> Language Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Loader Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:49:46 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Session Class Initialized
DEBUG - 2012-04-05 12:49:46 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:49:46 --> A session cookie was not found.
DEBUG - 2012-04-05 12:49:46 --> Session routines successfully run
DEBUG - 2012-04-05 12:49:46 --> Controller Class Initialized
DEBUG - 2012-04-05 12:49:46 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 12:49:46 --> Final output sent to browser
DEBUG - 2012-04-05 12:49:46 --> Total execution time: 0.2308
DEBUG - 2012-04-05 12:59:41 --> Config Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:59:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:59:41 --> URI Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Router Class Initialized
DEBUG - 2012-04-05 12:59:41 --> No URI present. Default controller set.
DEBUG - 2012-04-05 12:59:41 --> Output Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Security Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Input Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:59:41 --> Language Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Loader Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:59:41 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Session Class Initialized
DEBUG - 2012-04-05 12:59:41 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:59:41 --> Session routines successfully run
DEBUG - 2012-04-05 12:59:41 --> Controller Class Initialized
DEBUG - 2012-04-05 12:59:41 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 12:59:41 --> Final output sent to browser
DEBUG - 2012-04-05 12:59:41 --> Total execution time: 0.0569
DEBUG - 2012-04-05 12:59:51 --> Config Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:59:51 --> URI Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Router Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Output Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Security Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Input Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:59:51 --> Language Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Loader Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:59:51 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Session Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:59:51 --> Session routines successfully run
DEBUG - 2012-04-05 12:59:51 --> Controller Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Config Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:59:51 --> URI Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Router Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Output Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Security Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Input Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:59:51 --> Language Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Loader Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:59:51 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Session Class Initialized
DEBUG - 2012-04-05 12:59:51 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:59:51 --> A session cookie was not found.
DEBUG - 2012-04-05 12:59:51 --> Session routines successfully run
DEBUG - 2012-04-05 12:59:51 --> Controller Class Initialized
DEBUG - 2012-04-05 12:59:51 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 12:59:51 --> Final output sent to browser
DEBUG - 2012-04-05 12:59:51 --> Total execution time: 0.0518
DEBUG - 2012-04-05 12:59:58 --> Config Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 12:59:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 12:59:58 --> URI Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Router Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Output Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Security Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Input Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 12:59:58 --> Language Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Loader Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 12:59:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Session Class Initialized
DEBUG - 2012-04-05 12:59:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 12:59:58 --> Session routines successfully run
DEBUG - 2012-04-05 12:59:58 --> Controller Class Initialized
DEBUG - 2012-04-05 12:59:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 12:59:58 --> Final output sent to browser
DEBUG - 2012-04-05 12:59:58 --> Total execution time: 0.0829
DEBUG - 2012-04-05 13:01:57 --> Config Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:01:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:01:57 --> URI Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Router Class Initialized
DEBUG - 2012-04-05 13:01:57 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:01:57 --> Output Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Security Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Input Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:01:57 --> Language Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Loader Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:01:57 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Session Class Initialized
DEBUG - 2012-04-05 13:01:57 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:01:57 --> Session routines successfully run
DEBUG - 2012-04-05 13:01:57 --> Controller Class Initialized
DEBUG - 2012-04-05 13:01:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:01:57 --> Final output sent to browser
DEBUG - 2012-04-05 13:01:57 --> Total execution time: 0.0544
DEBUG - 2012-04-05 13:01:59 --> Config Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:01:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:01:59 --> URI Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Router Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Output Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Security Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Input Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:01:59 --> Language Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Loader Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:01:59 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Session Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:01:59 --> Session routines successfully run
DEBUG - 2012-04-05 13:01:59 --> Controller Class Initialized
DEBUG - 2012-04-05 13:01:59 --> Final output sent to browser
DEBUG - 2012-04-05 13:01:59 --> Total execution time: 0.0512
DEBUG - 2012-04-05 13:20:48 --> Config Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:20:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:20:48 --> URI Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Router Class Initialized
DEBUG - 2012-04-05 13:20:48 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:20:48 --> Output Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Security Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Input Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:20:48 --> Language Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Loader Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:20:48 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Session Class Initialized
DEBUG - 2012-04-05 13:20:48 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:20:48 --> Session routines successfully run
DEBUG - 2012-04-05 13:20:48 --> Controller Class Initialized
DEBUG - 2012-04-05 13:20:48 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:20:48 --> Final output sent to browser
DEBUG - 2012-04-05 13:20:48 --> Total execution time: 0.0528
DEBUG - 2012-04-05 13:20:50 --> Config Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:20:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:20:50 --> URI Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Router Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Output Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Security Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Input Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:20:50 --> Language Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Loader Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:20:50 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Session Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:20:50 --> Session routines successfully run
DEBUG - 2012-04-05 13:20:50 --> Controller Class Initialized
DEBUG - 2012-04-05 13:20:50 --> Final output sent to browser
DEBUG - 2012-04-05 13:20:50 --> Total execution time: 0.0572
DEBUG - 2012-04-05 13:21:13 --> Config Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:21:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:21:13 --> URI Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Router Class Initialized
DEBUG - 2012-04-05 13:21:13 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:21:13 --> Output Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Security Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Input Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:21:13 --> Language Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Loader Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:21:13 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Session Class Initialized
DEBUG - 2012-04-05 13:21:13 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:21:13 --> Session routines successfully run
DEBUG - 2012-04-05 13:21:13 --> Controller Class Initialized
DEBUG - 2012-04-05 13:21:13 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:21:13 --> Final output sent to browser
DEBUG - 2012-04-05 13:21:13 --> Total execution time: 0.0533
DEBUG - 2012-04-05 13:21:14 --> Config Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:21:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:21:14 --> URI Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Router Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Output Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Security Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Input Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:21:14 --> Language Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Loader Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:21:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Session Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:21:14 --> Session routines successfully run
DEBUG - 2012-04-05 13:21:14 --> Controller Class Initialized
DEBUG - 2012-04-05 13:21:14 --> Final output sent to browser
DEBUG - 2012-04-05 13:21:14 --> Total execution time: 0.0505
DEBUG - 2012-04-05 13:21:40 --> Config Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:21:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:21:40 --> URI Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Router Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Output Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Security Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Input Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:21:40 --> Language Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Loader Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:21:40 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Session Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:21:40 --> Session routines successfully run
DEBUG - 2012-04-05 13:21:40 --> Controller Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Model Class Initialized
DEBUG - 2012-04-05 13:21:40 --> Model Class Initialized
DEBUG - 2012-04-05 13:21:40 --> DB Transaction Failure
ERROR - 2012-04-05 13:21:40 --> Query error: Table 'sxccms.department' doesn't exist
DEBUG - 2012-04-05 13:21:40 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 13:22:00 --> Config Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:22:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:22:00 --> URI Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Router Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Output Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Security Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Input Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:22:00 --> Language Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Loader Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:22:00 --> Database Driver Class Initialized
ERROR - 2012-04-05 13:22:00 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-05 13:22:00 --> Session Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:22:00 --> Session routines successfully run
DEBUG - 2012-04-05 13:22:00 --> Controller Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Model Class Initialized
DEBUG - 2012-04-05 13:22:00 --> Model Class Initialized
ERROR - 2012-04-05 13:22:00 --> Severity: Notice  --> Undefined variable: row C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
ERROR - 2012-04-05 13:22:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
DEBUG - 2012-04-05 13:22:00 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:22:00 --> Final output sent to browser
DEBUG - 2012-04-05 13:22:00 --> Total execution time: 0.0903
DEBUG - 2012-04-05 13:25:46 --> Config Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:25:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:25:46 --> URI Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Router Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Output Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Security Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Input Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:25:46 --> Language Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Loader Class Initialized
DEBUG - 2012-04-05 13:25:46 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:25:47 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:25:47 --> Session Class Initialized
DEBUG - 2012-04-05 13:25:47 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:25:47 --> Session routines successfully run
DEBUG - 2012-04-05 13:25:47 --> Controller Class Initialized
DEBUG - 2012-04-05 13:25:47 --> Model Class Initialized
DEBUG - 2012-04-05 13:25:47 --> Model Class Initialized
ERROR - 2012-04-05 13:25:47 --> Severity: Notice  --> Undefined variable: row C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
ERROR - 2012-04-05 13:25:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
DEBUG - 2012-04-05 13:25:47 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:25:47 --> Final output sent to browser
DEBUG - 2012-04-05 13:25:47 --> Total execution time: 0.0622
DEBUG - 2012-04-05 13:25:50 --> Config Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:25:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:25:50 --> URI Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Router Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Output Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Security Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Input Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:25:50 --> Language Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Loader Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:25:50 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Session Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:25:50 --> Session routines successfully run
DEBUG - 2012-04-05 13:25:50 --> Controller Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Model Class Initialized
DEBUG - 2012-04-05 13:25:50 --> Model Class Initialized
ERROR - 2012-04-05 13:25:50 --> Severity: Notice  --> Undefined variable: row C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
ERROR - 2012-04-05 13:25:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
DEBUG - 2012-04-05 13:25:50 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:25:50 --> Final output sent to browser
DEBUG - 2012-04-05 13:25:50 --> Total execution time: 0.0630
DEBUG - 2012-04-05 13:25:53 --> Config Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:25:53 --> URI Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Router Class Initialized
DEBUG - 2012-04-05 13:25:53 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:25:53 --> Output Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Security Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Input Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:25:53 --> Language Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Loader Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:25:53 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Session Class Initialized
DEBUG - 2012-04-05 13:25:53 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:25:53 --> Session routines successfully run
DEBUG - 2012-04-05 13:25:53 --> Controller Class Initialized
DEBUG - 2012-04-05 13:25:53 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:25:53 --> Final output sent to browser
DEBUG - 2012-04-05 13:25:53 --> Total execution time: 0.0551
DEBUG - 2012-04-05 13:25:54 --> Config Class Initialized
DEBUG - 2012-04-05 13:25:54 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:25:54 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:25:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:25:54 --> URI Class Initialized
DEBUG - 2012-04-05 13:25:54 --> Router Class Initialized
DEBUG - 2012-04-05 13:25:54 --> Output Class Initialized
DEBUG - 2012-04-05 13:25:54 --> Security Class Initialized
DEBUG - 2012-04-05 13:25:55 --> Input Class Initialized
DEBUG - 2012-04-05 13:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:25:55 --> Language Class Initialized
DEBUG - 2012-04-05 13:25:55 --> Loader Class Initialized
DEBUG - 2012-04-05 13:25:55 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:25:55 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:25:55 --> Session Class Initialized
DEBUG - 2012-04-05 13:25:55 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:25:55 --> Session routines successfully run
DEBUG - 2012-04-05 13:25:55 --> Controller Class Initialized
DEBUG - 2012-04-05 13:25:55 --> Model Class Initialized
DEBUG - 2012-04-05 13:25:55 --> Model Class Initialized
ERROR - 2012-04-05 13:25:55 --> Severity: Notice  --> Undefined variable: row C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
ERROR - 2012-04-05 13:25:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
DEBUG - 2012-04-05 13:25:55 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:25:55 --> Final output sent to browser
DEBUG - 2012-04-05 13:25:55 --> Total execution time: 0.1440
DEBUG - 2012-04-05 13:26:10 --> Config Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:26:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:26:10 --> URI Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Router Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Output Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Security Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Input Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:26:10 --> Language Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Loader Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:26:10 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Session Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:26:10 --> Session routines successfully run
DEBUG - 2012-04-05 13:26:10 --> Controller Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Model Class Initialized
DEBUG - 2012-04-05 13:26:10 --> Model Class Initialized
ERROR - 2012-04-05 13:26:10 --> Severity: Notice  --> Undefined variable: row C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
ERROR - 2012-04-05 13:26:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
DEBUG - 2012-04-05 13:26:10 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:26:10 --> Final output sent to browser
DEBUG - 2012-04-05 13:26:10 --> Total execution time: 0.0737
DEBUG - 2012-04-05 13:27:43 --> Config Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:27:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:27:43 --> URI Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Router Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Output Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Security Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Input Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:27:43 --> Language Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Loader Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:27:43 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Session Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:27:43 --> Session routines successfully run
DEBUG - 2012-04-05 13:27:43 --> Controller Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Model Class Initialized
DEBUG - 2012-04-05 13:27:43 --> Model Class Initialized
ERROR - 2012-04-05 13:27:43 --> Severity: Notice  --> Undefined variable: row C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 67
ERROR - 2012-04-05 13:27:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 67
ERROR - 2012-04-05 13:27:43 --> Severity: Notice  --> Undefined variable: row C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
ERROR - 2012-04-05 13:27:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\register_view.php 13
DEBUG - 2012-04-05 13:27:43 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:27:43 --> Final output sent to browser
DEBUG - 2012-04-05 13:27:43 --> Total execution time: 0.0775
DEBUG - 2012-04-05 13:28:52 --> Config Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:28:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:28:52 --> URI Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Router Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Output Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Security Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Input Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:28:52 --> Language Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Loader Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:28:52 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Session Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:28:52 --> Session routines successfully run
DEBUG - 2012-04-05 13:28:52 --> Controller Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Model Class Initialized
DEBUG - 2012-04-05 13:28:52 --> Model Class Initialized
ERROR - 2012-04-05 13:28:52 --> Severity: Notice  --> Undefined index: Code C:\Software\xampp\htdocs\xcms\system\views\register_view.php 15
DEBUG - 2012-04-05 13:28:52 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:28:52 --> Final output sent to browser
DEBUG - 2012-04-05 13:28:52 --> Total execution time: 0.0652
DEBUG - 2012-04-05 13:29:45 --> Config Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:29:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:29:45 --> URI Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Router Class Initialized
DEBUG - 2012-04-05 13:29:45 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:29:45 --> Output Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Security Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Input Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:29:45 --> Language Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Loader Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:29:45 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Session Class Initialized
DEBUG - 2012-04-05 13:29:45 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:29:45 --> Session routines successfully run
DEBUG - 2012-04-05 13:29:45 --> Controller Class Initialized
DEBUG - 2012-04-05 13:29:45 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:29:45 --> Final output sent to browser
DEBUG - 2012-04-05 13:29:45 --> Total execution time: 0.0623
DEBUG - 2012-04-05 13:29:47 --> Config Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:29:47 --> URI Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Router Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Output Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Security Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Input Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:29:47 --> Language Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Loader Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:29:47 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Session Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:29:47 --> Session routines successfully run
DEBUG - 2012-04-05 13:29:47 --> Controller Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Model Class Initialized
DEBUG - 2012-04-05 13:29:47 --> Model Class Initialized
ERROR - 2012-04-05 13:29:47 --> Severity: Notice  --> Undefined index: Code C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 69
ERROR - 2012-04-05 13:29:47 --> Severity: Notice  --> Undefined index: Code C:\Software\xampp\htdocs\xcms\system\views\register_view.php 15
DEBUG - 2012-04-05 13:29:47 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:29:47 --> Final output sent to browser
DEBUG - 2012-04-05 13:29:47 --> Total execution time: 0.1114
DEBUG - 2012-04-05 13:31:33 --> Config Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:31:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:31:33 --> URI Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Router Class Initialized
DEBUG - 2012-04-05 13:31:33 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:31:33 --> Output Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Security Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Input Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:31:33 --> Language Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Loader Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:31:33 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Session Class Initialized
DEBUG - 2012-04-05 13:31:33 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:31:33 --> Session routines successfully run
DEBUG - 2012-04-05 13:31:33 --> Controller Class Initialized
DEBUG - 2012-04-05 13:31:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:31:33 --> Final output sent to browser
DEBUG - 2012-04-05 13:31:33 --> Total execution time: 0.0600
DEBUG - 2012-04-05 13:31:34 --> Config Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:31:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:31:34 --> URI Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Router Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Output Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Security Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Input Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:31:34 --> Language Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Loader Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:31:34 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Session Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:31:34 --> Session routines successfully run
DEBUG - 2012-04-05 13:31:34 --> Controller Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Model Class Initialized
DEBUG - 2012-04-05 13:31:34 --> Model Class Initialized
ERROR - 2012-04-05 13:31:34 --> Severity: Notice  --> Undefined index: Code C:\Software\xampp\htdocs\xcms\system\models\user.php 60
ERROR - 2012-04-05 13:31:34 --> Severity: Notice  --> Undefined index: Code C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 69
ERROR - 2012-04-05 13:31:34 --> Severity: Notice  --> Undefined index: Code C:\Software\xampp\htdocs\xcms\system\views\register_view.php 15
DEBUG - 2012-04-05 13:31:34 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:31:34 --> Final output sent to browser
DEBUG - 2012-04-05 13:31:34 --> Total execution time: 0.0716
DEBUG - 2012-04-05 13:32:34 --> Config Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:32:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:32:34 --> URI Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Router Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Output Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Security Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Input Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:32:34 --> Language Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Loader Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:32:34 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Session Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:32:34 --> Session routines successfully run
DEBUG - 2012-04-05 13:32:34 --> Controller Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Model Class Initialized
DEBUG - 2012-04-05 13:32:34 --> Model Class Initialized
DEBUG - 2012-04-05 13:32:34 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:32:34 --> Final output sent to browser
DEBUG - 2012-04-05 13:32:34 --> Total execution time: 0.0717
DEBUG - 2012-04-05 13:32:44 --> Config Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:32:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:32:44 --> URI Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Router Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Output Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Security Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Input Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:32:44 --> Language Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Loader Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:32:44 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Session Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:32:44 --> Session routines successfully run
DEBUG - 2012-04-05 13:32:44 --> Controller Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Model Class Initialized
DEBUG - 2012-04-05 13:32:44 --> Model Class Initialized
DEBUG - 2012-04-05 13:32:44 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:32:44 --> Final output sent to browser
DEBUG - 2012-04-05 13:32:44 --> Total execution time: 0.0666
DEBUG - 2012-04-05 13:33:39 --> Config Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:33:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:33:39 --> URI Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Router Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Output Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Security Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Input Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:33:39 --> Language Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Loader Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:33:39 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Session Class Initialized
DEBUG - 2012-04-05 13:33:39 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:33:39 --> Session routines successfully run
DEBUG - 2012-04-05 13:33:39 --> Controller Class Initialized
DEBUG - 2012-04-05 13:33:39 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:33:39 --> Final output sent to browser
DEBUG - 2012-04-05 13:33:39 --> Total execution time: 0.0594
DEBUG - 2012-04-05 13:33:41 --> Config Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:33:41 --> URI Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Router Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Output Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Security Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Input Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:33:41 --> Language Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Loader Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:33:41 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Session Class Initialized
DEBUG - 2012-04-05 13:33:41 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:33:41 --> Session routines successfully run
DEBUG - 2012-04-05 13:33:41 --> Controller Class Initialized
DEBUG - 2012-04-05 13:33:41 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:33:41 --> Final output sent to browser
DEBUG - 2012-04-05 13:33:41 --> Total execution time: 0.0595
DEBUG - 2012-04-05 13:33:42 --> Config Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:33:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:33:42 --> URI Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Router Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Output Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Security Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Input Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:33:42 --> Language Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Loader Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:33:42 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Session Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:33:42 --> Session routines successfully run
DEBUG - 2012-04-05 13:33:42 --> Controller Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Model Class Initialized
DEBUG - 2012-04-05 13:33:42 --> Model Class Initialized
DEBUG - 2012-04-05 13:33:42 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:33:42 --> Final output sent to browser
DEBUG - 2012-04-05 13:33:42 --> Total execution time: 0.0649
DEBUG - 2012-04-05 13:34:19 --> Config Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:34:19 --> URI Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Router Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Output Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Security Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Input Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:34:19 --> Language Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Loader Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:34:19 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Session Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:34:19 --> Session routines successfully run
DEBUG - 2012-04-05 13:34:19 --> Controller Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Model Class Initialized
DEBUG - 2012-04-05 13:34:19 --> Model Class Initialized
DEBUG - 2012-04-05 13:34:19 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:34:19 --> Final output sent to browser
DEBUG - 2012-04-05 13:34:19 --> Total execution time: 0.0685
DEBUG - 2012-04-05 13:38:42 --> Config Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:38:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:38:42 --> URI Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Router Class Initialized
DEBUG - 2012-04-05 13:38:42 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:38:42 --> Output Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Security Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Input Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:38:42 --> Language Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Loader Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:38:42 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Session Class Initialized
DEBUG - 2012-04-05 13:38:42 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:38:42 --> Session routines successfully run
DEBUG - 2012-04-05 13:38:42 --> Controller Class Initialized
DEBUG - 2012-04-05 13:38:42 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:38:42 --> Final output sent to browser
DEBUG - 2012-04-05 13:38:42 --> Total execution time: 0.0623
DEBUG - 2012-04-05 13:38:44 --> Config Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:38:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:38:44 --> URI Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Router Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Output Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Security Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Input Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:38:44 --> Language Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Loader Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:38:44 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Session Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:38:44 --> Session routines successfully run
DEBUG - 2012-04-05 13:38:44 --> Controller Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Model Class Initialized
DEBUG - 2012-04-05 13:38:44 --> Model Class Initialized
DEBUG - 2012-04-05 13:38:44 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:38:44 --> Final output sent to browser
DEBUG - 2012-04-05 13:38:44 --> Total execution time: 0.0647
DEBUG - 2012-04-05 13:39:04 --> Config Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:39:04 --> URI Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Router Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Output Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Security Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Input Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:39:04 --> Language Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Loader Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:39:04 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Session Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:39:04 --> Session routines successfully run
DEBUG - 2012-04-05 13:39:04 --> Controller Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Model Class Initialized
DEBUG - 2012-04-05 13:39:04 --> Model Class Initialized
DEBUG - 2012-04-05 13:39:04 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:39:04 --> Final output sent to browser
DEBUG - 2012-04-05 13:39:04 --> Total execution time: 0.0667
DEBUG - 2012-04-05 13:39:05 --> Config Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:39:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:39:05 --> URI Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Router Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Output Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Security Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Input Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:39:05 --> Language Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Loader Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:39:05 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Session Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:39:05 --> Session routines successfully run
DEBUG - 2012-04-05 13:39:05 --> Controller Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Model Class Initialized
DEBUG - 2012-04-05 13:39:05 --> Model Class Initialized
DEBUG - 2012-04-05 13:39:05 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:39:05 --> Final output sent to browser
DEBUG - 2012-04-05 13:39:05 --> Total execution time: 0.0671
DEBUG - 2012-04-05 13:39:06 --> Config Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:39:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:39:06 --> URI Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Router Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Output Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Security Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Input Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:39:06 --> Language Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Loader Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:39:06 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Session Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:39:06 --> Session routines successfully run
DEBUG - 2012-04-05 13:39:06 --> Controller Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Model Class Initialized
DEBUG - 2012-04-05 13:39:06 --> Model Class Initialized
DEBUG - 2012-04-05 13:39:06 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:39:06 --> Final output sent to browser
DEBUG - 2012-04-05 13:39:06 --> Total execution time: 0.0699
DEBUG - 2012-04-05 13:39:07 --> Config Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:39:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:39:07 --> URI Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Router Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Output Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Security Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Input Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:39:07 --> Language Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Loader Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:39:07 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Session Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:39:07 --> Session routines successfully run
DEBUG - 2012-04-05 13:39:07 --> Controller Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Model Class Initialized
DEBUG - 2012-04-05 13:39:07 --> Model Class Initialized
DEBUG - 2012-04-05 13:39:07 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:39:07 --> Final output sent to browser
DEBUG - 2012-04-05 13:39:07 --> Total execution time: 0.0731
DEBUG - 2012-04-05 13:42:30 --> Config Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:42:30 --> URI Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Router Class Initialized
DEBUG - 2012-04-05 13:42:30 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:42:30 --> Output Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Security Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Input Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:42:30 --> Language Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Loader Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:42:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Session Class Initialized
DEBUG - 2012-04-05 13:42:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:42:30 --> Session routines successfully run
DEBUG - 2012-04-05 13:42:30 --> Controller Class Initialized
DEBUG - 2012-04-05 13:42:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:42:30 --> Final output sent to browser
DEBUG - 2012-04-05 13:42:30 --> Total execution time: 0.0680
DEBUG - 2012-04-05 13:42:38 --> Config Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:42:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:42:38 --> URI Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Router Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Output Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Security Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Input Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:42:38 --> Language Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Loader Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:42:38 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Session Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:42:38 --> Session routines successfully run
DEBUG - 2012-04-05 13:42:38 --> Controller Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Model Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Model Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Config Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:42:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:42:38 --> URI Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Router Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Output Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Security Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Input Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:42:38 --> Language Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Loader Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:42:38 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Session Class Initialized
DEBUG - 2012-04-05 13:42:38 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:42:38 --> Session routines successfully run
DEBUG - 2012-04-05 13:42:38 --> Controller Class Initialized
DEBUG - 2012-04-05 13:42:38 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 13:42:38 --> Final output sent to browser
DEBUG - 2012-04-05 13:42:38 --> Total execution time: 0.0619
DEBUG - 2012-04-05 13:42:46 --> Config Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:42:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:42:46 --> URI Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Router Class Initialized
DEBUG - 2012-04-05 13:42:46 --> No URI present. Default controller set.
DEBUG - 2012-04-05 13:42:46 --> Output Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Security Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Input Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:42:46 --> Language Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Loader Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:42:46 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Session Class Initialized
DEBUG - 2012-04-05 13:42:46 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:42:46 --> Session routines successfully run
DEBUG - 2012-04-05 13:42:46 --> Controller Class Initialized
DEBUG - 2012-04-05 13:42:46 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 13:42:46 --> Final output sent to browser
DEBUG - 2012-04-05 13:42:46 --> Total execution time: 0.0640
DEBUG - 2012-04-05 13:42:48 --> Config Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:42:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:42:48 --> URI Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Router Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Output Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Security Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Input Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:42:48 --> Language Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Loader Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:42:48 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Session Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:42:48 --> Session routines successfully run
DEBUG - 2012-04-05 13:42:48 --> Controller Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Config Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:42:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:42:48 --> URI Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Router Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Output Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Security Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Input Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:42:48 --> Language Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Loader Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:42:48 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Session Class Initialized
DEBUG - 2012-04-05 13:42:48 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:42:48 --> A session cookie was not found.
DEBUG - 2012-04-05 13:42:48 --> Session routines successfully run
DEBUG - 2012-04-05 13:42:48 --> Controller Class Initialized
DEBUG - 2012-04-05 13:42:48 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 13:42:48 --> Final output sent to browser
DEBUG - 2012-04-05 13:42:48 --> Total execution time: 0.0641
DEBUG - 2012-04-05 13:44:22 --> Config Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:44:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:44:22 --> URI Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Router Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Output Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Security Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Input Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:44:22 --> Language Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Loader Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:44:22 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Session Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:44:22 --> Session routines successfully run
DEBUG - 2012-04-05 13:44:22 --> Controller Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Model Class Initialized
DEBUG - 2012-04-05 13:44:22 --> Model Class Initialized
DEBUG - 2012-04-05 13:44:22 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:44:22 --> Final output sent to browser
DEBUG - 2012-04-05 13:44:22 --> Total execution time: 0.0706
DEBUG - 2012-04-05 13:53:29 --> Config Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:53:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:53:29 --> URI Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Router Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Output Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Security Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Input Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:53:29 --> Language Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Loader Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:53:29 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Session Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:53:29 --> Session routines successfully run
DEBUG - 2012-04-05 13:53:29 --> Controller Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Model Class Initialized
DEBUG - 2012-04-05 13:53:29 --> Model Class Initialized
DEBUG - 2012-04-05 13:53:29 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:53:29 --> Final output sent to browser
DEBUG - 2012-04-05 13:53:29 --> Total execution time: 0.0707
DEBUG - 2012-04-05 13:53:49 --> Config Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:53:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:53:49 --> URI Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Router Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Output Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Security Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Input Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:53:49 --> Language Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Loader Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:53:49 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Session Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:53:49 --> Session routines successfully run
DEBUG - 2012-04-05 13:53:49 --> Controller Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Model Class Initialized
DEBUG - 2012-04-05 13:53:49 --> Model Class Initialized
DEBUG - 2012-04-05 13:53:49 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:53:49 --> Final output sent to browser
DEBUG - 2012-04-05 13:53:49 --> Total execution time: 0.0693
DEBUG - 2012-04-05 13:53:59 --> Config Class Initialized
DEBUG - 2012-04-05 13:53:59 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:53:59 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:53:59 --> URI Class Initialized
DEBUG - 2012-04-05 13:53:59 --> Router Class Initialized
DEBUG - 2012-04-05 13:53:59 --> Output Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Security Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Input Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:54:00 --> Language Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Loader Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:54:00 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Session Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:54:00 --> Session routines successfully run
DEBUG - 2012-04-05 13:54:00 --> Controller Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Model Class Initialized
DEBUG - 2012-04-05 13:54:00 --> Model Class Initialized
DEBUG - 2012-04-05 13:54:00 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:54:00 --> Final output sent to browser
DEBUG - 2012-04-05 13:54:00 --> Total execution time: 0.0707
DEBUG - 2012-04-05 13:54:59 --> Config Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:54:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:54:59 --> URI Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Router Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Output Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Security Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Input Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:54:59 --> Language Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Loader Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:54:59 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Session Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:54:59 --> Session routines successfully run
DEBUG - 2012-04-05 13:54:59 --> Controller Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Model Class Initialized
DEBUG - 2012-04-05 13:54:59 --> Model Class Initialized
ERROR - 2012-04-05 13:54:59 --> Severity: Notice  --> Undefined variable: FirstName C:\Software\xampp\htdocs\xcms\system\views\register_view.php 5
DEBUG - 2012-04-05 13:54:59 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:54:59 --> Final output sent to browser
DEBUG - 2012-04-05 13:54:59 --> Total execution time: 0.0735
DEBUG - 2012-04-05 13:55:20 --> Config Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:55:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:55:20 --> URI Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Router Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Output Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Security Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Input Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:55:20 --> Language Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Loader Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:55:20 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Session Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:55:20 --> Session routines successfully run
DEBUG - 2012-04-05 13:55:20 --> Controller Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Model Class Initialized
DEBUG - 2012-04-05 13:55:20 --> Model Class Initialized
ERROR - 2012-04-05 13:55:20 --> Severity: Notice  --> Undefined variable: FirstName C:\Software\xampp\htdocs\xcms\system\views\register_view.php 5
DEBUG - 2012-04-05 13:55:20 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:55:20 --> Final output sent to browser
DEBUG - 2012-04-05 13:55:20 --> Total execution time: 0.0742
DEBUG - 2012-04-05 13:56:40 --> Config Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:56:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:56:40 --> URI Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Router Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Output Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Security Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Input Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:56:40 --> Language Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Loader Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:56:40 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Session Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:56:40 --> Session routines successfully run
DEBUG - 2012-04-05 13:56:40 --> Controller Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Model Class Initialized
DEBUG - 2012-04-05 13:56:40 --> Model Class Initialized
DEBUG - 2012-04-05 13:56:40 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:56:40 --> Final output sent to browser
DEBUG - 2012-04-05 13:56:40 --> Total execution time: 0.0700
DEBUG - 2012-04-05 13:56:46 --> Config Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:56:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:56:46 --> URI Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Router Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Output Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Security Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Input Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:56:46 --> Language Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Loader Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:56:46 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Session Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:56:46 --> Session routines successfully run
DEBUG - 2012-04-05 13:56:46 --> Controller Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Model Class Initialized
DEBUG - 2012-04-05 13:56:46 --> Model Class Initialized
DEBUG - 2012-04-05 13:56:46 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:56:46 --> Final output sent to browser
DEBUG - 2012-04-05 13:56:46 --> Total execution time: 0.0745
DEBUG - 2012-04-05 13:56:48 --> Config Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:56:48 --> URI Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Router Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Output Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Security Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Input Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:56:48 --> Language Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Loader Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:56:48 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Session Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:56:48 --> Session routines successfully run
DEBUG - 2012-04-05 13:56:48 --> Controller Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Model Class Initialized
DEBUG - 2012-04-05 13:56:48 --> Model Class Initialized
DEBUG - 2012-04-05 13:56:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:56:48 --> Final output sent to browser
DEBUG - 2012-04-05 13:56:48 --> Total execution time: 0.0713
DEBUG - 2012-04-05 13:57:00 --> Config Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:57:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:57:00 --> URI Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Router Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Output Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Security Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Input Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:57:00 --> Language Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Loader Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:57:00 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Session Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:57:00 --> Session routines successfully run
DEBUG - 2012-04-05 13:57:00 --> Controller Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Model Class Initialized
DEBUG - 2012-04-05 13:57:00 --> Model Class Initialized
DEBUG - 2012-04-05 13:57:00 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:57:00 --> Final output sent to browser
DEBUG - 2012-04-05 13:57:00 --> Total execution time: 0.0719
DEBUG - 2012-04-05 13:57:06 --> Config Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Hooks Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Utf8 Class Initialized
DEBUG - 2012-04-05 13:57:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 13:57:06 --> URI Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Router Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Output Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Security Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Input Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 13:57:06 --> Language Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Loader Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Helper loaded: url_helper
DEBUG - 2012-04-05 13:57:06 --> Database Driver Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Session Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Helper loaded: string_helper
DEBUG - 2012-04-05 13:57:06 --> Session routines successfully run
DEBUG - 2012-04-05 13:57:06 --> Controller Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Model Class Initialized
DEBUG - 2012-04-05 13:57:06 --> Model Class Initialized
DEBUG - 2012-04-05 13:57:06 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 13:57:06 --> Final output sent to browser
DEBUG - 2012-04-05 13:57:06 --> Total execution time: 0.0709
DEBUG - 2012-04-05 14:08:48 --> Config Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:08:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:08:48 --> URI Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Router Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Output Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Security Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Input Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:08:48 --> Language Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Loader Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:08:48 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Session Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:08:48 --> Session routines successfully run
DEBUG - 2012-04-05 14:08:48 --> Controller Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Model Class Initialized
DEBUG - 2012-04-05 14:08:48 --> Model Class Initialized
DEBUG - 2012-04-05 14:08:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:08:48 --> Final output sent to browser
DEBUG - 2012-04-05 14:08:48 --> Total execution time: 0.0779
DEBUG - 2012-04-05 14:08:53 --> Config Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:08:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:08:53 --> URI Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Router Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Output Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Security Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Input Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:08:53 --> Language Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Loader Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:08:53 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Session Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:08:53 --> Session routines successfully run
DEBUG - 2012-04-05 14:08:53 --> Controller Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Model Class Initialized
DEBUG - 2012-04-05 14:08:53 --> Model Class Initialized
DEBUG - 2012-04-05 14:08:53 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:08:53 --> Final output sent to browser
DEBUG - 2012-04-05 14:08:53 --> Total execution time: 0.0728
DEBUG - 2012-04-05 14:09:13 --> Config Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:09:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:09:13 --> URI Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Router Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Output Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Security Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Input Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:09:13 --> Language Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Loader Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:09:13 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Session Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:09:13 --> Session routines successfully run
DEBUG - 2012-04-05 14:09:13 --> Controller Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Model Class Initialized
DEBUG - 2012-04-05 14:09:13 --> Model Class Initialized
DEBUG - 2012-04-05 14:09:13 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:09:13 --> Final output sent to browser
DEBUG - 2012-04-05 14:09:13 --> Total execution time: 0.0729
DEBUG - 2012-04-05 14:10:18 --> Config Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:10:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:10:18 --> URI Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Router Class Initialized
DEBUG - 2012-04-05 14:10:18 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:10:18 --> Output Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Security Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Input Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:10:18 --> Language Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Loader Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:10:18 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Session Class Initialized
DEBUG - 2012-04-05 14:10:18 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:10:18 --> Session routines successfully run
DEBUG - 2012-04-05 14:10:18 --> Controller Class Initialized
DEBUG - 2012-04-05 14:10:18 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:10:18 --> Final output sent to browser
DEBUG - 2012-04-05 14:10:18 --> Total execution time: 0.0689
DEBUG - 2012-04-05 14:10:20 --> Config Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:10:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:10:20 --> URI Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Router Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Output Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Security Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Input Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:10:20 --> Language Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Loader Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:10:20 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Session Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:10:20 --> Session routines successfully run
DEBUG - 2012-04-05 14:10:20 --> Controller Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Model Class Initialized
DEBUG - 2012-04-05 14:10:20 --> Model Class Initialized
ERROR - 2012-04-05 14:10:20 --> Severity: Notice  --> Undefined index: FirstName C:\Software\xampp\htdocs\xcms\system\views\register_view.php 5
ERROR - 2012-04-05 14:10:20 --> Severity: Notice  --> Undefined index: LastName C:\Software\xampp\htdocs\xcms\system\views\register_view.php 6
DEBUG - 2012-04-05 14:10:20 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:10:20 --> Final output sent to browser
DEBUG - 2012-04-05 14:10:20 --> Total execution time: 0.1162
DEBUG - 2012-04-05 14:11:21 --> Config Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:11:21 --> URI Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Router Class Initialized
DEBUG - 2012-04-05 14:11:21 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:11:21 --> Output Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Security Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Input Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:11:21 --> Language Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Loader Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:11:21 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Session Class Initialized
DEBUG - 2012-04-05 14:11:21 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:11:21 --> Session routines successfully run
DEBUG - 2012-04-05 14:11:21 --> Controller Class Initialized
DEBUG - 2012-04-05 14:11:21 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:11:21 --> Final output sent to browser
DEBUG - 2012-04-05 14:11:21 --> Total execution time: 0.0674
DEBUG - 2012-04-05 14:11:23 --> Config Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:11:23 --> URI Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Router Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Output Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Security Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Input Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:11:23 --> Language Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Loader Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:11:23 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Session Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:11:23 --> Session routines successfully run
DEBUG - 2012-04-05 14:11:23 --> Controller Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Model Class Initialized
DEBUG - 2012-04-05 14:11:23 --> Model Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Config Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:12:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:12:12 --> URI Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Router Class Initialized
DEBUG - 2012-04-05 14:12:12 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:12:12 --> Output Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Security Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Input Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:12:12 --> Language Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Loader Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:12:12 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Session Class Initialized
DEBUG - 2012-04-05 14:12:12 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:12:12 --> Session routines successfully run
DEBUG - 2012-04-05 14:12:12 --> Controller Class Initialized
DEBUG - 2012-04-05 14:12:12 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:12:12 --> Final output sent to browser
DEBUG - 2012-04-05 14:12:12 --> Total execution time: 0.0671
DEBUG - 2012-04-05 14:12:13 --> Config Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:12:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:12:13 --> URI Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Router Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Output Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Security Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Input Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:12:13 --> Language Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Loader Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:12:13 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Session Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:12:13 --> Session routines successfully run
DEBUG - 2012-04-05 14:12:13 --> Controller Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Model Class Initialized
DEBUG - 2012-04-05 14:12:13 --> Model Class Initialized
ERROR - 2012-04-05 14:12:13 --> Severity: Notice  --> Undefined index: LastName C:\Software\xampp\htdocs\xcms\system\views\register_view.php 6
DEBUG - 2012-04-05 14:12:13 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:12:13 --> Final output sent to browser
DEBUG - 2012-04-05 14:12:13 --> Total execution time: 0.0874
DEBUG - 2012-04-05 14:12:56 --> Config Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:12:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:12:56 --> URI Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Router Class Initialized
DEBUG - 2012-04-05 14:12:56 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:12:56 --> Output Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Security Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Input Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:12:56 --> Language Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Loader Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:12:56 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Session Class Initialized
DEBUG - 2012-04-05 14:12:56 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:12:56 --> Session routines successfully run
DEBUG - 2012-04-05 14:12:56 --> Controller Class Initialized
DEBUG - 2012-04-05 14:12:56 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:12:56 --> Final output sent to browser
DEBUG - 2012-04-05 14:12:56 --> Total execution time: 0.0704
DEBUG - 2012-04-05 14:12:58 --> Config Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:12:58 --> URI Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Router Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Output Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Security Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Input Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:12:58 --> Language Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Loader Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:12:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Session Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:12:58 --> Session routines successfully run
DEBUG - 2012-04-05 14:12:58 --> Controller Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Model Class Initialized
DEBUG - 2012-04-05 14:12:58 --> Model Class Initialized
DEBUG - 2012-04-05 14:12:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:12:58 --> Final output sent to browser
DEBUG - 2012-04-05 14:12:58 --> Total execution time: 0.0761
DEBUG - 2012-04-05 14:13:14 --> Config Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:13:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:13:14 --> URI Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Router Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Output Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Security Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Input Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:13:14 --> Language Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Loader Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:13:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Session Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:13:14 --> Session routines successfully run
DEBUG - 2012-04-05 14:13:14 --> Controller Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Model Class Initialized
DEBUG - 2012-04-05 14:13:14 --> Model Class Initialized
DEBUG - 2012-04-05 14:13:14 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:13:14 --> Final output sent to browser
DEBUG - 2012-04-05 14:13:14 --> Total execution time: 0.0728
DEBUG - 2012-04-05 14:13:22 --> Config Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:13:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:13:22 --> URI Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Router Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Output Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Security Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Input Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:13:22 --> Language Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Loader Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:13:22 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Session Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:13:22 --> Session routines successfully run
DEBUG - 2012-04-05 14:13:22 --> Controller Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Model Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Model Class Initialized
DEBUG - 2012-04-05 14:13:22 --> Final output sent to browser
DEBUG - 2012-04-05 14:13:22 --> Total execution time: 0.0683
DEBUG - 2012-04-05 14:13:26 --> Config Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:13:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:13:26 --> URI Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Router Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Output Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Security Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Input Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:13:26 --> Language Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Loader Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:13:26 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Session Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:13:26 --> Session routines successfully run
DEBUG - 2012-04-05 14:13:26 --> Controller Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Model Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Model Class Initialized
DEBUG - 2012-04-05 14:13:26 --> Final output sent to browser
DEBUG - 2012-04-05 14:13:26 --> Total execution time: 0.0683
DEBUG - 2012-04-05 14:13:30 --> Config Class Initialized
DEBUG - 2012-04-05 14:13:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:13:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:13:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:13:30 --> URI Class Initialized
DEBUG - 2012-04-05 14:13:30 --> Router Class Initialized
DEBUG - 2012-04-05 14:13:30 --> Output Class Initialized
DEBUG - 2012-04-05 14:13:30 --> Security Class Initialized
DEBUG - 2012-04-05 14:13:30 --> Input Class Initialized
DEBUG - 2012-04-05 14:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:13:30 --> Language Class Initialized
DEBUG - 2012-04-05 14:13:30 --> Loader Class Initialized
DEBUG - 2012-04-05 14:13:31 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:13:31 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:13:31 --> Session Class Initialized
DEBUG - 2012-04-05 14:13:31 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:13:31 --> Session routines successfully run
DEBUG - 2012-04-05 14:13:31 --> Controller Class Initialized
DEBUG - 2012-04-05 14:13:31 --> Model Class Initialized
DEBUG - 2012-04-05 14:13:31 --> Model Class Initialized
DEBUG - 2012-04-05 14:13:31 --> Final output sent to browser
DEBUG - 2012-04-05 14:13:31 --> Total execution time: 0.0684
DEBUG - 2012-04-05 14:14:42 --> Config Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:14:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:14:42 --> URI Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Router Class Initialized
DEBUG - 2012-04-05 14:14:42 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:14:42 --> Output Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Security Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Input Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:14:42 --> Language Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Loader Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:14:42 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Session Class Initialized
DEBUG - 2012-04-05 14:14:42 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:14:42 --> Session routines successfully run
DEBUG - 2012-04-05 14:14:42 --> Controller Class Initialized
DEBUG - 2012-04-05 14:14:42 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:14:42 --> Final output sent to browser
DEBUG - 2012-04-05 14:14:42 --> Total execution time: 0.0678
DEBUG - 2012-04-05 14:14:44 --> Config Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:14:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:14:44 --> URI Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Router Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Output Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Security Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Input Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:14:44 --> Language Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Loader Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:14:44 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Session Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:14:44 --> Session routines successfully run
DEBUG - 2012-04-05 14:14:44 --> Controller Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Model Class Initialized
DEBUG - 2012-04-05 14:14:44 --> Model Class Initialized
DEBUG - 2012-04-05 14:14:44 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:14:44 --> Final output sent to browser
DEBUG - 2012-04-05 14:14:44 --> Total execution time: 0.1025
DEBUG - 2012-04-05 14:14:51 --> Config Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:14:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:14:51 --> URI Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Router Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Output Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Security Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Input Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:14:51 --> Language Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Loader Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:14:51 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Session Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:14:51 --> Session routines successfully run
DEBUG - 2012-04-05 14:14:51 --> Controller Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Model Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Model Class Initialized
DEBUG - 2012-04-05 14:14:51 --> Final output sent to browser
DEBUG - 2012-04-05 14:14:51 --> Total execution time: 0.0691
DEBUG - 2012-04-05 14:16:56 --> Config Class Initialized
DEBUG - 2012-04-05 14:16:56 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:16:56 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:16:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:16:56 --> URI Class Initialized
DEBUG - 2012-04-05 14:16:56 --> Router Class Initialized
DEBUG - 2012-04-05 14:16:56 --> Output Class Initialized
DEBUG - 2012-04-05 14:16:56 --> Security Class Initialized
DEBUG - 2012-04-05 14:16:56 --> Input Class Initialized
DEBUG - 2012-04-05 14:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:16:56 --> Language Class Initialized
DEBUG - 2012-04-05 14:16:56 --> Loader Class Initialized
DEBUG - 2012-04-05 14:16:57 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:16:57 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:16:57 --> Session Class Initialized
DEBUG - 2012-04-05 14:16:57 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:16:57 --> Session routines successfully run
DEBUG - 2012-04-05 14:16:57 --> Controller Class Initialized
DEBUG - 2012-04-05 14:16:57 --> Model Class Initialized
DEBUG - 2012-04-05 14:16:57 --> Model Class Initialized
DEBUG - 2012-04-05 14:16:57 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:16:57 --> Final output sent to browser
DEBUG - 2012-04-05 14:16:57 --> Total execution time: 0.0734
DEBUG - 2012-04-05 14:17:00 --> Config Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:17:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:17:00 --> URI Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Router Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Output Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Security Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Input Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:17:00 --> Language Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Loader Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:17:00 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Session Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:17:00 --> Session routines successfully run
DEBUG - 2012-04-05 14:17:00 --> Controller Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Model Class Initialized
DEBUG - 2012-04-05 14:17:00 --> Model Class Initialized
DEBUG - 2012-04-05 14:17:00 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:17:00 --> Final output sent to browser
DEBUG - 2012-04-05 14:17:00 --> Total execution time: 0.0730
DEBUG - 2012-04-05 14:17:05 --> Config Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:17:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:17:05 --> URI Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Router Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Output Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Security Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Input Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:17:05 --> Language Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Loader Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:17:05 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Session Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:17:05 --> Session routines successfully run
DEBUG - 2012-04-05 14:17:05 --> Controller Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Model Class Initialized
DEBUG - 2012-04-05 14:17:05 --> Model Class Initialized
DEBUG - 2012-04-05 14:17:05 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:17:05 --> Final output sent to browser
DEBUG - 2012-04-05 14:17:05 --> Total execution time: 0.0731
DEBUG - 2012-04-05 14:17:10 --> Config Class Initialized
DEBUG - 2012-04-05 14:17:10 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:17:10 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:17:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:17:10 --> URI Class Initialized
DEBUG - 2012-04-05 14:17:10 --> Router Class Initialized
DEBUG - 2012-04-05 14:17:10 --> Output Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Security Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Input Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:17:11 --> Language Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Loader Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:17:11 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Session Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:17:11 --> Session routines successfully run
DEBUG - 2012-04-05 14:17:11 --> Controller Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Model Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Model Class Initialized
DEBUG - 2012-04-05 14:17:11 --> Final output sent to browser
DEBUG - 2012-04-05 14:17:11 --> Total execution time: 0.0703
DEBUG - 2012-04-05 14:18:05 --> Config Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:18:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:18:05 --> URI Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Router Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Output Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Security Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Input Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:18:05 --> Language Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Loader Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:18:05 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Session Class Initialized
DEBUG - 2012-04-05 14:18:05 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:18:05 --> Session routines successfully run
DEBUG - 2012-04-05 14:18:05 --> Controller Class Initialized
ERROR - 2012-04-05 14:18:05 --> Severity: Notice  --> Undefined variable: dept C:\Software\xampp\htdocs\xcms\system\views\register_view.php 12
ERROR - 2012-04-05 14:18:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\register_view.php 12
DEBUG - 2012-04-05 14:18:05 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:18:05 --> Final output sent to browser
DEBUG - 2012-04-05 14:18:05 --> Total execution time: 0.0712
DEBUG - 2012-04-05 14:21:59 --> Config Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:21:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:21:59 --> URI Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Router Class Initialized
DEBUG - 2012-04-05 14:21:59 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:21:59 --> Output Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Security Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Input Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:21:59 --> Language Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Loader Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:21:59 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Session Class Initialized
DEBUG - 2012-04-05 14:21:59 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:21:59 --> Session routines successfully run
DEBUG - 2012-04-05 14:21:59 --> Controller Class Initialized
DEBUG - 2012-04-05 14:21:59 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:21:59 --> Final output sent to browser
DEBUG - 2012-04-05 14:21:59 --> Total execution time: 0.0682
DEBUG - 2012-04-05 14:22:00 --> Config Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:22:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:22:00 --> URI Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Router Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Output Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Security Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Input Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:22:00 --> Language Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Loader Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:22:00 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Session Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:22:00 --> Session routines successfully run
DEBUG - 2012-04-05 14:22:00 --> Controller Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Model Class Initialized
DEBUG - 2012-04-05 14:22:00 --> Model Class Initialized
DEBUG - 2012-04-05 14:22:00 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:22:00 --> Final output sent to browser
DEBUG - 2012-04-05 14:22:00 --> Total execution time: 0.0726
DEBUG - 2012-04-05 14:22:07 --> Config Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:22:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:22:07 --> URI Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Router Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Output Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Security Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Input Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:22:07 --> Language Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Loader Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:22:07 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Session Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:22:07 --> Session routines successfully run
DEBUG - 2012-04-05 14:22:07 --> Controller Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Model Class Initialized
DEBUG - 2012-04-05 14:22:07 --> Model Class Initialized
DEBUG - 2012-04-05 14:22:07 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:22:07 --> Final output sent to browser
DEBUG - 2012-04-05 14:22:07 --> Total execution time: 0.0751
DEBUG - 2012-04-05 14:22:18 --> Config Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:22:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:22:18 --> URI Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Router Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Output Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Security Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Input Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:22:18 --> Language Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Loader Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:22:18 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Session Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:22:18 --> Session routines successfully run
DEBUG - 2012-04-05 14:22:18 --> Controller Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Model Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Model Class Initialized
DEBUG - 2012-04-05 14:22:18 --> Final output sent to browser
DEBUG - 2012-04-05 14:22:18 --> Total execution time: 0.0716
DEBUG - 2012-04-05 14:35:52 --> Config Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:35:52 --> URI Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Router Class Initialized
DEBUG - 2012-04-05 14:35:52 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:35:52 --> Output Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Security Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Input Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:35:52 --> Language Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Loader Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:35:52 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Session Class Initialized
DEBUG - 2012-04-05 14:35:52 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:35:52 --> Session routines successfully run
DEBUG - 2012-04-05 14:35:52 --> Controller Class Initialized
DEBUG - 2012-04-05 14:35:52 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:35:52 --> Final output sent to browser
DEBUG - 2012-04-05 14:35:52 --> Total execution time: 0.0689
DEBUG - 2012-04-05 14:39:59 --> Config Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:39:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:39:59 --> URI Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Router Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Output Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Security Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Input Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:39:59 --> Language Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Loader Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:39:59 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Session Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:39:59 --> Session routines successfully run
DEBUG - 2012-04-05 14:39:59 --> Controller Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Model Class Initialized
DEBUG - 2012-04-05 14:39:59 --> Model Class Initialized
DEBUG - 2012-04-05 14:39:59 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:39:59 --> Final output sent to browser
DEBUG - 2012-04-05 14:39:59 --> Total execution time: 0.0809
DEBUG - 2012-04-05 14:40:01 --> Config Class Initialized
DEBUG - 2012-04-05 14:40:01 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:40:01 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:40:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:40:01 --> URI Class Initialized
DEBUG - 2012-04-05 14:40:01 --> Router Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Output Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Security Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Input Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:40:02 --> Language Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Loader Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:40:02 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Session Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:40:02 --> Session routines successfully run
DEBUG - 2012-04-05 14:40:02 --> Controller Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Model Class Initialized
DEBUG - 2012-04-05 14:40:02 --> Model Class Initialized
DEBUG - 2012-04-05 14:40:02 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:40:02 --> Final output sent to browser
DEBUG - 2012-04-05 14:40:02 --> Total execution time: 0.0741
DEBUG - 2012-04-05 14:40:43 --> Config Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:40:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:40:43 --> URI Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Router Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Output Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Security Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Input Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:40:43 --> Language Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Loader Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:40:43 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Session Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:40:43 --> Session routines successfully run
DEBUG - 2012-04-05 14:40:43 --> Controller Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Model Class Initialized
DEBUG - 2012-04-05 14:40:43 --> Model Class Initialized
ERROR - 2012-04-05 14:40:43 --> Severity: Notice  --> Undefined index: Department C:\Software\xampp\htdocs\xcms\system\models\user.php 62
DEBUG - 2012-04-05 14:40:43 --> DB Transaction Failure
ERROR - 2012-04-05 14:40:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '530,nelson@gmail.com,nelson,1)' at line 1
DEBUG - 2012-04-05 14:40:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 14:41:56 --> Config Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:41:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:41:56 --> URI Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Router Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Output Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Security Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Input Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:41:56 --> Language Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Loader Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:41:56 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Session Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:41:56 --> Session routines successfully run
DEBUG - 2012-04-05 14:41:56 --> Controller Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Model Class Initialized
DEBUG - 2012-04-05 14:41:56 --> Model Class Initialized
DEBUG - 2012-04-05 14:41:56 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:41:56 --> Final output sent to browser
DEBUG - 2012-04-05 14:41:56 --> Total execution time: 0.0725
DEBUG - 2012-04-05 14:43:19 --> Config Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:43:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:43:19 --> URI Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Router Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Output Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Security Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Input Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:43:19 --> Language Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Loader Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:43:19 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Session Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:43:19 --> Session routines successfully run
DEBUG - 2012-04-05 14:43:19 --> Controller Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Model Class Initialized
DEBUG - 2012-04-05 14:43:19 --> Model Class Initialized
DEBUG - 2012-04-05 14:43:19 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:43:19 --> Final output sent to browser
DEBUG - 2012-04-05 14:43:19 --> Total execution time: 0.0739
DEBUG - 2012-04-05 14:43:44 --> Config Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:43:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:43:44 --> URI Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Router Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Output Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Security Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Input Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:43:44 --> Language Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Loader Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:43:44 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Session Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:43:44 --> Session routines successfully run
DEBUG - 2012-04-05 14:43:44 --> Controller Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Model Class Initialized
DEBUG - 2012-04-05 14:43:44 --> Model Class Initialized
ERROR - 2012-04-05 14:43:44 --> Severity: Notice  --> Undefined index: Department C:\Software\xampp\htdocs\xcms\system\models\user.php 62
DEBUG - 2012-04-05 14:43:44 --> DB Transaction Failure
ERROR - 2012-04-05 14:43:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '530,nelson@gmail.com,nelson,1)' at line 1
DEBUG - 2012-04-05 14:43:44 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 14:46:00 --> Config Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:46:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:46:00 --> URI Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Router Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Output Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Security Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Input Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:46:00 --> Language Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Loader Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:46:00 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Session Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:46:00 --> Session routines successfully run
DEBUG - 2012-04-05 14:46:00 --> Controller Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Model Class Initialized
DEBUG - 2012-04-05 14:46:00 --> Model Class Initialized
DEBUG - 2012-04-05 14:46:00 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:46:00 --> Final output sent to browser
DEBUG - 2012-04-05 14:46:00 --> Total execution time: 0.0766
DEBUG - 2012-04-05 14:46:47 --> Config Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:46:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:46:47 --> URI Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Router Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Output Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Security Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Input Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:46:47 --> Language Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Loader Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:46:47 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Session Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:46:47 --> Session routines successfully run
DEBUG - 2012-04-05 14:46:47 --> Controller Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Model Class Initialized
DEBUG - 2012-04-05 14:46:47 --> Model Class Initialized
DEBUG - 2012-04-05 14:46:47 --> DB Transaction Failure
ERROR - 2012-04-05 14:46:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@gmail.com,nelson,1)' at line 1
DEBUG - 2012-04-05 14:46:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 14:48:19 --> Config Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:48:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:48:19 --> URI Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Router Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Output Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Security Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Input Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:48:19 --> Language Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Loader Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:48:19 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Session Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:48:19 --> Session routines successfully run
DEBUG - 2012-04-05 14:48:19 --> Controller Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Model Class Initialized
DEBUG - 2012-04-05 14:48:19 --> Model Class Initialized
DEBUG - 2012-04-05 14:48:19 --> DB Transaction Failure
ERROR - 2012-04-05 14:48:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@gmail.com,nelson,1)' at line 1
DEBUG - 2012-04-05 14:48:19 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 14:49:51 --> Config Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:49:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:49:51 --> URI Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Router Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Output Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Security Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Input Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:49:51 --> Language Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Loader Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:49:51 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Session Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:49:51 --> Session routines successfully run
DEBUG - 2012-04-05 14:49:51 --> Controller Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Model Class Initialized
DEBUG - 2012-04-05 14:49:51 --> Model Class Initialized
DEBUG - 2012-04-05 14:49:51 --> DB Transaction Failure
ERROR - 2012-04-05 14:49:51 --> Query error: Unknown column 'student' in 'field list'
DEBUG - 2012-04-05 14:49:51 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 14:50:15 --> Config Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:50:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:50:15 --> URI Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Router Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Output Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Security Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Input Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:50:15 --> Language Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Loader Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:50:15 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Session Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:50:15 --> Session routines successfully run
DEBUG - 2012-04-05 14:50:15 --> Controller Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Model Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Model Class Initialized
DEBUG - 2012-04-05 14:50:15 --> Final output sent to browser
DEBUG - 2012-04-05 14:50:15 --> Total execution time: 0.1213
DEBUG - 2012-04-05 14:52:57 --> Config Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:52:57 --> URI Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Router Class Initialized
DEBUG - 2012-04-05 14:52:57 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:52:57 --> Output Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Security Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Input Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:52:57 --> Language Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Loader Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:52:57 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Session Class Initialized
DEBUG - 2012-04-05 14:52:57 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:52:57 --> Session routines successfully run
DEBUG - 2012-04-05 14:52:57 --> Controller Class Initialized
DEBUG - 2012-04-05 14:52:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:52:57 --> Final output sent to browser
DEBUG - 2012-04-05 14:52:57 --> Total execution time: 0.0703
DEBUG - 2012-04-05 14:52:58 --> Config Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:52:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:52:58 --> URI Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Router Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Output Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Security Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Input Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:52:58 --> Language Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Loader Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:52:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Session Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:52:58 --> Session routines successfully run
DEBUG - 2012-04-05 14:52:58 --> Controller Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Model Class Initialized
DEBUG - 2012-04-05 14:52:58 --> Model Class Initialized
DEBUG - 2012-04-05 14:52:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:52:58 --> Final output sent to browser
DEBUG - 2012-04-05 14:52:58 --> Total execution time: 0.0822
DEBUG - 2012-04-05 14:53:10 --> Config Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:53:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:53:10 --> URI Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Router Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Output Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Security Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Input Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:53:10 --> Language Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Loader Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:53:10 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Session Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:53:10 --> Session routines successfully run
DEBUG - 2012-04-05 14:53:10 --> Controller Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Model Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Model Class Initialized
DEBUG - 2012-04-05 14:53:10 --> Helper loaded: email_helper
DEBUG - 2012-04-05 14:53:10 --> Final output sent to browser
DEBUG - 2012-04-05 14:53:10 --> Total execution time: 0.1235
DEBUG - 2012-04-05 14:54:31 --> Config Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:54:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:54:31 --> URI Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Router Class Initialized
DEBUG - 2012-04-05 14:54:31 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:54:31 --> Output Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Security Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Input Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:54:31 --> Language Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Loader Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:54:31 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Session Class Initialized
DEBUG - 2012-04-05 14:54:31 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:54:31 --> Session routines successfully run
DEBUG - 2012-04-05 14:54:31 --> Controller Class Initialized
DEBUG - 2012-04-05 14:54:31 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:54:31 --> Final output sent to browser
DEBUG - 2012-04-05 14:54:31 --> Total execution time: 0.0709
DEBUG - 2012-04-05 14:54:33 --> Config Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:54:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:54:33 --> URI Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Router Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Output Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Security Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Input Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:54:33 --> Language Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Loader Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:54:33 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Session Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:54:33 --> Session routines successfully run
DEBUG - 2012-04-05 14:54:33 --> Controller Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Model Class Initialized
DEBUG - 2012-04-05 14:54:33 --> Model Class Initialized
DEBUG - 2012-04-05 14:54:33 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:54:33 --> Final output sent to browser
DEBUG - 2012-04-05 14:54:33 --> Total execution time: 0.1164
DEBUG - 2012-04-05 14:54:42 --> Config Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:54:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:54:42 --> URI Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Router Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Output Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Security Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Input Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:54:42 --> Language Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Loader Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:54:42 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Session Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:54:42 --> Session routines successfully run
DEBUG - 2012-04-05 14:54:42 --> Controller Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Model Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Model Class Initialized
DEBUG - 2012-04-05 14:54:42 --> Helper loaded: email_helper
DEBUG - 2012-04-05 14:54:42 --> Final output sent to browser
DEBUG - 2012-04-05 14:54:42 --> Total execution time: 0.0974
DEBUG - 2012-04-05 14:55:44 --> Config Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:55:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:55:44 --> URI Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Router Class Initialized
DEBUG - 2012-04-05 14:55:44 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:55:44 --> Output Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Security Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Input Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:55:44 --> Language Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Loader Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:55:44 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Session Class Initialized
DEBUG - 2012-04-05 14:55:44 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:55:44 --> Session routines successfully run
DEBUG - 2012-04-05 14:55:44 --> Controller Class Initialized
DEBUG - 2012-04-05 14:55:44 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:55:44 --> Final output sent to browser
DEBUG - 2012-04-05 14:55:44 --> Total execution time: 0.0666
DEBUG - 2012-04-05 14:55:45 --> Config Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:55:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:55:45 --> URI Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Router Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Output Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Security Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Input Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:55:45 --> Language Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Loader Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:55:45 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Session Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:55:45 --> Session routines successfully run
DEBUG - 2012-04-05 14:55:45 --> Controller Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Model Class Initialized
DEBUG - 2012-04-05 14:55:45 --> Model Class Initialized
DEBUG - 2012-04-05 14:55:45 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:55:45 --> Final output sent to browser
DEBUG - 2012-04-05 14:55:45 --> Total execution time: 0.0743
DEBUG - 2012-04-05 14:55:53 --> Config Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:55:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:55:53 --> URI Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Router Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Output Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Security Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Input Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:55:53 --> Language Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Loader Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:55:53 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Session Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:55:53 --> Session routines successfully run
DEBUG - 2012-04-05 14:55:53 --> Controller Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Model Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Model Class Initialized
DEBUG - 2012-04-05 14:55:53 --> Helper loaded: email_helper
DEBUG - 2012-04-05 14:55:53 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:55:53 --> Final output sent to browser
DEBUG - 2012-04-05 14:55:53 --> Total execution time: 0.0779
DEBUG - 2012-04-05 14:58:34 --> Config Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:58:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:58:34 --> URI Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Router Class Initialized
DEBUG - 2012-04-05 14:58:34 --> No URI present. Default controller set.
DEBUG - 2012-04-05 14:58:34 --> Output Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Security Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Input Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:58:34 --> Language Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Loader Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:58:34 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Session Class Initialized
DEBUG - 2012-04-05 14:58:34 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:58:34 --> Session routines successfully run
DEBUG - 2012-04-05 14:58:34 --> Controller Class Initialized
DEBUG - 2012-04-05 14:58:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 14:58:34 --> Final output sent to browser
DEBUG - 2012-04-05 14:58:34 --> Total execution time: 0.0818
DEBUG - 2012-04-05 14:58:37 --> Config Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:58:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:58:37 --> URI Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Router Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Output Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Security Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Input Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:58:37 --> Language Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Loader Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:58:37 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Session Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:58:37 --> Session routines successfully run
DEBUG - 2012-04-05 14:58:37 --> Controller Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Model Class Initialized
DEBUG - 2012-04-05 14:58:37 --> Model Class Initialized
DEBUG - 2012-04-05 14:58:37 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:58:37 --> Final output sent to browser
DEBUG - 2012-04-05 14:58:37 --> Total execution time: 0.0753
DEBUG - 2012-04-05 14:59:32 --> Config Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Hooks Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Utf8 Class Initialized
DEBUG - 2012-04-05 14:59:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 14:59:32 --> URI Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Router Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Output Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Security Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Input Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 14:59:32 --> Language Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Loader Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Helper loaded: url_helper
DEBUG - 2012-04-05 14:59:32 --> Database Driver Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Session Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Helper loaded: string_helper
DEBUG - 2012-04-05 14:59:32 --> Session routines successfully run
DEBUG - 2012-04-05 14:59:32 --> Controller Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Model Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Model Class Initialized
DEBUG - 2012-04-05 14:59:32 --> Helper loaded: email_helper
DEBUG - 2012-04-05 14:59:32 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 14:59:32 --> Final output sent to browser
DEBUG - 2012-04-05 14:59:32 --> Total execution time: 0.0865
DEBUG - 2012-04-05 15:00:18 --> Config Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:00:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:00:18 --> URI Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Router Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Output Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Security Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Input Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:00:18 --> Language Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Loader Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:00:18 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Session Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:00:18 --> Session routines successfully run
DEBUG - 2012-04-05 15:00:18 --> Controller Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Model Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Model Class Initialized
DEBUG - 2012-04-05 15:00:18 --> Helper loaded: email_helper
DEBUG - 2012-04-05 15:00:18 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:00:18 --> Final output sent to browser
DEBUG - 2012-04-05 15:00:18 --> Total execution time: 0.0783
DEBUG - 2012-04-05 15:00:42 --> Config Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:00:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:00:42 --> URI Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Router Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Output Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Security Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Input Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:00:42 --> Language Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Loader Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:00:42 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Session Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:00:42 --> Session routines successfully run
DEBUG - 2012-04-05 15:00:42 --> Controller Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Model Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Model Class Initialized
DEBUG - 2012-04-05 15:00:42 --> Helper loaded: email_helper
DEBUG - 2012-04-05 15:00:42 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:00:42 --> Final output sent to browser
DEBUG - 2012-04-05 15:00:42 --> Total execution time: 0.0938
DEBUG - 2012-04-05 15:01:57 --> Config Class Initialized
DEBUG - 2012-04-05 15:01:57 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:01:57 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:01:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:01:57 --> URI Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Router Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Output Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Security Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Input Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:01:58 --> Language Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Loader Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:01:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Session Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:01:58 --> Session routines successfully run
DEBUG - 2012-04-05 15:01:58 --> Controller Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Model Class Initialized
DEBUG - 2012-04-05 15:01:58 --> Model Class Initialized
DEBUG - 2012-04-05 15:01:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:01:58 --> Final output sent to browser
DEBUG - 2012-04-05 15:01:58 --> Total execution time: 0.0743
DEBUG - 2012-04-05 15:02:30 --> Config Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:02:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:02:30 --> URI Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Router Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Output Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Security Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Input Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:02:30 --> Language Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Loader Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:02:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Session Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:02:30 --> Session routines successfully run
DEBUG - 2012-04-05 15:02:30 --> Controller Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Model Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Model Class Initialized
DEBUG - 2012-04-05 15:02:30 --> Helper loaded: email_helper
DEBUG - 2012-04-05 15:02:30 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:02:30 --> Final output sent to browser
DEBUG - 2012-04-05 15:02:30 --> Total execution time: 0.0804
DEBUG - 2012-04-05 15:03:13 --> Config Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:03:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:03:13 --> URI Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Router Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Output Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Security Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Input Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:03:13 --> Language Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Loader Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:03:13 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Session Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:03:13 --> Session routines successfully run
DEBUG - 2012-04-05 15:03:13 --> Controller Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Model Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Model Class Initialized
DEBUG - 2012-04-05 15:03:13 --> Helper loaded: email_helper
DEBUG - 2012-04-05 15:03:13 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:03:13 --> Final output sent to browser
DEBUG - 2012-04-05 15:03:13 --> Total execution time: 0.0873
DEBUG - 2012-04-05 15:05:35 --> Config Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:05:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:05:35 --> URI Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Router Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Output Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Security Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Input Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:05:35 --> Language Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Loader Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:05:35 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Session Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:05:35 --> Session routines successfully run
DEBUG - 2012-04-05 15:05:35 --> Controller Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Model Class Initialized
DEBUG - 2012-04-05 15:05:35 --> Model Class Initialized
DEBUG - 2012-04-05 15:05:35 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:05:35 --> Final output sent to browser
DEBUG - 2012-04-05 15:05:35 --> Total execution time: 0.0707
DEBUG - 2012-04-05 15:06:11 --> Config Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:06:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:06:11 --> URI Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Router Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Output Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Security Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Input Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:06:11 --> Language Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Loader Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:06:11 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Session Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:06:11 --> Session routines successfully run
DEBUG - 2012-04-05 15:06:11 --> Controller Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Model Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Model Class Initialized
DEBUG - 2012-04-05 15:06:11 --> Helper loaded: email_helper
DEBUG - 2012-04-05 15:06:11 --> DB Transaction Failure
ERROR - 2012-04-05 15:06:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`,'pete@pete.com','peter',1)' at line 1
DEBUG - 2012-04-05 15:06:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 15:06:56 --> Config Class Initialized
DEBUG - 2012-04-05 15:06:56 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:06:57 --> URI Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Router Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Output Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Security Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Input Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:06:57 --> Language Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Loader Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:06:57 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Session Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:06:57 --> Session routines successfully run
DEBUG - 2012-04-05 15:06:57 --> Controller Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Model Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Model Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Helper loaded: email_helper
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 103
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 103
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 104
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 104
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 105
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 105
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 106
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 106
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 107
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 107
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 108
ERROR - 2012-04-05 15:06:57 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 108
DEBUG - 2012-04-05 15:06:57 --> Config Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:06:57 --> URI Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Router Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Output Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Security Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Input Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:06:57 --> Language Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Loader Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:06:57 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Session Class Initialized
DEBUG - 2012-04-05 15:06:57 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:06:57 --> Session routines successfully run
DEBUG - 2012-04-05 15:06:57 --> Controller Class Initialized
DEBUG - 2012-04-05 15:06:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:06:57 --> Final output sent to browser
DEBUG - 2012-04-05 15:06:57 --> Total execution time: 0.0618
DEBUG - 2012-04-05 15:16:14 --> Config Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:16:14 --> URI Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Router Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Output Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Security Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Input Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:16:14 --> Language Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Loader Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:16:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Session Class Initialized
DEBUG - 2012-04-05 15:16:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:16:14 --> Session routines successfully run
DEBUG - 2012-04-05 15:16:14 --> Controller Class Initialized
DEBUG - 2012-04-05 15:16:14 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:16:14 --> Final output sent to browser
DEBUG - 2012-04-05 15:16:14 --> Total execution time: 0.0675
DEBUG - 2012-04-05 15:16:15 --> Config Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:16:15 --> URI Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Router Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Output Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Security Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Input Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:16:15 --> Language Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Loader Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:16:15 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Session Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:16:15 --> Session routines successfully run
DEBUG - 2012-04-05 15:16:15 --> Controller Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Model Class Initialized
DEBUG - 2012-04-05 15:16:15 --> Model Class Initialized
DEBUG - 2012-04-05 15:16:15 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:16:15 --> Final output sent to browser
DEBUG - 2012-04-05 15:16:15 --> Total execution time: 0.0762
DEBUG - 2012-04-05 15:16:48 --> Config Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:16:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:16:49 --> URI Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Router Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Output Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Security Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Input Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:16:49 --> Language Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Loader Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:16:49 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Session Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:16:49 --> Session routines successfully run
DEBUG - 2012-04-05 15:16:49 --> Controller Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Model Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Model Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Helper loaded: email_helper
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 104
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 104
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 105
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 105
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 106
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 106
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 107
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 107
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 108
ERROR - 2012-04-05 15:16:49 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 108
DEBUG - 2012-04-05 15:16:49 --> Config Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:16:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:16:49 --> URI Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Router Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Output Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Security Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Input Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:16:49 --> Language Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Loader Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:16:49 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Session Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:16:49 --> Session routines successfully run
DEBUG - 2012-04-05 15:16:49 --> Controller Class Initialized
DEBUG - 2012-04-05 15:16:49 --> Final output sent to browser
DEBUG - 2012-04-05 15:16:49 --> Total execution time: 0.0776
DEBUG - 2012-04-05 15:20:09 --> Config Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:20:09 --> URI Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Router Class Initialized
DEBUG - 2012-04-05 15:20:09 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:20:09 --> Output Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Security Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Input Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:20:09 --> Language Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Loader Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:20:09 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Session Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:20:09 --> Session routines successfully run
DEBUG - 2012-04-05 15:20:09 --> Controller Class Initialized
DEBUG - 2012-04-05 15:20:09 --> Final output sent to browser
DEBUG - 2012-04-05 15:20:09 --> Total execution time: 0.0647
DEBUG - 2012-04-05 15:21:56 --> Config Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:21:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:21:56 --> URI Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Router Class Initialized
DEBUG - 2012-04-05 15:21:56 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:21:56 --> Output Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Security Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Input Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:21:56 --> Language Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Loader Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:21:56 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Session Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:21:56 --> Session routines successfully run
DEBUG - 2012-04-05 15:21:56 --> Controller Class Initialized
DEBUG - 2012-04-05 15:21:56 --> Final output sent to browser
DEBUG - 2012-04-05 15:21:56 --> Total execution time: 0.0658
DEBUG - 2012-04-05 15:22:03 --> Config Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:22:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:22:03 --> URI Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Router Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Output Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Security Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Input Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:22:03 --> Language Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Loader Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:22:03 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Session Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:22:03 --> Session routines successfully run
DEBUG - 2012-04-05 15:22:03 --> Controller Class Initialized
DEBUG - 2012-04-05 15:22:03 --> Final output sent to browser
DEBUG - 2012-04-05 15:22:03 --> Total execution time: 0.0775
DEBUG - 2012-04-05 15:23:28 --> Config Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:23:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:23:28 --> URI Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Router Class Initialized
DEBUG - 2012-04-05 15:23:28 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:23:28 --> Output Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Security Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Input Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:23:28 --> Language Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Loader Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:23:28 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Session Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:23:28 --> Session routines successfully run
DEBUG - 2012-04-05 15:23:28 --> Controller Class Initialized
DEBUG - 2012-04-05 15:23:28 --> Final output sent to browser
DEBUG - 2012-04-05 15:23:28 --> Total execution time: 0.0651
DEBUG - 2012-04-05 15:23:58 --> Config Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:23:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:23:58 --> URI Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Router Class Initialized
DEBUG - 2012-04-05 15:23:58 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:23:58 --> Output Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Security Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Input Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:23:58 --> Language Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Loader Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:23:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Session Class Initialized
DEBUG - 2012-04-05 15:23:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:23:58 --> A session cookie was not found.
DEBUG - 2012-04-05 15:23:58 --> Session routines successfully run
DEBUG - 2012-04-05 15:23:58 --> Controller Class Initialized
DEBUG - 2012-04-05 15:23:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:23:58 --> Final output sent to browser
DEBUG - 2012-04-05 15:23:58 --> Total execution time: 0.1728
DEBUG - 2012-04-05 15:24:26 --> Config Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:24:26 --> URI Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Router Class Initialized
DEBUG - 2012-04-05 15:24:26 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:24:26 --> Output Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Security Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Input Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:24:26 --> Language Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Loader Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:24:26 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Session Class Initialized
DEBUG - 2012-04-05 15:24:26 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:24:26 --> Session routines successfully run
DEBUG - 2012-04-05 15:24:26 --> Controller Class Initialized
DEBUG - 2012-04-05 15:24:26 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:24:26 --> Final output sent to browser
DEBUG - 2012-04-05 15:24:26 --> Total execution time: 0.0722
DEBUG - 2012-04-05 15:24:44 --> Config Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:24:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:24:44 --> URI Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Router Class Initialized
DEBUG - 2012-04-05 15:24:44 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:24:44 --> Output Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Security Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Input Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:24:44 --> Language Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Loader Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:24:44 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Session Class Initialized
DEBUG - 2012-04-05 15:24:44 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:24:44 --> A session cookie was not found.
DEBUG - 2012-04-05 15:24:44 --> Session routines successfully run
DEBUG - 2012-04-05 15:24:44 --> Controller Class Initialized
DEBUG - 2012-04-05 15:24:44 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:24:44 --> Final output sent to browser
DEBUG - 2012-04-05 15:24:44 --> Total execution time: 0.0716
DEBUG - 2012-04-05 15:24:51 --> Config Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:24:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:24:51 --> URI Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Router Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Output Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Security Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Input Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:24:51 --> Language Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Loader Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:24:51 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Session Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:24:51 --> Session routines successfully run
DEBUG - 2012-04-05 15:24:51 --> Controller Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Model Class Initialized
DEBUG - 2012-04-05 15:24:51 --> Model Class Initialized
DEBUG - 2012-04-05 15:24:51 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:24:51 --> Final output sent to browser
DEBUG - 2012-04-05 15:24:51 --> Total execution time: 0.0806
DEBUG - 2012-04-05 15:25:19 --> Config Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:25:19 --> URI Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Router Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Output Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Security Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Input Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:25:19 --> Language Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Loader Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:25:19 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Session Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:25:19 --> Session routines successfully run
DEBUG - 2012-04-05 15:25:19 --> Controller Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Model Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Model Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Config Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:25:19 --> URI Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Router Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Output Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Security Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Input Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:25:19 --> Language Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Loader Class Initialized
DEBUG - 2012-04-05 15:25:19 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:25:20 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:25:20 --> Session Class Initialized
DEBUG - 2012-04-05 15:25:20 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:25:20 --> Session routines successfully run
DEBUG - 2012-04-05 15:25:20 --> Controller Class Initialized
DEBUG - 2012-04-05 15:25:20 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 15:25:20 --> Final output sent to browser
DEBUG - 2012-04-05 15:25:20 --> Total execution time: 0.0664
DEBUG - 2012-04-05 15:25:25 --> Config Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:25:25 --> URI Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Router Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Output Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Security Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Input Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:25:25 --> Language Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Loader Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:25:25 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Session Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:25:25 --> Session routines successfully run
DEBUG - 2012-04-05 15:25:25 --> Controller Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Config Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:25:25 --> URI Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Router Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Output Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Security Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Input Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:25:25 --> Language Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Loader Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:25:25 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Session Class Initialized
DEBUG - 2012-04-05 15:25:25 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:25:25 --> A session cookie was not found.
DEBUG - 2012-04-05 15:25:25 --> Session routines successfully run
DEBUG - 2012-04-05 15:25:25 --> Controller Class Initialized
DEBUG - 2012-04-05 15:25:25 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:25:25 --> Final output sent to browser
DEBUG - 2012-04-05 15:25:25 --> Total execution time: 0.0677
DEBUG - 2012-04-05 15:25:28 --> Config Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:25:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:25:28 --> URI Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Router Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Output Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Security Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Input Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:25:28 --> Language Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Loader Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:25:28 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Session Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:25:28 --> Session routines successfully run
DEBUG - 2012-04-05 15:25:28 --> Controller Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Model Class Initialized
DEBUG - 2012-04-05 15:25:28 --> Model Class Initialized
DEBUG - 2012-04-05 15:25:28 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:25:28 --> Final output sent to browser
DEBUG - 2012-04-05 15:25:28 --> Total execution time: 0.0746
DEBUG - 2012-04-05 15:27:05 --> Config Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:27:05 --> URI Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Router Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Output Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Security Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Input Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:27:05 --> Language Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Loader Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:27:05 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Session Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:27:05 --> Session routines successfully run
DEBUG - 2012-04-05 15:27:05 --> Controller Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Model Class Initialized
DEBUG - 2012-04-05 15:27:05 --> Model Class Initialized
DEBUG - 2012-04-05 15:27:05 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:27:05 --> Final output sent to browser
DEBUG - 2012-04-05 15:27:05 --> Total execution time: 0.0730
DEBUG - 2012-04-05 15:27:15 --> Config Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:27:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:27:15 --> URI Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Router Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Output Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Security Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Input Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:27:15 --> Language Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Loader Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:27:15 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Session Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:27:15 --> Session routines successfully run
DEBUG - 2012-04-05 15:27:15 --> Controller Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Model Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Model Class Initialized
DEBUG - 2012-04-05 15:27:15 --> Helper loaded: email_helper
DEBUG - 2012-04-05 15:27:15 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:27:15 --> Final output sent to browser
DEBUG - 2012-04-05 15:27:15 --> Total execution time: 0.0795
DEBUG - 2012-04-05 15:27:27 --> Config Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:27:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:27:27 --> URI Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Router Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Output Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Security Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Input Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:27:27 --> Language Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Loader Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:27:27 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Session Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:27:27 --> Session routines successfully run
DEBUG - 2012-04-05 15:27:27 --> Controller Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Model Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Model Class Initialized
DEBUG - 2012-04-05 15:27:27 --> Helper loaded: email_helper
DEBUG - 2012-04-05 15:27:27 --> DB Transaction Failure
ERROR - 2012-04-05 15:27:27 --> Query error: Unknown column 'mmmm' in 'field list'
DEBUG - 2012-04-05 15:27:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 15:27:58 --> Config Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:27:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:27:58 --> URI Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Router Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Output Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Security Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Input Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:27:58 --> Language Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Loader Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:27:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Session Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:27:58 --> Session routines successfully run
DEBUG - 2012-04-05 15:27:58 --> Controller Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Model Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Model Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Helper loaded: email_helper
ERROR - 2012-04-05 15:27:58 --> Severity: Notice  --> Undefined property: Accounts::$UserType C:\Software\xampp\htdocs\xcms\system\core\Model.php 51
DEBUG - 2012-04-05 15:27:58 --> Config Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:27:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:27:58 --> URI Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Router Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Output Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Security Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Input Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:27:58 --> Language Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Loader Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:27:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Session Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:27:58 --> Session routines successfully run
DEBUG - 2012-04-05 15:27:58 --> Controller Class Initialized
DEBUG - 2012-04-05 15:27:58 --> Final output sent to browser
DEBUG - 2012-04-05 15:27:58 --> Total execution time: 0.0635
DEBUG - 2012-04-05 15:28:01 --> Config Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:28:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:28:01 --> URI Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Router Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Output Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Security Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Input Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:28:01 --> Language Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Loader Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:28:01 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Session Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:28:01 --> Session routines successfully run
DEBUG - 2012-04-05 15:28:01 --> Controller Class Initialized
DEBUG - 2012-04-05 15:28:01 --> Final output sent to browser
DEBUG - 2012-04-05 15:28:01 --> Total execution time: 0.0635
DEBUG - 2012-04-05 15:29:56 --> Config Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:29:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:29:56 --> URI Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Router Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Output Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Security Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Input Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:29:56 --> Language Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Loader Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:29:56 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Session Class Initialized
DEBUG - 2012-04-05 15:29:56 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:29:56 --> A session cookie was not found.
DEBUG - 2012-04-05 15:29:56 --> Session routines successfully run
DEBUG - 2012-04-05 15:29:56 --> Controller Class Initialized
DEBUG - 2012-04-05 15:29:56 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:29:56 --> Final output sent to browser
DEBUG - 2012-04-05 15:29:56 --> Total execution time: 0.0734
DEBUG - 2012-04-05 15:29:58 --> Config Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:29:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:29:58 --> URI Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Router Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Output Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Security Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Input Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:29:58 --> Language Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Loader Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:29:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Session Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:29:58 --> Session routines successfully run
DEBUG - 2012-04-05 15:29:58 --> Controller Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Model Class Initialized
DEBUG - 2012-04-05 15:29:58 --> Model Class Initialized
DEBUG - 2012-04-05 15:29:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:29:58 --> Final output sent to browser
DEBUG - 2012-04-05 15:29:58 --> Total execution time: 0.0759
DEBUG - 2012-04-05 15:30:14 --> Config Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:30:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:30:14 --> URI Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Router Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Output Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Security Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Input Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:30:14 --> Language Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Loader Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:30:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Session Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:30:14 --> Session routines successfully run
DEBUG - 2012-04-05 15:30:14 --> Controller Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Model Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Model Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Helper loaded: email_helper
ERROR - 2012-04-05 15:30:14 --> Severity: Notice  --> Undefined property: Accounts::$UserType C:\Software\xampp\htdocs\xcms\system\core\Model.php 51
DEBUG - 2012-04-05 15:30:14 --> Config Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:30:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:30:14 --> URI Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Router Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Output Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Security Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Input Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:30:14 --> Language Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Loader Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:30:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Session Class Initialized
DEBUG - 2012-04-05 15:30:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:30:14 --> Session routines successfully run
DEBUG - 2012-04-05 15:30:14 --> Controller Class Initialized
ERROR - 2012-04-05 15:30:14 --> Severity: Notice  --> Use of undefined constant student - assumed 'student' C:\Software\xampp\htdocs\xcms\system\controllers\main.php 28
DEBUG - 2012-04-05 15:30:14 --> Final output sent to browser
DEBUG - 2012-04-05 15:30:14 --> Total execution time: 0.0682
DEBUG - 2012-04-05 15:32:12 --> Config Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:32:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:32:12 --> URI Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Router Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Output Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Security Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Input Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:32:12 --> Language Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Loader Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:32:12 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Session Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:32:12 --> Session routines successfully run
DEBUG - 2012-04-05 15:32:12 --> Controller Class Initialized
DEBUG - 2012-04-05 15:32:12 --> Final output sent to browser
DEBUG - 2012-04-05 15:32:12 --> Total execution time: 0.0643
DEBUG - 2012-04-05 15:32:14 --> Config Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:32:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:32:14 --> URI Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Router Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Output Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Security Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Input Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:32:14 --> Language Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Loader Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:32:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Session Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:32:14 --> Session routines successfully run
DEBUG - 2012-04-05 15:32:14 --> Controller Class Initialized
DEBUG - 2012-04-05 15:32:14 --> Final output sent to browser
DEBUG - 2012-04-05 15:32:14 --> Total execution time: 0.0752
DEBUG - 2012-04-05 15:32:26 --> Config Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:32:26 --> URI Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Router Class Initialized
DEBUG - 2012-04-05 15:32:26 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:32:26 --> Output Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Security Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Input Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:32:26 --> Language Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Loader Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:32:26 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Session Class Initialized
DEBUG - 2012-04-05 15:32:26 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:32:26 --> A session cookie was not found.
DEBUG - 2012-04-05 15:32:26 --> Session routines successfully run
DEBUG - 2012-04-05 15:32:26 --> Controller Class Initialized
DEBUG - 2012-04-05 15:32:26 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:32:26 --> Final output sent to browser
DEBUG - 2012-04-05 15:32:26 --> Total execution time: 0.0714
DEBUG - 2012-04-05 15:32:30 --> Config Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:32:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:32:30 --> URI Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Router Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Output Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Security Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Input Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:32:30 --> Language Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Loader Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:32:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Session Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:32:30 --> Session routines successfully run
DEBUG - 2012-04-05 15:32:30 --> Controller Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Model Class Initialized
DEBUG - 2012-04-05 15:32:30 --> Model Class Initialized
DEBUG - 2012-04-05 15:32:30 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:32:30 --> Final output sent to browser
DEBUG - 2012-04-05 15:32:30 --> Total execution time: 0.0759
DEBUG - 2012-04-05 15:32:45 --> Config Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:32:45 --> URI Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Router Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Output Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Security Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Input Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:32:45 --> Language Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Loader Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:32:45 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Session Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:32:45 --> Session routines successfully run
DEBUG - 2012-04-05 15:32:45 --> Controller Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Model Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Model Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Helper loaded: email_helper
ERROR - 2012-04-05 15:32:45 --> Severity: Notice  --> Undefined property: Accounts::$UserType C:\Software\xampp\htdocs\xcms\system\core\Model.php 51
DEBUG - 2012-04-05 15:32:45 --> Config Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:32:45 --> URI Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Router Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Output Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Security Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Input Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:32:45 --> Language Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Loader Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:32:45 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Session Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:32:45 --> Session routines successfully run
DEBUG - 2012-04-05 15:32:45 --> Controller Class Initialized
DEBUG - 2012-04-05 15:32:45 --> Final output sent to browser
DEBUG - 2012-04-05 15:32:45 --> Total execution time: 0.0635
DEBUG - 2012-04-05 15:33:23 --> Config Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:33:23 --> URI Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Router Class Initialized
DEBUG - 2012-04-05 15:33:23 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:33:23 --> Output Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Security Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Input Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:33:23 --> Language Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Loader Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:33:23 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Session Class Initialized
DEBUG - 2012-04-05 15:33:23 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:33:23 --> A session cookie was not found.
DEBUG - 2012-04-05 15:33:23 --> Session routines successfully run
DEBUG - 2012-04-05 15:33:23 --> Controller Class Initialized
DEBUG - 2012-04-05 15:33:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:33:23 --> Final output sent to browser
DEBUG - 2012-04-05 15:33:23 --> Total execution time: 0.0713
DEBUG - 2012-04-05 15:33:24 --> Config Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:33:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:33:24 --> URI Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Router Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Output Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Security Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Input Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:33:24 --> Language Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Loader Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:33:24 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Session Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:33:24 --> Session routines successfully run
DEBUG - 2012-04-05 15:33:24 --> Controller Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Model Class Initialized
DEBUG - 2012-04-05 15:33:24 --> Model Class Initialized
DEBUG - 2012-04-05 15:33:24 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:33:24 --> Final output sent to browser
DEBUG - 2012-04-05 15:33:24 --> Total execution time: 0.0744
DEBUG - 2012-04-05 15:33:35 --> Config Class Initialized
DEBUG - 2012-04-05 15:33:35 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:33:35 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:33:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:33:35 --> URI Class Initialized
DEBUG - 2012-04-05 15:33:35 --> Router Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Output Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Security Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Input Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:33:36 --> Language Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Loader Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:33:36 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Session Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:33:36 --> Session routines successfully run
DEBUG - 2012-04-05 15:33:36 --> Controller Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Model Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Model Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Helper loaded: email_helper
ERROR - 2012-04-05 15:33:36 --> Severity: Notice  --> Undefined property: Accounts::$UserType C:\Software\xampp\htdocs\xcms\system\core\Model.php 51
DEBUG - 2012-04-05 15:33:36 --> Config Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:33:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:33:36 --> URI Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Router Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Output Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Security Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Input Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:33:36 --> Language Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Loader Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:33:36 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Session Class Initialized
DEBUG - 2012-04-05 15:33:36 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:33:36 --> Session routines successfully run
DEBUG - 2012-04-05 15:33:36 --> Controller Class Initialized
DEBUG - 2012-04-05 15:33:36 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 15:33:36 --> Final output sent to browser
DEBUG - 2012-04-05 15:33:36 --> Total execution time: 0.0645
DEBUG - 2012-04-05 15:38:03 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:03 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:03 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:03 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:03 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:03 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:03 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:03 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-05 15:38:03 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:03 --> Total execution time: 0.0727
DEBUG - 2012-04-05 15:38:11 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:11 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:11 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:38:11 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:11 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:11 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:11 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:11 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:11 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:11 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-05 15:38:11 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:11 --> Total execution time: 0.0747
DEBUG - 2012-04-05 15:38:16 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:16 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:16 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:16 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:16 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:16 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:16 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:16 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:16 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:16 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:16 --> A session cookie was not found.
DEBUG - 2012-04-05 15:38:16 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:16 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:16 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:38:16 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:16 --> Total execution time: 0.0676
DEBUG - 2012-04-05 15:38:24 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:24 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:24 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:24 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:24 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:24 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Model Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Model Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:24 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:24 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:24 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:24 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:24 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:24 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:24 --> Total execution time: 0.0644
DEBUG - 2012-04-05 15:38:27 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:27 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:27 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:27 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:27 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:27 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:27 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:27 --> Total execution time: 0.0663
DEBUG - 2012-04-05 15:38:30 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:30 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:30 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:30 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:30 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:30 --> Total execution time: 0.0645
DEBUG - 2012-04-05 15:38:30 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:30 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:30 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:30 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:30 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:30 --> Total execution time: 0.0648
DEBUG - 2012-04-05 15:38:30 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:30 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:30 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:30 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:30 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:30 --> Total execution time: 0.0678
DEBUG - 2012-04-05 15:38:30 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:30 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:30 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:30 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:30 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:30 --> Total execution time: 0.0642
DEBUG - 2012-04-05 15:38:30 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:30 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:30 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:31 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:31 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:31 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:31 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:31 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:31 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:31 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:31 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:31 --> Total execution time: 0.0647
DEBUG - 2012-04-05 15:38:34 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:34 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:34 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:34 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:34 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:34 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:34 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:34 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:34 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:35 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:35 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:35 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Config Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:38:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:38:35 --> URI Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Router Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Output Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Security Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Input Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:38:35 --> Language Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Loader Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:38:35 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Session Class Initialized
DEBUG - 2012-04-05 15:38:35 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:38:35 --> A session cookie was not found.
DEBUG - 2012-04-05 15:38:35 --> Session routines successfully run
DEBUG - 2012-04-05 15:38:35 --> Controller Class Initialized
DEBUG - 2012-04-05 15:38:35 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:38:35 --> Final output sent to browser
DEBUG - 2012-04-05 15:38:35 --> Total execution time: 0.0708
DEBUG - 2012-04-05 15:40:11 --> Config Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:40:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:40:11 --> URI Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Router Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Output Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Security Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Input Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:40:11 --> Language Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Loader Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:40:11 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Session Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:40:11 --> Session routines successfully run
DEBUG - 2012-04-05 15:40:11 --> Controller Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Model Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Model Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Config Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:40:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:40:11 --> URI Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Router Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Output Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Security Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Input Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:40:11 --> Language Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Loader Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:40:11 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Session Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:40:11 --> Session routines successfully run
DEBUG - 2012-04-05 15:40:11 --> Controller Class Initialized
DEBUG - 2012-04-05 15:40:11 --> Final output sent to browser
DEBUG - 2012-04-05 15:40:11 --> Total execution time: 0.0624
DEBUG - 2012-04-05 15:45:30 --> Config Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:45:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:45:30 --> URI Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Router Class Initialized
DEBUG - 2012-04-05 15:45:30 --> No URI present. Default controller set.
DEBUG - 2012-04-05 15:45:30 --> Output Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Security Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Input Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:45:30 --> Language Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Loader Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:45:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Session Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:45:30 --> Session routines successfully run
DEBUG - 2012-04-05 15:45:30 --> Controller Class Initialized
DEBUG - 2012-04-05 15:45:30 --> Final output sent to browser
DEBUG - 2012-04-05 15:45:30 --> Total execution time: 0.0674
DEBUG - 2012-04-05 15:45:40 --> Config Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:45:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:45:40 --> URI Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Router Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Output Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Security Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Input Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:45:40 --> Language Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Loader Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:45:40 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Session Class Initialized
DEBUG - 2012-04-05 15:45:40 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:45:40 --> A session cookie was not found.
DEBUG - 2012-04-05 15:45:40 --> Session routines successfully run
DEBUG - 2012-04-05 15:45:40 --> Controller Class Initialized
DEBUG - 2012-04-05 15:45:40 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:45:40 --> Final output sent to browser
DEBUG - 2012-04-05 15:45:40 --> Total execution time: 0.0694
DEBUG - 2012-04-05 15:46:02 --> Config Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:46:02 --> URI Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Router Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Output Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Security Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Input Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:46:02 --> Language Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Loader Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:46:02 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Session Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:46:02 --> Session routines successfully run
DEBUG - 2012-04-05 15:46:02 --> Controller Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Model Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Model Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Config Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:46:02 --> URI Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Router Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Output Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Security Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Input Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:46:02 --> Language Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Loader Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:46:02 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Session Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:46:02 --> Session routines successfully run
DEBUG - 2012-04-05 15:46:02 --> Controller Class Initialized
DEBUG - 2012-04-05 15:46:02 --> Final output sent to browser
DEBUG - 2012-04-05 15:46:02 --> Total execution time: 0.0636
DEBUG - 2012-04-05 15:47:08 --> Config Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:47:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:47:08 --> URI Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Router Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Output Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Security Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Input Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:47:08 --> Language Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Loader Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:47:08 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Session Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:47:08 --> Session routines successfully run
DEBUG - 2012-04-05 15:47:08 --> Controller Class Initialized
DEBUG - 2012-04-05 15:47:08 --> Final output sent to browser
DEBUG - 2012-04-05 15:47:08 --> Total execution time: 0.0663
DEBUG - 2012-04-05 15:47:29 --> Config Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:47:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:47:29 --> URI Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Router Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Output Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Security Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Input Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:47:29 --> Language Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Loader Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:47:29 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Session Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:47:29 --> Session routines successfully run
DEBUG - 2012-04-05 15:47:29 --> Controller Class Initialized
DEBUG - 2012-04-05 15:47:29 --> Final output sent to browser
DEBUG - 2012-04-05 15:47:29 --> Total execution time: 0.0688
DEBUG - 2012-04-05 15:47:31 --> Config Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:47:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:47:31 --> URI Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Router Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Output Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Security Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Input Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:47:31 --> Language Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Loader Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:47:31 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Session Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:47:31 --> Session routines successfully run
DEBUG - 2012-04-05 15:47:31 --> Controller Class Initialized
DEBUG - 2012-04-05 15:47:31 --> Final output sent to browser
DEBUG - 2012-04-05 15:47:31 --> Total execution time: 0.0656
DEBUG - 2012-04-05 15:48:04 --> Config Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:48:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:48:04 --> URI Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Router Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Output Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Security Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Input Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:48:04 --> Language Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Loader Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:48:04 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Session Class Initialized
DEBUG - 2012-04-05 15:48:04 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:48:04 --> Session routines successfully run
DEBUG - 2012-04-05 15:48:04 --> Controller Class Initialized
DEBUG - 2012-04-05 15:48:04 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 15:48:04 --> Final output sent to browser
DEBUG - 2012-04-05 15:48:04 --> Total execution time: 0.0661
DEBUG - 2012-04-05 15:49:01 --> Config Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:49:01 --> URI Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Router Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Output Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Security Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Input Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:49:01 --> Language Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Loader Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:49:01 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Session Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:49:01 --> Session routines successfully run
DEBUG - 2012-04-05 15:49:01 --> Controller Class Initialized
DEBUG - 2012-04-05 15:49:01 --> Final output sent to browser
DEBUG - 2012-04-05 15:49:01 --> Total execution time: 0.0679
DEBUG - 2012-04-05 15:49:17 --> Config Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:49:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:49:17 --> URI Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Router Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Output Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Security Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Input Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:49:17 --> Language Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Loader Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:49:17 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Session Class Initialized
DEBUG - 2012-04-05 15:49:17 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:49:17 --> Session routines successfully run
DEBUG - 2012-04-05 15:49:17 --> Controller Class Initialized
DEBUG - 2012-04-05 15:49:17 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 15:49:17 --> Final output sent to browser
DEBUG - 2012-04-05 15:49:17 --> Total execution time: 0.0709
DEBUG - 2012-04-05 15:53:26 --> Config Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:53:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:53:26 --> URI Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Router Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Output Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Security Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Input Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:53:26 --> Language Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Loader Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:53:26 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Session Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:53:26 --> Session routines successfully run
DEBUG - 2012-04-05 15:53:26 --> Controller Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Config Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:53:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:53:26 --> URI Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Router Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Output Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Security Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Input Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:53:26 --> Language Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Loader Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:53:26 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Session Class Initialized
DEBUG - 2012-04-05 15:53:26 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:53:26 --> A session cookie was not found.
DEBUG - 2012-04-05 15:53:26 --> Session routines successfully run
DEBUG - 2012-04-05 15:53:26 --> Controller Class Initialized
DEBUG - 2012-04-05 15:53:26 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:53:26 --> Final output sent to browser
DEBUG - 2012-04-05 15:53:26 --> Total execution time: 0.0679
DEBUG - 2012-04-05 15:53:27 --> Config Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:53:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:53:27 --> URI Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Router Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Output Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Security Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Input Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:53:27 --> Language Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Loader Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:53:27 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Session Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:53:27 --> Session routines successfully run
DEBUG - 2012-04-05 15:53:27 --> Controller Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Model Class Initialized
DEBUG - 2012-04-05 15:53:27 --> Model Class Initialized
DEBUG - 2012-04-05 15:53:27 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:53:27 --> Final output sent to browser
DEBUG - 2012-04-05 15:53:27 --> Total execution time: 0.0759
DEBUG - 2012-04-05 15:53:46 --> Config Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:53:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:53:46 --> URI Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Router Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Output Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Security Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Input Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:53:46 --> Language Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Loader Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:53:46 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Session Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:53:46 --> Session routines successfully run
DEBUG - 2012-04-05 15:53:46 --> Controller Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Model Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Model Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Helper loaded: email_helper
DEBUG - 2012-04-05 15:53:46 --> Config Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:53:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:53:46 --> URI Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Router Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Output Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Security Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Input Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:53:46 --> Language Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Loader Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:53:46 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Session Class Initialized
DEBUG - 2012-04-05 15:53:46 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:53:46 --> Session routines successfully run
DEBUG - 2012-04-05 15:53:46 --> Controller Class Initialized
DEBUG - 2012-04-05 15:53:46 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 15:53:46 --> Final output sent to browser
DEBUG - 2012-04-05 15:53:46 --> Total execution time: 0.0691
DEBUG - 2012-04-05 15:53:50 --> Config Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:53:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:53:50 --> URI Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Router Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Output Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Security Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Input Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:53:50 --> Language Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Loader Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:53:50 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Session Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:53:50 --> Session routines successfully run
DEBUG - 2012-04-05 15:53:50 --> Controller Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Config Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:53:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:53:50 --> URI Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Router Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Output Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Security Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Input Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:53:50 --> Language Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Loader Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:53:50 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Session Class Initialized
DEBUG - 2012-04-05 15:53:50 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:53:50 --> A session cookie was not found.
DEBUG - 2012-04-05 15:53:50 --> Session routines successfully run
DEBUG - 2012-04-05 15:53:50 --> Controller Class Initialized
DEBUG - 2012-04-05 15:53:50 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:53:50 --> Final output sent to browser
DEBUG - 2012-04-05 15:53:50 --> Total execution time: 0.0679
DEBUG - 2012-04-05 15:54:05 --> Config Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:54:05 --> URI Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Router Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Output Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Security Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Input Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:54:05 --> Language Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Loader Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:54:05 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Session Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:54:05 --> Session routines successfully run
DEBUG - 2012-04-05 15:54:05 --> Controller Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Model Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Model Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Config Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:54:05 --> URI Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Router Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Output Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Security Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Input Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:54:05 --> Language Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Loader Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:54:05 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Session Class Initialized
DEBUG - 2012-04-05 15:54:05 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:54:05 --> Session routines successfully run
DEBUG - 2012-04-05 15:54:05 --> Controller Class Initialized
DEBUG - 2012-04-05 15:54:05 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 15:54:05 --> Final output sent to browser
DEBUG - 2012-04-05 15:54:05 --> Total execution time: 0.0645
DEBUG - 2012-04-05 15:54:08 --> Config Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:54:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:54:08 --> URI Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Router Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Output Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Security Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Input Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:54:08 --> Language Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Loader Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:54:08 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Session Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:54:08 --> Session routines successfully run
DEBUG - 2012-04-05 15:54:08 --> Controller Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Config Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:54:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:54:08 --> URI Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Router Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Output Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Security Class Initialized
DEBUG - 2012-04-05 15:54:08 --> Input Class Initialized
DEBUG - 2012-04-05 15:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:54:09 --> Language Class Initialized
DEBUG - 2012-04-05 15:54:09 --> Loader Class Initialized
DEBUG - 2012-04-05 15:54:09 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:54:09 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:54:09 --> Session Class Initialized
DEBUG - 2012-04-05 15:54:09 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:54:09 --> A session cookie was not found.
DEBUG - 2012-04-05 15:54:09 --> Session routines successfully run
DEBUG - 2012-04-05 15:54:09 --> Controller Class Initialized
DEBUG - 2012-04-05 15:54:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:54:09 --> Final output sent to browser
DEBUG - 2012-04-05 15:54:09 --> Total execution time: 0.0674
DEBUG - 2012-04-05 15:56:24 --> Config Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:56:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:56:24 --> URI Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Router Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Output Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Security Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Input Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:56:24 --> Language Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Loader Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:56:24 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Session Class Initialized
DEBUG - 2012-04-05 15:56:24 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:56:24 --> Session routines successfully run
DEBUG - 2012-04-05 15:56:24 --> Controller Class Initialized
DEBUG - 2012-04-05 15:56:24 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:56:24 --> Final output sent to browser
DEBUG - 2012-04-05 15:56:24 --> Total execution time: 0.0663
DEBUG - 2012-04-05 15:56:25 --> Config Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:56:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:56:25 --> URI Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Router Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Output Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Security Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Input Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:56:25 --> Language Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Loader Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:56:25 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Session Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:56:25 --> Session routines successfully run
DEBUG - 2012-04-05 15:56:25 --> Controller Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Model Class Initialized
DEBUG - 2012-04-05 15:56:25 --> Model Class Initialized
DEBUG - 2012-04-05 15:56:25 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:56:25 --> Final output sent to browser
DEBUG - 2012-04-05 15:56:25 --> Total execution time: 0.1092
DEBUG - 2012-04-05 15:56:49 --> Config Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:56:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:56:49 --> URI Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Router Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Output Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Security Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Input Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:56:49 --> Language Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Loader Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:56:49 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Session Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:56:49 --> Session routines successfully run
DEBUG - 2012-04-05 15:56:49 --> Controller Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Model Class Initialized
DEBUG - 2012-04-05 15:56:49 --> Model Class Initialized
DEBUG - 2012-04-05 15:58:08 --> Config Class Initialized
DEBUG - 2012-04-05 15:58:08 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:58:08 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:58:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:58:08 --> URI Class Initialized
DEBUG - 2012-04-05 15:58:08 --> Router Class Initialized
DEBUG - 2012-04-05 15:58:08 --> Output Class Initialized
DEBUG - 2012-04-05 15:58:08 --> Security Class Initialized
DEBUG - 2012-04-05 15:58:08 --> Input Class Initialized
DEBUG - 2012-04-05 15:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:58:08 --> Language Class Initialized
DEBUG - 2012-04-05 15:58:09 --> Loader Class Initialized
DEBUG - 2012-04-05 15:58:09 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:58:09 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:58:09 --> Session Class Initialized
DEBUG - 2012-04-05 15:58:09 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:58:09 --> Session routines successfully run
DEBUG - 2012-04-05 15:58:09 --> Controller Class Initialized
DEBUG - 2012-04-05 15:58:09 --> Model Class Initialized
DEBUG - 2012-04-05 15:58:09 --> Model Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Config Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:58:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:58:40 --> URI Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Router Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Output Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Security Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Input Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:58:40 --> Language Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Loader Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:58:40 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Session Class Initialized
DEBUG - 2012-04-05 15:58:40 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:58:40 --> Session routines successfully run
DEBUG - 2012-04-05 15:58:40 --> Controller Class Initialized
DEBUG - 2012-04-05 15:58:40 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 15:58:40 --> Final output sent to browser
DEBUG - 2012-04-05 15:58:40 --> Total execution time: 0.0682
DEBUG - 2012-04-05 15:58:41 --> Config Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:58:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:58:41 --> URI Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Router Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Output Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Security Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Input Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:58:41 --> Language Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Loader Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:58:41 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Session Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:58:41 --> Session routines successfully run
DEBUG - 2012-04-05 15:58:41 --> Controller Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Config Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:58:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:58:41 --> URI Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Router Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Output Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Security Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Input Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:58:41 --> Language Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Loader Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:58:41 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Session Class Initialized
DEBUG - 2012-04-05 15:58:41 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:58:41 --> A session cookie was not found.
DEBUG - 2012-04-05 15:58:41 --> Session routines successfully run
DEBUG - 2012-04-05 15:58:41 --> Controller Class Initialized
DEBUG - 2012-04-05 15:58:41 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:58:41 --> Final output sent to browser
DEBUG - 2012-04-05 15:58:41 --> Total execution time: 0.0678
DEBUG - 2012-04-05 15:59:33 --> Config Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:59:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:59:33 --> URI Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Router Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Output Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Security Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Input Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:59:33 --> Language Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Loader Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:59:33 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Session Class Initialized
DEBUG - 2012-04-05 15:59:33 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:59:33 --> Session routines successfully run
DEBUG - 2012-04-05 15:59:33 --> Controller Class Initialized
DEBUG - 2012-04-05 15:59:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 15:59:33 --> Final output sent to browser
DEBUG - 2012-04-05 15:59:33 --> Total execution time: 0.0676
DEBUG - 2012-04-05 15:59:36 --> Config Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:59:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:59:36 --> URI Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Router Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Output Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Security Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Input Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:59:36 --> Language Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Loader Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:59:36 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Session Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:59:36 --> Session routines successfully run
DEBUG - 2012-04-05 15:59:36 --> Controller Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Model Class Initialized
DEBUG - 2012-04-05 15:59:36 --> Model Class Initialized
DEBUG - 2012-04-05 15:59:36 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:59:36 --> Final output sent to browser
DEBUG - 2012-04-05 15:59:36 --> Total execution time: 0.0750
DEBUG - 2012-04-05 15:59:51 --> Config Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Hooks Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Utf8 Class Initialized
DEBUG - 2012-04-05 15:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 15:59:51 --> URI Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Router Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Output Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Security Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Input Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 15:59:51 --> Language Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Loader Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Helper loaded: url_helper
DEBUG - 2012-04-05 15:59:51 --> Database Driver Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Session Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Helper loaded: string_helper
DEBUG - 2012-04-05 15:59:51 --> Session routines successfully run
DEBUG - 2012-04-05 15:59:51 --> Controller Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Model Class Initialized
DEBUG - 2012-04-05 15:59:51 --> Model Class Initialized
DEBUG - 2012-04-05 15:59:51 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 15:59:51 --> Final output sent to browser
DEBUG - 2012-04-05 15:59:51 --> Total execution time: 0.0754
DEBUG - 2012-04-05 16:15:49 --> Config Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:15:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:15:49 --> URI Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Router Class Initialized
DEBUG - 2012-04-05 16:15:49 --> No URI present. Default controller set.
DEBUG - 2012-04-05 16:15:49 --> Output Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Security Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Input Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:15:49 --> Language Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Loader Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:15:49 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Session Class Initialized
DEBUG - 2012-04-05 16:15:49 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:15:49 --> Session routines successfully run
DEBUG - 2012-04-05 16:15:49 --> Controller Class Initialized
DEBUG - 2012-04-05 16:15:49 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 16:15:49 --> Final output sent to browser
DEBUG - 2012-04-05 16:15:49 --> Total execution time: 0.0694
DEBUG - 2012-04-05 16:15:51 --> Config Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:15:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:15:51 --> URI Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Router Class Initialized
DEBUG - 2012-04-05 16:15:51 --> No URI present. Default controller set.
DEBUG - 2012-04-05 16:15:51 --> Output Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Security Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Input Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:15:51 --> Language Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Loader Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:15:51 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Session Class Initialized
DEBUG - 2012-04-05 16:15:51 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:15:51 --> Session routines successfully run
DEBUG - 2012-04-05 16:15:51 --> Controller Class Initialized
DEBUG - 2012-04-05 16:15:51 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 16:15:51 --> Final output sent to browser
DEBUG - 2012-04-05 16:15:51 --> Total execution time: 0.0933
DEBUG - 2012-04-05 16:15:52 --> Config Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:15:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:15:52 --> URI Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Router Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Output Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Security Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Input Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:15:52 --> Language Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Loader Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:15:52 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Session Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:15:52 --> Session routines successfully run
DEBUG - 2012-04-05 16:15:52 --> Controller Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Model Class Initialized
DEBUG - 2012-04-05 16:15:52 --> Model Class Initialized
DEBUG - 2012-04-05 16:15:52 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:15:52 --> Final output sent to browser
DEBUG - 2012-04-05 16:15:52 --> Total execution time: 0.0765
DEBUG - 2012-04-05 16:15:54 --> Config Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:15:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:15:54 --> URI Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Router Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Output Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Security Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Input Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:15:54 --> Language Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Loader Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:15:54 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Session Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:15:54 --> Session routines successfully run
DEBUG - 2012-04-05 16:15:54 --> Controller Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Model Class Initialized
DEBUG - 2012-04-05 16:15:54 --> Model Class Initialized
DEBUG - 2012-04-05 16:15:54 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:15:54 --> Final output sent to browser
DEBUG - 2012-04-05 16:15:54 --> Total execution time: 0.0732
DEBUG - 2012-04-05 16:15:56 --> Config Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:15:56 --> URI Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Router Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Output Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Security Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Input Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:15:56 --> Language Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Loader Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:15:56 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Session Class Initialized
DEBUG - 2012-04-05 16:15:56 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:15:57 --> Session routines successfully run
DEBUG - 2012-04-05 16:15:57 --> Controller Class Initialized
DEBUG - 2012-04-05 16:15:57 --> Model Class Initialized
DEBUG - 2012-04-05 16:15:57 --> Model Class Initialized
DEBUG - 2012-04-05 16:15:57 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:15:57 --> Final output sent to browser
DEBUG - 2012-04-05 16:15:57 --> Total execution time: 0.0753
DEBUG - 2012-04-05 16:16:08 --> Config Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:16:08 --> URI Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Router Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Output Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Security Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Input Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:16:08 --> Language Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Loader Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:16:08 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Session Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:16:08 --> Session routines successfully run
DEBUG - 2012-04-05 16:16:08 --> Controller Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Model Class Initialized
DEBUG - 2012-04-05 16:16:08 --> Model Class Initialized
DEBUG - 2012-04-05 16:16:08 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:16:08 --> Final output sent to browser
DEBUG - 2012-04-05 16:16:08 --> Total execution time: 0.0747
DEBUG - 2012-04-05 16:16:34 --> Config Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:16:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:16:34 --> URI Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Router Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Output Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Security Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Input Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:16:34 --> Language Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Loader Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:16:34 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Session Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:16:34 --> Session routines successfully run
DEBUG - 2012-04-05 16:16:34 --> Controller Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Model Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Model Class Initialized
DEBUG - 2012-04-05 16:16:34 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:16:34 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:16:34 --> Final output sent to browser
DEBUG - 2012-04-05 16:16:34 --> Total execution time: 0.0769
DEBUG - 2012-04-05 16:16:50 --> Config Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:16:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:16:50 --> URI Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Router Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Output Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Security Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Input Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:16:50 --> Language Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Loader Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:16:50 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Session Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:16:50 --> Session routines successfully run
DEBUG - 2012-04-05 16:16:50 --> Controller Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Model Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Model Class Initialized
DEBUG - 2012-04-05 16:16:50 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:16:50 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:16:50 --> Final output sent to browser
DEBUG - 2012-04-05 16:16:50 --> Total execution time: 0.0786
DEBUG - 2012-04-05 16:17:31 --> Config Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:17:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:17:31 --> URI Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Router Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Output Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Security Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Input Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:17:31 --> Language Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Loader Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:17:31 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Session Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:17:31 --> Session routines successfully run
DEBUG - 2012-04-05 16:17:31 --> Controller Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Model Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Model Class Initialized
DEBUG - 2012-04-05 16:17:31 --> Helper loaded: email_helper
ERROR - 2012-04-05 16:17:31 --> Severity: Notice  --> Undefined variable: errorMessage C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 96
DEBUG - 2012-04-05 16:17:31 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:17:31 --> Final output sent to browser
DEBUG - 2012-04-05 16:17:31 --> Total execution time: 0.0808
DEBUG - 2012-04-05 16:19:06 --> Config Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:19:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:19:06 --> URI Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Router Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Output Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Security Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Input Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:19:06 --> Language Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Loader Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:19:06 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Session Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:19:06 --> Session routines successfully run
DEBUG - 2012-04-05 16:19:06 --> Controller Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Model Class Initialized
DEBUG - 2012-04-05 16:19:06 --> Model Class Initialized
DEBUG - 2012-04-05 16:19:06 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:19:06 --> Final output sent to browser
DEBUG - 2012-04-05 16:19:06 --> Total execution time: 0.0741
DEBUG - 2012-04-05 16:19:16 --> Config Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:19:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:19:16 --> URI Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Router Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Output Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Security Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Input Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:19:16 --> Language Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Loader Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:19:16 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Session Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:19:16 --> Session routines successfully run
DEBUG - 2012-04-05 16:19:16 --> Controller Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Model Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Model Class Initialized
DEBUG - 2012-04-05 16:19:16 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:19:16 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:19:16 --> Final output sent to browser
DEBUG - 2012-04-05 16:19:16 --> Total execution time: 0.0799
DEBUG - 2012-04-05 16:19:32 --> Config Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:19:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:19:32 --> URI Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Router Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Output Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Security Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Input Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:19:32 --> Language Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Loader Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:19:32 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Session Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:19:32 --> Session routines successfully run
DEBUG - 2012-04-05 16:19:32 --> Controller Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Model Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Model Class Initialized
DEBUG - 2012-04-05 16:19:32 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:19:32 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:19:32 --> Final output sent to browser
DEBUG - 2012-04-05 16:19:32 --> Total execution time: 0.0798
DEBUG - 2012-04-05 16:21:30 --> Config Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:21:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:21:30 --> URI Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Router Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Output Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Security Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Input Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:21:30 --> Language Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Loader Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:21:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Session Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:21:30 --> Session routines successfully run
DEBUG - 2012-04-05 16:21:30 --> Controller Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Model Class Initialized
DEBUG - 2012-04-05 16:21:30 --> Model Class Initialized
DEBUG - 2012-04-05 16:21:30 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:21:30 --> Final output sent to browser
DEBUG - 2012-04-05 16:21:30 --> Total execution time: 0.0734
DEBUG - 2012-04-05 16:21:55 --> Config Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:21:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:21:55 --> URI Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Router Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Output Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Security Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Input Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:21:55 --> Language Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Loader Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:21:55 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Session Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:21:55 --> Session routines successfully run
DEBUG - 2012-04-05 16:21:55 --> Controller Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Model Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Model Class Initialized
DEBUG - 2012-04-05 16:21:55 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:21:55 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:21:55 --> Final output sent to browser
DEBUG - 2012-04-05 16:21:55 --> Total execution time: 0.0782
DEBUG - 2012-04-05 16:28:36 --> Config Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:28:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:28:37 --> URI Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Router Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Output Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Security Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Input Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:28:37 --> Language Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Loader Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:28:37 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Session Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:28:37 --> Session routines successfully run
DEBUG - 2012-04-05 16:28:37 --> Controller Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Model Class Initialized
DEBUG - 2012-04-05 16:28:37 --> Model Class Initialized
DEBUG - 2012-04-05 16:28:37 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:28:37 --> Final output sent to browser
DEBUG - 2012-04-05 16:28:37 --> Total execution time: 0.0793
DEBUG - 2012-04-05 16:28:55 --> Config Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:28:55 --> URI Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Router Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Output Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Security Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Input Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:28:55 --> Language Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Loader Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:28:55 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Session Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:28:55 --> Session routines successfully run
DEBUG - 2012-04-05 16:28:55 --> Controller Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Model Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Model Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:28:55 --> Config Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:28:55 --> URI Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Router Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Output Class Initialized
DEBUG - 2012-04-05 16:28:55 --> Security Class Initialized
DEBUG - 2012-04-05 16:28:56 --> Input Class Initialized
DEBUG - 2012-04-05 16:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:28:56 --> Language Class Initialized
DEBUG - 2012-04-05 16:28:56 --> Loader Class Initialized
DEBUG - 2012-04-05 16:28:56 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:28:56 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:28:56 --> Session Class Initialized
DEBUG - 2012-04-05 16:28:56 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:28:56 --> Session routines successfully run
DEBUG - 2012-04-05 16:28:56 --> Controller Class Initialized
DEBUG - 2012-04-05 16:28:56 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 16:28:56 --> Final output sent to browser
DEBUG - 2012-04-05 16:28:56 --> Total execution time: 0.0655
DEBUG - 2012-04-05 16:29:57 --> Config Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:29:57 --> URI Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Router Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Output Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Security Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Input Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:29:57 --> Language Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Loader Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:29:57 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Session Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:29:57 --> Session routines successfully run
DEBUG - 2012-04-05 16:29:57 --> Controller Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Config Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:29:57 --> URI Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Router Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Output Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Security Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Input Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:29:57 --> Language Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Loader Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:29:57 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Session Class Initialized
DEBUG - 2012-04-05 16:29:57 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:29:57 --> A session cookie was not found.
DEBUG - 2012-04-05 16:29:57 --> Session routines successfully run
DEBUG - 2012-04-05 16:29:57 --> Controller Class Initialized
DEBUG - 2012-04-05 16:29:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 16:29:57 --> Final output sent to browser
DEBUG - 2012-04-05 16:29:57 --> Total execution time: 0.0687
DEBUG - 2012-04-05 16:29:58 --> Config Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:29:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:29:58 --> URI Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Router Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Output Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Security Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Input Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:29:58 --> Language Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Loader Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:29:58 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Session Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:29:58 --> Session routines successfully run
DEBUG - 2012-04-05 16:29:58 --> Controller Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Model Class Initialized
DEBUG - 2012-04-05 16:29:58 --> Model Class Initialized
DEBUG - 2012-04-05 16:29:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:29:58 --> Final output sent to browser
DEBUG - 2012-04-05 16:29:58 --> Total execution time: 0.0847
DEBUG - 2012-04-05 16:30:14 --> Config Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:30:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:30:14 --> URI Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Router Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Output Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Security Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Input Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:30:14 --> Language Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Loader Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:30:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Session Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:30:14 --> Session routines successfully run
DEBUG - 2012-04-05 16:30:14 --> Controller Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Model Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Model Class Initialized
DEBUG - 2012-04-05 16:30:14 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:30:14 --> DB Transaction Failure
ERROR - 2012-04-05 16:30:14 --> Query error: Unknown column 'ii' in 'field list'
DEBUG - 2012-04-05 16:30:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 16:31:53 --> Config Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:31:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:31:53 --> URI Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Router Class Initialized
DEBUG - 2012-04-05 16:31:53 --> No URI present. Default controller set.
DEBUG - 2012-04-05 16:31:53 --> Output Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Security Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Input Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:31:53 --> Language Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Loader Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:31:53 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Session Class Initialized
DEBUG - 2012-04-05 16:31:53 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:31:53 --> Session routines successfully run
DEBUG - 2012-04-05 16:31:53 --> Controller Class Initialized
DEBUG - 2012-04-05 16:31:53 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 16:31:53 --> Final output sent to browser
DEBUG - 2012-04-05 16:31:53 --> Total execution time: 0.0757
DEBUG - 2012-04-05 16:31:54 --> Config Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:31:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:31:54 --> URI Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Router Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Output Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Security Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Input Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:31:54 --> Language Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Loader Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:31:54 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Session Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:31:54 --> Session routines successfully run
DEBUG - 2012-04-05 16:31:54 --> Controller Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Model Class Initialized
DEBUG - 2012-04-05 16:31:54 --> Model Class Initialized
DEBUG - 2012-04-05 16:31:54 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:31:54 --> Final output sent to browser
DEBUG - 2012-04-05 16:31:54 --> Total execution time: 0.0761
DEBUG - 2012-04-05 16:32:05 --> Config Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:32:05 --> URI Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Router Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Output Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Security Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Input Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:32:05 --> Language Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Loader Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:32:05 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Session Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:32:05 --> Session routines successfully run
DEBUG - 2012-04-05 16:32:05 --> Controller Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Model Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Model Class Initialized
DEBUG - 2012-04-05 16:32:05 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:32:05 --> DB Transaction Failure
ERROR - 2012-04-05 16:32:05 --> Query error: Unknown column 'aasasd' in 'field list'
DEBUG - 2012-04-05 16:32:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-05 16:32:31 --> Config Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:32:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:32:31 --> URI Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Router Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Output Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Security Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Input Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:32:31 --> Language Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Loader Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:32:31 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Session Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:32:31 --> Session routines successfully run
DEBUG - 2012-04-05 16:32:31 --> Controller Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Model Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Model Class Initialized
DEBUG - 2012-04-05 16:32:31 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:32:31 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 16:32:31 --> Final output sent to browser
DEBUG - 2012-04-05 16:32:31 --> Total execution time: 0.0779
DEBUG - 2012-04-05 16:32:40 --> Config Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:32:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:32:40 --> URI Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Router Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Output Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Security Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Input Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:32:40 --> Language Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Loader Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:32:40 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Session Class Initialized
DEBUG - 2012-04-05 16:32:40 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:32:40 --> Session routines successfully run
DEBUG - 2012-04-05 16:32:40 --> Controller Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Model Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Model Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Helper loaded: email_helper
DEBUG - 2012-04-05 16:32:41 --> Config Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:32:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:32:41 --> URI Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Router Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Output Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Security Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Input Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:32:41 --> Language Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Loader Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:32:41 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Session Class Initialized
DEBUG - 2012-04-05 16:32:41 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:32:41 --> Session routines successfully run
DEBUG - 2012-04-05 16:32:41 --> Controller Class Initialized
DEBUG - 2012-04-05 16:32:41 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 16:32:41 --> Final output sent to browser
DEBUG - 2012-04-05 16:32:41 --> Total execution time: 0.0669
DEBUG - 2012-04-05 16:32:42 --> Config Class Initialized
DEBUG - 2012-04-05 16:32:42 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:32:42 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:32:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:32:42 --> URI Class Initialized
DEBUG - 2012-04-05 16:32:42 --> Router Class Initialized
DEBUG - 2012-04-05 16:32:42 --> Output Class Initialized
DEBUG - 2012-04-05 16:32:42 --> Security Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Input Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:32:43 --> Language Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Loader Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:32:43 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Session Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:32:43 --> Session routines successfully run
DEBUG - 2012-04-05 16:32:43 --> Controller Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Config Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:32:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:32:43 --> URI Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Router Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Output Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Security Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Input Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:32:43 --> Language Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Loader Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:32:43 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Session Class Initialized
DEBUG - 2012-04-05 16:32:43 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:32:43 --> A session cookie was not found.
DEBUG - 2012-04-05 16:32:43 --> Session routines successfully run
DEBUG - 2012-04-05 16:32:43 --> Controller Class Initialized
DEBUG - 2012-04-05 16:32:43 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 16:32:43 --> Final output sent to browser
DEBUG - 2012-04-05 16:32:43 --> Total execution time: 0.0709
DEBUG - 2012-04-05 16:58:19 --> Config Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Hooks Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Utf8 Class Initialized
DEBUG - 2012-04-05 16:58:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 16:58:19 --> URI Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Router Class Initialized
DEBUG - 2012-04-05 16:58:19 --> No URI present. Default controller set.
DEBUG - 2012-04-05 16:58:19 --> Output Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Security Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Input Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 16:58:19 --> Language Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Loader Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Helper loaded: url_helper
DEBUG - 2012-04-05 16:58:19 --> Database Driver Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Session Class Initialized
DEBUG - 2012-04-05 16:58:19 --> Helper loaded: string_helper
DEBUG - 2012-04-05 16:58:19 --> Session routines successfully run
DEBUG - 2012-04-05 16:58:19 --> Controller Class Initialized
DEBUG - 2012-04-05 16:58:19 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 16:58:19 --> Final output sent to browser
DEBUG - 2012-04-05 16:58:19 --> Total execution time: 0.0694
DEBUG - 2012-04-05 18:31:59 --> Config Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:31:59 --> URI Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Router Class Initialized
DEBUG - 2012-04-05 18:31:59 --> No URI present. Default controller set.
DEBUG - 2012-04-05 18:31:59 --> Output Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Security Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Input Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:31:59 --> Language Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Loader Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:31:59 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Session Class Initialized
DEBUG - 2012-04-05 18:31:59 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:31:59 --> Session routines successfully run
DEBUG - 2012-04-05 18:31:59 --> Controller Class Initialized
DEBUG - 2012-04-05 18:31:59 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:31:59 --> Final output sent to browser
DEBUG - 2012-04-05 18:31:59 --> Total execution time: 0.0771
DEBUG - 2012-04-05 18:32:01 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:01 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:01 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:01 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:01 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:01 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:01 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:32:01 --> Final output sent to browser
DEBUG - 2012-04-05 18:32:01 --> Total execution time: 0.1008
DEBUG - 2012-04-05 18:32:03 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:03 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:03 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:03 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:03 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:03 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:03 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:32:03 --> Final output sent to browser
DEBUG - 2012-04-05 18:32:03 --> Total execution time: 0.0672
DEBUG - 2012-04-05 18:32:04 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:04 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:04 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:04 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:04 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:04 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:04 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:04 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:32:04 --> Final output sent to browser
DEBUG - 2012-04-05 18:32:04 --> Total execution time: 0.0703
DEBUG - 2012-04-05 18:32:14 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:14 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:14 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:14 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:14 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Model Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Model Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:14 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:14 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:14 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:14 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:14 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:14 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:14 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-05 18:32:14 --> Final output sent to browser
DEBUG - 2012-04-05 18:32:14 --> Total execution time: 0.0684
DEBUG - 2012-04-05 18:32:18 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:18 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:18 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:18 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:18 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:18 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:18 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:18 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:18 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:18 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:18 --> A session cookie was not found.
DEBUG - 2012-04-05 18:32:18 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:18 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:18 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:32:18 --> Final output sent to browser
DEBUG - 2012-04-05 18:32:18 --> Total execution time: 0.0667
DEBUG - 2012-04-05 18:32:26 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:26 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:26 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:26 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:26 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:26 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Model Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Model Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:26 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:26 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:26 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:26 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:26 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:26 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:26 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-05 18:32:26 --> Final output sent to browser
DEBUG - 2012-04-05 18:32:26 --> Total execution time: 0.0646
DEBUG - 2012-04-05 18:32:40 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:40 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:40 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:40 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:40 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:40 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:40 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:40 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:40 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:40 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:40 --> A session cookie was not found.
DEBUG - 2012-04-05 18:32:40 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:40 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:40 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:32:40 --> Final output sent to browser
DEBUG - 2012-04-05 18:32:40 --> Total execution time: 0.0712
DEBUG - 2012-04-05 18:32:41 --> Config Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:32:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:32:41 --> URI Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Router Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Output Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Security Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Input Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:32:41 --> Language Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Loader Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:32:41 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Session Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:32:41 --> Session routines successfully run
DEBUG - 2012-04-05 18:32:41 --> Controller Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Model Class Initialized
DEBUG - 2012-04-05 18:32:41 --> Model Class Initialized
DEBUG - 2012-04-05 18:32:41 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 18:32:41 --> Final output sent to browser
DEBUG - 2012-04-05 18:32:41 --> Total execution time: 0.0927
DEBUG - 2012-04-05 18:33:11 --> Config Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:33:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:33:11 --> URI Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Router Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Output Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Security Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Input Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:33:11 --> Language Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Loader Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:33:11 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Session Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:33:11 --> Session routines successfully run
DEBUG - 2012-04-05 18:33:11 --> Controller Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Model Class Initialized
DEBUG - 2012-04-05 18:33:11 --> Model Class Initialized
DEBUG - 2012-04-05 18:33:11 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 18:33:11 --> Final output sent to browser
DEBUG - 2012-04-05 18:33:11 --> Total execution time: 0.0750
DEBUG - 2012-04-05 18:33:42 --> Config Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:33:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:33:42 --> URI Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Router Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Output Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Security Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Input Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:33:42 --> Language Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Loader Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:33:42 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Session Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:33:42 --> Session routines successfully run
DEBUG - 2012-04-05 18:33:42 --> Controller Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Model Class Initialized
DEBUG - 2012-04-05 18:33:42 --> Model Class Initialized
DEBUG - 2012-04-05 18:33:42 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 18:33:42 --> Final output sent to browser
DEBUG - 2012-04-05 18:33:42 --> Total execution time: 0.0732
DEBUG - 2012-04-05 18:33:55 --> Config Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:33:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:33:55 --> URI Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Router Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Output Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Security Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Input Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:33:55 --> Language Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Loader Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:33:55 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Session Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:33:55 --> Session routines successfully run
DEBUG - 2012-04-05 18:33:55 --> Controller Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Model Class Initialized
DEBUG - 2012-04-05 18:33:55 --> Model Class Initialized
DEBUG - 2012-04-05 18:33:55 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-05 18:33:55 --> Final output sent to browser
DEBUG - 2012-04-05 18:33:55 --> Total execution time: 0.0732
DEBUG - 2012-04-05 18:34:15 --> Config Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:34:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:34:15 --> URI Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Router Class Initialized
DEBUG - 2012-04-05 18:34:15 --> No URI present. Default controller set.
DEBUG - 2012-04-05 18:34:15 --> Output Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Security Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Input Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:34:15 --> Language Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Loader Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:34:15 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Session Class Initialized
DEBUG - 2012-04-05 18:34:15 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:34:15 --> A session cookie was not found.
DEBUG - 2012-04-05 18:34:15 --> Session routines successfully run
DEBUG - 2012-04-05 18:34:15 --> Controller Class Initialized
DEBUG - 2012-04-05 18:34:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:34:15 --> Final output sent to browser
DEBUG - 2012-04-05 18:34:15 --> Total execution time: 0.0757
DEBUG - 2012-04-05 18:34:30 --> Config Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:34:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:34:30 --> URI Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Router Class Initialized
DEBUG - 2012-04-05 18:34:30 --> No URI present. Default controller set.
DEBUG - 2012-04-05 18:34:30 --> Output Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Security Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Input Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:34:30 --> Language Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Loader Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:34:30 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Session Class Initialized
DEBUG - 2012-04-05 18:34:30 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:34:30 --> A session cookie was not found.
DEBUG - 2012-04-05 18:34:30 --> Session routines successfully run
DEBUG - 2012-04-05 18:34:30 --> Controller Class Initialized
DEBUG - 2012-04-05 18:34:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:34:30 --> Final output sent to browser
DEBUG - 2012-04-05 18:34:30 --> Total execution time: 0.0696
DEBUG - 2012-04-05 18:35:19 --> Config Class Initialized
DEBUG - 2012-04-05 18:35:19 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:35:19 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:35:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:35:19 --> URI Class Initialized
DEBUG - 2012-04-05 18:35:19 --> Router Class Initialized
DEBUG - 2012-04-05 18:35:19 --> No URI present. Default controller set.
DEBUG - 2012-04-05 18:35:19 --> Output Class Initialized
DEBUG - 2012-04-05 18:35:19 --> Security Class Initialized
DEBUG - 2012-04-05 18:35:19 --> Input Class Initialized
DEBUG - 2012-04-05 18:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:35:19 --> Language Class Initialized
DEBUG - 2012-04-05 18:35:19 --> Loader Class Initialized
DEBUG - 2012-04-05 18:35:19 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:35:19 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:35:20 --> Session Class Initialized
DEBUG - 2012-04-05 18:35:20 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:35:20 --> Session routines successfully run
DEBUG - 2012-04-05 18:35:20 --> Controller Class Initialized
DEBUG - 2012-04-05 18:35:20 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:35:20 --> Final output sent to browser
DEBUG - 2012-04-05 18:35:20 --> Total execution time: 0.0723
DEBUG - 2012-04-05 18:35:22 --> Config Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Hooks Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Utf8 Class Initialized
DEBUG - 2012-04-05 18:35:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-05 18:35:22 --> URI Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Router Class Initialized
DEBUG - 2012-04-05 18:35:22 --> No URI present. Default controller set.
DEBUG - 2012-04-05 18:35:22 --> Output Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Security Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Input Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-05 18:35:22 --> Language Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Loader Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Helper loaded: url_helper
DEBUG - 2012-04-05 18:35:22 --> Database Driver Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Session Class Initialized
DEBUG - 2012-04-05 18:35:22 --> Helper loaded: string_helper
DEBUG - 2012-04-05 18:35:22 --> Session routines successfully run
DEBUG - 2012-04-05 18:35:22 --> Controller Class Initialized
DEBUG - 2012-04-05 18:35:22 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-05 18:35:22 --> Final output sent to browser
DEBUG - 2012-04-05 18:35:22 --> Total execution time: 0.0700
