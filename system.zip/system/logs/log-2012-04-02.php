<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-02 14:38:46 --> Config Class Initialized
DEBUG - 2012-04-02 14:38:46 --> Hooks Class Initialized
DEBUG - 2012-04-02 14:38:46 --> Utf8 Class Initialized
DEBUG - 2012-04-02 14:38:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-02 14:38:46 --> URI Class Initialized
DEBUG - 2012-04-02 14:38:46 --> Router Class Initialized
DEBUG - 2012-04-02 14:38:46 --> No URI present. Default controller set.
DEBUG - 2012-04-02 14:38:46 --> Output Class Initialized
DEBUG - 2012-04-02 14:38:46 --> Security Class Initialized
DEBUG - 2012-04-02 14:38:46 --> Input Class Initialized
DEBUG - 2012-04-02 14:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-02 14:38:46 --> Language Class Initialized
DEBUG - 2012-04-02 14:38:46 --> Loader Class Initialized
DEBUG - 2012-04-02 14:38:46 --> Controller Class Initialized
DEBUG - 2012-04-02 14:38:46 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-02 14:38:46 --> Final output sent to browser
DEBUG - 2012-04-02 14:38:46 --> Total execution time: 0.8311
DEBUG - 2012-04-02 14:38:53 --> Config Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Hooks Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Utf8 Class Initialized
DEBUG - 2012-04-02 14:38:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-02 14:38:53 --> URI Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Router Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Output Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Security Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Input Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-02 14:38:53 --> Language Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Loader Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Controller Class Initialized
ERROR - 2012-04-02 14:38:53 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 8
ERROR - 2012-04-02 14:38:53 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 8
ERROR - 2012-04-02 14:38:53 --> Severity: Notice  --> Use of undefined constant user - assumed 'user' C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 10
DEBUG - 2012-04-02 14:38:53 --> Model Class Initialized
DEBUG - 2012-04-02 14:38:53 --> Model Class Initialized
ERROR - 2012-04-02 14:38:53 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-02 14:38:53 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-02 14:38:53 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
