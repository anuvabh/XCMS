<html>
    <form>
        <table>
            <tr><td>Department Name:</td><td><input type="text" name:</td></tr>
            <tr><td>Department Code:</td></tr>
            <tr><td>Admin Username: </td><td> <input type="text" name="Email" /></td></tr>   
            <tr><td> Password: </td><td> <input type="password" name="Password1" /></td></tr>
            <tr><td> Confirm Password: </td><td> <input type="password" name="Password" /></td></tr>
            <tr><td>Type:</td>
                <td><select name="type">
                        <option>Academic</option>
                        <option>Non-Academic</option>
                </select></td></tr>
        </table>
    </form>
</html>
