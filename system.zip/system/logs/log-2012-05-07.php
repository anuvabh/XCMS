<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-05-07 14:16:02 --> Config Class Initialized
DEBUG - 2012-05-07 14:16:02 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:16:02 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:16:02 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:16:02 --> URI Class Initialized
DEBUG - 2012-05-07 14:16:02 --> Router Class Initialized
DEBUG - 2012-05-07 14:16:02 --> No URI present. Default controller set.
DEBUG - 2012-05-07 14:16:02 --> Output Class Initialized
DEBUG - 2012-05-07 14:16:02 --> Security Class Initialized
DEBUG - 2012-05-07 14:16:02 --> Input Class Initialized
DEBUG - 2012-05-07 14:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:16:02 --> Language Class Initialized
DEBUG - 2012-05-07 14:16:02 --> Loader Class Initialized
DEBUG - 2012-05-07 14:16:02 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:16:02 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:16:04 --> Session Class Initialized
DEBUG - 2012-05-07 14:16:04 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:16:04 --> A session cookie was not found.
DEBUG - 2012-05-07 14:16:04 --> Session routines successfully run
DEBUG - 2012-05-07 14:16:04 --> Controller Class Initialized
DEBUG - 2012-05-07 14:16:04 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:16:04 --> Final output sent to browser
DEBUG - 2012-05-07 14:16:04 --> Total execution time: 2.1517
DEBUG - 2012-05-07 14:16:47 --> Config Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:16:47 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:16:47 --> URI Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Router Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Output Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Security Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Input Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:16:47 --> Language Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Loader Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:16:47 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Session Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:16:47 --> Session routines successfully run
DEBUG - 2012-05-07 14:16:47 --> Controller Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Model Class Initialized
DEBUG - 2012-05-07 14:16:47 --> Model Class Initialized
DEBUG - 2012-05-07 14:16:48 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:16:48 --> Final output sent to browser
DEBUG - 2012-05-07 14:16:48 --> Total execution time: 0.8678
DEBUG - 2012-05-07 14:16:58 --> Config Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:16:58 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:16:58 --> URI Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Router Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Output Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Security Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Input Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:16:58 --> Language Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Loader Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:16:58 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Session Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:16:58 --> Session routines successfully run
DEBUG - 2012-05-07 14:16:58 --> Controller Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Model Class Initialized
DEBUG - 2012-05-07 14:16:58 --> Model Class Initialized
DEBUG - 2012-05-07 14:16:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:16:58 --> Final output sent to browser
DEBUG - 2012-05-07 14:16:58 --> Total execution time: 0.0860
DEBUG - 2012-05-07 14:17:06 --> Config Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:17:06 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:17:06 --> URI Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Router Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Output Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Security Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Input Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:17:06 --> Language Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Loader Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:17:06 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Session Class Initialized
DEBUG - 2012-05-07 14:17:06 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:17:06 --> Session routines successfully run
DEBUG - 2012-05-07 14:17:06 --> Controller Class Initialized
DEBUG - 2012-05-07 14:17:06 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:17:06 --> Final output sent to browser
DEBUG - 2012-05-07 14:17:06 --> Total execution time: 0.0513
DEBUG - 2012-05-07 14:17:07 --> Config Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:17:07 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:17:07 --> URI Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Router Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Output Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Security Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Input Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:17:07 --> Language Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Loader Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:17:07 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Session Class Initialized
DEBUG - 2012-05-07 14:17:07 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:17:07 --> Session routines successfully run
DEBUG - 2012-05-07 14:17:07 --> Controller Class Initialized
DEBUG - 2012-05-07 14:17:07 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:17:07 --> Final output sent to browser
DEBUG - 2012-05-07 14:17:07 --> Total execution time: 0.1119
DEBUG - 2012-05-07 14:17:08 --> Config Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:17:08 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:17:08 --> URI Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Router Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Output Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Security Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Input Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:17:08 --> Language Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Loader Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:17:08 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Session Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:17:08 --> Session routines successfully run
DEBUG - 2012-05-07 14:17:08 --> Controller Class Initialized
DEBUG - 2012-05-07 14:17:08 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:17:08 --> Final output sent to browser
DEBUG - 2012-05-07 14:17:08 --> Total execution time: 0.0551
DEBUG - 2012-05-07 14:17:08 --> Config Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:17:08 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:17:08 --> URI Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Router Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Output Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Security Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Input Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:17:08 --> Language Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Loader Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:17:08 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Session Class Initialized
DEBUG - 2012-05-07 14:17:08 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:17:08 --> Session routines successfully run
DEBUG - 2012-05-07 14:17:08 --> Controller Class Initialized
DEBUG - 2012-05-07 14:17:08 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:17:08 --> Final output sent to browser
DEBUG - 2012-05-07 14:17:08 --> Total execution time: 0.0664
DEBUG - 2012-05-07 14:17:09 --> Config Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:17:09 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:17:09 --> URI Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Router Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Output Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Security Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Input Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:17:09 --> Language Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Loader Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:17:09 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Session Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:17:09 --> Session routines successfully run
DEBUG - 2012-05-07 14:17:09 --> Controller Class Initialized
DEBUG - 2012-05-07 14:17:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:17:09 --> Final output sent to browser
DEBUG - 2012-05-07 14:17:09 --> Total execution time: 0.0747
DEBUG - 2012-05-07 14:17:09 --> Config Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Hooks Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Utf8 Class Initialized
DEBUG - 2012-05-07 14:17:09 --> UTF-8 Support Enabled
DEBUG - 2012-05-07 14:17:09 --> URI Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Router Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Output Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Security Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Input Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-07 14:17:09 --> Language Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Loader Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Helper loaded: url_helper
DEBUG - 2012-05-07 14:17:09 --> Database Driver Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Session Class Initialized
DEBUG - 2012-05-07 14:17:09 --> Helper loaded: string_helper
DEBUG - 2012-05-07 14:17:09 --> Session routines successfully run
DEBUG - 2012-05-07 14:17:09 --> Controller Class Initialized
DEBUG - 2012-05-07 14:17:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-07 14:17:09 --> Final output sent to browser
DEBUG - 2012-05-07 14:17:09 --> Total execution time: 0.0525
