<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-07 08:39:37 --> Config Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 08:39:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 08:39:37 --> URI Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Router Class Initialized
DEBUG - 2012-04-07 08:39:37 --> No URI present. Default controller set.
DEBUG - 2012-04-07 08:39:37 --> Output Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Security Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Input Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 08:39:37 --> Language Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Loader Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 08:39:37 --> Database Driver Class Initialized
ERROR - 2012-04-07 08:39:37 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-07 08:39:37 --> Session Class Initialized
DEBUG - 2012-04-07 08:39:37 --> Helper loaded: string_helper
DEBUG - 2012-04-07 08:39:37 --> Session routines successfully run
DEBUG - 2012-04-07 08:39:37 --> Controller Class Initialized
DEBUG - 2012-04-07 08:39:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 08:39:37 --> Final output sent to browser
DEBUG - 2012-04-07 08:39:37 --> Total execution time: 0.0578
DEBUG - 2012-04-07 12:27:07 --> Config Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Hooks Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Utf8 Class Initialized
DEBUG - 2012-04-07 12:27:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 12:27:07 --> URI Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Router Class Initialized
DEBUG - 2012-04-07 12:27:07 --> No URI present. Default controller set.
DEBUG - 2012-04-07 12:27:07 --> Output Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Security Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Input Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 12:27:07 --> Language Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Loader Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Helper loaded: url_helper
DEBUG - 2012-04-07 12:27:07 --> Database Driver Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Session Class Initialized
DEBUG - 2012-04-07 12:27:07 --> Helper loaded: string_helper
DEBUG - 2012-04-07 12:27:07 --> Session routines successfully run
DEBUG - 2012-04-07 12:27:07 --> Controller Class Initialized
DEBUG - 2012-04-07 12:27:07 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 12:27:07 --> Final output sent to browser
DEBUG - 2012-04-07 12:27:07 --> Total execution time: 0.0785
DEBUG - 2012-04-07 12:27:08 --> Config Class Initialized
DEBUG - 2012-04-07 12:27:08 --> Hooks Class Initialized
DEBUG - 2012-04-07 12:27:08 --> Utf8 Class Initialized
DEBUG - 2012-04-07 12:27:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 12:27:08 --> URI Class Initialized
DEBUG - 2012-04-07 12:27:08 --> Router Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Output Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Security Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Input Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 12:27:09 --> Language Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Loader Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 12:27:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Session Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 12:27:09 --> Session routines successfully run
DEBUG - 2012-04-07 12:27:09 --> Controller Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Model Class Initialized
DEBUG - 2012-04-07 12:27:09 --> Model Class Initialized
DEBUG - 2012-04-07 12:27:09 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 12:27:09 --> Final output sent to browser
DEBUG - 2012-04-07 12:27:09 --> Total execution time: 0.7065
DEBUG - 2012-04-07 12:31:51 --> Config Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Hooks Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Utf8 Class Initialized
DEBUG - 2012-04-07 12:31:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 12:31:51 --> URI Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Router Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Output Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Security Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Input Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 12:31:51 --> Language Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Loader Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Helper loaded: url_helper
DEBUG - 2012-04-07 12:31:51 --> Database Driver Class Initialized
ERROR - 2012-04-07 12:31:51 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-07 12:31:51 --> Session Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Helper loaded: string_helper
DEBUG - 2012-04-07 12:31:51 --> Session routines successfully run
DEBUG - 2012-04-07 12:31:51 --> Controller Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Model Class Initialized
DEBUG - 2012-04-07 12:31:51 --> Model Class Initialized
DEBUG - 2012-04-07 12:31:51 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 12:31:51 --> Final output sent to browser
DEBUG - 2012-04-07 12:31:51 --> Total execution time: 0.1360
DEBUG - 2012-04-07 12:32:29 --> Config Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Hooks Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Utf8 Class Initialized
DEBUG - 2012-04-07 12:32:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 12:32:29 --> URI Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Router Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Output Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Security Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Input Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 12:32:29 --> Language Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Loader Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Helper loaded: url_helper
DEBUG - 2012-04-07 12:32:29 --> Database Driver Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Session Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Helper loaded: string_helper
DEBUG - 2012-04-07 12:32:29 --> Session routines successfully run
DEBUG - 2012-04-07 12:32:29 --> Controller Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Model Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Model Class Initialized
DEBUG - 2012-04-07 12:32:29 --> Helper loaded: email_helper
DEBUG - 2012-04-07 12:32:29 --> Model Class Initialized
DEBUG - 2012-04-07 12:32:29 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 12:32:29 --> Final output sent to browser
DEBUG - 2012-04-07 12:32:29 --> Total execution time: 0.1096
DEBUG - 2012-04-07 13:53:34 --> Config Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:53:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:53:34 --> URI Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Router Class Initialized
DEBUG - 2012-04-07 13:53:34 --> No URI present. Default controller set.
DEBUG - 2012-04-07 13:53:34 --> Output Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Security Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Input Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:53:34 --> Language Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Loader Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:53:34 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Session Class Initialized
DEBUG - 2012-04-07 13:53:34 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:53:34 --> Session routines successfully run
DEBUG - 2012-04-07 13:53:34 --> Controller Class Initialized
DEBUG - 2012-04-07 13:53:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 13:53:34 --> Final output sent to browser
DEBUG - 2012-04-07 13:53:34 --> Total execution time: 0.0575
DEBUG - 2012-04-07 13:53:39 --> Config Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:53:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:53:39 --> URI Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Router Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Output Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Security Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Input Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:53:39 --> Language Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Loader Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:53:39 --> Database Driver Class Initialized
ERROR - 2012-04-07 13:53:39 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-07 13:53:39 --> Session Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:53:39 --> Session routines successfully run
DEBUG - 2012-04-07 13:53:39 --> Controller Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Model Class Initialized
DEBUG - 2012-04-07 13:53:39 --> Model Class Initialized
DEBUG - 2012-04-07 13:53:39 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 13:53:39 --> Final output sent to browser
DEBUG - 2012-04-07 13:53:39 --> Total execution time: 0.0808
DEBUG - 2012-04-07 13:54:54 --> Config Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:54:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:54:54 --> URI Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Router Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Output Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Security Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Input Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:54:54 --> Language Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Loader Class Initialized
DEBUG - 2012-04-07 13:54:54 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:54:55 --> Database Driver Class Initialized
ERROR - 2012-04-07 13:54:55 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-07 13:54:55 --> Session Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:54:55 --> Session routines successfully run
DEBUG - 2012-04-07 13:54:55 --> Controller Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Model Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Model Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Helper loaded: email_helper
DEBUG - 2012-04-07 13:54:55 --> Model Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Config Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:54:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:54:55 --> URI Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Router Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Output Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Security Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Input Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:54:55 --> Language Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Loader Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:54:55 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Session Class Initialized
DEBUG - 2012-04-07 13:54:55 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:54:55 --> Session routines successfully run
DEBUG - 2012-04-07 13:54:55 --> Controller Class Initialized
DEBUG - 2012-04-07 13:54:55 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-07 13:54:55 --> Final output sent to browser
DEBUG - 2012-04-07 13:54:55 --> Total execution time: 0.0512
DEBUG - 2012-04-07 13:56:40 --> Config Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:56:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:56:40 --> URI Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Router Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Output Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Security Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Input Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:56:40 --> Language Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Loader Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:56:40 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Session Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:56:40 --> Session routines successfully run
DEBUG - 2012-04-07 13:56:40 --> Controller Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Config Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:56:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:56:40 --> URI Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Router Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Output Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Security Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Input Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:56:40 --> Language Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Loader Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:56:40 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Session Class Initialized
DEBUG - 2012-04-07 13:56:40 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:56:40 --> A session cookie was not found.
DEBUG - 2012-04-07 13:56:40 --> Session routines successfully run
DEBUG - 2012-04-07 13:56:40 --> Controller Class Initialized
DEBUG - 2012-04-07 13:56:40 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 13:56:40 --> Final output sent to browser
DEBUG - 2012-04-07 13:56:40 --> Total execution time: 0.0497
DEBUG - 2012-04-07 13:56:59 --> Config Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:56:59 --> URI Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Router Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Output Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Security Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Input Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:56:59 --> Language Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Loader Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:56:59 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Session Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:56:59 --> Session routines successfully run
DEBUG - 2012-04-07 13:56:59 --> Controller Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Model Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Model Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Config Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:56:59 --> URI Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Router Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Output Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Security Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Input Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:56:59 --> Language Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Loader Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:56:59 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Session Class Initialized
DEBUG - 2012-04-07 13:56:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:56:59 --> Session routines successfully run
DEBUG - 2012-04-07 13:56:59 --> Controller Class Initialized
DEBUG - 2012-04-07 13:56:59 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-07 13:56:59 --> Final output sent to browser
DEBUG - 2012-04-07 13:56:59 --> Total execution time: 0.0502
DEBUG - 2012-04-07 13:57:01 --> Config Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:57:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:57:01 --> URI Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Router Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Output Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Security Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Input Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:57:01 --> Language Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Loader Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:57:01 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Session Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:57:01 --> Session routines successfully run
DEBUG - 2012-04-07 13:57:01 --> Controller Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Config Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:57:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:57:01 --> URI Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Router Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Output Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Security Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Input Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:57:01 --> Language Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Loader Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:57:01 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Session Class Initialized
DEBUG - 2012-04-07 13:57:01 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:57:01 --> A session cookie was not found.
DEBUG - 2012-04-07 13:57:01 --> Session routines successfully run
DEBUG - 2012-04-07 13:57:01 --> Controller Class Initialized
DEBUG - 2012-04-07 13:57:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 13:57:01 --> Final output sent to browser
DEBUG - 2012-04-07 13:57:01 --> Total execution time: 0.0553
DEBUG - 2012-04-07 13:57:05 --> Config Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:57:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:57:05 --> URI Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Router Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Output Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Security Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Input Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:57:05 --> Language Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Loader Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:57:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Session Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:57:05 --> Session routines successfully run
DEBUG - 2012-04-07 13:57:05 --> Controller Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Model Class Initialized
DEBUG - 2012-04-07 13:57:05 --> Model Class Initialized
DEBUG - 2012-04-07 13:57:05 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 13:57:05 --> Final output sent to browser
DEBUG - 2012-04-07 13:57:05 --> Total execution time: 0.0606
DEBUG - 2012-04-07 13:57:31 --> Config Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:57:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:57:31 --> URI Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Router Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Output Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Security Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Input Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:57:31 --> Language Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Loader Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:57:31 --> Database Driver Class Initialized
ERROR - 2012-04-07 13:57:31 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-07 13:57:31 --> Session Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:57:31 --> Session routines successfully run
DEBUG - 2012-04-07 13:57:31 --> Controller Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Model Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Model Class Initialized
DEBUG - 2012-04-07 13:57:31 --> Helper loaded: email_helper
DEBUG - 2012-04-07 13:57:31 --> Model Class Initialized
ERROR - 2012-04-07 13:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\models\block.php 39
DEBUG - 2012-04-07 13:57:31 --> DB Transaction Failure
ERROR - 2012-04-07 13:57:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-07 13:57:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-07 13:59:12 --> Config Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:59:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:59:12 --> URI Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Router Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Output Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Security Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Input Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:59:12 --> Language Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Loader Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:59:12 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Session Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:59:12 --> Session routines successfully run
DEBUG - 2012-04-07 13:59:12 --> Controller Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Model Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Model Class Initialized
DEBUG - 2012-04-07 13:59:12 --> Helper loaded: email_helper
DEBUG - 2012-04-07 13:59:12 --> Model Class Initialized
DEBUG - 2012-04-07 13:59:12 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 13:59:12 --> Final output sent to browser
DEBUG - 2012-04-07 13:59:12 --> Total execution time: 0.0670
DEBUG - 2012-04-07 13:59:28 --> Config Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:59:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:59:28 --> URI Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Router Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Output Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Security Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Input Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:59:28 --> Language Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Loader Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:59:28 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Session Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:59:28 --> Session routines successfully run
DEBUG - 2012-04-07 13:59:28 --> Controller Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Model Class Initialized
DEBUG - 2012-04-07 13:59:28 --> Model Class Initialized
DEBUG - 2012-04-07 13:59:28 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 13:59:28 --> Final output sent to browser
DEBUG - 2012-04-07 13:59:28 --> Total execution time: 0.0635
DEBUG - 2012-04-07 13:59:33 --> Config Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Hooks Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Utf8 Class Initialized
DEBUG - 2012-04-07 13:59:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 13:59:33 --> URI Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Router Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Output Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Security Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Input Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 13:59:33 --> Language Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Loader Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Helper loaded: url_helper
DEBUG - 2012-04-07 13:59:33 --> Database Driver Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Session Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Helper loaded: string_helper
DEBUG - 2012-04-07 13:59:33 --> Session routines successfully run
DEBUG - 2012-04-07 13:59:33 --> Controller Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Model Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Model Class Initialized
DEBUG - 2012-04-07 13:59:33 --> Helper loaded: email_helper
DEBUG - 2012-04-07 13:59:33 --> Model Class Initialized
DEBUG - 2012-04-07 13:59:33 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 13:59:33 --> Final output sent to browser
DEBUG - 2012-04-07 13:59:33 --> Total execution time: 0.0681
DEBUG - 2012-04-07 14:00:00 --> Config Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:00:00 --> URI Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Router Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Output Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Security Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Input Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:00:00 --> Language Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Loader Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:00:00 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Session Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:00:00 --> Session routines successfully run
DEBUG - 2012-04-07 14:00:00 --> Controller Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:00 --> Helper loaded: email_helper
DEBUG - 2012-04-07 14:00:00 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:00 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 14:00:00 --> Final output sent to browser
DEBUG - 2012-04-07 14:00:00 --> Total execution time: 0.0671
DEBUG - 2012-04-07 14:00:17 --> Config Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:00:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:00:17 --> URI Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Router Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Output Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Security Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Input Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:00:17 --> Language Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Loader Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:00:17 --> Database Driver Class Initialized
ERROR - 2012-04-07 14:00:17 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-07 14:00:17 --> Session Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:00:17 --> Session routines successfully run
DEBUG - 2012-04-07 14:00:17 --> Controller Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:17 --> Helper loaded: email_helper
DEBUG - 2012-04-07 14:00:17 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:17 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 14:00:17 --> Final output sent to browser
DEBUG - 2012-04-07 14:00:17 --> Total execution time: 0.1039
DEBUG - 2012-04-07 14:00:32 --> Config Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:00:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:00:32 --> URI Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Router Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Output Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Security Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Input Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:00:32 --> Language Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Loader Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:00:32 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Session Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:00:32 --> Session routines successfully run
DEBUG - 2012-04-07 14:00:32 --> Controller Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:32 --> Helper loaded: email_helper
DEBUG - 2012-04-07 14:00:32 --> Model Class Initialized
DEBUG - 2012-04-07 14:00:32 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 14:00:32 --> Final output sent to browser
DEBUG - 2012-04-07 14:00:32 --> Total execution time: 0.0715
DEBUG - 2012-04-07 14:11:35 --> Config Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:11:35 --> URI Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Router Class Initialized
DEBUG - 2012-04-07 14:11:35 --> No URI present. Default controller set.
DEBUG - 2012-04-07 14:11:35 --> Output Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Security Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Input Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:11:35 --> Language Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Loader Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:11:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Session Class Initialized
DEBUG - 2012-04-07 14:11:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:11:35 --> Session routines successfully run
DEBUG - 2012-04-07 14:11:35 --> Controller Class Initialized
DEBUG - 2012-04-07 14:11:35 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 14:11:35 --> Final output sent to browser
DEBUG - 2012-04-07 14:11:35 --> Total execution time: 0.0588
DEBUG - 2012-04-07 14:11:42 --> Config Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:11:42 --> URI Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Router Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Output Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Security Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Input Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:11:42 --> Language Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Loader Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:11:42 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Session Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:11:42 --> Session routines successfully run
DEBUG - 2012-04-07 14:11:42 --> Controller Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Model Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Model Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Config Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:11:42 --> URI Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Router Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Output Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Security Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Input Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:11:42 --> Language Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Loader Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:11:42 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Session Class Initialized
DEBUG - 2012-04-07 14:11:42 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:11:42 --> Session routines successfully run
DEBUG - 2012-04-07 14:11:42 --> Controller Class Initialized
DEBUG - 2012-04-07 14:11:42 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-07 14:11:42 --> Final output sent to browser
DEBUG - 2012-04-07 14:11:42 --> Total execution time: 0.0572
DEBUG - 2012-04-07 14:11:44 --> Config Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:11:44 --> URI Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Router Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Output Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Security Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Input Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:11:44 --> Language Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Loader Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:11:44 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Session Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:11:44 --> Session routines successfully run
DEBUG - 2012-04-07 14:11:44 --> Controller Class Initialized
DEBUG - 2012-04-07 14:11:44 --> Final output sent to browser
DEBUG - 2012-04-07 14:11:44 --> Total execution time: 0.0562
DEBUG - 2012-04-07 14:12:44 --> Config Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:12:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:12:44 --> URI Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Router Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Output Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Security Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Input Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:12:44 --> Language Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Loader Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:12:44 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Session Class Initialized
DEBUG - 2012-04-07 14:12:44 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:12:44 --> Session routines successfully run
DEBUG - 2012-04-07 14:12:44 --> Controller Class Initialized
ERROR - 2012-04-07 14:12:44 --> Severity: Notice  --> Undefined variable: dept C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 11
ERROR - 2012-04-07 14:12:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 11
DEBUG - 2012-04-07 14:12:44 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:12:44 --> Final output sent to browser
DEBUG - 2012-04-07 14:12:44 --> Total execution time: 0.0642
DEBUG - 2012-04-07 14:13:49 --> Config Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:13:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:13:49 --> URI Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Router Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Output Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Security Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Input Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:13:49 --> Language Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Loader Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:13:49 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Session Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:13:49 --> Session routines successfully run
DEBUG - 2012-04-07 14:13:49 --> Controller Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Model Class Initialized
DEBUG - 2012-04-07 14:13:49 --> Model Class Initialized
DEBUG - 2012-04-07 14:13:49 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:13:49 --> Final output sent to browser
DEBUG - 2012-04-07 14:13:49 --> Total execution time: 0.0656
DEBUG - 2012-04-07 14:18:56 --> Config Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:18:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:18:56 --> URI Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Router Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Output Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Security Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Input Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:18:56 --> Language Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Loader Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:18:56 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Session Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:18:56 --> Session routines successfully run
DEBUG - 2012-04-07 14:18:56 --> Controller Class Initialized
ERROR - 2012-04-07 14:18:56 --> Severity: Notice  --> Undefined variable: Email C:\Software\xampp\htdocs\xcms\system\controllers\blocks.php 15
DEBUG - 2012-04-07 14:18:56 --> Model Class Initialized
DEBUG - 2012-04-07 14:18:56 --> Model Class Initialized
DEBUG - 2012-04-07 14:18:56 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:18:56 --> Final output sent to browser
DEBUG - 2012-04-07 14:18:56 --> Total execution time: 0.0706
DEBUG - 2012-04-07 14:26:05 --> Config Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:26:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:26:05 --> URI Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Router Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Output Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Security Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Input Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:26:05 --> Language Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Loader Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:26:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Session Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:26:05 --> Session routines successfully run
DEBUG - 2012-04-07 14:26:05 --> Controller Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Model Class Initialized
DEBUG - 2012-04-07 14:26:05 --> Model Class Initialized
DEBUG - 2012-04-07 14:26:05 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:26:05 --> Final output sent to browser
DEBUG - 2012-04-07 14:26:05 --> Total execution time: 0.1090
DEBUG - 2012-04-07 14:26:08 --> Config Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:26:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:26:08 --> URI Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Router Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Output Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Security Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Input Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:26:08 --> Language Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Loader Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:26:08 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Session Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:26:08 --> Session routines successfully run
DEBUG - 2012-04-07 14:26:08 --> Controller Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Model Class Initialized
DEBUG - 2012-04-07 14:26:08 --> Model Class Initialized
DEBUG - 2012-04-07 14:26:08 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:26:08 --> Final output sent to browser
DEBUG - 2012-04-07 14:26:08 --> Total execution time: 0.0654
DEBUG - 2012-04-07 14:26:54 --> Config Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:26:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:26:54 --> URI Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Router Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Output Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Security Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Input Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:26:54 --> Language Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Loader Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:26:54 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Session Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:26:54 --> Session routines successfully run
DEBUG - 2012-04-07 14:26:54 --> Controller Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Model Class Initialized
DEBUG - 2012-04-07 14:26:54 --> Model Class Initialized
DEBUG - 2012-04-07 14:26:54 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:26:54 --> Final output sent to browser
DEBUG - 2012-04-07 14:26:54 --> Total execution time: 0.0645
DEBUG - 2012-04-07 14:26:59 --> Config Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:26:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:26:59 --> URI Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Router Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Output Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Security Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Input Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:26:59 --> Language Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Loader Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:26:59 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Session Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:26:59 --> Session routines successfully run
DEBUG - 2012-04-07 14:26:59 --> Controller Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Model Class Initialized
DEBUG - 2012-04-07 14:26:59 --> Model Class Initialized
DEBUG - 2012-04-07 14:26:59 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:26:59 --> Final output sent to browser
DEBUG - 2012-04-07 14:26:59 --> Total execution time: 0.0652
DEBUG - 2012-04-07 14:27:01 --> Config Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:27:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:27:01 --> URI Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Router Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Output Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Security Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Input Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:27:01 --> Language Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Loader Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:27:01 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Session Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:27:01 --> Session routines successfully run
DEBUG - 2012-04-07 14:27:01 --> Controller Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Model Class Initialized
DEBUG - 2012-04-07 14:27:01 --> Model Class Initialized
DEBUG - 2012-04-07 14:27:01 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:27:01 --> Final output sent to browser
DEBUG - 2012-04-07 14:27:01 --> Total execution time: 0.0648
DEBUG - 2012-04-07 14:31:35 --> Config Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:31:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:31:35 --> URI Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Router Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Output Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Security Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Input Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:31:35 --> Language Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Loader Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:31:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Session Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:31:35 --> Session routines successfully run
DEBUG - 2012-04-07 14:31:35 --> Controller Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Model Class Initialized
DEBUG - 2012-04-07 14:31:35 --> Model Class Initialized
DEBUG - 2012-04-07 14:31:35 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:31:35 --> Final output sent to browser
DEBUG - 2012-04-07 14:31:35 --> Total execution time: 0.0672
DEBUG - 2012-04-07 14:32:58 --> Config Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:32:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:32:58 --> URI Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Router Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Output Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Security Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Input Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:32:58 --> Language Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Loader Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:32:58 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Session Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:32:58 --> Session routines successfully run
DEBUG - 2012-04-07 14:32:58 --> Controller Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Model Class Initialized
DEBUG - 2012-04-07 14:32:58 --> Model Class Initialized
DEBUG - 2012-04-07 14:32:58 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:32:58 --> Final output sent to browser
DEBUG - 2012-04-07 14:32:58 --> Total execution time: 0.0672
DEBUG - 2012-04-07 14:33:02 --> Config Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:33:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:33:02 --> URI Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Router Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Output Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Security Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Input Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:33:02 --> Language Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Loader Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:33:02 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Session Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:33:02 --> Session routines successfully run
DEBUG - 2012-04-07 14:33:02 --> Controller Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Model Class Initialized
DEBUG - 2012-04-07 14:33:02 --> Model Class Initialized
DEBUG - 2012-04-07 14:33:02 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:33:02 --> Final output sent to browser
DEBUG - 2012-04-07 14:33:02 --> Total execution time: 0.0678
DEBUG - 2012-04-07 14:33:05 --> Config Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:33:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:33:05 --> URI Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Router Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Output Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Security Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Input Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:33:05 --> Language Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Loader Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:33:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Session Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:33:05 --> Session routines successfully run
DEBUG - 2012-04-07 14:33:05 --> Controller Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Model Class Initialized
DEBUG - 2012-04-07 14:33:05 --> Model Class Initialized
DEBUG - 2012-04-07 14:33:05 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:33:05 --> Final output sent to browser
DEBUG - 2012-04-07 14:33:05 --> Total execution time: 0.0671
DEBUG - 2012-04-07 14:33:13 --> Config Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:33:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:33:13 --> URI Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Router Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Output Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Security Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Input Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:33:13 --> Language Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Loader Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:33:13 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Session Class Initialized
DEBUG - 2012-04-07 14:33:13 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:33:13 --> Session routines successfully run
DEBUG - 2012-04-07 14:33:13 --> Controller Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Config Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:34:22 --> URI Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Router Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Output Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Security Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Input Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:34:22 --> Language Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Loader Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:34:22 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Session Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:34:22 --> Session routines successfully run
DEBUG - 2012-04-07 14:34:22 --> Controller Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:22 --> Model Class Initialized
ERROR - 2012-04-07 14:34:22 --> Severity: Notice  --> Undefined variable: dept C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 14
ERROR - 2012-04-07 14:34:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 14
DEBUG - 2012-04-07 14:34:22 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:34:22 --> Final output sent to browser
DEBUG - 2012-04-07 14:34:22 --> Total execution time: 0.1004
DEBUG - 2012-04-07 14:34:24 --> Config Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:34:24 --> URI Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Router Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Output Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Security Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Input Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:34:24 --> Language Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Loader Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:34:24 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Session Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:34:24 --> Session routines successfully run
DEBUG - 2012-04-07 14:34:24 --> Controller Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:24 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:24 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:34:24 --> Final output sent to browser
DEBUG - 2012-04-07 14:34:24 --> Total execution time: 0.0685
DEBUG - 2012-04-07 14:34:29 --> Config Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:34:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:34:29 --> URI Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Router Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Output Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Security Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Input Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:34:29 --> Language Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Loader Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:34:29 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Session Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:34:29 --> Session routines successfully run
DEBUG - 2012-04-07 14:34:29 --> Controller Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:29 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:29 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:34:29 --> Final output sent to browser
DEBUG - 2012-04-07 14:34:30 --> Total execution time: 0.0716
DEBUG - 2012-04-07 14:34:35 --> Config Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:34:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:34:35 --> URI Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Router Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Output Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Security Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Input Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:34:35 --> Language Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Loader Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:34:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Session Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:34:35 --> Session routines successfully run
DEBUG - 2012-04-07 14:34:35 --> Controller Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:35 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:35 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:34:35 --> Final output sent to browser
DEBUG - 2012-04-07 14:34:35 --> Total execution time: 0.0700
DEBUG - 2012-04-07 14:34:40 --> Config Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:34:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:34:40 --> URI Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Router Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Output Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Security Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Input Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:34:40 --> Language Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Loader Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:34:40 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Session Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:34:40 --> Session routines successfully run
DEBUG - 2012-04-07 14:34:40 --> Controller Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:40 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:40 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:34:40 --> Final output sent to browser
DEBUG - 2012-04-07 14:34:40 --> Total execution time: 0.0688
DEBUG - 2012-04-07 14:34:43 --> Config Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:34:43 --> URI Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Router Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Output Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Security Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Input Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:34:43 --> Language Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Loader Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:34:43 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Session Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:34:43 --> Session routines successfully run
DEBUG - 2012-04-07 14:34:43 --> Controller Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:43 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:43 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:34:43 --> Final output sent to browser
DEBUG - 2012-04-07 14:34:43 --> Total execution time: 0.0686
DEBUG - 2012-04-07 14:34:47 --> Config Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:34:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:34:47 --> URI Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Router Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Output Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Security Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Input Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:34:47 --> Language Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Loader Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:34:47 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Session Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:34:47 --> Session routines successfully run
DEBUG - 2012-04-07 14:34:47 --> Controller Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Model Class Initialized
DEBUG - 2012-04-07 14:34:47 --> Model Class Initialized
ERROR - 2012-04-07 14:34:47 --> Severity: Notice  --> Undefined variable: dept C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 14
ERROR - 2012-04-07 14:34:47 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 14
DEBUG - 2012-04-07 14:34:47 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:34:47 --> Final output sent to browser
DEBUG - 2012-04-07 14:34:47 --> Total execution time: 0.0741
DEBUG - 2012-04-07 14:36:06 --> Config Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:36:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:36:06 --> URI Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Router Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Output Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Security Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Input Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:36:06 --> Language Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Loader Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:36:06 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Session Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:36:06 --> Session routines successfully run
DEBUG - 2012-04-07 14:36:06 --> Controller Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Model Class Initialized
DEBUG - 2012-04-07 14:36:06 --> Model Class Initialized
DEBUG - 2012-04-07 14:36:06 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:36:06 --> Final output sent to browser
DEBUG - 2012-04-07 14:36:06 --> Total execution time: 0.0694
DEBUG - 2012-04-07 14:36:11 --> Config Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:36:11 --> URI Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Router Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Output Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Security Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Input Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:36:11 --> Language Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Loader Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:36:11 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Session Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:36:11 --> Session routines successfully run
DEBUG - 2012-04-07 14:36:11 --> Controller Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Model Class Initialized
DEBUG - 2012-04-07 14:36:11 --> Model Class Initialized
ERROR - 2012-04-07 14:36:11 --> Severity: Notice  --> Undefined variable: dept C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 14
ERROR - 2012-04-07 14:36:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 14
DEBUG - 2012-04-07 14:36:11 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:36:11 --> Final output sent to browser
DEBUG - 2012-04-07 14:36:11 --> Total execution time: 0.0759
DEBUG - 2012-04-07 14:40:08 --> Config Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:40:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:40:08 --> URI Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Router Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Output Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Security Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Input Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:40:08 --> Language Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Loader Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:40:08 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Session Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:40:08 --> Session routines successfully run
DEBUG - 2012-04-07 14:40:08 --> Controller Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Model Class Initialized
DEBUG - 2012-04-07 14:40:08 --> Model Class Initialized
DEBUG - 2012-04-07 14:40:08 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:40:08 --> Final output sent to browser
DEBUG - 2012-04-07 14:40:08 --> Total execution time: 0.0715
DEBUG - 2012-04-07 14:40:13 --> Config Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:40:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:40:13 --> URI Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Router Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Output Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Security Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Input Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:40:13 --> Language Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Loader Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:40:13 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Session Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:40:13 --> Session routines successfully run
DEBUG - 2012-04-07 14:40:13 --> Controller Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Model Class Initialized
DEBUG - 2012-04-07 14:40:13 --> Model Class Initialized
ERROR - 2012-04-07 14:40:13 --> Severity: Notice  --> Undefined variable: dept C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 14
ERROR - 2012-04-07 14:40:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Software\xampp\htdocs\xcms\system\views\newset_view.php 14
DEBUG - 2012-04-07 14:40:13 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:40:13 --> Final output sent to browser
DEBUG - 2012-04-07 14:40:13 --> Total execution time: 0.0763
DEBUG - 2012-04-07 14:41:09 --> Config Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:41:09 --> URI Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Router Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Output Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Security Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Input Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:41:09 --> Language Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Loader Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:41:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Session Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:41:09 --> Session routines successfully run
DEBUG - 2012-04-07 14:41:09 --> Controller Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Model Class Initialized
DEBUG - 2012-04-07 14:41:09 --> Model Class Initialized
DEBUG - 2012-04-07 14:41:09 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:41:09 --> Final output sent to browser
DEBUG - 2012-04-07 14:41:09 --> Total execution time: 0.0727
DEBUG - 2012-04-07 14:41:13 --> Config Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:41:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:41:13 --> URI Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Router Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Output Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Security Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Input Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:41:13 --> Language Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Loader Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:41:13 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Session Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:41:13 --> Session routines successfully run
DEBUG - 2012-04-07 14:41:13 --> Controller Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Model Class Initialized
DEBUG - 2012-04-07 14:41:13 --> Model Class Initialized
DEBUG - 2012-04-07 14:41:13 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 14:41:13 --> Final output sent to browser
DEBUG - 2012-04-07 14:41:13 --> Total execution time: 0.0722
DEBUG - 2012-04-07 14:53:22 --> Config Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:53:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:53:22 --> URI Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Router Class Initialized
DEBUG - 2012-04-07 14:53:22 --> No URI present. Default controller set.
DEBUG - 2012-04-07 14:53:22 --> Output Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Security Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Input Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:53:22 --> Language Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Loader Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:53:22 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Session Class Initialized
DEBUG - 2012-04-07 14:53:22 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:53:22 --> Session routines successfully run
DEBUG - 2012-04-07 14:53:22 --> Controller Class Initialized
DEBUG - 2012-04-07 14:53:22 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-07 14:53:22 --> Final output sent to browser
DEBUG - 2012-04-07 14:53:22 --> Total execution time: 0.0709
DEBUG - 2012-04-07 14:53:28 --> Config Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:53:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:53:28 --> URI Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Router Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Output Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Security Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Input Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:53:28 --> Language Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Loader Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:53:28 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Session Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:53:28 --> Session routines successfully run
DEBUG - 2012-04-07 14:53:28 --> Controller Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Config Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:53:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:53:28 --> URI Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Router Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Output Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Security Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Input Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:53:28 --> Language Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Loader Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:53:28 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Session Class Initialized
DEBUG - 2012-04-07 14:53:28 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:53:28 --> A session cookie was not found.
DEBUG - 2012-04-07 14:53:28 --> Session routines successfully run
DEBUG - 2012-04-07 14:53:28 --> Controller Class Initialized
DEBUG - 2012-04-07 14:53:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 14:53:28 --> Final output sent to browser
DEBUG - 2012-04-07 14:53:28 --> Total execution time: 0.0686
DEBUG - 2012-04-07 14:53:58 --> Config Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:53:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:53:58 --> URI Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Router Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Output Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Security Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Input Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:53:58 --> Language Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Loader Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:53:58 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Session Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:53:58 --> Session routines successfully run
DEBUG - 2012-04-07 14:53:58 --> Controller Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Model Class Initialized
DEBUG - 2012-04-07 14:53:58 --> Model Class Initialized
DEBUG - 2012-04-07 14:53:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 14:53:58 --> Final output sent to browser
DEBUG - 2012-04-07 14:53:58 --> Total execution time: 0.0731
DEBUG - 2012-04-07 14:54:48 --> Config Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:54:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:54:48 --> URI Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Router Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Output Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Security Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Input Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:54:48 --> Language Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Loader Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:54:48 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Session Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:54:48 --> Session routines successfully run
DEBUG - 2012-04-07 14:54:48 --> Controller Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Model Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Model Class Initialized
DEBUG - 2012-04-07 14:54:48 --> Helper loaded: email_helper
DEBUG - 2012-04-07 14:54:48 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Config Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:55:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:55:09 --> URI Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Router Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Output Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Security Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Input Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:55:09 --> Language Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Loader Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:55:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Session Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:55:09 --> Session routines successfully run
DEBUG - 2012-04-07 14:55:09 --> Controller Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:09 --> Helper loaded: email_helper
DEBUG - 2012-04-07 14:55:09 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Config Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:55:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:55:37 --> URI Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Router Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Output Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Security Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Input Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:55:37 --> Language Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Loader Class Initialized
DEBUG - 2012-04-07 14:55:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:55:38 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:55:38 --> Session Class Initialized
DEBUG - 2012-04-07 14:55:38 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:55:38 --> Session routines successfully run
DEBUG - 2012-04-07 14:55:38 --> Controller Class Initialized
DEBUG - 2012-04-07 14:55:38 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:38 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:38 --> Helper loaded: email_helper
DEBUG - 2012-04-07 14:55:38 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Config Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:55:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:55:48 --> URI Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Router Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Output Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Security Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Input Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:55:48 --> Language Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Loader Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:55:48 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Session Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:55:48 --> Session routines successfully run
DEBUG - 2012-04-07 14:55:48 --> Controller Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Model Class Initialized
DEBUG - 2012-04-07 14:55:48 --> Helper loaded: email_helper
DEBUG - 2012-04-07 14:55:48 --> Model Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Config Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:56:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:56:00 --> URI Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Router Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Output Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Security Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Input Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:56:00 --> Language Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Loader Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:56:00 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Session Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:56:00 --> Session routines successfully run
DEBUG - 2012-04-07 14:56:00 --> Controller Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Model Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Model Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Helper loaded: email_helper
DEBUG - 2012-04-07 14:56:00 --> Model Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Config Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:56:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:56:00 --> URI Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Router Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Output Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Security Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Input Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:56:00 --> Language Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Loader Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:56:00 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Session Class Initialized
DEBUG - 2012-04-07 14:56:00 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:56:00 --> Session routines successfully run
DEBUG - 2012-04-07 14:56:00 --> Controller Class Initialized
DEBUG - 2012-04-07 14:56:00 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-07 14:56:00 --> Final output sent to browser
DEBUG - 2012-04-07 14:56:00 --> Total execution time: 0.0660
DEBUG - 2012-04-07 14:58:54 --> Config Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:58:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:58:54 --> URI Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Router Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Output Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Security Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Input Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:58:54 --> Language Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Loader Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:58:54 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Session Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:58:54 --> Session routines successfully run
DEBUG - 2012-04-07 14:58:54 --> Controller Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Config Class Initialized
DEBUG - 2012-04-07 14:58:54 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:58:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:58:55 --> URI Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Router Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Output Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Security Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Input Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:58:55 --> Language Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Loader Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:58:55 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Session Class Initialized
DEBUG - 2012-04-07 14:58:55 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:58:55 --> A session cookie was not found.
DEBUG - 2012-04-07 14:58:55 --> Session routines successfully run
DEBUG - 2012-04-07 14:58:55 --> Controller Class Initialized
DEBUG - 2012-04-07 14:58:55 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 14:58:55 --> Final output sent to browser
DEBUG - 2012-04-07 14:58:55 --> Total execution time: 0.0691
DEBUG - 2012-04-07 14:58:57 --> Config Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Hooks Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Utf8 Class Initialized
DEBUG - 2012-04-07 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 14:58:57 --> URI Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Router Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Output Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Security Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Input Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 14:58:57 --> Language Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Loader Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Helper loaded: url_helper
DEBUG - 2012-04-07 14:58:57 --> Database Driver Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Session Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Helper loaded: string_helper
DEBUG - 2012-04-07 14:58:57 --> Session routines successfully run
DEBUG - 2012-04-07 14:58:57 --> Controller Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Model Class Initialized
DEBUG - 2012-04-07 14:58:57 --> Model Class Initialized
DEBUG - 2012-04-07 14:58:57 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 14:58:57 --> Final output sent to browser
DEBUG - 2012-04-07 14:58:57 --> Total execution time: 0.0871
DEBUG - 2012-04-07 15:00:38 --> Config Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:00:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:00:38 --> URI Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Router Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Output Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Security Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Input Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:00:38 --> Language Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Loader Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:00:38 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Session Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:00:38 --> Session routines successfully run
DEBUG - 2012-04-07 15:00:38 --> Controller Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Model Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Model Class Initialized
DEBUG - 2012-04-07 15:00:38 --> Helper loaded: email_helper
DEBUG - 2012-04-07 15:00:38 --> Model Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Config Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:01:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:01:17 --> URI Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Router Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Output Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Security Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Input Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:01:17 --> Language Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Loader Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:01:17 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Session Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:01:17 --> Session routines successfully run
DEBUG - 2012-04-07 15:01:17 --> Controller Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Model Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Model Class Initialized
DEBUG - 2012-04-07 15:01:17 --> Helper loaded: email_helper
DEBUG - 2012-04-07 15:01:17 --> Model Class Initialized
DEBUG - 2012-04-07 15:01:17 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 15:01:17 --> Final output sent to browser
DEBUG - 2012-04-07 15:01:17 --> Total execution time: 0.0823
DEBUG - 2012-04-07 15:16:34 --> Config Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:16:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:16:34 --> URI Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Router Class Initialized
DEBUG - 2012-04-07 15:16:34 --> No URI present. Default controller set.
DEBUG - 2012-04-07 15:16:34 --> Output Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Security Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Input Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:16:34 --> Language Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Loader Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:16:34 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Session Class Initialized
DEBUG - 2012-04-07 15:16:34 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:16:34 --> Session routines successfully run
DEBUG - 2012-04-07 15:16:34 --> Controller Class Initialized
DEBUG - 2012-04-07 15:16:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 15:16:34 --> Final output sent to browser
DEBUG - 2012-04-07 15:16:34 --> Total execution time: 0.0754
DEBUG - 2012-04-07 15:16:41 --> Config Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:16:41 --> URI Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Router Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Output Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Security Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Input Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:16:41 --> Language Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Loader Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:16:41 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Session Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:16:41 --> Session routines successfully run
DEBUG - 2012-04-07 15:16:41 --> Controller Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Model Class Initialized
DEBUG - 2012-04-07 15:16:41 --> Model Class Initialized
DEBUG - 2012-04-07 15:16:41 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 15:16:41 --> Final output sent to browser
DEBUG - 2012-04-07 15:16:41 --> Total execution time: 0.0765
DEBUG - 2012-04-07 15:16:48 --> Config Class Initialized
DEBUG - 2012-04-07 15:16:48 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:16:48 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:16:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:16:48 --> URI Class Initialized
DEBUG - 2012-04-07 15:16:48 --> Router Class Initialized
ERROR - 2012-04-07 15:16:48 --> 404 Page Not Found --> block
DEBUG - 2012-04-07 15:16:58 --> Config Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:16:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:16:58 --> URI Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Router Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Output Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Security Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Input Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:16:58 --> Language Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Loader Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:16:58 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Session Class Initialized
DEBUG - 2012-04-07 15:16:58 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:16:58 --> Session routines successfully run
DEBUG - 2012-04-07 15:16:58 --> Controller Class Initialized
ERROR - 2012-04-07 15:16:58 --> 404 Page Not Found --> blocks/index
DEBUG - 2012-04-07 15:17:09 --> Config Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:17:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:17:09 --> URI Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Router Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Output Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Security Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Input Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:17:09 --> Language Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Loader Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:17:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Session Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:17:09 --> Session routines successfully run
DEBUG - 2012-04-07 15:17:09 --> Controller Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Model Class Initialized
DEBUG - 2012-04-07 15:17:09 --> Model Class Initialized
DEBUG - 2012-04-07 15:17:09 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 15:17:09 --> Final output sent to browser
DEBUG - 2012-04-07 15:17:09 --> Total execution time: 0.0785
DEBUG - 2012-04-07 15:36:14 --> Config Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:36:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:36:14 --> URI Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Router Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Output Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Security Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Input Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:36:14 --> Language Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Loader Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:36:14 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Session Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:36:14 --> Session routines successfully run
DEBUG - 2012-04-07 15:36:14 --> Controller Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Model Class Initialized
DEBUG - 2012-04-07 15:36:14 --> Model Class Initialized
DEBUG - 2012-04-07 15:36:14 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 15:36:14 --> Final output sent to browser
DEBUG - 2012-04-07 15:36:14 --> Total execution time: 0.0816
DEBUG - 2012-04-07 15:53:55 --> Config Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:53:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:53:55 --> URI Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Router Class Initialized
DEBUG - 2012-04-07 15:53:55 --> No URI present. Default controller set.
DEBUG - 2012-04-07 15:53:55 --> Output Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Security Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Input Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:53:55 --> Language Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Loader Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:53:55 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Session Class Initialized
DEBUG - 2012-04-07 15:53:55 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:53:55 --> Session routines successfully run
DEBUG - 2012-04-07 15:53:55 --> Controller Class Initialized
DEBUG - 2012-04-07 15:53:55 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 15:53:55 --> Final output sent to browser
DEBUG - 2012-04-07 15:53:55 --> Total execution time: 0.0703
DEBUG - 2012-04-07 15:54:03 --> Config Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:54:03 --> URI Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Router Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Output Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Security Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Input Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:54:03 --> Language Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Loader Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:54:03 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Session Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:54:03 --> Session routines successfully run
DEBUG - 2012-04-07 15:54:03 --> Controller Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Model Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Model Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Config Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:54:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:54:03 --> URI Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Router Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Output Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Security Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Input Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:54:03 --> Language Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Loader Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:54:03 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Session Class Initialized
DEBUG - 2012-04-07 15:54:03 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:54:03 --> Session routines successfully run
DEBUG - 2012-04-07 15:54:03 --> Controller Class Initialized
DEBUG - 2012-04-07 15:54:03 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-07 15:54:03 --> Final output sent to browser
DEBUG - 2012-04-07 15:54:03 --> Total execution time: 0.0678
DEBUG - 2012-04-07 15:54:05 --> Config Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:54:05 --> URI Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Router Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Output Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Security Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Input Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:54:05 --> Language Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Loader Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:54:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Session Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:54:05 --> Session routines successfully run
DEBUG - 2012-04-07 15:54:05 --> Controller Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Model Class Initialized
DEBUG - 2012-04-07 15:54:05 --> Model Class Initialized
DEBUG - 2012-04-07 15:54:05 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 15:54:05 --> Final output sent to browser
DEBUG - 2012-04-07 15:54:05 --> Total execution time: 0.0903
DEBUG - 2012-04-07 15:55:37 --> Config Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:55:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:55:37 --> URI Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Router Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Output Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Security Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Input Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:55:37 --> Language Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Loader Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:55:37 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Session Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:55:37 --> Session routines successfully run
DEBUG - 2012-04-07 15:55:37 --> Controller Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Model Class Initialized
DEBUG - 2012-04-07 15:55:37 --> Model Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Config Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:57:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:57:51 --> URI Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Router Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Output Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Security Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Input Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:57:51 --> Language Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Loader Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:57:51 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Session Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:57:51 --> Session routines successfully run
DEBUG - 2012-04-07 15:57:51 --> Controller Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Model Class Initialized
DEBUG - 2012-04-07 15:57:51 --> Model Class Initialized
DEBUG - 2012-04-07 15:57:51 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 15:57:51 --> Final output sent to browser
DEBUG - 2012-04-07 15:57:51 --> Total execution time: 0.0787
DEBUG - 2012-04-07 15:58:41 --> Config Class Initialized
DEBUG - 2012-04-07 15:58:41 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:58:41 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:58:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:58:42 --> URI Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Router Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Output Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Security Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Input Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:58:42 --> Language Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Loader Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:58:42 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Session Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:58:42 --> Session routines successfully run
DEBUG - 2012-04-07 15:58:42 --> Controller Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Model Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Model Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Model Class Initialized
DEBUG - 2012-04-07 15:58:42 --> Final output sent to browser
DEBUG - 2012-04-07 15:58:42 --> Total execution time: 0.3973
DEBUG - 2012-04-07 15:59:55 --> Config Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Hooks Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Utf8 Class Initialized
DEBUG - 2012-04-07 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 15:59:55 --> URI Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Router Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Output Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Security Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Input Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 15:59:55 --> Language Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Loader Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Helper loaded: url_helper
DEBUG - 2012-04-07 15:59:55 --> Database Driver Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Session Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Helper loaded: string_helper
DEBUG - 2012-04-07 15:59:55 --> Session routines successfully run
DEBUG - 2012-04-07 15:59:55 --> Controller Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Model Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Model Class Initialized
DEBUG - 2012-04-07 15:59:55 --> Model Class Initialized
DEBUG - 2012-04-07 15:59:56 --> Final output sent to browser
DEBUG - 2012-04-07 15:59:56 --> Total execution time: 1.5210
DEBUG - 2012-04-07 16:09:46 --> Config Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:09:46 --> URI Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Router Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Output Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Security Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Input Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:09:46 --> Language Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Loader Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:09:46 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Session Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:09:46 --> Session routines successfully run
DEBUG - 2012-04-07 16:09:46 --> Controller Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Model Class Initialized
DEBUG - 2012-04-07 16:09:46 --> Model Class Initialized
DEBUG - 2012-04-07 16:09:46 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 16:09:46 --> Final output sent to browser
DEBUG - 2012-04-07 16:09:46 --> Total execution time: 0.0863
DEBUG - 2012-04-07 16:09:59 --> Config Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:09:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:09:59 --> URI Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Router Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Output Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Security Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Input Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:09:59 --> Language Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Loader Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:09:59 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Session Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:09:59 --> Session routines successfully run
DEBUG - 2012-04-07 16:09:59 --> Controller Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Model Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Model Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Model Class Initialized
DEBUG - 2012-04-07 16:09:59 --> Final output sent to browser
DEBUG - 2012-04-07 16:09:59 --> Total execution time: 0.1203
DEBUG - 2012-04-07 16:10:47 --> Config Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:10:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:10:47 --> URI Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Router Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Output Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Security Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Input Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:10:47 --> Language Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Loader Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:10:47 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Session Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:10:47 --> Session routines successfully run
DEBUG - 2012-04-07 16:10:47 --> Controller Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Model Class Initialized
DEBUG - 2012-04-07 16:10:47 --> Model Class Initialized
DEBUG - 2012-04-07 16:10:47 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 16:10:47 --> Final output sent to browser
DEBUG - 2012-04-07 16:10:47 --> Total execution time: 0.0765
DEBUG - 2012-04-07 16:10:59 --> Config Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:10:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:10:59 --> URI Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Router Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Output Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Security Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Input Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:10:59 --> Language Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Loader Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:10:59 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Session Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:10:59 --> Session routines successfully run
DEBUG - 2012-04-07 16:10:59 --> Controller Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Model Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Model Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Model Class Initialized
DEBUG - 2012-04-07 16:10:59 --> Final output sent to browser
DEBUG - 2012-04-07 16:10:59 --> Total execution time: 0.2543
DEBUG - 2012-04-07 16:11:09 --> Config Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:11:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:11:09 --> URI Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Router Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Output Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Security Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Input Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:11:09 --> Language Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Loader Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:11:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Session Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:11:09 --> Session routines successfully run
DEBUG - 2012-04-07 16:11:09 --> Controller Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Model Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Model Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Model Class Initialized
DEBUG - 2012-04-07 16:11:09 --> Final output sent to browser
DEBUG - 2012-04-07 16:11:09 --> Total execution time: 0.0835
DEBUG - 2012-04-07 16:11:25 --> Config Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:11:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:11:25 --> URI Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Router Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Output Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Security Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Input Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:11:25 --> Language Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Loader Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:11:25 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Session Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:11:25 --> Session routines successfully run
DEBUG - 2012-04-07 16:11:25 --> Controller Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Model Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Model Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Model Class Initialized
DEBUG - 2012-04-07 16:11:25 --> Final output sent to browser
DEBUG - 2012-04-07 16:11:25 --> Total execution time: 0.0818
DEBUG - 2012-04-07 16:13:22 --> Config Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:13:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:13:22 --> URI Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Router Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Output Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Security Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Input Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:13:22 --> Language Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Loader Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:13:22 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Session Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:13:22 --> Session routines successfully run
DEBUG - 2012-04-07 16:13:22 --> Controller Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:22 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:23 --> Final output sent to browser
DEBUG - 2012-04-07 16:13:23 --> Total execution time: 0.1036
DEBUG - 2012-04-07 16:13:33 --> Config Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:13:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:13:33 --> URI Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Router Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Output Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Security Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Input Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:13:33 --> Language Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Loader Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:13:33 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Session Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:13:33 --> Session routines successfully run
DEBUG - 2012-04-07 16:13:33 --> Controller Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:33 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:42 --> Final output sent to browser
DEBUG - 2012-04-07 16:13:42 --> Total execution time: 8.9772
DEBUG - 2012-04-07 16:13:49 --> Config Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:13:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:13:49 --> URI Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Router Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Output Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Security Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Input Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:13:49 --> Language Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Loader Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:13:49 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Session Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:13:49 --> Session routines successfully run
DEBUG - 2012-04-07 16:13:49 --> Controller Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:49 --> Model Class Initialized
DEBUG - 2012-04-07 16:13:58 --> Final output sent to browser
DEBUG - 2012-04-07 16:13:58 --> Total execution time: 9.5271
DEBUG - 2012-04-07 16:16:02 --> Config Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:16:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:16:02 --> URI Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Router Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Output Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Security Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Input Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:16:02 --> Language Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Loader Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:16:02 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Session Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:16:02 --> Session routines successfully run
DEBUG - 2012-04-07 16:16:02 --> Controller Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Model Class Initialized
DEBUG - 2012-04-07 16:16:02 --> Model Class Initialized
DEBUG - 2012-04-07 16:16:02 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 16:16:02 --> Final output sent to browser
DEBUG - 2012-04-07 16:16:02 --> Total execution time: 0.0792
DEBUG - 2012-04-07 16:16:17 --> Config Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:16:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:16:17 --> URI Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Router Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Output Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Security Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Input Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:16:17 --> Language Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Loader Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:16:17 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Session Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:16:17 --> Session routines successfully run
DEBUG - 2012-04-07 16:16:17 --> Controller Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Model Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Model Class Initialized
DEBUG - 2012-04-07 16:16:17 --> Model Class Initialized
DEBUG - 2012-04-07 16:16:17 --> DB Transaction Failure
ERROR - 2012-04-07 16:16:17 --> Query error: Duplicate entry '1333808177-89' for key 'PRIMARY'
DEBUG - 2012-04-07 16:16:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-07 16:17:06 --> Config Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:17:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:17:06 --> URI Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Router Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Output Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Security Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Input Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:17:06 --> Language Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Loader Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:17:06 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Session Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:17:06 --> Session routines successfully run
DEBUG - 2012-04-07 16:17:06 --> Controller Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Model Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Model Class Initialized
DEBUG - 2012-04-07 16:17:06 --> Model Class Initialized
DEBUG - 2012-04-07 16:17:06 --> DB Transaction Failure
ERROR - 2012-04-07 16:17:06 --> Query error: Duplicate entry '48' for key 'Code'
DEBUG - 2012-04-07 16:17:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-07 16:18:10 --> Config Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:18:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:18:10 --> URI Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Router Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Output Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Security Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Input Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:18:10 --> Language Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Loader Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:18:10 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Session Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:18:10 --> Session routines successfully run
DEBUG - 2012-04-07 16:18:10 --> Controller Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:10 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:10 --> DB Transaction Failure
ERROR - 2012-04-07 16:18:10 --> Query error: Duplicate entry '24' for key 'Code'
DEBUG - 2012-04-07 16:18:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-07 16:18:24 --> Config Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:18:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:18:24 --> URI Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Router Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Output Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Security Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Input Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:18:24 --> Language Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Loader Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:18:24 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Session Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:18:24 --> Session routines successfully run
DEBUG - 2012-04-07 16:18:24 --> Controller Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:24 --> Final output sent to browser
DEBUG - 2012-04-07 16:18:24 --> Total execution time: 0.0841
DEBUG - 2012-04-07 16:18:29 --> Config Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:18:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:18:29 --> URI Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Router Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Output Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Security Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Input Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:18:29 --> Language Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Loader Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:18:29 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Session Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:18:29 --> Session routines successfully run
DEBUG - 2012-04-07 16:18:29 --> Controller Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:29 --> Model Class Initialized
DEBUG - 2012-04-07 16:18:29 --> DB Transaction Failure
ERROR - 2012-04-07 16:18:29 --> Query error: Duplicate entry '96' for key 'Code'
DEBUG - 2012-04-07 16:18:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-07 16:33:37 --> Config Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:33:37 --> URI Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Router Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Output Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Security Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Input Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:33:37 --> Language Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Loader Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:33:37 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Session Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:33:37 --> Session routines successfully run
DEBUG - 2012-04-07 16:33:37 --> Controller Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Model Class Initialized
DEBUG - 2012-04-07 16:33:37 --> Model Class Initialized
DEBUG - 2012-04-07 16:33:37 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 16:33:37 --> Final output sent to browser
DEBUG - 2012-04-07 16:33:37 --> Total execution time: 0.0774
DEBUG - 2012-04-07 16:33:54 --> Config Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:33:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:33:54 --> URI Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Router Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Output Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Security Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Input Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:33:54 --> Language Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Loader Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:33:54 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Session Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:33:54 --> Session routines successfully run
DEBUG - 2012-04-07 16:33:54 --> Controller Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Model Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Model Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Model Class Initialized
DEBUG - 2012-04-07 16:33:54 --> Final output sent to browser
DEBUG - 2012-04-07 16:33:54 --> Total execution time: 0.1048
DEBUG - 2012-04-07 16:37:16 --> Config Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:37:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:37:16 --> URI Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Router Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Output Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Security Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Input Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:37:16 --> Language Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Loader Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:37:16 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Session Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:37:16 --> Session routines successfully run
DEBUG - 2012-04-07 16:37:16 --> Controller Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Model Class Initialized
DEBUG - 2012-04-07 16:37:16 --> Model Class Initialized
DEBUG - 2012-04-07 16:37:16 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 16:37:16 --> Final output sent to browser
DEBUG - 2012-04-07 16:37:16 --> Total execution time: 0.0766
DEBUG - 2012-04-07 16:37:29 --> Config Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:37:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:37:29 --> URI Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Router Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Output Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Security Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Input Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:37:29 --> Language Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Loader Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:37:29 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Session Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:37:29 --> Session routines successfully run
DEBUG - 2012-04-07 16:37:29 --> Controller Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Model Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Model Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Model Class Initialized
DEBUG - 2012-04-07 16:37:29 --> Final output sent to browser
DEBUG - 2012-04-07 16:37:29 --> Total execution time: 0.0905
DEBUG - 2012-04-07 16:38:31 --> Config Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:38:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:38:31 --> URI Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Router Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Output Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Security Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Input Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:38:31 --> Language Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Loader Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:38:31 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Session Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:38:31 --> Session routines successfully run
DEBUG - 2012-04-07 16:38:31 --> Controller Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Model Class Initialized
DEBUG - 2012-04-07 16:38:31 --> Model Class Initialized
DEBUG - 2012-04-07 16:38:31 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 16:38:31 --> Final output sent to browser
DEBUG - 2012-04-07 16:38:31 --> Total execution time: 0.0788
DEBUG - 2012-04-07 16:38:37 --> Config Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:38:37 --> URI Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Router Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Output Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Security Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Input Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:38:37 --> Language Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Loader Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:38:37 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Session Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:38:37 --> Session routines successfully run
DEBUG - 2012-04-07 16:38:37 --> Controller Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Model Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Model Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Model Class Initialized
DEBUG - 2012-04-07 16:38:37 --> Final output sent to browser
DEBUG - 2012-04-07 16:38:37 --> Total execution time: 0.0869
DEBUG - 2012-04-07 16:39:09 --> Config Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:39:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:39:09 --> URI Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Router Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Output Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Security Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Input Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:39:09 --> Language Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Loader Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:39:09 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Session Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:39:09 --> Session routines successfully run
DEBUG - 2012-04-07 16:39:09 --> Controller Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Model Class Initialized
DEBUG - 2012-04-07 16:39:09 --> Model Class Initialized
DEBUG - 2012-04-07 16:39:09 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 16:39:09 --> Final output sent to browser
DEBUG - 2012-04-07 16:39:09 --> Total execution time: 0.0766
DEBUG - 2012-04-07 16:39:15 --> Config Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:39:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:39:15 --> URI Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Router Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Output Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Security Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Input Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:39:15 --> Language Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Loader Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:39:15 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Session Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:39:15 --> Session routines successfully run
DEBUG - 2012-04-07 16:39:15 --> Controller Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Model Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Model Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Model Class Initialized
DEBUG - 2012-04-07 16:39:15 --> Final output sent to browser
DEBUG - 2012-04-07 16:39:15 --> Total execution time: 0.0875
DEBUG - 2012-04-07 16:42:16 --> Config Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:42:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:42:16 --> URI Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Router Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Output Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Security Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Input Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:42:16 --> Language Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Loader Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:42:16 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Session Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:42:16 --> Session routines successfully run
DEBUG - 2012-04-07 16:42:16 --> Controller Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Model Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Model Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Model Class Initialized
DEBUG - 2012-04-07 16:42:16 --> Final output sent to browser
DEBUG - 2012-04-07 16:42:16 --> Total execution time: 0.1072
DEBUG - 2012-04-07 16:42:52 --> Config Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:42:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:42:52 --> URI Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Router Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Output Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Security Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Input Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:42:52 --> Language Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Loader Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:42:52 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Session Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:42:52 --> Session routines successfully run
DEBUG - 2012-04-07 16:42:52 --> Controller Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Model Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Model Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Model Class Initialized
DEBUG - 2012-04-07 16:42:52 --> Final output sent to browser
DEBUG - 2012-04-07 16:42:52 --> Total execution time: 0.1103
DEBUG - 2012-04-07 16:43:01 --> Config Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Hooks Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Utf8 Class Initialized
DEBUG - 2012-04-07 16:43:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 16:43:01 --> URI Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Router Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Output Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Security Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Input Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 16:43:01 --> Language Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Loader Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Helper loaded: url_helper
DEBUG - 2012-04-07 16:43:01 --> Database Driver Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Session Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Helper loaded: string_helper
DEBUG - 2012-04-07 16:43:01 --> Session routines successfully run
DEBUG - 2012-04-07 16:43:01 --> Controller Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Model Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Model Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Model Class Initialized
DEBUG - 2012-04-07 16:43:01 --> Final output sent to browser
DEBUG - 2012-04-07 16:43:01 --> Total execution time: 0.1151
DEBUG - 2012-04-07 19:32:46 --> Config Class Initialized
DEBUG - 2012-04-07 19:32:46 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:32:46 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:32:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:32:46 --> URI Class Initialized
DEBUG - 2012-04-07 19:32:46 --> Router Class Initialized
DEBUG - 2012-04-07 19:32:46 --> No URI present. Default controller set.
DEBUG - 2012-04-07 19:32:47 --> Output Class Initialized
DEBUG - 2012-04-07 19:32:47 --> Security Class Initialized
DEBUG - 2012-04-07 19:32:47 --> Input Class Initialized
DEBUG - 2012-04-07 19:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:32:47 --> Language Class Initialized
DEBUG - 2012-04-07 19:32:47 --> Loader Class Initialized
DEBUG - 2012-04-07 19:32:47 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:32:47 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:32:47 --> Session Class Initialized
DEBUG - 2012-04-07 19:32:47 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:32:47 --> Session routines successfully run
DEBUG - 2012-04-07 19:32:47 --> Controller Class Initialized
DEBUG - 2012-04-07 19:32:47 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-07 19:32:47 --> Final output sent to browser
DEBUG - 2012-04-07 19:32:47 --> Total execution time: 1.3437
DEBUG - 2012-04-07 19:32:49 --> Config Class Initialized
DEBUG - 2012-04-07 19:32:49 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:32:49 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:32:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:32:49 --> URI Class Initialized
DEBUG - 2012-04-07 19:32:49 --> Router Class Initialized
DEBUG - 2012-04-07 19:32:49 --> Output Class Initialized
DEBUG - 2012-04-07 19:32:49 --> Security Class Initialized
DEBUG - 2012-04-07 19:32:49 --> Input Class Initialized
DEBUG - 2012-04-07 19:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:32:50 --> Language Class Initialized
DEBUG - 2012-04-07 19:32:50 --> Loader Class Initialized
DEBUG - 2012-04-07 19:32:50 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:32:50 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:32:50 --> Session Class Initialized
DEBUG - 2012-04-07 19:32:50 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:32:50 --> Session routines successfully run
DEBUG - 2012-04-07 19:32:50 --> Controller Class Initialized
DEBUG - 2012-04-07 19:32:50 --> Model Class Initialized
DEBUG - 2012-04-07 19:32:50 --> Model Class Initialized
DEBUG - 2012-04-07 19:32:50 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 19:32:50 --> Final output sent to browser
DEBUG - 2012-04-07 19:32:50 --> Total execution time: 0.7650
DEBUG - 2012-04-07 19:33:01 --> Config Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:33:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:33:01 --> URI Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Router Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Output Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Security Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Input Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:33:01 --> Language Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Loader Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:33:01 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Session Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:33:01 --> Session routines successfully run
DEBUG - 2012-04-07 19:33:01 --> Controller Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Model Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Model Class Initialized
DEBUG - 2012-04-07 19:33:01 --> Helper loaded: email_helper
DEBUG - 2012-04-07 19:33:01 --> Model Class Initialized
DEBUG - 2012-04-07 19:33:01 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-07 19:33:01 --> Final output sent to browser
DEBUG - 2012-04-07 19:33:01 --> Total execution time: 0.4720
DEBUG - 2012-04-07 19:34:04 --> Config Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:34:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:34:04 --> URI Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Router Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Output Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Security Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Input Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:34:04 --> Language Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Loader Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:34:04 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Session Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:34:04 --> Session routines successfully run
DEBUG - 2012-04-07 19:34:04 --> Controller Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Model Class Initialized
DEBUG - 2012-04-07 19:34:04 --> Model Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Config Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:34:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:34:05 --> URI Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Router Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Output Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Security Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Input Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:34:05 --> Language Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Loader Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:34:05 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Session Class Initialized
DEBUG - 2012-04-07 19:34:05 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:34:05 --> Session routines successfully run
DEBUG - 2012-04-07 19:34:05 --> Controller Class Initialized
DEBUG - 2012-04-07 19:34:05 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-07 19:34:05 --> Final output sent to browser
DEBUG - 2012-04-07 19:34:05 --> Total execution time: 0.4415
DEBUG - 2012-04-07 19:34:07 --> Config Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:34:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:34:07 --> URI Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Router Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Output Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Security Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Input Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:34:07 --> Language Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Loader Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:34:07 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Session Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:34:07 --> Session routines successfully run
DEBUG - 2012-04-07 19:34:07 --> Controller Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Model Class Initialized
DEBUG - 2012-04-07 19:34:07 --> Model Class Initialized
DEBUG - 2012-04-07 19:34:07 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 19:34:07 --> Final output sent to browser
DEBUG - 2012-04-07 19:34:07 --> Total execution time: 0.4981
DEBUG - 2012-04-07 19:34:37 --> Config Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:34:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:34:37 --> URI Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Router Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Output Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Security Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Input Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:34:37 --> Language Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Loader Class Initialized
DEBUG - 2012-04-07 19:34:37 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:34:38 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:34:38 --> Session Class Initialized
DEBUG - 2012-04-07 19:34:38 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:34:38 --> Session routines successfully run
DEBUG - 2012-04-07 19:34:38 --> Controller Class Initialized
DEBUG - 2012-04-07 19:34:38 --> Model Class Initialized
DEBUG - 2012-04-07 19:34:38 --> Model Class Initialized
DEBUG - 2012-04-07 19:34:38 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 19:34:38 --> Final output sent to browser
DEBUG - 2012-04-07 19:34:38 --> Total execution time: 0.5031
DEBUG - 2012-04-07 19:34:53 --> Config Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:34:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:34:53 --> URI Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Router Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Output Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Security Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Input Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:34:53 --> Language Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Loader Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:34:53 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Session Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:34:53 --> Session routines successfully run
DEBUG - 2012-04-07 19:34:53 --> Controller Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Model Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Model Class Initialized
DEBUG - 2012-04-07 19:34:53 --> Model Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Config Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:38:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:38:51 --> URI Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Router Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Output Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Security Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Input Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:38:51 --> Language Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Loader Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:38:51 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Session Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:38:51 --> Session routines successfully run
DEBUG - 2012-04-07 19:38:51 --> Controller Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Model Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Model Class Initialized
DEBUG - 2012-04-07 19:38:51 --> Model Class Initialized
DEBUG - 2012-04-07 19:46:34 --> Config Class Initialized
DEBUG - 2012-04-07 19:46:34 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:46:34 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:46:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:46:34 --> URI Class Initialized
DEBUG - 2012-04-07 19:46:34 --> Router Class Initialized
DEBUG - 2012-04-07 19:46:34 --> Output Class Initialized
DEBUG - 2012-04-07 19:46:34 --> Security Class Initialized
DEBUG - 2012-04-07 19:46:34 --> Input Class Initialized
DEBUG - 2012-04-07 19:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:46:34 --> Language Class Initialized
DEBUG - 2012-04-07 19:46:35 --> Loader Class Initialized
DEBUG - 2012-04-07 19:46:35 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:46:35 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:46:35 --> Session Class Initialized
DEBUG - 2012-04-07 19:46:35 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:46:35 --> Session routines successfully run
DEBUG - 2012-04-07 19:46:35 --> Controller Class Initialized
DEBUG - 2012-04-07 19:46:35 --> Model Class Initialized
DEBUG - 2012-04-07 19:46:35 --> Model Class Initialized
DEBUG - 2012-04-07 19:46:35 --> Model Class Initialized
DEBUG - 2012-04-07 19:46:35 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-07 19:46:35 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-07 19:46:35 --> Final output sent to browser
DEBUG - 2012-04-07 19:46:35 --> Total execution time: 1.4667
DEBUG - 2012-04-07 19:48:15 --> Config Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:48:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:48:15 --> URI Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Router Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Output Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Security Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Input Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:48:15 --> Language Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Loader Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:48:15 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Session Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:48:15 --> Session routines successfully run
DEBUG - 2012-04-07 19:48:15 --> Controller Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Model Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Model Class Initialized
DEBUG - 2012-04-07 19:48:15 --> Model Class Initialized
DEBUG - 2012-04-07 19:48:15 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-07 19:48:15 --> Final output sent to browser
DEBUG - 2012-04-07 19:48:15 --> Total execution time: 0.6251
DEBUG - 2012-04-07 19:53:26 --> Config Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Hooks Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Utf8 Class Initialized
DEBUG - 2012-04-07 19:53:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-07 19:53:26 --> URI Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Router Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Output Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Security Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Input Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-07 19:53:26 --> Language Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Loader Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Helper loaded: url_helper
DEBUG - 2012-04-07 19:53:26 --> Database Driver Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Session Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Helper loaded: string_helper
DEBUG - 2012-04-07 19:53:26 --> Session routines successfully run
DEBUG - 2012-04-07 19:53:26 --> Controller Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Model Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Model Class Initialized
DEBUG - 2012-04-07 19:53:26 --> Model Class Initialized
DEBUG - 2012-04-07 19:53:26 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-07 19:53:26 --> Final output sent to browser
DEBUG - 2012-04-07 19:53:26 --> Total execution time: 0.5631
