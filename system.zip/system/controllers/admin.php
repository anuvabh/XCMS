<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function createDepartment()
        {
            
            
        }
        public function createCR()
        {
            redirect(base_url().'accounts/register/cr', 'location');
            return;
        }
        public function deleteDepartment(){}
	public function editDepartment(){}
	public function viewRegistry(){}
	public function editRegistry(){}
	public function viewActionLog(){}
	public function viewErrorLog(){}
}