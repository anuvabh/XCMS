<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-03 12:59:19 --> Config Class Initialized
DEBUG - 2012-04-03 12:59:19 --> Hooks Class Initialized
DEBUG - 2012-04-03 12:59:19 --> Utf8 Class Initialized
DEBUG - 2012-04-03 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 12:59:19 --> URI Class Initialized
DEBUG - 2012-04-03 12:59:19 --> Router Class Initialized
DEBUG - 2012-04-03 12:59:19 --> No URI present. Default controller set.
DEBUG - 2012-04-03 12:59:19 --> Output Class Initialized
DEBUG - 2012-04-03 12:59:19 --> Security Class Initialized
DEBUG - 2012-04-03 12:59:19 --> Input Class Initialized
DEBUG - 2012-04-03 12:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 12:59:19 --> Language Class Initialized
DEBUG - 2012-04-03 12:59:19 --> Loader Class Initialized
DEBUG - 2012-04-03 12:59:19 --> Controller Class Initialized
DEBUG - 2012-04-03 12:59:19 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 12:59:19 --> Final output sent to browser
DEBUG - 2012-04-03 12:59:19 --> Total execution time: 0.3203
DEBUG - 2012-04-03 14:03:18 --> Config Class Initialized
DEBUG - 2012-04-03 14:03:18 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:03:18 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:03:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:03:18 --> URI Class Initialized
DEBUG - 2012-04-03 14:03:18 --> Router Class Initialized
DEBUG - 2012-04-03 14:03:18 --> No URI present. Default controller set.
DEBUG - 2012-04-03 14:03:18 --> Output Class Initialized
DEBUG - 2012-04-03 14:03:18 --> Security Class Initialized
DEBUG - 2012-04-03 14:03:18 --> Input Class Initialized
DEBUG - 2012-04-03 14:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:03:18 --> Language Class Initialized
DEBUG - 2012-04-03 14:03:18 --> Loader Class Initialized
DEBUG - 2012-04-03 14:03:18 --> Controller Class Initialized
DEBUG - 2012-04-03 14:03:18 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:03:18 --> Final output sent to browser
DEBUG - 2012-04-03 14:03:18 --> Total execution time: 0.0293
DEBUG - 2012-04-03 14:03:38 --> Config Class Initialized
DEBUG - 2012-04-03 14:03:38 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:03:38 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:03:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:03:38 --> URI Class Initialized
DEBUG - 2012-04-03 14:03:38 --> Router Class Initialized
DEBUG - 2012-04-03 14:03:38 --> Output Class Initialized
DEBUG - 2012-04-03 14:03:38 --> Security Class Initialized
DEBUG - 2012-04-03 14:03:38 --> Input Class Initialized
DEBUG - 2012-04-03 14:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:03:38 --> Language Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Config Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:04:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:04:34 --> URI Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Router Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Output Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Security Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Input Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:04:34 --> Language Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Loader Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Controller Class Initialized
ERROR - 2012-04-03 14:04:34 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 8
ERROR - 2012-04-03 14:04:34 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 8
ERROR - 2012-04-03 14:04:34 --> Severity: Notice  --> Use of undefined constant user - assumed 'user' C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 10
DEBUG - 2012-04-03 14:04:34 --> Model Class Initialized
DEBUG - 2012-04-03 14:04:34 --> Model Class Initialized
ERROR - 2012-04-03 14:04:34 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:04:34 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:04:34 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:06:11 --> Config Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:06:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:06:11 --> URI Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Router Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Output Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Security Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Input Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:06:11 --> Language Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Loader Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Controller Class Initialized
ERROR - 2012-04-03 14:06:11 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 8
ERROR - 2012-04-03 14:06:11 --> Severity: Notice  --> Undefined variable: password C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 8
ERROR - 2012-04-03 14:06:11 --> Severity: Notice  --> Use of undefined constant user - assumed 'user' C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 10
DEBUG - 2012-04-03 14:06:11 --> Model Class Initialized
DEBUG - 2012-04-03 14:06:11 --> Model Class Initialized
ERROR - 2012-04-03 14:06:11 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:06:11 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:06:11 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:06:39 --> Config Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:06:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:06:39 --> URI Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Router Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Output Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Security Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Input Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:06:39 --> Language Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Loader Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Controller Class Initialized
ERROR - 2012-04-03 14:06:39 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 8
ERROR - 2012-04-03 14:06:39 --> Severity: Notice  --> Undefined variable: password C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 8
ERROR - 2012-04-03 14:06:39 --> Severity: Notice  --> Use of undefined constant user - assumed 'user' C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 10
DEBUG - 2012-04-03 14:06:39 --> Model Class Initialized
DEBUG - 2012-04-03 14:06:39 --> Model Class Initialized
ERROR - 2012-04-03 14:06:39 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:06:39 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:06:39 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:07:13 --> Config Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:07:13 --> URI Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Router Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Output Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Security Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Input Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:07:13 --> Language Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Loader Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Controller Class Initialized
DEBUG - 2012-04-03 14:07:13 --> Final output sent to browser
DEBUG - 2012-04-03 14:07:13 --> Total execution time: 0.0513
DEBUG - 2012-04-03 14:07:22 --> Config Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:07:22 --> URI Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Router Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Output Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Security Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Input Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:07:22 --> Language Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Loader Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Controller Class Initialized
ERROR - 2012-04-03 14:07:22 --> Severity: Notice  --> Use of undefined constant user - assumed 'user' C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 10
DEBUG - 2012-04-03 14:07:22 --> Model Class Initialized
DEBUG - 2012-04-03 14:07:22 --> Model Class Initialized
ERROR - 2012-04-03 14:07:22 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:07:22 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:07:22 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:07:46 --> Config Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:07:46 --> URI Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Router Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Output Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Security Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Input Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:07:46 --> Language Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Loader Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Controller Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Model Class Initialized
DEBUG - 2012-04-03 14:07:46 --> Model Class Initialized
ERROR - 2012-04-03 14:07:46 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:07:46 --> Severity: Notice  --> Undefined variable: username C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 12
ERROR - 2012-04-03 14:07:46 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:08:14 --> Config Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:08:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:08:14 --> URI Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Router Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Output Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Security Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Input Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:08:14 --> Language Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Loader Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Controller Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Model Class Initialized
DEBUG - 2012-04-03 14:08:14 --> Model Class Initialized
ERROR - 2012-04-03 14:08:14 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:09:51 --> Config Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:09:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:09:51 --> URI Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Router Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Output Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Security Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Input Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:09:51 --> Language Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Loader Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Controller Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Model Class Initialized
DEBUG - 2012-04-03 14:09:51 --> Model Class Initialized
ERROR - 2012-04-03 14:09:51 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:09:59 --> Config Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:09:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:09:59 --> URI Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Router Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Output Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Security Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Input Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:09:59 --> Language Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Loader Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Controller Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Model Class Initialized
DEBUG - 2012-04-03 14:09:59 --> Model Class Initialized
ERROR - 2012-04-03 14:09:59 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:11:37 --> Config Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:11:37 --> URI Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Router Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Output Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Security Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Input Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:11:37 --> Language Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Loader Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Controller Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Model Class Initialized
DEBUG - 2012-04-03 14:11:37 --> Model Class Initialized
ERROR - 2012-04-03 14:11:37 --> Severity: Notice  --> Undefined property: Accounts::$db C:\Software\xampp\htdocs\XCMS\system\core\Model.php 51
DEBUG - 2012-04-03 14:15:47 --> Config Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:15:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:15:47 --> URI Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Router Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Output Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Security Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Input Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:15:47 --> Language Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Loader Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Controller Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Model Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Model Class Initialized
DEBUG - 2012-04-03 14:15:47 --> Database Driver Class Initialized
ERROR - 2012-04-03 14:15:47 --> Severity: Notice  --> Undefined property: stdClass::$password C:\Software\xampp\htdocs\XCMS\system\models\user.php 17
DEBUG - 2012-04-03 14:15:47 --> Final output sent to browser
DEBUG - 2012-04-03 14:15:47 --> Total execution time: 0.2967
DEBUG - 2012-04-03 14:16:09 --> Config Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:16:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:16:09 --> URI Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Router Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Output Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Security Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Input Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:16:09 --> Language Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Loader Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Controller Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Model Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Model Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:16:09 --> Final output sent to browser
DEBUG - 2012-04-03 14:16:09 --> Total execution time: 0.0812
DEBUG - 2012-04-03 14:16:17 --> Config Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:16:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:16:17 --> URI Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Router Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Output Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Security Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Input Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:16:17 --> Language Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Loader Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Controller Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Model Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Model Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:16:17 --> Final output sent to browser
DEBUG - 2012-04-03 14:16:17 --> Total execution time: 0.1296
DEBUG - 2012-04-03 14:17:56 --> Config Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:17:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:17:56 --> URI Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Router Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Output Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Security Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Input Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:17:56 --> Language Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Loader Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Controller Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Model Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Model Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:17:56 --> Final output sent to browser
DEBUG - 2012-04-03 14:17:56 --> Total execution time: 0.0417
DEBUG - 2012-04-03 14:19:24 --> Config Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:19:24 --> URI Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Router Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Output Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Security Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Input Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:19:24 --> Language Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Loader Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Controller Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Model Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Model Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:19:24 --> Final output sent to browser
DEBUG - 2012-04-03 14:19:24 --> Total execution time: 0.0422
DEBUG - 2012-04-03 14:20:15 --> Config Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:20:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:20:15 --> URI Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Router Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Output Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Security Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Input Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:20:15 --> Language Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Loader Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Controller Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Model Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Model Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:20:15 --> Final output sent to browser
DEBUG - 2012-04-03 14:20:15 --> Total execution time: 0.0495
DEBUG - 2012-04-03 14:20:20 --> Config Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:20:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:20:20 --> URI Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Router Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Output Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Security Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Input Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:20:20 --> Language Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Loader Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Controller Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Model Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Model Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:20:20 --> Final output sent to browser
DEBUG - 2012-04-03 14:20:20 --> Total execution time: 0.0435
DEBUG - 2012-04-03 14:20:25 --> Config Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:20:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:20:25 --> URI Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Router Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Output Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Security Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Input Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:20:25 --> Language Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Loader Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Controller Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Model Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Model Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:20:25 --> Final output sent to browser
DEBUG - 2012-04-03 14:20:25 --> Total execution time: 0.0452
DEBUG - 2012-04-03 14:20:50 --> Config Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:20:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:20:50 --> URI Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Router Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Output Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Security Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Input Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:20:50 --> Language Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Loader Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Controller Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Model Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Model Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:20:50 --> Final output sent to browser
DEBUG - 2012-04-03 14:20:50 --> Total execution time: 0.0439
DEBUG - 2012-04-03 14:21:38 --> Config Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:21:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:21:38 --> URI Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Router Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Output Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Security Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Input Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:21:38 --> Language Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Loader Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Controller Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Model Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Model Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:21:38 --> Final output sent to browser
DEBUG - 2012-04-03 14:21:38 --> Total execution time: 0.0459
DEBUG - 2012-04-03 14:22:22 --> Config Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:22:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:22:22 --> URI Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Router Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Output Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Security Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Input Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:22:22 --> Language Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Loader Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Controller Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Model Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Model Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:22:22 --> Final output sent to browser
DEBUG - 2012-04-03 14:22:22 --> Total execution time: 0.0487
DEBUG - 2012-04-03 14:23:15 --> Config Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:23:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:23:15 --> URI Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Router Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Output Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Security Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Input Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:23:15 --> Language Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Loader Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Controller Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Model Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Model Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:23:15 --> Final output sent to browser
DEBUG - 2012-04-03 14:23:15 --> Total execution time: 0.0464
DEBUG - 2012-04-03 14:23:43 --> Config Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:23:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:23:43 --> URI Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Router Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Output Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Security Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Input Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:23:43 --> Language Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Loader Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Controller Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Model Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Model Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:23:43 --> Final output sent to browser
DEBUG - 2012-04-03 14:23:43 --> Total execution time: 0.0458
DEBUG - 2012-04-03 14:25:20 --> Config Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:25:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:25:20 --> URI Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Router Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Output Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Security Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Input Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:25:20 --> Language Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Loader Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Controller Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Model Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Model Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:25:20 --> Final output sent to browser
DEBUG - 2012-04-03 14:25:20 --> Total execution time: 0.0453
DEBUG - 2012-04-03 14:26:27 --> Config Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:26:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:26:27 --> URI Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Router Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Output Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Security Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Input Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:26:27 --> Language Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Loader Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Controller Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Model Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Model Class Initialized
DEBUG - 2012-04-03 14:26:27 --> Database Driver Class Initialized
ERROR - 2012-04-03 14:26:27 --> Severity: Notice  --> Undefined property: stdClass::$Username C:\Software\xampp\htdocs\XCMS\system\models\user.php 17
DEBUG - 2012-04-03 14:26:27 --> Final output sent to browser
DEBUG - 2012-04-03 14:26:27 --> Total execution time: 0.0491
DEBUG - 2012-04-03 14:26:54 --> Config Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:26:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:26:54 --> URI Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Router Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Output Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Security Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Input Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:26:54 --> Language Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Loader Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Controller Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Model Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Model Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:26:54 --> Final output sent to browser
DEBUG - 2012-04-03 14:26:54 --> Total execution time: 0.0459
DEBUG - 2012-04-03 14:28:07 --> Config Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:28:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:28:07 --> URI Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Router Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Output Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Security Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Input Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:28:07 --> Language Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Loader Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Controller Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Model Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Model Class Initialized
DEBUG - 2012-04-03 14:28:07 --> Database Driver Class Initialized
ERROR - 2012-04-03 14:28:07 --> Severity: Notice  --> Undefined property: stdClass::$status C:\Software\xampp\htdocs\XCMS\system\models\user.php 20
DEBUG - 2012-04-03 14:28:07 --> Final output sent to browser
DEBUG - 2012-04-03 14:28:07 --> Total execution time: 0.0485
DEBUG - 2012-04-03 14:29:36 --> Config Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:29:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:29:36 --> URI Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Router Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Output Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Security Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Input Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:29:36 --> Language Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Loader Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Controller Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Model Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Model Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Session Class Initialized
DEBUG - 2012-04-03 14:29:36 --> Helper loaded: string_helper
DEBUG - 2012-04-03 14:29:36 --> A session cookie was not found.
DEBUG - 2012-04-03 14:29:36 --> Session routines successfully run
DEBUG - 2012-04-03 14:29:36 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-03 14:29:36 --> Final output sent to browser
DEBUG - 2012-04-03 14:29:36 --> Total execution time: 0.2070
DEBUG - 2012-04-03 14:30:06 --> Config Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:30:06 --> URI Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Router Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Output Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Security Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Input Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:30:06 --> Language Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Loader Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Controller Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Model Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Model Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:30:06 --> Final output sent to browser
DEBUG - 2012-04-03 14:30:06 --> Total execution time: 0.0463
DEBUG - 2012-04-03 14:30:41 --> Config Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:30:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:30:41 --> URI Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Router Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Output Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Security Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Input Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:30:41 --> Language Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Loader Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Controller Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Model Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Model Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:30:41 --> Final output sent to browser
DEBUG - 2012-04-03 14:30:41 --> Total execution time: 0.0464
DEBUG - 2012-04-03 14:35:23 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:23 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:23 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:23 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:23 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:23 --> No URI present. Default controller set.
DEBUG - 2012-04-03 14:35:23 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:23 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:23 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:23 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:23 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:23 --> Controller Class Initialized
DEBUG - 2012-04-03 14:35:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:35:23 --> Final output sent to browser
DEBUG - 2012-04-03 14:35:23 --> Total execution time: 0.0365
DEBUG - 2012-04-03 14:35:30 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:30 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:30 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Controller Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Model Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Model Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:35:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:35:30 --> Final output sent to browser
DEBUG - 2012-04-03 14:35:30 --> Total execution time: 0.0871
DEBUG - 2012-04-03 14:35:30 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:30 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:30 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Controller Class Initialized
ERROR - 2012-04-03 14:35:30 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 14:35:30 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:30 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:30 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Controller Class Initialized
ERROR - 2012-04-03 14:35:30 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 14:35:30 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:30 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:30 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:30 --> Controller Class Initialized
ERROR - 2012-04-03 14:35:30 --> 404 Page Not Found --> accounts/images
DEBUG - 2012-04-03 14:35:34 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:34 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:34 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Controller Class Initialized
DEBUG - 2012-04-03 14:35:34 --> Final output sent to browser
DEBUG - 2012-04-03 14:35:34 --> Total execution time: 0.0327
DEBUG - 2012-04-03 14:35:44 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:44 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:44 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Controller Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Model Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Model Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:35:44 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:35:44 --> Final output sent to browser
DEBUG - 2012-04-03 14:35:44 --> Total execution time: 0.0493
DEBUG - 2012-04-03 14:35:44 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:44 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:44 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:44 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:44 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:44 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:44 --> Controller Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Language Class Initialized
ERROR - 2012-04-03 14:35:44 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 14:35:44 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Controller Class Initialized
ERROR - 2012-04-03 14:35:44 --> 404 Page Not Found --> accounts/images
DEBUG - 2012-04-03 14:35:44 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:44 --> Controller Class Initialized
ERROR - 2012-04-03 14:35:44 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 14:35:52 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:52 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:52 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:52 --> Controller Class Initialized
ERROR - 2012-04-03 14:35:52 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 14:35:55 --> Config Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:35:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:35:55 --> URI Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Router Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Output Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Security Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Input Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:35:55 --> Language Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Loader Class Initialized
DEBUG - 2012-04-03 14:35:55 --> Controller Class Initialized
ERROR - 2012-04-03 14:35:55 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 14:36:09 --> Config Class Initialized
DEBUG - 2012-04-03 14:36:09 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:36:09 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:36:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:36:09 --> URI Class Initialized
DEBUG - 2012-04-03 14:36:09 --> Router Class Initialized
DEBUG - 2012-04-03 14:36:09 --> No URI present. Default controller set.
DEBUG - 2012-04-03 14:36:09 --> Output Class Initialized
DEBUG - 2012-04-03 14:36:09 --> Security Class Initialized
DEBUG - 2012-04-03 14:36:09 --> Input Class Initialized
DEBUG - 2012-04-03 14:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:36:09 --> Language Class Initialized
DEBUG - 2012-04-03 14:36:09 --> Loader Class Initialized
DEBUG - 2012-04-03 14:36:09 --> Controller Class Initialized
DEBUG - 2012-04-03 14:36:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:36:09 --> Final output sent to browser
DEBUG - 2012-04-03 14:36:09 --> Total execution time: 0.0414
DEBUG - 2012-04-03 14:38:06 --> Config Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:38:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:38:06 --> URI Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Router Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Output Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Security Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Input Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:38:06 --> Language Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Loader Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Controller Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Model Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Model Class Initialized
DEBUG - 2012-04-03 14:38:06 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:38:07 --> Session Class Initialized
DEBUG - 2012-04-03 14:38:07 --> Helper loaded: string_helper
DEBUG - 2012-04-03 14:38:07 --> Session routines successfully run
DEBUG - 2012-04-03 14:38:07 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-03 14:38:07 --> Final output sent to browser
DEBUG - 2012-04-03 14:38:07 --> Total execution time: 0.0610
DEBUG - 2012-04-03 14:38:11 --> Config Class Initialized
DEBUG - 2012-04-03 14:38:11 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:38:11 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:38:11 --> URI Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Router Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Output Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Security Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Input Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:38:12 --> Language Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Loader Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Controller Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Model Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Model Class Initialized
DEBUG - 2012-04-03 14:38:12 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Config Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:40:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:40:32 --> URI Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Router Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Output Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Security Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Input Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:40:32 --> Language Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Loader Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Controller Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Model Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Model Class Initialized
DEBUG - 2012-04-03 14:40:32 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Config Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:43:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:43:11 --> URI Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Router Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Output Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Security Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Input Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:43:11 --> Language Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Loader Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Controller Class Initialized
DEBUG - 2012-04-03 14:43:11 --> Final output sent to browser
DEBUG - 2012-04-03 14:43:11 --> Total execution time: 0.0348
DEBUG - 2012-04-03 14:43:16 --> Config Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:43:16 --> URI Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Router Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Output Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Security Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Input Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:43:16 --> Language Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Loader Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Controller Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Model Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Model Class Initialized
DEBUG - 2012-04-03 14:43:16 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Config Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:43:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:43:20 --> URI Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Router Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Output Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Security Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Input Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:43:20 --> Language Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Loader Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Controller Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Model Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Model Class Initialized
DEBUG - 2012-04-03 14:43:20 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Config Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:44:04 --> URI Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Router Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Output Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Security Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Input Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:44:04 --> Language Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Loader Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Controller Class Initialized
DEBUG - 2012-04-03 14:44:04 --> Final output sent to browser
DEBUG - 2012-04-03 14:44:04 --> Total execution time: 0.0363
DEBUG - 2012-04-03 14:44:07 --> Config Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:44:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:44:07 --> URI Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Router Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Output Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Security Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Input Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:44:07 --> Language Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Loader Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Controller Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Model Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Model Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:44:07 --> Config Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:44:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:44:07 --> URI Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Router Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Output Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Security Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Input Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:44:07 --> Language Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Loader Class Initialized
DEBUG - 2012-04-03 14:44:07 --> Controller Class Initialized
DEBUG - 2012-04-03 14:44:07 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:44:07 --> Final output sent to browser
DEBUG - 2012-04-03 14:44:07 --> Total execution time: 0.0366
DEBUG - 2012-04-03 14:44:11 --> Config Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:44:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:44:11 --> URI Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Router Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Output Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Security Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Input Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:44:11 --> Language Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Loader Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Controller Class Initialized
DEBUG - 2012-04-03 14:44:11 --> Final output sent to browser
DEBUG - 2012-04-03 14:44:11 --> Total execution time: 0.0372
DEBUG - 2012-04-03 14:44:15 --> Config Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:44:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:44:15 --> URI Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Router Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Output Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Security Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Input Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:44:15 --> Language Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Loader Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Controller Class Initialized
DEBUG - 2012-04-03 14:44:15 --> Final output sent to browser
DEBUG - 2012-04-03 14:44:15 --> Total execution time: 0.0359
DEBUG - 2012-04-03 14:44:21 --> Config Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:44:21 --> URI Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Router Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Output Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Security Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Input Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:44:21 --> Language Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Loader Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Controller Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Model Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Model Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:44:21 --> Config Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:44:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:44:21 --> URI Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Router Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Output Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Security Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Input Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:44:21 --> Language Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Loader Class Initialized
DEBUG - 2012-04-03 14:44:21 --> Controller Class Initialized
DEBUG - 2012-04-03 14:44:21 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:44:21 --> Final output sent to browser
DEBUG - 2012-04-03 14:44:21 --> Total execution time: 0.0365
DEBUG - 2012-04-03 14:44:32 --> Config Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:44:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:44:32 --> URI Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Router Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Output Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Security Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Input Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:44:32 --> Language Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Loader Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Controller Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Model Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Model Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Session Class Initialized
DEBUG - 2012-04-03 14:44:32 --> Helper loaded: string_helper
DEBUG - 2012-04-03 14:44:32 --> Session routines successfully run
DEBUG - 2012-04-03 14:44:32 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-03 14:44:32 --> Final output sent to browser
DEBUG - 2012-04-03 14:44:32 --> Total execution time: 0.0608
DEBUG - 2012-04-03 14:45:44 --> Config Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:45:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:45:44 --> URI Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Router Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Output Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Security Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Input Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:45:44 --> Language Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Loader Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Controller Class Initialized
DEBUG - 2012-04-03 14:45:44 --> Final output sent to browser
DEBUG - 2012-04-03 14:45:44 --> Total execution time: 0.0359
DEBUG - 2012-04-03 14:47:38 --> Config Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:47:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:47:38 --> URI Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Router Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Output Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Security Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Input Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:47:38 --> Language Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Loader Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Controller Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:47:38 --> Config Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:47:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:47:38 --> URI Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Router Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Output Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Security Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Input Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:47:38 --> Language Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Loader Class Initialized
DEBUG - 2012-04-03 14:47:38 --> Controller Class Initialized
DEBUG - 2012-04-03 14:47:38 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:47:38 --> Final output sent to browser
DEBUG - 2012-04-03 14:47:38 --> Total execution time: 0.0387
DEBUG - 2012-04-03 14:47:44 --> Config Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:47:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:47:44 --> URI Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Router Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Output Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Security Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Input Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:47:44 --> Language Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Loader Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Controller Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:47:44 --> Config Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:47:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:47:44 --> URI Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Router Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Output Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Security Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Input Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:47:44 --> Language Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Loader Class Initialized
DEBUG - 2012-04-03 14:47:44 --> Controller Class Initialized
DEBUG - 2012-04-03 14:47:44 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:47:44 --> Final output sent to browser
DEBUG - 2012-04-03 14:47:44 --> Total execution time: 0.0393
DEBUG - 2012-04-03 14:47:46 --> Config Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:47:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:47:46 --> URI Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Router Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Output Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Security Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Input Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:47:46 --> Language Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Loader Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Controller Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:47:46 --> Config Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:47:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:47:46 --> URI Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Router Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Output Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Security Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Input Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:47:46 --> Language Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Loader Class Initialized
DEBUG - 2012-04-03 14:47:46 --> Controller Class Initialized
DEBUG - 2012-04-03 14:47:46 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:47:46 --> Final output sent to browser
DEBUG - 2012-04-03 14:47:46 --> Total execution time: 0.0370
DEBUG - 2012-04-03 14:50:22 --> Config Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:50:22 --> URI Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Router Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Output Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Security Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Input Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:50:22 --> Language Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Loader Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Controller Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Model Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Model Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Database Driver Class Initialized
ERROR - 2012-04-03 14:50:22 --> Severity: Notice  --> Undefined variable: err C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 13
DEBUG - 2012-04-03 14:50:22 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:50:22 --> Config Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:50:22 --> URI Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Router Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Output Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Security Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Input Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:50:22 --> Language Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Loader Class Initialized
DEBUG - 2012-04-03 14:50:22 --> Controller Class Initialized
DEBUG - 2012-04-03 14:50:22 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:50:22 --> Final output sent to browser
DEBUG - 2012-04-03 14:50:22 --> Total execution time: 0.0370
DEBUG - 2012-04-03 14:50:32 --> Config Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:50:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:50:32 --> URI Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Router Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Output Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Security Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Input Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:50:32 --> Language Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Loader Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Controller Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Model Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Model Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Database Driver Class Initialized
ERROR - 2012-04-03 14:50:32 --> Severity: Notice  --> Undefined variable: err C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 13
DEBUG - 2012-04-03 14:50:32 --> Session Class Initialized
DEBUG - 2012-04-03 14:50:32 --> Helper loaded: string_helper
DEBUG - 2012-04-03 14:50:32 --> Session routines successfully run
DEBUG - 2012-04-03 14:50:32 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-03 14:50:32 --> Final output sent to browser
DEBUG - 2012-04-03 14:50:32 --> Total execution time: 0.0622
DEBUG - 2012-04-03 14:51:05 --> Config Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:51:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:51:05 --> URI Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Router Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Output Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Security Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Input Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:51:05 --> Language Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Loader Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Controller Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Model Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Model Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:51:05 --> Config Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:51:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:51:05 --> URI Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Router Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Output Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Security Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Input Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:51:05 --> Language Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Loader Class Initialized
DEBUG - 2012-04-03 14:51:05 --> Controller Class Initialized
DEBUG - 2012-04-03 14:51:05 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:51:05 --> Final output sent to browser
DEBUG - 2012-04-03 14:51:05 --> Total execution time: 0.0386
DEBUG - 2012-04-03 14:52:50 --> Config Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:52:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:52:50 --> URI Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Router Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Output Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Security Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Input Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:52:50 --> Language Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Loader Class Initialized
DEBUG - 2012-04-03 14:52:50 --> Controller Class Initialized
DEBUG - 2012-04-03 14:52:50 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:52:50 --> Final output sent to browser
DEBUG - 2012-04-03 14:52:50 --> Total execution time: 0.0396
DEBUG - 2012-04-03 14:52:57 --> Config Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:52:57 --> URI Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Router Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Output Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Security Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Input Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:52:57 --> Language Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Loader Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Controller Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Model Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Model Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:52:57 --> Config Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:52:57 --> URI Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Router Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Output Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Security Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Input Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:52:57 --> Language Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Loader Class Initialized
DEBUG - 2012-04-03 14:52:57 --> Controller Class Initialized
DEBUG - 2012-04-03 14:52:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:52:57 --> Final output sent to browser
DEBUG - 2012-04-03 14:52:57 --> Total execution time: 0.0393
DEBUG - 2012-04-03 14:53:06 --> Config Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:53:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:53:06 --> URI Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Router Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Output Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Security Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Input Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:53:06 --> Language Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Loader Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Controller Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Model Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Model Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Database Driver Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Helper loaded: url_helper
DEBUG - 2012-04-03 14:53:06 --> Config Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Hooks Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Utf8 Class Initialized
DEBUG - 2012-04-03 14:53:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 14:53:06 --> URI Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Router Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Output Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Security Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Input Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 14:53:06 --> Language Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Loader Class Initialized
DEBUG - 2012-04-03 14:53:06 --> Controller Class Initialized
DEBUG - 2012-04-03 14:53:06 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 14:53:06 --> Final output sent to browser
DEBUG - 2012-04-03 14:53:06 --> Total execution time: 0.0388
DEBUG - 2012-04-03 15:07:59 --> Config Class Initialized
DEBUG - 2012-04-03 15:07:59 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:07:59 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:07:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:07:59 --> URI Class Initialized
DEBUG - 2012-04-03 15:07:59 --> Router Class Initialized
DEBUG - 2012-04-03 15:07:59 --> No URI present. Default controller set.
DEBUG - 2012-04-03 15:07:59 --> Output Class Initialized
DEBUG - 2012-04-03 15:07:59 --> Security Class Initialized
DEBUG - 2012-04-03 15:07:59 --> Input Class Initialized
DEBUG - 2012-04-03 15:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:07:59 --> Language Class Initialized
DEBUG - 2012-04-03 15:07:59 --> Loader Class Initialized
DEBUG - 2012-04-03 15:07:59 --> Controller Class Initialized
ERROR - 2012-04-03 15:07:59 --> Severity: Notice  --> Undefined variable: errorcode C:\Software\xampp\htdocs\XCMS\system\views\main_view.php 29
DEBUG - 2012-04-03 15:07:59 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:07:59 --> Final output sent to browser
DEBUG - 2012-04-03 15:07:59 --> Total execution time: 0.0429
DEBUG - 2012-04-03 15:09:13 --> Config Class Initialized
DEBUG - 2012-04-03 15:09:13 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:09:13 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:09:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:09:13 --> URI Class Initialized
DEBUG - 2012-04-03 15:09:13 --> Router Class Initialized
DEBUG - 2012-04-03 15:09:13 --> No URI present. Default controller set.
DEBUG - 2012-04-03 15:09:13 --> Output Class Initialized
DEBUG - 2012-04-03 15:09:13 --> Security Class Initialized
DEBUG - 2012-04-03 15:09:13 --> Input Class Initialized
DEBUG - 2012-04-03 15:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:09:13 --> Language Class Initialized
DEBUG - 2012-04-03 15:09:13 --> Loader Class Initialized
DEBUG - 2012-04-03 15:09:13 --> Controller Class Initialized
DEBUG - 2012-04-03 15:09:13 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:09:13 --> Final output sent to browser
DEBUG - 2012-04-03 15:09:13 --> Total execution time: 0.0387
DEBUG - 2012-04-03 15:09:25 --> Config Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:09:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:09:25 --> URI Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Router Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Output Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Security Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Input Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:09:25 --> Language Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Loader Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Controller Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Model Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Model Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Database Driver Class Initialized
DEBUG - 2012-04-03 15:09:25 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:09:25 --> Final output sent to browser
DEBUG - 2012-04-03 15:09:25 --> Total execution time: 0.0561
DEBUG - 2012-04-03 15:09:25 --> Config Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:09:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:09:25 --> URI Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Router Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Output Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Security Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Input Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:09:25 --> Language Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Loader Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Controller Class Initialized
ERROR - 2012-04-03 15:09:25 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 15:09:25 --> Config Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:09:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:09:25 --> URI Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Router Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Output Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Security Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Input Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:09:25 --> Language Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Loader Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Controller Class Initialized
ERROR - 2012-04-03 15:09:25 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 15:09:25 --> Config Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:09:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:09:25 --> URI Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Router Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Output Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Security Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Input Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:09:25 --> Language Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Loader Class Initialized
DEBUG - 2012-04-03 15:09:25 --> Controller Class Initialized
ERROR - 2012-04-03 15:09:25 --> 404 Page Not Found --> accounts/images
DEBUG - 2012-04-03 15:11:27 --> Config Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:11:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:11:27 --> URI Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Router Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Output Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Security Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Input Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:11:27 --> Language Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Loader Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Controller Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Model Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Model Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Database Driver Class Initialized
DEBUG - 2012-04-03 15:11:27 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:11:27 --> Final output sent to browser
DEBUG - 2012-04-03 15:11:27 --> Total execution time: 0.0601
DEBUG - 2012-04-03 15:11:27 --> Config Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:11:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:11:27 --> URI Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Router Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Output Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Security Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Input Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:11:27 --> Language Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Loader Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Controller Class Initialized
ERROR - 2012-04-03 15:11:27 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 15:11:27 --> Config Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:11:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:11:27 --> URI Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Router Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Output Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Security Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Input Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:11:27 --> Language Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Loader Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Controller Class Initialized
ERROR - 2012-04-03 15:11:27 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 15:11:27 --> Config Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:11:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:11:27 --> URI Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Router Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Output Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Security Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Input Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:11:27 --> Language Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Loader Class Initialized
DEBUG - 2012-04-03 15:11:27 --> Controller Class Initialized
ERROR - 2012-04-03 15:11:27 --> 404 Page Not Found --> accounts/images
DEBUG - 2012-04-03 15:11:45 --> Config Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:11:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:11:45 --> URI Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Router Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Output Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Security Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Input Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:11:45 --> Language Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Loader Class Initialized
DEBUG - 2012-04-03 15:11:45 --> Controller Class Initialized
ERROR - 2012-04-03 15:11:45 --> 404 Page Not Found --> accounts/styles
DEBUG - 2012-04-03 15:14:37 --> Config Class Initialized
DEBUG - 2012-04-03 15:14:37 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:14:37 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:14:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:14:37 --> URI Class Initialized
DEBUG - 2012-04-03 15:14:37 --> Router Class Initialized
DEBUG - 2012-04-03 15:14:37 --> No URI present. Default controller set.
DEBUG - 2012-04-03 15:14:37 --> Output Class Initialized
DEBUG - 2012-04-03 15:14:37 --> Security Class Initialized
DEBUG - 2012-04-03 15:14:37 --> Input Class Initialized
DEBUG - 2012-04-03 15:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:14:37 --> Language Class Initialized
DEBUG - 2012-04-03 15:14:37 --> Loader Class Initialized
DEBUG - 2012-04-03 15:14:37 --> Controller Class Initialized
DEBUG - 2012-04-03 15:14:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:14:37 --> Final output sent to browser
DEBUG - 2012-04-03 15:14:37 --> Total execution time: 0.0395
DEBUG - 2012-04-03 15:15:43 --> Config Class Initialized
DEBUG - 2012-04-03 15:15:43 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:15:43 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:15:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:15:43 --> URI Class Initialized
DEBUG - 2012-04-03 15:15:43 --> Router Class Initialized
DEBUG - 2012-04-03 15:15:43 --> No URI present. Default controller set.
DEBUG - 2012-04-03 15:15:43 --> Output Class Initialized
DEBUG - 2012-04-03 15:15:43 --> Security Class Initialized
DEBUG - 2012-04-03 15:15:43 --> Input Class Initialized
DEBUG - 2012-04-03 15:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:15:43 --> Language Class Initialized
DEBUG - 2012-04-03 15:15:43 --> Loader Class Initialized
DEBUG - 2012-04-03 15:15:43 --> Controller Class Initialized
DEBUG - 2012-04-03 15:15:43 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:15:43 --> Final output sent to browser
DEBUG - 2012-04-03 15:15:43 --> Total execution time: 0.0458
DEBUG - 2012-04-03 15:15:56 --> Config Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:15:56 --> URI Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Router Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Output Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Security Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Input Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:15:56 --> Language Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Loader Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Controller Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Model Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Model Class Initialized
DEBUG - 2012-04-03 15:15:56 --> Database Driver Class Initialized
DEBUG - 2012-04-03 15:15:56 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:15:56 --> Final output sent to browser
DEBUG - 2012-04-03 15:15:56 --> Total execution time: 0.0599
DEBUG - 2012-04-03 15:16:26 --> Config Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:16:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:16:26 --> URI Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Router Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Output Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Security Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Input Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:16:26 --> Language Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Loader Class Initialized
DEBUG - 2012-04-03 15:16:26 --> Controller Class Initialized
ERROR - 2012-04-03 15:16:26 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
ERROR - 2012-04-03 15:16:26 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
DEBUG - 2012-04-03 15:16:26 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:16:26 --> Final output sent to browser
DEBUG - 2012-04-03 15:16:26 --> Total execution time: 0.0464
DEBUG - 2012-04-03 15:16:32 --> Config Class Initialized
DEBUG - 2012-04-03 15:16:32 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:16:32 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:16:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:16:32 --> URI Class Initialized
DEBUG - 2012-04-03 15:16:32 --> Router Class Initialized
DEBUG - 2012-04-03 15:16:32 --> No URI present. Default controller set.
DEBUG - 2012-04-03 15:16:32 --> Output Class Initialized
DEBUG - 2012-04-03 15:16:32 --> Security Class Initialized
DEBUG - 2012-04-03 15:16:32 --> Input Class Initialized
DEBUG - 2012-04-03 15:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:16:32 --> Language Class Initialized
DEBUG - 2012-04-03 15:16:32 --> Loader Class Initialized
DEBUG - 2012-04-03 15:16:32 --> Controller Class Initialized
DEBUG - 2012-04-03 15:16:32 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:16:32 --> Final output sent to browser
DEBUG - 2012-04-03 15:16:32 --> Total execution time: 0.0448
DEBUG - 2012-04-03 15:16:37 --> Config Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:16:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:16:37 --> URI Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Router Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Output Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Security Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Input Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:16:37 --> Language Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Loader Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Controller Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Model Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Model Class Initialized
DEBUG - 2012-04-03 15:16:37 --> Database Driver Class Initialized
DEBUG - 2012-04-03 15:16:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 15:16:37 --> Final output sent to browser
DEBUG - 2012-04-03 15:16:37 --> Total execution time: 0.0583
DEBUG - 2012-04-03 15:16:44 --> Config Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Hooks Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Utf8 Class Initialized
DEBUG - 2012-04-03 15:16:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 15:16:45 --> URI Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Router Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Output Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Security Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Input Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 15:16:45 --> Language Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Loader Class Initialized
DEBUG - 2012-04-03 15:16:45 --> Controller Class Initialized
ERROR - 2012-04-03 15:16:45 --> 404 Page Not Found --> accounts/index
DEBUG - 2012-04-03 18:18:46 --> Config Class Initialized
DEBUG - 2012-04-03 18:18:46 --> Hooks Class Initialized
DEBUG - 2012-04-03 18:18:46 --> Utf8 Class Initialized
DEBUG - 2012-04-03 18:18:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 18:18:46 --> URI Class Initialized
DEBUG - 2012-04-03 18:18:46 --> Router Class Initialized
DEBUG - 2012-04-03 18:18:46 --> No URI present. Default controller set.
DEBUG - 2012-04-03 18:18:46 --> Output Class Initialized
DEBUG - 2012-04-03 18:18:46 --> Security Class Initialized
DEBUG - 2012-04-03 18:18:46 --> Input Class Initialized
DEBUG - 2012-04-03 18:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 18:18:46 --> Language Class Initialized
DEBUG - 2012-04-03 18:18:46 --> Loader Class Initialized
DEBUG - 2012-04-03 18:18:46 --> Controller Class Initialized
DEBUG - 2012-04-03 18:18:46 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 18:18:46 --> Final output sent to browser
DEBUG - 2012-04-03 18:18:46 --> Total execution time: 0.0493
DEBUG - 2012-04-03 18:23:39 --> Config Class Initialized
DEBUG - 2012-04-03 18:23:39 --> Hooks Class Initialized
DEBUG - 2012-04-03 18:23:39 --> Utf8 Class Initialized
DEBUG - 2012-04-03 18:23:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 18:23:39 --> URI Class Initialized
DEBUG - 2012-04-03 18:23:39 --> Router Class Initialized
DEBUG - 2012-04-03 18:23:39 --> No URI present. Default controller set.
DEBUG - 2012-04-03 18:23:39 --> Output Class Initialized
DEBUG - 2012-04-03 18:23:39 --> Security Class Initialized
DEBUG - 2012-04-03 18:23:39 --> Input Class Initialized
DEBUG - 2012-04-03 18:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 18:23:39 --> Language Class Initialized
DEBUG - 2012-04-03 18:23:39 --> Loader Class Initialized
DEBUG - 2012-04-03 18:23:39 --> Controller Class Initialized
DEBUG - 2012-04-03 18:23:39 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 18:23:39 --> Final output sent to browser
DEBUG - 2012-04-03 18:23:39 --> Total execution time: 0.0475
DEBUG - 2012-04-03 18:23:43 --> Config Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Hooks Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Utf8 Class Initialized
DEBUG - 2012-04-03 18:23:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 18:23:43 --> URI Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Router Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Output Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Security Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Input Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 18:23:43 --> Language Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Loader Class Initialized
DEBUG - 2012-04-03 18:23:43 --> Controller Class Initialized
ERROR - 2012-04-03 18:23:43 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
ERROR - 2012-04-03 18:23:43 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
DEBUG - 2012-04-03 18:23:43 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 18:23:43 --> Final output sent to browser
DEBUG - 2012-04-03 18:23:43 --> Total execution time: 0.0470
DEBUG - 2012-04-03 18:23:53 --> Config Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Hooks Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Utf8 Class Initialized
DEBUG - 2012-04-03 18:23:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 18:23:53 --> URI Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Router Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Output Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Security Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Input Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 18:23:53 --> Language Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Loader Class Initialized
DEBUG - 2012-04-03 18:23:53 --> Controller Class Initialized
ERROR - 2012-04-03 18:23:54 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
ERROR - 2012-04-03 18:23:54 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
DEBUG - 2012-04-03 18:23:54 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 18:23:54 --> Final output sent to browser
DEBUG - 2012-04-03 18:23:54 --> Total execution time: 0.0505
DEBUG - 2012-04-03 18:24:01 --> Config Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Hooks Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Utf8 Class Initialized
DEBUG - 2012-04-03 18:24:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 18:24:01 --> URI Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Router Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Output Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Security Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Input Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 18:24:01 --> Language Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Loader Class Initialized
DEBUG - 2012-04-03 18:24:01 --> Controller Class Initialized
ERROR - 2012-04-03 18:24:01 --> 404 Page Not Found --> accounts/index
DEBUG - 2012-04-03 18:24:13 --> Config Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Hooks Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Utf8 Class Initialized
DEBUG - 2012-04-03 18:24:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 18:24:13 --> URI Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Router Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Output Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Security Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Input Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 18:24:13 --> Language Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Loader Class Initialized
DEBUG - 2012-04-03 18:24:13 --> Controller Class Initialized
ERROR - 2012-04-03 18:24:13 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
ERROR - 2012-04-03 18:24:13 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
DEBUG - 2012-04-03 18:24:13 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 18:24:13 --> Final output sent to browser
DEBUG - 2012-04-03 18:24:13 --> Total execution time: 0.0469
DEBUG - 2012-04-03 18:24:17 --> Config Class Initialized
DEBUG - 2012-04-03 18:24:17 --> Hooks Class Initialized
DEBUG - 2012-04-03 18:24:17 --> Utf8 Class Initialized
DEBUG - 2012-04-03 18:24:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 18:24:17 --> URI Class Initialized
DEBUG - 2012-04-03 18:24:17 --> Router Class Initialized
DEBUG - 2012-04-03 18:24:17 --> No URI present. Default controller set.
DEBUG - 2012-04-03 18:24:17 --> Output Class Initialized
DEBUG - 2012-04-03 18:24:17 --> Security Class Initialized
DEBUG - 2012-04-03 18:24:17 --> Input Class Initialized
DEBUG - 2012-04-03 18:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 18:24:17 --> Language Class Initialized
DEBUG - 2012-04-03 18:24:17 --> Loader Class Initialized
DEBUG - 2012-04-03 18:24:17 --> Controller Class Initialized
DEBUG - 2012-04-03 18:24:17 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 18:24:17 --> Final output sent to browser
DEBUG - 2012-04-03 18:24:17 --> Total execution time: 0.0411
DEBUG - 2012-04-03 20:00:11 --> Config Class Initialized
DEBUG - 2012-04-03 20:00:11 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:00:11 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:00:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:00:11 --> URI Class Initialized
DEBUG - 2012-04-03 20:00:11 --> Router Class Initialized
DEBUG - 2012-04-03 20:00:11 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:00:11 --> Output Class Initialized
DEBUG - 2012-04-03 20:00:11 --> Security Class Initialized
DEBUG - 2012-04-03 20:00:11 --> Input Class Initialized
DEBUG - 2012-04-03 20:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:00:11 --> Language Class Initialized
DEBUG - 2012-04-03 20:00:11 --> Loader Class Initialized
DEBUG - 2012-04-03 20:00:11 --> Controller Class Initialized
DEBUG - 2012-04-03 20:00:11 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:00:11 --> Final output sent to browser
DEBUG - 2012-04-03 20:00:11 --> Total execution time: 0.0444
DEBUG - 2012-04-03 20:00:14 --> Config Class Initialized
DEBUG - 2012-04-03 20:00:14 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:00:14 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:00:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:00:14 --> URI Class Initialized
DEBUG - 2012-04-03 20:00:14 --> Router Class Initialized
ERROR - 2012-04-03 20:00:14 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:00:20 --> Config Class Initialized
DEBUG - 2012-04-03 20:00:20 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:00:20 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:00:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:00:20 --> URI Class Initialized
DEBUG - 2012-04-03 20:00:20 --> Router Class Initialized
ERROR - 2012-04-03 20:00:20 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:00:28 --> Config Class Initialized
DEBUG - 2012-04-03 20:00:28 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:00:28 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:00:28 --> URI Class Initialized
DEBUG - 2012-04-03 20:00:28 --> Router Class Initialized
ERROR - 2012-04-03 20:00:28 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:00:31 --> Config Class Initialized
DEBUG - 2012-04-03 20:00:31 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:00:31 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:00:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:00:31 --> URI Class Initialized
DEBUG - 2012-04-03 20:00:31 --> Router Class Initialized
ERROR - 2012-04-03 20:00:31 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:00:38 --> Config Class Initialized
DEBUG - 2012-04-03 20:00:38 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:00:38 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:00:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:00:38 --> URI Class Initialized
DEBUG - 2012-04-03 20:00:38 --> Router Class Initialized
ERROR - 2012-04-03 20:00:38 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:00:48 --> Config Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:00:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:00:48 --> URI Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Router Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Output Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Security Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Input Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:00:48 --> Language Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Loader Class Initialized
DEBUG - 2012-04-03 20:00:48 --> Controller Class Initialized
ERROR - 2012-04-03 20:00:48 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
ERROR - 2012-04-03 20:00:48 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
DEBUG - 2012-04-03 20:00:48 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:00:48 --> Final output sent to browser
DEBUG - 2012-04-03 20:00:48 --> Total execution time: 0.0489
DEBUG - 2012-04-03 20:05:49 --> Config Class Initialized
DEBUG - 2012-04-03 20:05:49 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:05:49 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:05:49 --> URI Class Initialized
DEBUG - 2012-04-03 20:05:49 --> Router Class Initialized
DEBUG - 2012-04-03 20:05:49 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:05:49 --> Output Class Initialized
DEBUG - 2012-04-03 20:05:49 --> Security Class Initialized
DEBUG - 2012-04-03 20:05:49 --> Input Class Initialized
DEBUG - 2012-04-03 20:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:05:49 --> Language Class Initialized
DEBUG - 2012-04-03 20:05:49 --> Loader Class Initialized
DEBUG - 2012-04-03 20:05:49 --> Controller Class Initialized
DEBUG - 2012-04-03 20:05:49 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:05:49 --> Final output sent to browser
DEBUG - 2012-04-03 20:05:49 --> Total execution time: 0.0707
DEBUG - 2012-04-03 20:05:53 --> Config Class Initialized
DEBUG - 2012-04-03 20:05:53 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:05:53 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:05:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:05:53 --> URI Class Initialized
DEBUG - 2012-04-03 20:05:53 --> Router Class Initialized
ERROR - 2012-04-03 20:05:53 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:06:04 --> Config Class Initialized
DEBUG - 2012-04-03 20:06:04 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:06:04 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:06:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:06:04 --> URI Class Initialized
DEBUG - 2012-04-03 20:06:04 --> Router Class Initialized
DEBUG - 2012-04-03 20:06:04 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:06:04 --> Output Class Initialized
DEBUG - 2012-04-03 20:06:04 --> Security Class Initialized
DEBUG - 2012-04-03 20:06:04 --> Input Class Initialized
DEBUG - 2012-04-03 20:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:06:04 --> Language Class Initialized
DEBUG - 2012-04-03 20:06:04 --> Loader Class Initialized
DEBUG - 2012-04-03 20:06:04 --> Controller Class Initialized
DEBUG - 2012-04-03 20:06:04 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:06:04 --> Final output sent to browser
DEBUG - 2012-04-03 20:06:04 --> Total execution time: 0.0486
DEBUG - 2012-04-03 20:06:07 --> Config Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:06:07 --> URI Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Router Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Output Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Security Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Input Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:06:07 --> Language Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Loader Class Initialized
DEBUG - 2012-04-03 20:06:07 --> Controller Class Initialized
ERROR - 2012-04-03 20:06:08 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
ERROR - 2012-04-03 20:06:08 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\XCMS\system\controllers\accounts.php 43
DEBUG - 2012-04-03 20:06:08 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:06:08 --> Final output sent to browser
DEBUG - 2012-04-03 20:06:08 --> Total execution time: 0.0534
DEBUG - 2012-04-03 20:11:03 --> Config Class Initialized
DEBUG - 2012-04-03 20:11:03 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:11:03 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:11:03 --> URI Class Initialized
DEBUG - 2012-04-03 20:11:03 --> Router Class Initialized
ERROR - 2012-04-03 20:11:03 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:11:12 --> Config Class Initialized
DEBUG - 2012-04-03 20:11:12 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:11:12 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:11:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:11:12 --> URI Class Initialized
DEBUG - 2012-04-03 20:11:12 --> Router Class Initialized
DEBUG - 2012-04-03 20:11:12 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:11:12 --> Output Class Initialized
DEBUG - 2012-04-03 20:11:12 --> Security Class Initialized
DEBUG - 2012-04-03 20:11:12 --> Input Class Initialized
DEBUG - 2012-04-03 20:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:11:12 --> Language Class Initialized
DEBUG - 2012-04-03 20:11:12 --> Loader Class Initialized
DEBUG - 2012-04-03 20:11:12 --> Controller Class Initialized
DEBUG - 2012-04-03 20:11:12 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:11:12 --> Final output sent to browser
DEBUG - 2012-04-03 20:11:12 --> Total execution time: 0.0420
DEBUG - 2012-04-03 20:11:18 --> Config Class Initialized
DEBUG - 2012-04-03 20:11:18 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:11:18 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:11:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:11:18 --> URI Class Initialized
DEBUG - 2012-04-03 20:11:18 --> Router Class Initialized
ERROR - 2012-04-03 20:11:18 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:11:44 --> Config Class Initialized
DEBUG - 2012-04-03 20:11:44 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:11:44 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:11:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:11:44 --> URI Class Initialized
DEBUG - 2012-04-03 20:11:44 --> Router Class Initialized
DEBUG - 2012-04-03 20:11:44 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:11:44 --> Output Class Initialized
DEBUG - 2012-04-03 20:11:44 --> Security Class Initialized
DEBUG - 2012-04-03 20:11:44 --> Input Class Initialized
DEBUG - 2012-04-03 20:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:11:44 --> Language Class Initialized
DEBUG - 2012-04-03 20:11:44 --> Loader Class Initialized
DEBUG - 2012-04-03 20:11:44 --> Controller Class Initialized
DEBUG - 2012-04-03 20:11:44 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:11:44 --> Final output sent to browser
DEBUG - 2012-04-03 20:11:44 --> Total execution time: 0.0424
DEBUG - 2012-04-03 20:11:48 --> Config Class Initialized
DEBUG - 2012-04-03 20:11:48 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:11:48 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:11:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:11:48 --> URI Class Initialized
DEBUG - 2012-04-03 20:11:48 --> Router Class Initialized
ERROR - 2012-04-03 20:11:48 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:12:30 --> Config Class Initialized
DEBUG - 2012-04-03 20:12:30 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:12:30 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:12:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:12:30 --> URI Class Initialized
DEBUG - 2012-04-03 20:12:30 --> Router Class Initialized
ERROR - 2012-04-03 20:12:30 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:12:33 --> Config Class Initialized
DEBUG - 2012-04-03 20:12:33 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:12:33 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:12:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:12:33 --> URI Class Initialized
DEBUG - 2012-04-03 20:12:33 --> Router Class Initialized
DEBUG - 2012-04-03 20:12:33 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:12:33 --> Output Class Initialized
DEBUG - 2012-04-03 20:12:33 --> Security Class Initialized
DEBUG - 2012-04-03 20:12:33 --> Input Class Initialized
DEBUG - 2012-04-03 20:12:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:12:33 --> Language Class Initialized
DEBUG - 2012-04-03 20:12:33 --> Loader Class Initialized
DEBUG - 2012-04-03 20:12:33 --> Controller Class Initialized
DEBUG - 2012-04-03 20:12:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:12:33 --> Final output sent to browser
DEBUG - 2012-04-03 20:12:33 --> Total execution time: 0.0472
DEBUG - 2012-04-03 20:13:51 --> Config Class Initialized
DEBUG - 2012-04-03 20:13:51 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:13:51 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:13:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:13:51 --> URI Class Initialized
DEBUG - 2012-04-03 20:13:51 --> Router Class Initialized
ERROR - 2012-04-03 20:13:51 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-03 20:14:18 --> Config Class Initialized
DEBUG - 2012-04-03 20:14:18 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:14:18 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:14:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:14:18 --> URI Class Initialized
DEBUG - 2012-04-03 20:14:18 --> Router Class Initialized
DEBUG - 2012-04-03 20:14:18 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:14:18 --> Output Class Initialized
DEBUG - 2012-04-03 20:14:18 --> Security Class Initialized
DEBUG - 2012-04-03 20:14:18 --> Input Class Initialized
DEBUG - 2012-04-03 20:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:14:18 --> Language Class Initialized
DEBUG - 2012-04-03 20:14:18 --> Loader Class Initialized
DEBUG - 2012-04-03 20:14:18 --> Controller Class Initialized
DEBUG - 2012-04-03 20:14:18 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:14:18 --> Final output sent to browser
DEBUG - 2012-04-03 20:14:18 --> Total execution time: 0.0576
DEBUG - 2012-04-03 20:14:23 --> Config Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:14:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:14:23 --> URI Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Router Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Output Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Security Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Input Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:14:23 --> Language Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Loader Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Controller Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Model Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Model Class Initialized
DEBUG - 2012-04-03 20:14:23 --> Database Driver Class Initialized
DEBUG - 2012-04-03 20:14:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:14:23 --> Final output sent to browser
DEBUG - 2012-04-03 20:14:23 --> Total execution time: 0.0630
DEBUG - 2012-04-03 20:14:29 --> Config Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:14:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:14:29 --> URI Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Router Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Output Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Security Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Input Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:14:29 --> Language Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Loader Class Initialized
DEBUG - 2012-04-03 20:14:29 --> Controller Class Initialized
ERROR - 2012-04-03 20:14:29 --> 404 Page Not Found --> accounts/index
DEBUG - 2012-04-03 20:14:46 --> Config Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:14:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:14:46 --> URI Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Router Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Output Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Security Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Input Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:14:46 --> Language Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Loader Class Initialized
DEBUG - 2012-04-03 20:14:46 --> Controller Class Initialized
ERROR - 2012-04-03 20:14:46 --> 404 Page Not Found --> accounts/index
DEBUG - 2012-04-03 20:14:49 --> Config Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:14:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:14:49 --> URI Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Router Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Output Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Security Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Input Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:14:49 --> Language Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Loader Class Initialized
DEBUG - 2012-04-03 20:14:49 --> Controller Class Initialized
ERROR - 2012-04-03 20:14:49 --> 404 Page Not Found --> accounts/index
DEBUG - 2012-04-03 20:14:58 --> Config Class Initialized
DEBUG - 2012-04-03 20:14:58 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:14:58 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:14:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:14:58 --> URI Class Initialized
DEBUG - 2012-04-03 20:14:58 --> Router Class Initialized
DEBUG - 2012-04-03 20:14:58 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:14:58 --> Output Class Initialized
DEBUG - 2012-04-03 20:14:58 --> Security Class Initialized
DEBUG - 2012-04-03 20:14:58 --> Input Class Initialized
DEBUG - 2012-04-03 20:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:14:58 --> Language Class Initialized
DEBUG - 2012-04-03 20:14:58 --> Loader Class Initialized
DEBUG - 2012-04-03 20:14:58 --> Controller Class Initialized
DEBUG - 2012-04-03 20:14:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:14:58 --> Final output sent to browser
DEBUG - 2012-04-03 20:14:58 --> Total execution time: 0.0434
DEBUG - 2012-04-03 20:15:06 --> Config Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:15:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:15:06 --> URI Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Router Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Output Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Security Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Input Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:15:06 --> Language Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Loader Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Controller Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Model Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Model Class Initialized
DEBUG - 2012-04-03 20:15:06 --> Database Driver Class Initialized
DEBUG - 2012-04-03 20:15:06 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:15:06 --> Final output sent to browser
DEBUG - 2012-04-03 20:15:06 --> Total execution time: 0.0629
DEBUG - 2012-04-03 20:15:09 --> Config Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:15:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:15:09 --> URI Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Router Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Output Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Security Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Input Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:15:09 --> Language Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Loader Class Initialized
DEBUG - 2012-04-03 20:15:09 --> Controller Class Initialized
ERROR - 2012-04-03 20:15:09 --> 404 Page Not Found --> accounts/index
DEBUG - 2012-04-03 20:27:02 --> Config Class Initialized
DEBUG - 2012-04-03 20:27:02 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:27:02 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:27:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:27:02 --> URI Class Initialized
DEBUG - 2012-04-03 20:27:02 --> Router Class Initialized
DEBUG - 2012-04-03 20:27:02 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:27:02 --> Output Class Initialized
DEBUG - 2012-04-03 20:27:02 --> Security Class Initialized
DEBUG - 2012-04-03 20:27:02 --> Input Class Initialized
DEBUG - 2012-04-03 20:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:27:02 --> Language Class Initialized
DEBUG - 2012-04-03 20:27:02 --> Loader Class Initialized
DEBUG - 2012-04-03 20:27:02 --> Controller Class Initialized
DEBUG - 2012-04-03 20:27:02 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:27:02 --> Final output sent to browser
DEBUG - 2012-04-03 20:27:02 --> Total execution time: 0.0513
DEBUG - 2012-04-03 20:27:09 --> Config Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:27:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:27:09 --> URI Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Router Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Output Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Security Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Input Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:27:09 --> Language Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Loader Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Controller Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Model Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Model Class Initialized
DEBUG - 2012-04-03 20:27:09 --> Database Driver Class Initialized
DEBUG - 2012-04-03 20:27:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:27:09 --> Final output sent to browser
DEBUG - 2012-04-03 20:27:09 --> Total execution time: 0.0654
DEBUG - 2012-04-03 20:27:15 --> Config Class Initialized
DEBUG - 2012-04-03 20:27:15 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:27:15 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:27:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:27:15 --> URI Class Initialized
DEBUG - 2012-04-03 20:27:15 --> Router Class Initialized
DEBUG - 2012-04-03 20:27:15 --> No URI present. Default controller set.
DEBUG - 2012-04-03 20:27:15 --> Output Class Initialized
DEBUG - 2012-04-03 20:27:15 --> Security Class Initialized
DEBUG - 2012-04-03 20:27:15 --> Input Class Initialized
DEBUG - 2012-04-03 20:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:27:15 --> Language Class Initialized
DEBUG - 2012-04-03 20:27:15 --> Loader Class Initialized
DEBUG - 2012-04-03 20:27:15 --> Controller Class Initialized
DEBUG - 2012-04-03 20:27:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:27:15 --> Final output sent to browser
DEBUG - 2012-04-03 20:27:15 --> Total execution time: 0.0463
DEBUG - 2012-04-03 20:27:23 --> Config Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Hooks Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Utf8 Class Initialized
DEBUG - 2012-04-03 20:27:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-03 20:27:23 --> URI Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Router Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Output Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Security Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Input Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-03 20:27:23 --> Language Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Loader Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Controller Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Model Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Model Class Initialized
DEBUG - 2012-04-03 20:27:23 --> Database Driver Class Initialized
DEBUG - 2012-04-03 20:27:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-03 20:27:23 --> Final output sent to browser
DEBUG - 2012-04-03 20:27:23 --> Total execution time: 0.0616
