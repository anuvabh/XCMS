<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-21 17:13:29 --> Config Class Initialized
DEBUG - 2012-04-21 17:13:29 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:13:29 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:13:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:13:29 --> URI Class Initialized
DEBUG - 2012-04-21 17:13:29 --> Router Class Initialized
DEBUG - 2012-04-21 17:13:30 --> No URI present. Default controller set.
DEBUG - 2012-04-21 17:13:30 --> Output Class Initialized
DEBUG - 2012-04-21 17:13:30 --> Security Class Initialized
DEBUG - 2012-04-21 17:13:30 --> Input Class Initialized
DEBUG - 2012-04-21 17:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:13:30 --> Language Class Initialized
DEBUG - 2012-04-21 17:13:30 --> Loader Class Initialized
DEBUG - 2012-04-21 17:13:30 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:13:30 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:13:31 --> Session Class Initialized
DEBUG - 2012-04-21 17:13:31 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:13:31 --> A session cookie was not found.
DEBUG - 2012-04-21 17:13:31 --> Session routines successfully run
DEBUG - 2012-04-21 17:13:31 --> Controller Class Initialized
DEBUG - 2012-04-21 17:13:31 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-21 17:13:31 --> Final output sent to browser
DEBUG - 2012-04-21 17:13:31 --> Total execution time: 1.4536
DEBUG - 2012-04-21 17:14:16 --> Config Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:14:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:14:16 --> URI Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Router Class Initialized
DEBUG - 2012-04-21 17:14:16 --> No URI present. Default controller set.
DEBUG - 2012-04-21 17:14:16 --> Output Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Security Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Input Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:14:16 --> Language Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Loader Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:14:16 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Session Class Initialized
DEBUG - 2012-04-21 17:14:16 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:14:16 --> A session cookie was not found.
DEBUG - 2012-04-21 17:14:16 --> Session routines successfully run
DEBUG - 2012-04-21 17:14:16 --> Controller Class Initialized
DEBUG - 2012-04-21 17:14:16 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-21 17:14:16 --> Final output sent to browser
DEBUG - 2012-04-21 17:14:16 --> Total execution time: 0.0578
DEBUG - 2012-04-21 17:16:23 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:23 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:23 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:23 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:23 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:23 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Model Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Model Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:23 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:23 --> No URI present. Default controller set.
DEBUG - 2012-04-21 17:16:23 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:23 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:24 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:24 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:24 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:24 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:24 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:24 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:24 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:24 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-21 17:16:24 --> File loaded: system/views/links.php
DEBUG - 2012-04-21 17:16:24 --> Final output sent to browser
DEBUG - 2012-04-21 17:16:24 --> Total execution time: 0.0571
DEBUG - 2012-04-21 17:16:29 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:29 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:29 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:29 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:29 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:29 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:29 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:29 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:30 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:30 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:30 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:30 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:30 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:30 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-21 17:16:30 --> File loaded: system/views/links.php
DEBUG - 2012-04-21 17:16:30 --> Final output sent to browser
DEBUG - 2012-04-21 17:16:30 --> Total execution time: 0.0441
DEBUG - 2012-04-21 17:16:33 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:33 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:33 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:33 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:33 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:33 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:33 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:33 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:33 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:33 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:33 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:33 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:33 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-21 17:16:33 --> File loaded: system/views/links.php
DEBUG - 2012-04-21 17:16:33 --> Final output sent to browser
DEBUG - 2012-04-21 17:16:33 --> Total execution time: 0.0436
DEBUG - 2012-04-21 17:16:34 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:34 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:34 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:35 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:35 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:35 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:35 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:35 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:35 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:35 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:35 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:35 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:35 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Model Class Initialized
DEBUG - 2012-04-21 17:16:35 --> Model Class Initialized
DEBUG - 2012-04-21 17:16:35 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-21 17:16:35 --> Final output sent to browser
DEBUG - 2012-04-21 17:16:35 --> Total execution time: 0.2682
DEBUG - 2012-04-21 17:16:38 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:38 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:38 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:38 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:38 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:38 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:38 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:38 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:38 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:38 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:38 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:38 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:38 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-21 17:16:38 --> File loaded: system/views/links.php
DEBUG - 2012-04-21 17:16:38 --> Final output sent to browser
DEBUG - 2012-04-21 17:16:38 --> Total execution time: 0.0457
DEBUG - 2012-04-21 17:16:40 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:40 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:40 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:40 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:40 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:40 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Model Class Initialized
DEBUG - 2012-04-21 17:16:40 --> Model Class Initialized
DEBUG - 2012-04-21 17:16:40 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-21 17:16:40 --> Final output sent to browser
DEBUG - 2012-04-21 17:16:40 --> Total execution time: 0.1528
DEBUG - 2012-04-21 17:16:44 --> Config Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:16:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:16:44 --> URI Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Router Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Output Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Security Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Input Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:16:44 --> Language Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Loader Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:16:44 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Session Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:16:44 --> Session routines successfully run
DEBUG - 2012-04-21 17:16:44 --> Controller Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Model Class Initialized
DEBUG - 2012-04-21 17:16:44 --> Model Class Initialized
DEBUG - 2012-04-21 17:16:44 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-21 17:16:44 --> Final output sent to browser
DEBUG - 2012-04-21 17:16:44 --> Total execution time: 0.0772
DEBUG - 2012-04-21 17:17:38 --> Config Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:17:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:17:38 --> URI Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Router Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Output Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Security Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Input Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:17:38 --> Language Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Loader Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:17:38 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Session Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:17:38 --> Session routines successfully run
DEBUG - 2012-04-21 17:17:38 --> Controller Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Config Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Hooks Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Utf8 Class Initialized
DEBUG - 2012-04-21 17:17:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-21 17:17:38 --> URI Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Router Class Initialized
DEBUG - 2012-04-21 17:17:38 --> No URI present. Default controller set.
DEBUG - 2012-04-21 17:17:38 --> Output Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Security Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Input Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-21 17:17:38 --> Language Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Loader Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Helper loaded: url_helper
DEBUG - 2012-04-21 17:17:38 --> Database Driver Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Session Class Initialized
DEBUG - 2012-04-21 17:17:38 --> Helper loaded: string_helper
DEBUG - 2012-04-21 17:17:38 --> A session cookie was not found.
DEBUG - 2012-04-21 17:17:38 --> Session routines successfully run
DEBUG - 2012-04-21 17:17:38 --> Controller Class Initialized
DEBUG - 2012-04-21 17:17:38 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-21 17:17:38 --> Final output sent to browser
DEBUG - 2012-04-21 17:17:38 --> Total execution time: 0.0533
