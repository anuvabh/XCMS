<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-06 16:26:01 --> Config Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:26:01 --> URI Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Router Class Initialized
DEBUG - 2012-04-06 16:26:01 --> No URI present. Default controller set.
DEBUG - 2012-04-06 16:26:01 --> Output Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Security Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Input Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:26:01 --> Language Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Loader Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:26:01 --> Database Driver Class Initialized
ERROR - 2012-04-06 16:26:01 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-06 16:26:01 --> Session Class Initialized
DEBUG - 2012-04-06 16:26:01 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:26:01 --> Session routines successfully run
DEBUG - 2012-04-06 16:26:01 --> Controller Class Initialized
DEBUG - 2012-04-06 16:26:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-06 16:26:01 --> Final output sent to browser
DEBUG - 2012-04-06 16:26:01 --> Total execution time: 0.0841
DEBUG - 2012-04-06 16:26:04 --> Config Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:26:04 --> URI Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Router Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Output Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Security Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Input Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:26:04 --> Language Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Loader Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:26:04 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Session Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:26:04 --> Session routines successfully run
DEBUG - 2012-04-06 16:26:04 --> Controller Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Model Class Initialized
DEBUG - 2012-04-06 16:26:04 --> Model Class Initialized
DEBUG - 2012-04-06 16:26:04 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:26:04 --> Final output sent to browser
DEBUG - 2012-04-06 16:26:04 --> Total execution time: 0.0960
DEBUG - 2012-04-06 16:26:25 --> Config Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:26:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:26:25 --> URI Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Router Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Output Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Security Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Input Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:26:25 --> Language Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Loader Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:26:25 --> Database Driver Class Initialized
ERROR - 2012-04-06 16:26:25 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-06 16:26:25 --> Session Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:26:25 --> Session routines successfully run
DEBUG - 2012-04-06 16:26:25 --> Controller Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Model Class Initialized
DEBUG - 2012-04-06 16:26:25 --> Model Class Initialized
DEBUG - 2012-04-06 16:26:25 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:26:25 --> Final output sent to browser
DEBUG - 2012-04-06 16:26:25 --> Total execution time: 0.0840
DEBUG - 2012-04-06 16:26:48 --> Config Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:26:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:26:48 --> URI Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Router Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Output Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Security Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Input Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:26:48 --> Language Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Loader Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:26:48 --> Database Driver Class Initialized
ERROR - 2012-04-06 16:26:48 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-06 16:26:48 --> Session Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:26:48 --> Session routines successfully run
DEBUG - 2012-04-06 16:26:48 --> Controller Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Model Class Initialized
DEBUG - 2012-04-06 16:26:48 --> Model Class Initialized
DEBUG - 2012-04-06 16:26:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:26:48 --> Final output sent to browser
DEBUG - 2012-04-06 16:26:48 --> Total execution time: 0.1034
DEBUG - 2012-04-06 16:44:34 --> Config Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:44:34 --> URI Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Router Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Output Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Security Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Input Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:44:34 --> Language Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Loader Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:44:34 --> Database Driver Class Initialized
ERROR - 2012-04-06 16:44:34 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-06 16:44:34 --> Session Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:44:34 --> Session routines successfully run
DEBUG - 2012-04-06 16:44:34 --> Controller Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:34 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:34 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:44:34 --> Final output sent to browser
DEBUG - 2012-04-06 16:44:34 --> Total execution time: 0.0716
DEBUG - 2012-04-06 16:44:37 --> Config Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:44:37 --> URI Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Router Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Output Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Security Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Input Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:44:37 --> Language Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Loader Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:44:37 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Session Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:44:37 --> Session routines successfully run
DEBUG - 2012-04-06 16:44:37 --> Controller Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:37 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:37 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:44:37 --> Final output sent to browser
DEBUG - 2012-04-06 16:44:37 --> Total execution time: 0.0544
DEBUG - 2012-04-06 16:44:38 --> Config Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:44:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:44:38 --> URI Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Router Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Output Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Security Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Input Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:44:38 --> Language Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Loader Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:44:38 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Session Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:44:38 --> Session routines successfully run
DEBUG - 2012-04-06 16:44:38 --> Controller Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:38 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:38 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:44:38 --> Final output sent to browser
DEBUG - 2012-04-06 16:44:38 --> Total execution time: 0.0546
DEBUG - 2012-04-06 16:44:45 --> Config Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:44:45 --> URI Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Router Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Output Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Security Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Input Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:44:45 --> Language Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Loader Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:44:45 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Session Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:44:45 --> Session routines successfully run
DEBUG - 2012-04-06 16:44:45 --> Controller Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:45 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:45 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:44:45 --> Final output sent to browser
DEBUG - 2012-04-06 16:44:45 --> Total execution time: 0.0730
DEBUG - 2012-04-06 16:44:46 --> Config Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:44:46 --> URI Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Router Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Output Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Security Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Input Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:44:46 --> Language Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Loader Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:44:46 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Session Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:44:46 --> Session routines successfully run
DEBUG - 2012-04-06 16:44:46 --> Controller Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:46 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:46 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:44:46 --> Final output sent to browser
DEBUG - 2012-04-06 16:44:46 --> Total execution time: 0.0545
DEBUG - 2012-04-06 16:44:59 --> Config Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:44:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:44:59 --> URI Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Router Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Output Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Security Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Input Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:44:59 --> Language Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Loader Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:44:59 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Session Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:44:59 --> Session routines successfully run
DEBUG - 2012-04-06 16:44:59 --> Controller Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Model Class Initialized
DEBUG - 2012-04-06 16:44:59 --> Helper loaded: email_helper
DEBUG - 2012-04-06 16:44:59 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:44:59 --> Final output sent to browser
DEBUG - 2012-04-06 16:44:59 --> Total execution time: 0.0708
DEBUG - 2012-04-06 16:56:42 --> Config Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:56:42 --> URI Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Router Class Initialized
DEBUG - 2012-04-06 16:56:42 --> No URI present. Default controller set.
DEBUG - 2012-04-06 16:56:42 --> Output Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Security Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Input Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:56:42 --> Language Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Loader Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:56:42 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Session Class Initialized
DEBUG - 2012-04-06 16:56:42 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:56:42 --> Session routines successfully run
DEBUG - 2012-04-06 16:56:42 --> Controller Class Initialized
DEBUG - 2012-04-06 16:56:42 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-06 16:56:42 --> Final output sent to browser
DEBUG - 2012-04-06 16:56:42 --> Total execution time: 0.0583
DEBUG - 2012-04-06 16:56:44 --> Config Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:56:44 --> URI Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Router Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Output Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Security Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Input Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:56:44 --> Language Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Loader Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:56:44 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Session Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:56:44 --> Session routines successfully run
DEBUG - 2012-04-06 16:56:44 --> Controller Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Model Class Initialized
DEBUG - 2012-04-06 16:56:44 --> Model Class Initialized
DEBUG - 2012-04-06 16:56:44 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:56:44 --> Final output sent to browser
DEBUG - 2012-04-06 16:56:44 --> Total execution time: 0.0562
DEBUG - 2012-04-06 16:56:46 --> Config Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:56:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:56:46 --> URI Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Router Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Output Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Security Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Input Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:56:46 --> Language Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Loader Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:56:46 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Session Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:56:46 --> Session routines successfully run
DEBUG - 2012-04-06 16:56:46 --> Controller Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Model Class Initialized
DEBUG - 2012-04-06 16:56:46 --> Model Class Initialized
DEBUG - 2012-04-06 16:56:46 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:56:46 --> Final output sent to browser
DEBUG - 2012-04-06 16:56:46 --> Total execution time: 0.0568
DEBUG - 2012-04-06 16:56:56 --> Config Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:56:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:56:56 --> URI Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Router Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Output Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Security Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Input Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:56:56 --> Language Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Loader Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:56:56 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Session Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:56:56 --> Session routines successfully run
DEBUG - 2012-04-06 16:56:56 --> Controller Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Model Class Initialized
DEBUG - 2012-04-06 16:56:56 --> Model Class Initialized
DEBUG - 2012-04-06 16:56:56 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:56:56 --> Final output sent to browser
DEBUG - 2012-04-06 16:56:56 --> Total execution time: 0.0924
DEBUG - 2012-04-06 16:56:58 --> Config Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:56:58 --> URI Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Router Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Output Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Security Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Input Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:56:58 --> Language Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Loader Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:56:58 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Session Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:56:58 --> Session routines successfully run
DEBUG - 2012-04-06 16:56:58 --> Controller Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Model Class Initialized
DEBUG - 2012-04-06 16:56:58 --> Model Class Initialized
DEBUG - 2012-04-06 16:56:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:56:58 --> Final output sent to browser
DEBUG - 2012-04-06 16:56:58 --> Total execution time: 0.0620
DEBUG - 2012-04-06 16:57:12 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:12 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:12 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:12 --> Database Driver Class Initialized
ERROR - 2012-04-06 16:57:12 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-06 16:57:12 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:12 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:12 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Model Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Model Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:12 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:12 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:12 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:12 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:12 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:12 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:12 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-06 16:57:12 --> Final output sent to browser
DEBUG - 2012-04-06 16:57:12 --> Total execution time: 0.0525
DEBUG - 2012-04-06 16:57:17 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:17 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:17 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:18 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:18 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:18 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:18 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:18 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:18 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:18 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:18 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:18 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:18 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:18 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:18 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-06 16:57:18 --> Final output sent to browser
DEBUG - 2012-04-06 16:57:18 --> Total execution time: 0.0531
DEBUG - 2012-04-06 16:57:26 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:26 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:26 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:26 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:26 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:26 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Model Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Model Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:26 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:26 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:26 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:26 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:26 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:26 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:26 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-06 16:57:26 --> Final output sent to browser
DEBUG - 2012-04-06 16:57:26 --> Total execution time: 0.0558
DEBUG - 2012-04-06 16:57:30 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:30 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:30 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:30 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:30 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:30 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:30 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:30 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:30 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:30 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:30 --> A session cookie was not found.
DEBUG - 2012-04-06 16:57:30 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:30 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-06 16:57:30 --> Final output sent to browser
DEBUG - 2012-04-06 16:57:30 --> Total execution time: 0.0558
DEBUG - 2012-04-06 16:57:58 --> Config Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:57:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:57:58 --> URI Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Router Class Initialized
DEBUG - 2012-04-06 16:57:58 --> No URI present. Default controller set.
DEBUG - 2012-04-06 16:57:58 --> Output Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Security Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Input Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:57:58 --> Language Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Loader Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:57:58 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Session Class Initialized
DEBUG - 2012-04-06 16:57:58 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:57:58 --> A session cookie was not found.
DEBUG - 2012-04-06 16:57:58 --> Session routines successfully run
DEBUG - 2012-04-06 16:57:58 --> Controller Class Initialized
DEBUG - 2012-04-06 16:57:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-06 16:57:58 --> Final output sent to browser
DEBUG - 2012-04-06 16:57:58 --> Total execution time: 0.0580
DEBUG - 2012-04-06 16:58:09 --> Config Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:58:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:58:09 --> URI Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Router Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Output Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Security Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Input Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:58:09 --> Language Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Loader Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:58:09 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Session Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:58:09 --> Session routines successfully run
DEBUG - 2012-04-06 16:58:09 --> Controller Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Model Class Initialized
DEBUG - 2012-04-06 16:58:09 --> Model Class Initialized
DEBUG - 2012-04-06 16:58:09 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:58:09 --> Final output sent to browser
DEBUG - 2012-04-06 16:58:09 --> Total execution time: 0.0620
DEBUG - 2012-04-06 16:59:13 --> Config Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Hooks Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Utf8 Class Initialized
DEBUG - 2012-04-06 16:59:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-06 16:59:13 --> URI Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Router Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Output Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Security Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Input Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-06 16:59:13 --> Language Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Loader Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Helper loaded: url_helper
DEBUG - 2012-04-06 16:59:13 --> Database Driver Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Session Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Helper loaded: string_helper
DEBUG - 2012-04-06 16:59:13 --> Session routines successfully run
DEBUG - 2012-04-06 16:59:13 --> Controller Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Model Class Initialized
DEBUG - 2012-04-06 16:59:13 --> Model Class Initialized
DEBUG - 2012-04-06 16:59:13 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-06 16:59:13 --> Final output sent to browser
DEBUG - 2012-04-06 16:59:13 --> Total execution time: 0.0726
