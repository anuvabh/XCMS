<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-01 07:01:33 --> Config Class Initialized
DEBUG - 2012-04-01 07:01:33 --> Hooks Class Initialized
DEBUG - 2012-04-01 07:01:33 --> Utf8 Class Initialized
DEBUG - 2012-04-01 07:01:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-01 07:01:34 --> URI Class Initialized
DEBUG - 2012-04-01 07:01:34 --> Router Class Initialized
DEBUG - 2012-04-01 07:01:34 --> No URI present. Default controller set.
DEBUG - 2012-04-01 07:01:34 --> Output Class Initialized
DEBUG - 2012-04-01 07:01:34 --> Security Class Initialized
DEBUG - 2012-04-01 07:01:34 --> Input Class Initialized
DEBUG - 2012-04-01 07:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-01 07:01:34 --> Language Class Initialized
DEBUG - 2012-04-01 07:01:34 --> Loader Class Initialized
DEBUG - 2012-04-01 07:01:34 --> Controller Class Initialized
DEBUG - 2012-04-01 07:01:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-01 07:01:34 --> Final output sent to browser
DEBUG - 2012-04-01 07:01:34 --> Total execution time: 0.7397
DEBUG - 2012-04-01 09:09:15 --> Config Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Hooks Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Utf8 Class Initialized
DEBUG - 2012-04-01 09:09:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-01 09:09:15 --> URI Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Router Class Initialized
DEBUG - 2012-04-01 09:09:15 --> No URI present. Default controller set.
DEBUG - 2012-04-01 09:09:15 --> Output Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Security Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Input Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-01 09:09:15 --> Language Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Loader Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Controller Class Initialized
DEBUG - 2012-04-01 09:09:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-01 09:09:15 --> Final output sent to browser
DEBUG - 2012-04-01 09:09:15 --> Total execution time: 0.0244
DEBUG - 2012-04-01 09:09:15 --> Config Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Hooks Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Utf8 Class Initialized
DEBUG - 2012-04-01 09:09:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-01 09:09:15 --> URI Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Router Class Initialized
DEBUG - 2012-04-01 09:09:15 --> No URI present. Default controller set.
DEBUG - 2012-04-01 09:09:15 --> Output Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Security Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Input Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-01 09:09:15 --> Language Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Loader Class Initialized
DEBUG - 2012-04-01 09:09:15 --> Controller Class Initialized
DEBUG - 2012-04-01 09:09:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-01 09:09:15 --> Final output sent to browser
DEBUG - 2012-04-01 09:09:15 --> Total execution time: 0.0327
DEBUG - 2012-04-01 09:09:17 --> Config Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Hooks Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Utf8 Class Initialized
DEBUG - 2012-04-01 09:09:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-01 09:09:17 --> URI Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Router Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Output Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Security Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Input Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-01 09:09:17 --> Language Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Loader Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Controller Class Initialized
DEBUG - 2012-04-01 09:09:17 --> Final output sent to browser
DEBUG - 2012-04-01 09:09:17 --> Total execution time: 0.0543
