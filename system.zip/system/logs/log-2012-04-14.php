<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-14 15:32:19 --> Config Class Initialized
DEBUG - 2012-04-14 15:32:19 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:32:19 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:32:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:32:19 --> URI Class Initialized
DEBUG - 2012-04-14 15:32:19 --> Router Class Initialized
DEBUG - 2012-04-14 15:32:19 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:32:19 --> Output Class Initialized
DEBUG - 2012-04-14 15:32:19 --> Security Class Initialized
DEBUG - 2012-04-14 15:32:19 --> Input Class Initialized
DEBUG - 2012-04-14 15:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:32:19 --> Language Class Initialized
DEBUG - 2012-04-14 15:32:19 --> Loader Class Initialized
DEBUG - 2012-04-14 15:32:19 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:32:19 --> Database Driver Class Initialized
ERROR - 2012-04-14 15:32:20 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-14 15:32:22 --> Session Class Initialized
DEBUG - 2012-04-14 15:32:22 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:32:22 --> Session routines successfully run
DEBUG - 2012-04-14 15:32:22 --> Controller Class Initialized
DEBUG - 2012-04-14 15:32:22 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-14 15:32:22 --> Final output sent to browser
DEBUG - 2012-04-14 15:32:22 --> Total execution time: 3.4348
DEBUG - 2012-04-14 15:32:31 --> Config Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:32:31 --> URI Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Router Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Output Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Security Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Input Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:32:31 --> Language Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Loader Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:32:31 --> Database Driver Class Initialized
ERROR - 2012-04-14 15:32:31 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-14 15:32:31 --> Session Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:32:31 --> Session routines successfully run
DEBUG - 2012-04-14 15:32:31 --> Controller Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Model Class Initialized
DEBUG - 2012-04-14 15:32:31 --> Model Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Config Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:32:33 --> URI Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Router Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Output Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Security Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Input Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:32:33 --> Language Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Loader Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:32:33 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Session Class Initialized
DEBUG - 2012-04-14 15:32:33 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:32:33 --> Session routines successfully run
DEBUG - 2012-04-14 15:32:33 --> Controller Class Initialized
DEBUG - 2012-04-14 15:32:33 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-14 15:32:33 --> File loaded: system/views/links.php
DEBUG - 2012-04-14 15:32:33 --> Final output sent to browser
DEBUG - 2012-04-14 15:32:33 --> Total execution time: 0.1719
DEBUG - 2012-04-14 15:33:32 --> Config Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:33:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:33:32 --> URI Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Router Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Output Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Security Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Input Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:33:32 --> Language Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Loader Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:33:32 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Session Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:33:32 --> Session routines successfully run
DEBUG - 2012-04-14 15:33:32 --> Controller Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Config Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:33:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:33:32 --> URI Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Router Class Initialized
DEBUG - 2012-04-14 15:33:32 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:33:32 --> Output Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Security Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Input Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:33:32 --> Language Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Loader Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:33:32 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Session Class Initialized
DEBUG - 2012-04-14 15:33:32 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:33:32 --> A session cookie was not found.
DEBUG - 2012-04-14 15:33:32 --> Session routines successfully run
DEBUG - 2012-04-14 15:33:32 --> Controller Class Initialized
DEBUG - 2012-04-14 15:33:32 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-14 15:33:32 --> Final output sent to browser
DEBUG - 2012-04-14 15:33:32 --> Total execution time: 0.0985
DEBUG - 2012-04-14 15:33:39 --> Config Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:33:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:33:39 --> URI Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Router Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Output Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Security Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Input Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:33:39 --> Language Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Loader Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:33:39 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Session Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:33:39 --> Session routines successfully run
DEBUG - 2012-04-14 15:33:39 --> Controller Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Model Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Model Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Config Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:33:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:33:39 --> URI Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Router Class Initialized
DEBUG - 2012-04-14 15:33:39 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:33:39 --> Output Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Security Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Input Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:33:39 --> Language Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Loader Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:33:39 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Session Class Initialized
DEBUG - 2012-04-14 15:33:39 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:33:39 --> Session routines successfully run
DEBUG - 2012-04-14 15:33:39 --> Controller Class Initialized
DEBUG - 2012-04-14 15:33:39 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-14 15:33:39 --> File loaded: system/views/links.php
DEBUG - 2012-04-14 15:33:39 --> Final output sent to browser
DEBUG - 2012-04-14 15:33:39 --> Total execution time: 0.0484
DEBUG - 2012-04-14 15:33:55 --> Config Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:33:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:33:55 --> URI Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Router Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Output Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Security Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Input Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:33:55 --> Language Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Loader Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:33:55 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Session Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:33:55 --> Session routines successfully run
DEBUG - 2012-04-14 15:33:55 --> Controller Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Config Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:33:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:33:55 --> URI Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Router Class Initialized
DEBUG - 2012-04-14 15:33:55 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:33:55 --> Output Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Security Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Input Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:33:55 --> Language Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Loader Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:33:55 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Session Class Initialized
DEBUG - 2012-04-14 15:33:55 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:33:55 --> A session cookie was not found.
DEBUG - 2012-04-14 15:33:55 --> Session routines successfully run
DEBUG - 2012-04-14 15:33:55 --> Controller Class Initialized
DEBUG - 2012-04-14 15:33:55 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-14 15:33:55 --> Final output sent to browser
DEBUG - 2012-04-14 15:33:55 --> Total execution time: 0.0633
DEBUG - 2012-04-14 15:34:06 --> Config Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:34:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:34:06 --> URI Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Router Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Output Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Security Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Input Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:34:06 --> Language Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Loader Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:34:06 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Session Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:34:06 --> Session routines successfully run
DEBUG - 2012-04-14 15:34:06 --> Controller Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Model Class Initialized
DEBUG - 2012-04-14 15:34:06 --> Model Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Config Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:34:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:34:07 --> URI Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Router Class Initialized
DEBUG - 2012-04-14 15:34:07 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:34:07 --> Output Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Security Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Input Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:34:07 --> Language Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Loader Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:34:07 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Session Class Initialized
DEBUG - 2012-04-14 15:34:07 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:34:07 --> Session routines successfully run
DEBUG - 2012-04-14 15:34:07 --> Controller Class Initialized
DEBUG - 2012-04-14 15:34:07 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-14 15:34:07 --> File loaded: system/views/links.php
DEBUG - 2012-04-14 15:34:07 --> Final output sent to browser
DEBUG - 2012-04-14 15:34:07 --> Total execution time: 0.0639
DEBUG - 2012-04-14 15:35:54 --> Config Class Initialized
DEBUG - 2012-04-14 15:35:54 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:35:54 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:35:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:35:54 --> URI Class Initialized
DEBUG - 2012-04-14 15:35:54 --> Router Class Initialized
DEBUG - 2012-04-14 15:35:54 --> Output Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Security Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Input Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:35:55 --> Language Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Loader Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:35:55 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Session Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:35:55 --> Session routines successfully run
DEBUG - 2012-04-14 15:35:55 --> Controller Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Config Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:35:55 --> URI Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Router Class Initialized
DEBUG - 2012-04-14 15:35:55 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:35:55 --> Output Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Security Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Input Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:35:55 --> Language Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Loader Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:35:55 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Session Class Initialized
DEBUG - 2012-04-14 15:35:55 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:35:55 --> A session cookie was not found.
DEBUG - 2012-04-14 15:35:55 --> Session routines successfully run
DEBUG - 2012-04-14 15:35:55 --> Controller Class Initialized
DEBUG - 2012-04-14 15:35:55 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-14 15:35:55 --> Final output sent to browser
DEBUG - 2012-04-14 15:35:55 --> Total execution time: 0.3363
DEBUG - 2012-04-14 15:35:58 --> Config Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:35:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:35:58 --> URI Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Router Class Initialized
DEBUG - 2012-04-14 15:35:58 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:35:58 --> Output Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Security Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Input Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:35:58 --> Language Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Loader Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:35:58 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Session Class Initialized
DEBUG - 2012-04-14 15:35:58 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:35:58 --> Session routines successfully run
DEBUG - 2012-04-14 15:35:58 --> Controller Class Initialized
DEBUG - 2012-04-14 15:35:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-14 15:35:58 --> Final output sent to browser
DEBUG - 2012-04-14 15:35:58 --> Total execution time: 0.1801
DEBUG - 2012-04-14 15:36:07 --> Config Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:36:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:36:07 --> URI Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Router Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Output Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Security Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Input Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:36:07 --> Language Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Loader Class Initialized
DEBUG - 2012-04-14 15:36:07 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:36:07 --> Database Driver Class Initialized
ERROR - 2012-04-14 15:36:07 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-14 15:36:08 --> Session Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:36:08 --> Session routines successfully run
DEBUG - 2012-04-14 15:36:08 --> Controller Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Model Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Model Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Config Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:36:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:36:08 --> URI Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Router Class Initialized
DEBUG - 2012-04-14 15:36:08 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:36:08 --> Output Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Security Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Input Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:36:08 --> Language Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Loader Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:36:08 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Session Class Initialized
DEBUG - 2012-04-14 15:36:08 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:36:08 --> Session routines successfully run
DEBUG - 2012-04-14 15:36:08 --> Controller Class Initialized
DEBUG - 2012-04-14 15:36:08 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-14 15:36:08 --> File loaded: system/views/links.php
DEBUG - 2012-04-14 15:36:08 --> Final output sent to browser
DEBUG - 2012-04-14 15:36:08 --> Total execution time: 0.1243
DEBUG - 2012-04-14 15:36:11 --> Config Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:36:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:36:11 --> URI Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Router Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Output Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Security Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Input Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:36:11 --> Language Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Loader Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:36:11 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Session Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:36:11 --> Session routines successfully run
DEBUG - 2012-04-14 15:36:11 --> Controller Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Config Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Hooks Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Utf8 Class Initialized
DEBUG - 2012-04-14 15:36:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-14 15:36:11 --> URI Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Router Class Initialized
DEBUG - 2012-04-14 15:36:11 --> No URI present. Default controller set.
DEBUG - 2012-04-14 15:36:11 --> Output Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Security Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Input Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-14 15:36:11 --> Language Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Loader Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Helper loaded: url_helper
DEBUG - 2012-04-14 15:36:11 --> Database Driver Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Session Class Initialized
DEBUG - 2012-04-14 15:36:11 --> Helper loaded: string_helper
DEBUG - 2012-04-14 15:36:11 --> A session cookie was not found.
DEBUG - 2012-04-14 15:36:11 --> Session routines successfully run
DEBUG - 2012-04-14 15:36:11 --> Controller Class Initialized
DEBUG - 2012-04-14 15:36:11 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-14 15:36:11 --> Final output sent to browser
DEBUG - 2012-04-14 15:36:11 --> Total execution time: 0.0737
