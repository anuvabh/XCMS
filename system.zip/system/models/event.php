<?php

class Event extends CI_Model
{
    
}