<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-03-31 07:20:19 --> Config Class Initialized
DEBUG - 2012-03-31 07:20:20 --> Hooks Class Initialized
DEBUG - 2012-03-31 07:20:20 --> Utf8 Class Initialized
DEBUG - 2012-03-31 07:20:20 --> UTF-8 Support Enabled
DEBUG - 2012-03-31 07:20:20 --> URI Class Initialized
DEBUG - 2012-03-31 07:20:20 --> Router Class Initialized
DEBUG - 2012-03-31 07:20:20 --> No URI present. Default controller set.
DEBUG - 2012-03-31 07:20:20 --> Output Class Initialized
DEBUG - 2012-03-31 07:20:20 --> Security Class Initialized
DEBUG - 2012-03-31 07:20:20 --> Input Class Initialized
DEBUG - 2012-03-31 07:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-31 07:20:20 --> Language Class Initialized
DEBUG - 2012-03-31 07:20:20 --> Loader Class Initialized
DEBUG - 2012-03-31 07:20:20 --> Controller Class Initialized
DEBUG - 2012-03-31 07:20:20 --> File loaded: system/views/main_view.php
DEBUG - 2012-03-31 07:20:20 --> Final output sent to browser
DEBUG - 2012-03-31 07:20:20 --> Total execution time: 0.8220
