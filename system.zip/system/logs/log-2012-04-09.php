<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-09 07:54:30 --> Config Class Initialized
DEBUG - 2012-04-09 07:54:30 --> Hooks Class Initialized
DEBUG - 2012-04-09 07:54:30 --> Utf8 Class Initialized
DEBUG - 2012-04-09 07:54:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 07:54:31 --> URI Class Initialized
DEBUG - 2012-04-09 07:54:31 --> Router Class Initialized
DEBUG - 2012-04-09 07:54:31 --> No URI present. Default controller set.
DEBUG - 2012-04-09 07:54:31 --> Output Class Initialized
DEBUG - 2012-04-09 07:54:31 --> Security Class Initialized
DEBUG - 2012-04-09 07:54:31 --> Input Class Initialized
DEBUG - 2012-04-09 07:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 07:54:31 --> Language Class Initialized
DEBUG - 2012-04-09 07:54:31 --> Loader Class Initialized
DEBUG - 2012-04-09 07:54:31 --> Helper loaded: url_helper
DEBUG - 2012-04-09 07:54:31 --> Database Driver Class Initialized
ERROR - 2012-04-09 07:54:31 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-09 07:54:32 --> Session Class Initialized
DEBUG - 2012-04-09 07:54:32 --> Helper loaded: string_helper
DEBUG - 2012-04-09 07:54:32 --> A session cookie was not found.
DEBUG - 2012-04-09 07:54:32 --> Session routines successfully run
DEBUG - 2012-04-09 07:54:32 --> Controller Class Initialized
DEBUG - 2012-04-09 07:54:32 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 07:54:32 --> Final output sent to browser
DEBUG - 2012-04-09 07:54:32 --> Total execution time: 1.1055
DEBUG - 2012-04-09 07:54:40 --> Config Class Initialized
DEBUG - 2012-04-09 07:54:40 --> Hooks Class Initialized
DEBUG - 2012-04-09 07:54:40 --> Utf8 Class Initialized
DEBUG - 2012-04-09 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 07:54:41 --> URI Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Router Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Output Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Security Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Input Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 07:54:41 --> Language Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Loader Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Helper loaded: url_helper
DEBUG - 2012-04-09 07:54:41 --> Database Driver Class Initialized
ERROR - 2012-04-09 07:54:41 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-09 07:54:41 --> Session Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Helper loaded: string_helper
DEBUG - 2012-04-09 07:54:41 --> Session routines successfully run
DEBUG - 2012-04-09 07:54:41 --> Controller Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Model Class Initialized
DEBUG - 2012-04-09 07:54:41 --> Model Class Initialized
DEBUG - 2012-04-09 07:54:41 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 07:54:41 --> Final output sent to browser
DEBUG - 2012-04-09 07:54:41 --> Total execution time: 0.4932
DEBUG - 2012-04-09 07:54:51 --> Config Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Hooks Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Utf8 Class Initialized
DEBUG - 2012-04-09 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 07:54:51 --> URI Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Router Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Output Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Security Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Input Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 07:54:51 --> Language Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Loader Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Helper loaded: url_helper
DEBUG - 2012-04-09 07:54:51 --> Database Driver Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Session Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Helper loaded: string_helper
DEBUG - 2012-04-09 07:54:51 --> Session routines successfully run
DEBUG - 2012-04-09 07:54:51 --> Controller Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Model Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Model Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Config Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Hooks Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Utf8 Class Initialized
DEBUG - 2012-04-09 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 07:54:51 --> URI Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Router Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Output Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Security Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Input Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 07:54:51 --> Language Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Loader Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Helper loaded: url_helper
DEBUG - 2012-04-09 07:54:51 --> Database Driver Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Session Class Initialized
DEBUG - 2012-04-09 07:54:51 --> Helper loaded: string_helper
DEBUG - 2012-04-09 07:54:51 --> Session routines successfully run
DEBUG - 2012-04-09 07:54:51 --> Controller Class Initialized
DEBUG - 2012-04-09 07:54:51 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 07:54:51 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 07:54:51 --> Final output sent to browser
DEBUG - 2012-04-09 07:54:51 --> Total execution time: 0.1352
DEBUG - 2012-04-09 07:55:01 --> Config Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Hooks Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Utf8 Class Initialized
DEBUG - 2012-04-09 07:55:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 07:55:01 --> URI Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Router Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Output Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Security Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Input Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 07:55:01 --> Language Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Loader Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Helper loaded: url_helper
DEBUG - 2012-04-09 07:55:01 --> Database Driver Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Session Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Helper loaded: string_helper
DEBUG - 2012-04-09 07:55:01 --> Session routines successfully run
DEBUG - 2012-04-09 07:55:01 --> Controller Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Model Class Initialized
DEBUG - 2012-04-09 07:55:01 --> Model Class Initialized
DEBUG - 2012-04-09 07:55:01 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 07:55:01 --> Final output sent to browser
DEBUG - 2012-04-09 07:55:01 --> Total execution time: 0.1529
DEBUG - 2012-04-09 07:58:24 --> Config Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Hooks Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Utf8 Class Initialized
DEBUG - 2012-04-09 07:58:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 07:58:24 --> URI Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Router Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Output Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Security Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Input Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 07:58:24 --> Language Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Loader Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Helper loaded: url_helper
DEBUG - 2012-04-09 07:58:24 --> Database Driver Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Session Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Helper loaded: string_helper
DEBUG - 2012-04-09 07:58:24 --> Session routines successfully run
DEBUG - 2012-04-09 07:58:24 --> Controller Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Model Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Model Class Initialized
DEBUG - 2012-04-09 07:58:24 --> Model Class Initialized
DEBUG - 2012-04-09 07:58:25 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 07:58:25 --> Final output sent to browser
DEBUG - 2012-04-09 07:58:25 --> Total execution time: 0.3005
DEBUG - 2012-04-09 07:59:16 --> Config Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Hooks Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Utf8 Class Initialized
DEBUG - 2012-04-09 07:59:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 07:59:16 --> URI Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Router Class Initialized
DEBUG - 2012-04-09 07:59:16 --> No URI present. Default controller set.
DEBUG - 2012-04-09 07:59:16 --> Output Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Security Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Input Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 07:59:16 --> Language Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Loader Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Helper loaded: url_helper
DEBUG - 2012-04-09 07:59:16 --> Database Driver Class Initialized
ERROR - 2012-04-09 07:59:16 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-09 07:59:16 --> Session Class Initialized
DEBUG - 2012-04-09 07:59:16 --> Helper loaded: string_helper
DEBUG - 2012-04-09 07:59:16 --> A session cookie was not found.
DEBUG - 2012-04-09 07:59:16 --> Session routines successfully run
DEBUG - 2012-04-09 07:59:16 --> Controller Class Initialized
DEBUG - 2012-04-09 07:59:16 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 07:59:16 --> Final output sent to browser
DEBUG - 2012-04-09 07:59:16 --> Total execution time: 0.1665
DEBUG - 2012-04-09 07:59:30 --> Config Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Hooks Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Utf8 Class Initialized
DEBUG - 2012-04-09 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 07:59:30 --> URI Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Router Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Output Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Security Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Input Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 07:59:30 --> Language Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Loader Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Helper loaded: url_helper
DEBUG - 2012-04-09 07:59:30 --> Database Driver Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Session Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Helper loaded: string_helper
DEBUG - 2012-04-09 07:59:30 --> A session cookie was not found.
DEBUG - 2012-04-09 07:59:30 --> Session routines successfully run
DEBUG - 2012-04-09 07:59:30 --> Controller Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Model Class Initialized
DEBUG - 2012-04-09 07:59:30 --> Model Class Initialized
DEBUG - 2012-04-09 07:59:30 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 07:59:30 --> Final output sent to browser
DEBUG - 2012-04-09 07:59:30 --> Total execution time: 0.4046
DEBUG - 2012-04-09 08:00:48 --> Config Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Hooks Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Utf8 Class Initialized
DEBUG - 2012-04-09 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 08:00:48 --> URI Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Router Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Output Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Security Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Input Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 08:00:48 --> Language Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Loader Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Helper loaded: url_helper
DEBUG - 2012-04-09 08:00:48 --> Database Driver Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Session Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Helper loaded: string_helper
DEBUG - 2012-04-09 08:00:48 --> Session routines successfully run
DEBUG - 2012-04-09 08:00:48 --> Controller Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Model Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Model Class Initialized
DEBUG - 2012-04-09 08:00:48 --> Helper loaded: email_helper
DEBUG - 2012-04-09 08:00:48 --> Model Class Initialized
DEBUG - 2012-04-09 08:00:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 08:00:48 --> Final output sent to browser
DEBUG - 2012-04-09 08:00:48 --> Total execution time: 0.2020
DEBUG - 2012-04-09 08:03:04 --> Config Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Hooks Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Utf8 Class Initialized
DEBUG - 2012-04-09 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 08:03:04 --> URI Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Router Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Output Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Security Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Input Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 08:03:04 --> Language Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Loader Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Helper loaded: url_helper
DEBUG - 2012-04-09 08:03:04 --> Database Driver Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Session Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Helper loaded: string_helper
DEBUG - 2012-04-09 08:03:04 --> Session routines successfully run
DEBUG - 2012-04-09 08:03:04 --> Controller Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Model Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Model Class Initialized
DEBUG - 2012-04-09 08:03:04 --> Helper loaded: email_helper
DEBUG - 2012-04-09 08:03:04 --> Model Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Config Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Hooks Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Utf8 Class Initialized
DEBUG - 2012-04-09 08:03:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 08:03:05 --> URI Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Router Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Output Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Security Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Input Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 08:03:05 --> Language Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Loader Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Helper loaded: url_helper
DEBUG - 2012-04-09 08:03:05 --> Database Driver Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Session Class Initialized
DEBUG - 2012-04-09 08:03:05 --> Helper loaded: string_helper
DEBUG - 2012-04-09 08:03:05 --> Session routines successfully run
DEBUG - 2012-04-09 08:03:05 --> Controller Class Initialized
DEBUG - 2012-04-09 08:03:05 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-09 08:03:05 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 08:03:05 --> Final output sent to browser
DEBUG - 2012-04-09 08:03:05 --> Total execution time: 0.1858
DEBUG - 2012-04-09 12:42:40 --> Config Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:42:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:42:40 --> URI Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Router Class Initialized
DEBUG - 2012-04-09 12:42:40 --> No URI present. Default controller set.
DEBUG - 2012-04-09 12:42:40 --> Output Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Security Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Input Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:42:40 --> Language Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Loader Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:42:40 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Session Class Initialized
DEBUG - 2012-04-09 12:42:40 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:42:40 --> Session routines successfully run
DEBUG - 2012-04-09 12:42:40 --> Controller Class Initialized
DEBUG - 2012-04-09 12:42:40 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 12:42:40 --> Final output sent to browser
DEBUG - 2012-04-09 12:42:40 --> Total execution time: 0.1812
DEBUG - 2012-04-09 12:42:41 --> Config Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:42:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:42:41 --> URI Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Router Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Output Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Security Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Input Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:42:41 --> Language Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Loader Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:42:41 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Session Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:42:41 --> Session routines successfully run
DEBUG - 2012-04-09 12:42:41 --> Controller Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Model Class Initialized
DEBUG - 2012-04-09 12:42:41 --> Model Class Initialized
DEBUG - 2012-04-09 12:42:41 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 12:42:41 --> Final output sent to browser
DEBUG - 2012-04-09 12:42:41 --> Total execution time: 0.2379
DEBUG - 2012-04-09 12:42:52 --> Config Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:42:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:42:52 --> URI Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Router Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Output Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Security Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Input Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:42:52 --> Language Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Loader Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:42:52 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Session Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:42:52 --> Session routines successfully run
DEBUG - 2012-04-09 12:42:52 --> Controller Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Model Class Initialized
DEBUG - 2012-04-09 12:42:52 --> Model Class Initialized
DEBUG - 2012-04-09 12:42:52 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 12:42:52 --> Final output sent to browser
DEBUG - 2012-04-09 12:42:52 --> Total execution time: 0.2219
DEBUG - 2012-04-09 12:49:34 --> Config Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:49:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:49:34 --> URI Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Router Class Initialized
DEBUG - 2012-04-09 12:49:34 --> No URI present. Default controller set.
DEBUG - 2012-04-09 12:49:34 --> Output Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Security Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Input Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:49:34 --> Language Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Loader Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:49:34 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Session Class Initialized
DEBUG - 2012-04-09 12:49:34 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:49:34 --> Session routines successfully run
DEBUG - 2012-04-09 12:49:34 --> Controller Class Initialized
DEBUG - 2012-04-09 12:49:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 12:49:34 --> Final output sent to browser
DEBUG - 2012-04-09 12:49:34 --> Total execution time: 0.0753
DEBUG - 2012-04-09 12:49:36 --> Config Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:49:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:49:36 --> URI Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Router Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Output Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Security Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Input Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:49:36 --> Language Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Loader Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:49:36 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Session Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:49:36 --> Session routines successfully run
DEBUG - 2012-04-09 12:49:36 --> Controller Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Model Class Initialized
DEBUG - 2012-04-09 12:49:36 --> Model Class Initialized
DEBUG - 2012-04-09 12:49:36 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 12:49:36 --> Final output sent to browser
DEBUG - 2012-04-09 12:49:36 --> Total execution time: 0.0703
DEBUG - 2012-04-09 12:49:48 --> Config Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:49:48 --> URI Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Router Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Output Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Security Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Input Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:49:48 --> Language Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Loader Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:49:48 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Session Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:49:48 --> Session routines successfully run
DEBUG - 2012-04-09 12:49:48 --> Controller Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Model Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Model Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Config Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:49:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:49:48 --> URI Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Router Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Output Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Security Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Input Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:49:48 --> Language Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Loader Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:49:48 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Session Class Initialized
DEBUG - 2012-04-09 12:49:48 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:49:48 --> Session routines successfully run
DEBUG - 2012-04-09 12:49:48 --> Controller Class Initialized
DEBUG - 2012-04-09 12:49:48 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 12:49:48 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 12:49:48 --> Final output sent to browser
DEBUG - 2012-04-09 12:49:48 --> Total execution time: 0.0521
DEBUG - 2012-04-09 12:49:50 --> Config Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:49:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:49:50 --> URI Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Router Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Output Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Security Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Input Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:49:50 --> Language Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Loader Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:49:50 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Session Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:49:50 --> Session routines successfully run
DEBUG - 2012-04-09 12:49:50 --> Controller Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Model Class Initialized
DEBUG - 2012-04-09 12:49:50 --> Model Class Initialized
DEBUG - 2012-04-09 12:49:50 --> File loaded: system/views/createCR_view.php
DEBUG - 2012-04-09 12:49:50 --> Final output sent to browser
DEBUG - 2012-04-09 12:49:50 --> Total execution time: 0.0664
DEBUG - 2012-04-09 12:50:30 --> Config Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:50:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:50:30 --> URI Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Router Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Output Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Security Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Input Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:50:30 --> Language Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Loader Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:50:30 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Session Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:50:30 --> Session routines successfully run
DEBUG - 2012-04-09 12:50:30 --> Controller Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Model Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Model Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Helper loaded: email_helper
DEBUG - 2012-04-09 12:50:30 --> Model Class Initialized
DEBUG - 2012-04-09 12:50:30 --> Final output sent to browser
DEBUG - 2012-04-09 12:50:30 --> Total execution time: 0.0632
DEBUG - 2012-04-09 12:50:32 --> Config Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:50:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:50:32 --> URI Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Router Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Output Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Security Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Input Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:50:32 --> Language Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Loader Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:50:32 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Session Class Initialized
DEBUG - 2012-04-09 12:50:32 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:50:32 --> Session routines successfully run
DEBUG - 2012-04-09 12:50:32 --> Controller Class Initialized
DEBUG - 2012-04-09 12:50:32 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 12:50:32 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 12:50:32 --> Final output sent to browser
DEBUG - 2012-04-09 12:50:32 --> Total execution time: 0.0568
DEBUG - 2012-04-09 12:50:39 --> Config Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:50:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:50:39 --> URI Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Router Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Output Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Security Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Input Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:50:39 --> Language Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Loader Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:50:39 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Session Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:50:39 --> Session routines successfully run
DEBUG - 2012-04-09 12:50:39 --> Controller Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Model Class Initialized
DEBUG - 2012-04-09 12:50:39 --> Model Class Initialized
DEBUG - 2012-04-09 12:50:39 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 12:50:39 --> Final output sent to browser
DEBUG - 2012-04-09 12:50:39 --> Total execution time: 0.0592
DEBUG - 2012-04-09 12:50:48 --> Config Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Hooks Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Utf8 Class Initialized
DEBUG - 2012-04-09 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 12:50:48 --> URI Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Router Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Output Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Security Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Input Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 12:50:48 --> Language Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Loader Class Initialized
DEBUG - 2012-04-09 12:50:48 --> Helper loaded: url_helper
DEBUG - 2012-04-09 12:50:48 --> Database Driver Class Initialized
DEBUG - 2012-04-09 12:50:49 --> Session Class Initialized
DEBUG - 2012-04-09 12:50:49 --> Helper loaded: string_helper
DEBUG - 2012-04-09 12:50:49 --> Session routines successfully run
DEBUG - 2012-04-09 12:50:49 --> Controller Class Initialized
DEBUG - 2012-04-09 12:50:49 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 12:50:49 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 12:50:49 --> Final output sent to browser
DEBUG - 2012-04-09 12:50:49 --> Total execution time: 0.0904
DEBUG - 2012-04-09 13:02:24 --> Config Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:02:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:02:24 --> URI Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Router Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Output Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Security Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Input Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:02:24 --> Language Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Loader Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:02:24 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Session Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:02:24 --> Session routines successfully run
DEBUG - 2012-04-09 13:02:24 --> Controller Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Config Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:02:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:02:24 --> URI Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Router Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Output Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Security Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Input Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:02:24 --> Language Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Loader Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:02:24 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Session Class Initialized
DEBUG - 2012-04-09 13:02:24 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:02:24 --> A session cookie was not found.
DEBUG - 2012-04-09 13:02:24 --> Session routines successfully run
DEBUG - 2012-04-09 13:02:24 --> Controller Class Initialized
DEBUG - 2012-04-09 13:02:24 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 13:02:24 --> Final output sent to browser
DEBUG - 2012-04-09 13:02:24 --> Total execution time: 0.0579
DEBUG - 2012-04-09 13:36:34 --> Config Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:36:34 --> URI Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Router Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Output Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Security Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Input Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:36:34 --> Language Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Loader Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:36:34 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Session Class Initialized
DEBUG - 2012-04-09 13:36:34 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:36:34 --> Session routines successfully run
DEBUG - 2012-04-09 13:36:34 --> Controller Class Initialized
DEBUG - 2012-04-09 13:36:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 13:36:34 --> Final output sent to browser
DEBUG - 2012-04-09 13:36:34 --> Total execution time: 0.0617
DEBUG - 2012-04-09 13:36:36 --> Config Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:36:36 --> URI Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Router Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Output Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Security Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Input Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:36:36 --> Language Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Loader Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:36:36 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Session Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:36:36 --> Session routines successfully run
DEBUG - 2012-04-09 13:36:36 --> Controller Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Model Class Initialized
DEBUG - 2012-04-09 13:36:36 --> Model Class Initialized
DEBUG - 2012-04-09 13:36:36 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 13:36:36 --> Final output sent to browser
DEBUG - 2012-04-09 13:36:36 --> Total execution time: 0.0882
DEBUG - 2012-04-09 13:36:47 --> Config Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:36:47 --> URI Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Router Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Output Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Security Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Input Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:36:47 --> Language Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Loader Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:36:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Session Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:36:47 --> Session routines successfully run
DEBUG - 2012-04-09 13:36:47 --> Controller Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Model Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Model Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Config Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:36:47 --> URI Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Router Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Output Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Security Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Input Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:36:47 --> Language Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Loader Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:36:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Session Class Initialized
DEBUG - 2012-04-09 13:36:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:36:47 --> Session routines successfully run
DEBUG - 2012-04-09 13:36:47 --> Controller Class Initialized
DEBUG - 2012-04-09 13:36:47 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 13:36:47 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 13:36:47 --> Final output sent to browser
DEBUG - 2012-04-09 13:36:47 --> Total execution time: 0.0571
DEBUG - 2012-04-09 13:36:49 --> Config Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:36:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:36:49 --> URI Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Router Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Output Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Security Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Input Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:36:49 --> Language Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Loader Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:36:49 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Session Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:36:49 --> Session routines successfully run
DEBUG - 2012-04-09 13:36:49 --> Controller Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Model Class Initialized
DEBUG - 2012-04-09 13:36:49 --> Model Class Initialized
DEBUG - 2012-04-09 13:36:49 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 13:36:49 --> Final output sent to browser
DEBUG - 2012-04-09 13:36:49 --> Total execution time: 0.0642
DEBUG - 2012-04-09 13:36:58 --> Config Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:36:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:36:58 --> URI Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Router Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Output Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Security Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Input Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:36:58 --> Language Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Loader Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:36:58 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Session Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:36:58 --> Session routines successfully run
DEBUG - 2012-04-09 13:36:58 --> Controller Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Model Class Initialized
DEBUG - 2012-04-09 13:36:58 --> Model Class Initialized
DEBUG - 2012-04-09 13:36:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 13:36:58 --> Final output sent to browser
DEBUG - 2012-04-09 13:36:58 --> Total execution time: 0.0647
DEBUG - 2012-04-09 13:38:07 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:07 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:07 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:07 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:07 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:07 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:07 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:07 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:07 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:07 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:07 --> A session cookie was not found.
DEBUG - 2012-04-09 13:38:07 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:07 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:07 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 13:38:07 --> Final output sent to browser
DEBUG - 2012-04-09 13:38:07 --> Total execution time: 0.0594
DEBUG - 2012-04-09 13:38:09 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:09 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:09 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:09 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:09 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:09 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Model Class Initialized
DEBUG - 2012-04-09 13:38:09 --> Model Class Initialized
DEBUG - 2012-04-09 13:38:09 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 13:38:09 --> Final output sent to browser
DEBUG - 2012-04-09 13:38:09 --> Total execution time: 0.0656
DEBUG - 2012-04-09 13:38:21 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:21 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:21 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:21 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:21 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:21 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Model Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Model Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:21 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:21 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:21 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:21 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:21 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:21 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:21 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-09 13:38:21 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 13:38:21 --> Final output sent to browser
DEBUG - 2012-04-09 13:38:21 --> Total execution time: 0.0588
DEBUG - 2012-04-09 13:38:26 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:26 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:26 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:26 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:26 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:26 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Model Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Model Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:26 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:26 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:26 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:26 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:26 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:26 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:26 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-09 13:38:26 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 13:38:26 --> Final output sent to browser
DEBUG - 2012-04-09 13:38:26 --> Total execution time: 0.0597
DEBUG - 2012-04-09 13:38:37 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:37 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:37 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:37 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:37 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:37 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Config Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Hooks Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Utf8 Class Initialized
DEBUG - 2012-04-09 13:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 13:38:37 --> URI Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Router Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Output Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Security Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Input Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 13:38:37 --> Language Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Loader Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Helper loaded: url_helper
DEBUG - 2012-04-09 13:38:37 --> Database Driver Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Session Class Initialized
DEBUG - 2012-04-09 13:38:37 --> Helper loaded: string_helper
DEBUG - 2012-04-09 13:38:37 --> A session cookie was not found.
DEBUG - 2012-04-09 13:38:37 --> Session routines successfully run
DEBUG - 2012-04-09 13:38:37 --> Controller Class Initialized
DEBUG - 2012-04-09 13:38:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 13:38:37 --> Final output sent to browser
DEBUG - 2012-04-09 13:38:37 --> Total execution time: 0.0603
DEBUG - 2012-04-09 14:16:41 --> Config Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:16:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:16:41 --> URI Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Router Class Initialized
DEBUG - 2012-04-09 14:16:41 --> No URI present. Default controller set.
DEBUG - 2012-04-09 14:16:41 --> Output Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Security Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Input Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:16:41 --> Language Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Loader Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:16:41 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Session Class Initialized
DEBUG - 2012-04-09 14:16:41 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:16:41 --> Session routines successfully run
DEBUG - 2012-04-09 14:16:41 --> Controller Class Initialized
DEBUG - 2012-04-09 14:16:41 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 14:16:41 --> Final output sent to browser
DEBUG - 2012-04-09 14:16:41 --> Total execution time: 0.0641
DEBUG - 2012-04-09 14:19:24 --> Config Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:19:24 --> URI Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Router Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Output Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Security Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Input Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:19:24 --> Language Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Loader Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:19:24 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Session Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:19:24 --> Session routines successfully run
DEBUG - 2012-04-09 14:19:24 --> Controller Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Model Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Model Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Config Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:19:24 --> URI Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Router Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Output Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Security Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Input Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:19:24 --> Language Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Loader Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:19:24 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Session Class Initialized
DEBUG - 2012-04-09 14:19:24 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:19:24 --> Session routines successfully run
DEBUG - 2012-04-09 14:19:24 --> Controller Class Initialized
DEBUG - 2012-04-09 14:19:24 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:19:24 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:19:24 --> Final output sent to browser
DEBUG - 2012-04-09 14:19:24 --> Total execution time: 0.0608
DEBUG - 2012-04-09 14:19:27 --> Config Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:19:27 --> URI Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Router Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Output Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Security Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Input Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:19:27 --> Language Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Loader Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:19:27 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Session Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:19:27 --> Session routines successfully run
DEBUG - 2012-04-09 14:19:27 --> Controller Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:19:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:19:27 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:19:27 --> Final output sent to browser
DEBUG - 2012-04-09 14:19:27 --> Total execution time: 0.0872
DEBUG - 2012-04-09 14:20:05 --> Config Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:20:05 --> URI Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Router Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Output Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Security Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Input Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:20:05 --> Language Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Loader Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:20:05 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Session Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:20:05 --> Session routines successfully run
DEBUG - 2012-04-09 14:20:05 --> Controller Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Model Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Model Class Initialized
DEBUG - 2012-04-09 14:20:05 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:20:05 --> DB Transaction Failure
ERROR - 2012-04-09 14:20:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 14:20:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 14:22:15 --> Config Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:22:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:22:15 --> URI Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Router Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Output Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Security Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Input Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:22:15 --> Language Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Loader Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:22:15 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Session Class Initialized
DEBUG - 2012-04-09 14:22:15 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:22:15 --> Session routines successfully run
DEBUG - 2012-04-09 14:22:15 --> Controller Class Initialized
DEBUG - 2012-04-09 14:22:15 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:22:15 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:22:15 --> Final output sent to browser
DEBUG - 2012-04-09 14:22:15 --> Total execution time: 0.0674
DEBUG - 2012-04-09 14:22:17 --> Config Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:22:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:22:17 --> URI Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Router Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Output Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Security Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Input Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:22:17 --> Language Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Loader Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:22:17 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Session Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:22:17 --> Session routines successfully run
DEBUG - 2012-04-09 14:22:17 --> Controller Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Model Class Initialized
DEBUG - 2012-04-09 14:22:17 --> Model Class Initialized
DEBUG - 2012-04-09 14:22:17 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:22:17 --> Final output sent to browser
DEBUG - 2012-04-09 14:22:17 --> Total execution time: 0.0771
DEBUG - 2012-04-09 14:25:24 --> Config Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:25:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:25:24 --> URI Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Router Class Initialized
DEBUG - 2012-04-09 14:25:24 --> No URI present. Default controller set.
DEBUG - 2012-04-09 14:25:24 --> Output Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Security Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Input Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:25:24 --> Language Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Loader Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:25:24 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Session Class Initialized
DEBUG - 2012-04-09 14:25:24 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:25:24 --> Session routines successfully run
DEBUG - 2012-04-09 14:25:24 --> Controller Class Initialized
DEBUG - 2012-04-09 14:25:24 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:25:24 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:25:24 --> Final output sent to browser
DEBUG - 2012-04-09 14:25:24 --> Total execution time: 0.0721
DEBUG - 2012-04-09 14:25:26 --> Config Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:25:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:25:26 --> URI Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Router Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Output Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Security Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Input Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:25:26 --> Language Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Loader Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:25:26 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Session Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:25:26 --> Session routines successfully run
DEBUG - 2012-04-09 14:25:26 --> Controller Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Model Class Initialized
DEBUG - 2012-04-09 14:25:26 --> Model Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Config Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:27:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:27:59 --> URI Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Router Class Initialized
DEBUG - 2012-04-09 14:27:59 --> No URI present. Default controller set.
DEBUG - 2012-04-09 14:27:59 --> Output Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Security Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Input Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:27:59 --> Language Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Loader Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:27:59 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Session Class Initialized
DEBUG - 2012-04-09 14:27:59 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:27:59 --> Session routines successfully run
DEBUG - 2012-04-09 14:27:59 --> Controller Class Initialized
DEBUG - 2012-04-09 14:27:59 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:27:59 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:27:59 --> Final output sent to browser
DEBUG - 2012-04-09 14:27:59 --> Total execution time: 0.0680
DEBUG - 2012-04-09 14:28:00 --> Config Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:28:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:28:00 --> URI Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Router Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Output Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Security Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Input Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:28:00 --> Language Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Loader Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:28:00 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Session Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:28:00 --> Session routines successfully run
DEBUG - 2012-04-09 14:28:00 --> Controller Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Model Class Initialized
DEBUG - 2012-04-09 14:28:00 --> Model Class Initialized
DEBUG - 2012-04-09 14:28:00 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:28:00 --> Final output sent to browser
DEBUG - 2012-04-09 14:28:00 --> Total execution time: 0.0711
DEBUG - 2012-04-09 14:28:40 --> Config Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:28:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:28:40 --> URI Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Router Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Output Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Security Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Input Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:28:40 --> Language Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Loader Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:28:40 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Session Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:28:40 --> Session routines successfully run
DEBUG - 2012-04-09 14:28:40 --> Controller Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Model Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Model Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:28:40 --> Model Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Config Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:28:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:28:40 --> URI Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Router Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Output Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Security Class Initialized
DEBUG - 2012-04-09 14:28:40 --> Input Class Initialized
DEBUG - 2012-04-09 14:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:28:41 --> Language Class Initialized
DEBUG - 2012-04-09 14:28:41 --> Loader Class Initialized
DEBUG - 2012-04-09 14:28:41 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:28:41 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:28:41 --> Session Class Initialized
DEBUG - 2012-04-09 14:28:41 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:28:41 --> Session routines successfully run
DEBUG - 2012-04-09 14:28:41 --> Controller Class Initialized
DEBUG - 2012-04-09 14:28:41 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-09 14:28:41 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:28:41 --> Final output sent to browser
DEBUG - 2012-04-09 14:28:41 --> Total execution time: 0.0630
DEBUG - 2012-04-09 14:38:11 --> Config Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:38:11 --> URI Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Router Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Output Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Security Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Input Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:38:11 --> Language Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Loader Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:38:11 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Session Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:38:11 --> Session routines successfully run
DEBUG - 2012-04-09 14:38:11 --> Controller Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Config Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:38:11 --> URI Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Router Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Output Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Security Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Input Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:38:11 --> Language Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Loader Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:38:11 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Session Class Initialized
DEBUG - 2012-04-09 14:38:11 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:38:11 --> A session cookie was not found.
DEBUG - 2012-04-09 14:38:11 --> Session routines successfully run
DEBUG - 2012-04-09 14:38:11 --> Controller Class Initialized
DEBUG - 2012-04-09 14:38:11 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 14:38:11 --> Final output sent to browser
DEBUG - 2012-04-09 14:38:11 --> Total execution time: 0.0668
DEBUG - 2012-04-09 14:38:26 --> Config Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:38:26 --> URI Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Router Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Output Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Security Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Input Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:38:26 --> Language Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Loader Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:38:26 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Session Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:38:26 --> Session routines successfully run
DEBUG - 2012-04-09 14:38:26 --> Controller Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Model Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Model Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Config Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:38:26 --> URI Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Router Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Output Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Security Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Input Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:38:26 --> Language Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Loader Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:38:26 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Session Class Initialized
DEBUG - 2012-04-09 14:38:26 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:38:26 --> Session routines successfully run
DEBUG - 2012-04-09 14:38:26 --> Controller Class Initialized
DEBUG - 2012-04-09 14:38:26 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:38:26 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:38:26 --> Final output sent to browser
DEBUG - 2012-04-09 14:38:26 --> Total execution time: 0.0659
DEBUG - 2012-04-09 14:38:27 --> Config Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:38:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:38:27 --> URI Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Router Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Output Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Security Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Input Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:38:27 --> Language Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Loader Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:38:27 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Session Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:38:27 --> Session routines successfully run
DEBUG - 2012-04-09 14:38:27 --> Controller Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:38:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:38:28 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:38:28 --> Final output sent to browser
DEBUG - 2012-04-09 14:38:28 --> Total execution time: 0.0886
DEBUG - 2012-04-09 14:38:47 --> Config Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:38:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:38:47 --> URI Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Router Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Output Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Security Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Input Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:38:47 --> Language Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Loader Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:38:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Session Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:38:47 --> Session routines successfully run
DEBUG - 2012-04-09 14:38:47 --> Controller Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:38:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Config Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:38:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:38:47 --> URI Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Router Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Output Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Security Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Input Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:38:47 --> Language Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Loader Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:38:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Session Class Initialized
DEBUG - 2012-04-09 14:38:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:38:47 --> Session routines successfully run
DEBUG - 2012-04-09 14:38:47 --> Controller Class Initialized
DEBUG - 2012-04-09 14:38:48 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:38:48 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:38:48 --> Final output sent to browser
DEBUG - 2012-04-09 14:38:48 --> Total execution time: 0.0659
DEBUG - 2012-04-09 14:41:44 --> Config Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:41:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:41:44 --> URI Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Router Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Output Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Security Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Input Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:41:44 --> Language Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Loader Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:41:44 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Session Class Initialized
DEBUG - 2012-04-09 14:41:44 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:41:44 --> Session routines successfully run
DEBUG - 2012-04-09 14:41:44 --> Controller Class Initialized
DEBUG - 2012-04-09 14:41:44 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:41:44 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:41:44 --> Final output sent to browser
DEBUG - 2012-04-09 14:41:44 --> Total execution time: 0.0670
DEBUG - 2012-04-09 14:41:46 --> Config Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:41:46 --> URI Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Router Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Output Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Security Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Input Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:41:46 --> Language Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Loader Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:41:46 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Session Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:41:46 --> Session routines successfully run
DEBUG - 2012-04-09 14:41:46 --> Controller Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Model Class Initialized
DEBUG - 2012-04-09 14:41:46 --> Model Class Initialized
DEBUG - 2012-04-09 14:41:46 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:41:46 --> Final output sent to browser
DEBUG - 2012-04-09 14:41:46 --> Total execution time: 0.0803
DEBUG - 2012-04-09 14:41:51 --> Config Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:41:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:41:51 --> URI Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Router Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Output Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Security Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Input Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:41:51 --> Language Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Loader Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:41:51 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Session Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:41:51 --> Session routines successfully run
DEBUG - 2012-04-09 14:41:51 --> Controller Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Model Class Initialized
DEBUG - 2012-04-09 14:41:51 --> Model Class Initialized
DEBUG - 2012-04-09 14:41:51 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:41:51 --> Final output sent to browser
DEBUG - 2012-04-09 14:41:51 --> Total execution time: 0.0736
DEBUG - 2012-04-09 14:41:56 --> Config Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:41:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:41:56 --> URI Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Router Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Output Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Security Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Input Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:41:56 --> Language Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Loader Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:41:56 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Session Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:41:56 --> Session routines successfully run
DEBUG - 2012-04-09 14:41:56 --> Controller Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Model Class Initialized
DEBUG - 2012-04-09 14:41:56 --> Model Class Initialized
DEBUG - 2012-04-09 14:41:56 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:41:56 --> Final output sent to browser
DEBUG - 2012-04-09 14:41:56 --> Total execution time: 0.0746
DEBUG - 2012-04-09 14:42:21 --> Config Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:42:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:42:21 --> URI Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Router Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Output Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Security Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Input Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:42:21 --> Language Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Loader Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:42:21 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Session Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:42:21 --> Session routines successfully run
DEBUG - 2012-04-09 14:42:21 --> Controller Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:21 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:42:21 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:21 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:42:21 --> Final output sent to browser
DEBUG - 2012-04-09 14:42:21 --> Total execution time: 0.0799
DEBUG - 2012-04-09 14:42:33 --> Config Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:42:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:42:33 --> URI Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Router Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Output Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Security Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Input Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:42:33 --> Language Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Loader Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:42:33 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Session Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:42:33 --> Session routines successfully run
DEBUG - 2012-04-09 14:42:33 --> Controller Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:33 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:42:33 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:33 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:42:33 --> Final output sent to browser
DEBUG - 2012-04-09 14:42:33 --> Total execution time: 0.0807
DEBUG - 2012-04-09 14:42:47 --> Config Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:42:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:42:47 --> URI Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Router Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Output Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Security Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Input Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:42:47 --> Language Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Loader Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:42:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Session Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:42:47 --> Session routines successfully run
DEBUG - 2012-04-09 14:42:47 --> Controller Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:47 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:42:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:42:47 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:42:47 --> Final output sent to browser
DEBUG - 2012-04-09 14:42:47 --> Total execution time: 0.0790
DEBUG - 2012-04-09 14:43:27 --> Config Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:43:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:43:27 --> URI Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Router Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Output Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Security Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Input Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:43:27 --> Language Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Loader Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:43:27 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Session Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:43:27 --> Session routines successfully run
DEBUG - 2012-04-09 14:43:27 --> Controller Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:43:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:43:27 --> Final output sent to browser
DEBUG - 2012-04-09 14:43:27 --> Total execution time: 0.0835
DEBUG - 2012-04-09 14:43:29 --> Config Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:43:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:43:29 --> URI Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Router Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Output Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Security Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Input Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:43:29 --> Language Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Loader Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:43:29 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Session Class Initialized
DEBUG - 2012-04-09 14:43:29 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:43:29 --> Session routines successfully run
DEBUG - 2012-04-09 14:43:29 --> Controller Class Initialized
DEBUG - 2012-04-09 14:43:29 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:43:29 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:43:29 --> Final output sent to browser
DEBUG - 2012-04-09 14:43:29 --> Total execution time: 0.0706
DEBUG - 2012-04-09 14:44:44 --> Config Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:44:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:44:44 --> URI Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Router Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Output Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Security Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Input Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:44:44 --> Language Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Loader Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:44:44 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Session Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:44:44 --> Session routines successfully run
DEBUG - 2012-04-09 14:44:44 --> Controller Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Config Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:44:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:44:44 --> URI Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Router Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Output Class Initialized
DEBUG - 2012-04-09 14:44:44 --> Security Class Initialized
DEBUG - 2012-04-09 14:44:45 --> Input Class Initialized
DEBUG - 2012-04-09 14:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:44:45 --> Language Class Initialized
DEBUG - 2012-04-09 14:44:45 --> Loader Class Initialized
DEBUG - 2012-04-09 14:44:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:44:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:44:45 --> Session Class Initialized
DEBUG - 2012-04-09 14:44:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:44:45 --> A session cookie was not found.
DEBUG - 2012-04-09 14:44:45 --> Session routines successfully run
DEBUG - 2012-04-09 14:44:45 --> Controller Class Initialized
DEBUG - 2012-04-09 14:44:45 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 14:44:45 --> Final output sent to browser
DEBUG - 2012-04-09 14:44:45 --> Total execution time: 0.0690
DEBUG - 2012-04-09 14:45:35 --> Config Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:45:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:45:35 --> URI Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Router Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Output Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Security Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Input Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:45:35 --> Language Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Loader Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:45:35 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Session Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:45:35 --> Session routines successfully run
DEBUG - 2012-04-09 14:45:35 --> Controller Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Model Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Model Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Config Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:45:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:45:35 --> URI Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Router Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Output Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Security Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Input Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:45:35 --> Language Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Loader Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:45:35 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Session Class Initialized
DEBUG - 2012-04-09 14:45:35 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:45:35 --> Session routines successfully run
DEBUG - 2012-04-09 14:45:35 --> Controller Class Initialized
DEBUG - 2012-04-09 14:45:35 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:45:35 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:45:35 --> Final output sent to browser
DEBUG - 2012-04-09 14:45:35 --> Total execution time: 0.0713
DEBUG - 2012-04-09 14:45:40 --> Config Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:45:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:45:40 --> URI Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Router Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Output Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Security Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Input Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:45:40 --> Language Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Loader Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:45:40 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Session Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:45:40 --> Session routines successfully run
DEBUG - 2012-04-09 14:45:40 --> Controller Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Model Class Initialized
DEBUG - 2012-04-09 14:45:40 --> Model Class Initialized
DEBUG - 2012-04-09 14:45:40 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:45:40 --> Final output sent to browser
DEBUG - 2012-04-09 14:45:40 --> Total execution time: 0.1127
DEBUG - 2012-04-09 14:46:47 --> Config Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:46:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:46:47 --> URI Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Router Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Output Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Security Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Input Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:46:47 --> Language Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Loader Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:46:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Session Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:46:47 --> Session routines successfully run
DEBUG - 2012-04-09 14:46:47 --> Controller Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:46:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:46:47 --> Final output sent to browser
DEBUG - 2012-04-09 14:46:47 --> Total execution time: 0.0886
DEBUG - 2012-04-09 14:46:49 --> Config Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:46:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:46:49 --> URI Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Router Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Output Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Security Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Input Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:46:49 --> Language Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Loader Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:46:49 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Session Class Initialized
DEBUG - 2012-04-09 14:46:49 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:46:49 --> Session routines successfully run
DEBUG - 2012-04-09 14:46:49 --> Controller Class Initialized
DEBUG - 2012-04-09 14:46:49 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:46:49 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:46:49 --> Final output sent to browser
DEBUG - 2012-04-09 14:46:49 --> Total execution time: 0.0713
DEBUG - 2012-04-09 14:47:11 --> Config Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:47:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:47:11 --> URI Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Router Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Output Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Security Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Input Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:47:11 --> Language Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Loader Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:47:11 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Session Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:47:11 --> Session routines successfully run
DEBUG - 2012-04-09 14:47:11 --> Controller Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Model Class Initialized
DEBUG - 2012-04-09 14:47:11 --> Model Class Initialized
DEBUG - 2012-04-09 14:47:11 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:47:11 --> Final output sent to browser
DEBUG - 2012-04-09 14:47:11 --> Total execution time: 0.0753
DEBUG - 2012-04-09 14:47:36 --> Config Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:47:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:47:36 --> URI Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Router Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Output Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Security Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Input Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:47:36 --> Language Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Loader Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:47:36 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Session Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:47:36 --> Session routines successfully run
DEBUG - 2012-04-09 14:47:36 --> Controller Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Model Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Model Class Initialized
DEBUG - 2012-04-09 14:47:36 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:47:36 --> Model Class Initialized
DEBUG - 2012-04-09 14:47:36 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:47:36 --> Final output sent to browser
DEBUG - 2012-04-09 14:47:36 --> Total execution time: 0.0833
DEBUG - 2012-04-09 14:48:13 --> Config Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:48:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:48:13 --> URI Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Router Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Output Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Security Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Input Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:48:13 --> Language Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Loader Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:48:13 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:48:13 --> Session Class Initialized
DEBUG - 2012-04-09 14:48:14 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:48:14 --> Session routines successfully run
DEBUG - 2012-04-09 14:48:14 --> Controller Class Initialized
DEBUG - 2012-04-09 14:48:14 --> Model Class Initialized
DEBUG - 2012-04-09 14:48:14 --> Model Class Initialized
DEBUG - 2012-04-09 14:48:14 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:48:14 --> Model Class Initialized
DEBUG - 2012-04-09 14:48:14 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:48:14 --> Final output sent to browser
DEBUG - 2012-04-09 14:48:14 --> Total execution time: 0.0819
DEBUG - 2012-04-09 14:48:45 --> Config Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:48:45 --> URI Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Router Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Output Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Security Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Input Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:48:45 --> Language Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Loader Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:48:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Session Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:48:45 --> Session routines successfully run
DEBUG - 2012-04-09 14:48:45 --> Controller Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Model Class Initialized
DEBUG - 2012-04-09 14:48:45 --> Model Class Initialized
DEBUG - 2012-04-09 14:48:46 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:48:46 --> Model Class Initialized
DEBUG - 2012-04-09 14:48:46 --> Final output sent to browser
DEBUG - 2012-04-09 14:48:46 --> Total execution time: 0.1003
DEBUG - 2012-04-09 14:48:48 --> Config Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:48:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:48:48 --> URI Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Router Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Output Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Security Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Input Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:48:48 --> Language Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Loader Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:48:48 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Session Class Initialized
DEBUG - 2012-04-09 14:48:48 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:48:48 --> Session routines successfully run
DEBUG - 2012-04-09 14:48:48 --> Controller Class Initialized
DEBUG - 2012-04-09 14:48:48 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:48:48 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:48:48 --> Final output sent to browser
DEBUG - 2012-04-09 14:48:48 --> Total execution time: 0.0721
DEBUG - 2012-04-09 14:49:05 --> Config Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:49:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:49:05 --> URI Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Router Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Output Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Security Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Input Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:49:05 --> Language Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Loader Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:49:05 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Session Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:49:05 --> Session routines successfully run
DEBUG - 2012-04-09 14:49:05 --> Controller Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:05 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:05 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 14:49:05 --> Final output sent to browser
DEBUG - 2012-04-09 14:49:05 --> Total execution time: 0.0757
DEBUG - 2012-04-09 14:49:25 --> Config Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:49:25 --> URI Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Router Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Output Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Security Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Input Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:49:25 --> Language Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Loader Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:49:25 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Session Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:49:25 --> Session routines successfully run
DEBUG - 2012-04-09 14:49:25 --> Controller Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:25 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:25 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 14:49:25 --> Final output sent to browser
DEBUG - 2012-04-09 14:49:25 --> Total execution time: 0.0809
DEBUG - 2012-04-09 14:49:46 --> Config Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:49:46 --> URI Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Router Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Output Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Security Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Input Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:49:46 --> Language Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Loader Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:49:46 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Session Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:49:46 --> Session routines successfully run
DEBUG - 2012-04-09 14:49:46 --> Controller Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:46 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:46 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 14:49:46 --> Final output sent to browser
DEBUG - 2012-04-09 14:49:46 --> Total execution time: 0.0804
DEBUG - 2012-04-09 14:49:58 --> Config Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:49:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:49:58 --> URI Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Router Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Output Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Security Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Input Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:49:58 --> Language Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Loader Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:49:58 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Session Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:49:58 --> Session routines successfully run
DEBUG - 2012-04-09 14:49:58 --> Controller Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:58 --> Model Class Initialized
DEBUG - 2012-04-09 14:49:58 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 14:49:58 --> Final output sent to browser
DEBUG - 2012-04-09 14:49:58 --> Total execution time: 0.0796
DEBUG - 2012-04-09 14:50:08 --> Config Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:50:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:50:08 --> URI Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Router Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Output Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Security Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Input Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:50:08 --> Language Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Loader Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:50:08 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Session Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:50:08 --> Session routines successfully run
DEBUG - 2012-04-09 14:50:08 --> Controller Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Model Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Model Class Initialized
DEBUG - 2012-04-09 14:50:08 --> Model Class Initialized
DEBUG - 2012-04-09 14:50:08 --> DB Transaction Failure
ERROR - 2012-04-09 14:50:08 --> Query error: Column count doesn't match value count at row 1
DEBUG - 2012-04-09 14:50:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 14:52:47 --> Config Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:52:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:52:47 --> URI Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Router Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Output Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Security Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Input Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:52:47 --> Language Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Loader Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:52:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Session Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:52:47 --> Session routines successfully run
DEBUG - 2012-04-09 14:52:47 --> Controller Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:52:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:52:47 --> DB Transaction Failure
ERROR - 2012-04-09 14:52:47 --> Query error: Column 'UserID' cannot be null
DEBUG - 2012-04-09 14:52:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 14:54:18 --> Config Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:54:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:54:18 --> URI Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Router Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Output Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Security Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Input Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:54:18 --> Language Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Loader Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:54:18 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Session Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:54:18 --> Session routines successfully run
DEBUG - 2012-04-09 14:54:18 --> Controller Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Model Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Model Class Initialized
DEBUG - 2012-04-09 14:54:18 --> Model Class Initialized
DEBUG - 2012-04-09 14:54:18 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-09 14:54:18 --> Final output sent to browser
DEBUG - 2012-04-09 14:54:18 --> Total execution time: 0.0829
DEBUG - 2012-04-09 14:55:11 --> Config Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:55:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:55:11 --> URI Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Router Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Output Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Security Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Input Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:55:11 --> Language Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Loader Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:55:11 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Session Class Initialized
DEBUG - 2012-04-09 14:55:11 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:55:11 --> Session routines successfully run
DEBUG - 2012-04-09 14:55:11 --> Controller Class Initialized
DEBUG - 2012-04-09 14:55:11 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:55:11 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:55:11 --> Final output sent to browser
DEBUG - 2012-04-09 14:55:11 --> Total execution time: 0.0719
DEBUG - 2012-04-09 14:55:13 --> Config Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:55:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:55:13 --> URI Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Router Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Output Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Security Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Input Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:55:13 --> Language Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Loader Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:55:13 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Session Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:55:13 --> Session routines successfully run
DEBUG - 2012-04-09 14:55:13 --> Controller Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:13 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:13 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 14:55:13 --> Final output sent to browser
DEBUG - 2012-04-09 14:55:13 --> Total execution time: 0.0960
DEBUG - 2012-04-09 14:55:22 --> Config Class Initialized
DEBUG - 2012-04-09 14:55:22 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:55:22 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:55:22 --> URI Class Initialized
DEBUG - 2012-04-09 14:55:22 --> Router Class Initialized
DEBUG - 2012-04-09 14:55:22 --> Output Class Initialized
DEBUG - 2012-04-09 14:55:22 --> Security Class Initialized
DEBUG - 2012-04-09 14:55:22 --> Input Class Initialized
DEBUG - 2012-04-09 14:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:55:23 --> Language Class Initialized
DEBUG - 2012-04-09 14:55:23 --> Loader Class Initialized
DEBUG - 2012-04-09 14:55:23 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:55:23 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:55:23 --> Session Class Initialized
DEBUG - 2012-04-09 14:55:23 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:55:23 --> Session routines successfully run
DEBUG - 2012-04-09 14:55:23 --> Controller Class Initialized
DEBUG - 2012-04-09 14:55:23 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:23 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:23 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:23 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 14:55:23 --> Final output sent to browser
DEBUG - 2012-04-09 14:55:23 --> Total execution time: 0.3604
DEBUG - 2012-04-09 14:55:46 --> Config Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:55:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:55:46 --> URI Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Router Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Output Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Security Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Input Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:55:46 --> Language Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Loader Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:55:46 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Session Class Initialized
DEBUG - 2012-04-09 14:55:46 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:55:46 --> Session routines successfully run
DEBUG - 2012-04-09 14:55:46 --> Controller Class Initialized
DEBUG - 2012-04-09 14:55:46 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:55:46 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:55:46 --> Final output sent to browser
DEBUG - 2012-04-09 14:55:46 --> Total execution time: 0.0698
DEBUG - 2012-04-09 14:55:47 --> Config Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:55:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:55:47 --> URI Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Router Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Output Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Security Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Input Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:55:47 --> Language Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Loader Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:55:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Session Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:55:47 --> Session routines successfully run
DEBUG - 2012-04-09 14:55:47 --> Controller Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:47 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:47 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 14:55:47 --> Final output sent to browser
DEBUG - 2012-04-09 14:55:47 --> Total execution time: 0.0756
DEBUG - 2012-04-09 14:55:57 --> Config Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:55:57 --> URI Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Router Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Output Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Security Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Input Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:55:57 --> Language Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Loader Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:55:57 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Session Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:55:57 --> Session routines successfully run
DEBUG - 2012-04-09 14:55:57 --> Controller Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:57 --> Model Class Initialized
DEBUG - 2012-04-09 14:55:57 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-09 14:55:57 --> Final output sent to browser
DEBUG - 2012-04-09 14:55:57 --> Total execution time: 0.0804
DEBUG - 2012-04-09 14:56:23 --> Config Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:56:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:56:23 --> URI Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Router Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Output Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Security Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Input Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:56:23 --> Language Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Loader Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:56:23 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Session Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:56:23 --> Session routines successfully run
DEBUG - 2012-04-09 14:56:23 --> Controller Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Model Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Model Class Initialized
DEBUG - 2012-04-09 14:56:23 --> Final output sent to browser
DEBUG - 2012-04-09 14:56:23 --> Total execution time: 0.0882
DEBUG - 2012-04-09 14:56:27 --> Config Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:56:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:56:27 --> URI Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Router Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Output Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Security Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Input Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:56:27 --> Language Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Loader Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:56:27 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Session Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:56:27 --> Session routines successfully run
DEBUG - 2012-04-09 14:56:27 --> Controller Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:56:27 --> Model Class Initialized
DEBUG - 2012-04-09 14:56:27 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 14:56:27 --> Final output sent to browser
DEBUG - 2012-04-09 14:56:27 --> Total execution time: 0.0759
DEBUG - 2012-04-09 14:56:45 --> Config Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:56:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:56:45 --> URI Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Router Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Output Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Security Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Input Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:56:45 --> Language Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Loader Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:56:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Session Class Initialized
DEBUG - 2012-04-09 14:56:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:56:45 --> Session routines successfully run
DEBUG - 2012-04-09 14:56:45 --> Controller Class Initialized
DEBUG - 2012-04-09 14:56:45 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 14:56:45 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 14:56:45 --> Final output sent to browser
DEBUG - 2012-04-09 14:56:45 --> Total execution time: 0.0712
DEBUG - 2012-04-09 14:56:46 --> Config Class Initialized
DEBUG - 2012-04-09 14:56:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:56:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:56:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:56:46 --> URI Class Initialized
DEBUG - 2012-04-09 14:56:46 --> Router Class Initialized
DEBUG - 2012-04-09 14:56:46 --> Output Class Initialized
DEBUG - 2012-04-09 14:56:46 --> Security Class Initialized
DEBUG - 2012-04-09 14:56:46 --> Input Class Initialized
DEBUG - 2012-04-09 14:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:56:46 --> Language Class Initialized
DEBUG - 2012-04-09 14:56:46 --> Loader Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:56:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Session Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:56:47 --> Session routines successfully run
DEBUG - 2012-04-09 14:56:47 --> Controller Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Config Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:56:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:56:47 --> URI Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Router Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Output Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Security Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Input Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:56:47 --> Language Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Loader Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:56:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Session Class Initialized
DEBUG - 2012-04-09 14:56:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:56:47 --> A session cookie was not found.
DEBUG - 2012-04-09 14:56:47 --> Session routines successfully run
DEBUG - 2012-04-09 14:56:47 --> Controller Class Initialized
DEBUG - 2012-04-09 14:56:47 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 14:56:47 --> Final output sent to browser
DEBUG - 2012-04-09 14:56:47 --> Total execution time: 0.0693
DEBUG - 2012-04-09 14:56:48 --> Config Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:56:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:56:48 --> URI Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Router Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Output Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Security Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Input Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:56:48 --> Language Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Loader Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:56:48 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Session Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:56:48 --> Session routines successfully run
DEBUG - 2012-04-09 14:56:48 --> Controller Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Model Class Initialized
DEBUG - 2012-04-09 14:56:48 --> Model Class Initialized
DEBUG - 2012-04-09 14:56:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 14:56:48 --> Final output sent to browser
DEBUG - 2012-04-09 14:56:48 --> Total execution time: 0.0748
DEBUG - 2012-04-09 14:57:25 --> Config Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Hooks Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Utf8 Class Initialized
DEBUG - 2012-04-09 14:57:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 14:57:25 --> URI Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Router Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Output Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Security Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Input Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 14:57:25 --> Language Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Loader Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Helper loaded: url_helper
DEBUG - 2012-04-09 14:57:25 --> Database Driver Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Session Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Helper loaded: string_helper
DEBUG - 2012-04-09 14:57:25 --> Session routines successfully run
DEBUG - 2012-04-09 14:57:25 --> Controller Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Model Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Model Class Initialized
DEBUG - 2012-04-09 14:57:25 --> Helper loaded: email_helper
DEBUG - 2012-04-09 14:57:25 --> Model Class Initialized
DEBUG - 2012-04-09 14:57:25 --> DB Transaction Failure
ERROR - 2012-04-09 14:57:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 14:57:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 15:00:21 --> Config Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:00:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:00:21 --> URI Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Router Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Output Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Security Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Input Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:00:21 --> Language Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Loader Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:00:21 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Session Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:00:21 --> Session routines successfully run
DEBUG - 2012-04-09 15:00:21 --> Controller Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Model Class Initialized
DEBUG - 2012-04-09 15:00:21 --> Model Class Initialized
DEBUG - 2012-04-09 15:00:21 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:00:21 --> Final output sent to browser
DEBUG - 2012-04-09 15:00:21 --> Total execution time: 0.0771
DEBUG - 2012-04-09 15:00:59 --> Config Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:00:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:00:59 --> URI Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Router Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Output Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Security Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Input Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:00:59 --> Language Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Loader Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:00:59 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Session Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:00:59 --> Session routines successfully run
DEBUG - 2012-04-09 15:00:59 --> Controller Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Model Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Model Class Initialized
DEBUG - 2012-04-09 15:00:59 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:00:59 --> Model Class Initialized
DEBUG - 2012-04-09 15:00:59 --> DB Transaction Failure
ERROR - 2012-04-09 15:00:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 15:00:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 15:02:36 --> Config Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:02:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:02:36 --> URI Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Router Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Output Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Security Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Input Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:02:36 --> Language Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Loader Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:02:36 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Session Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:02:36 --> Session routines successfully run
DEBUG - 2012-04-09 15:02:36 --> Controller Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Model Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Model Class Initialized
DEBUG - 2012-04-09 15:02:36 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:02:36 --> Model Class Initialized
DEBUG - 2012-04-09 15:02:36 --> DB Transaction Failure
ERROR - 2012-04-09 15:02:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 15:02:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 15:03:56 --> Config Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:03:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:03:56 --> URI Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Router Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Output Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Security Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Input Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:03:56 --> Language Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Loader Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:03:56 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Session Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:03:56 --> Session routines successfully run
DEBUG - 2012-04-09 15:03:56 --> Controller Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Model Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Model Class Initialized
DEBUG - 2012-04-09 15:03:56 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:03:56 --> Model Class Initialized
DEBUG - 2012-04-09 15:03:56 --> DB Transaction Failure
ERROR - 2012-04-09 15:03:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 15:03:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 15:04:27 --> Config Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:04:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:04:27 --> URI Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Router Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Output Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Security Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Input Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:04:27 --> Language Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Loader Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:04:27 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Session Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:04:27 --> Session routines successfully run
DEBUG - 2012-04-09 15:04:27 --> Controller Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Model Class Initialized
DEBUG - 2012-04-09 15:04:27 --> Model Class Initialized
DEBUG - 2012-04-09 15:04:27 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:04:27 --> Final output sent to browser
DEBUG - 2012-04-09 15:04:27 --> Total execution time: 0.0765
DEBUG - 2012-04-09 15:05:09 --> Config Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:05:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:05:09 --> URI Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Router Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Output Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Security Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Input Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:05:09 --> Language Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Loader Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:05:09 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Session Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:05:09 --> Session routines successfully run
DEBUG - 2012-04-09 15:05:09 --> Controller Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Model Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Model Class Initialized
DEBUG - 2012-04-09 15:05:09 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:05:09 --> Model Class Initialized
DEBUG - 2012-04-09 15:05:09 --> DB Transaction Failure
ERROR - 2012-04-09 15:05:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 15:05:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 15:05:52 --> Config Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:05:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:05:52 --> URI Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Router Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Output Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Security Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Input Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:05:52 --> Language Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Loader Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:05:52 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Session Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:05:52 --> Session routines successfully run
DEBUG - 2012-04-09 15:05:52 --> Controller Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Model Class Initialized
DEBUG - 2012-04-09 15:05:52 --> Model Class Initialized
ERROR - 2012-04-09 15:05:52 --> Severity: Notice  --> Undefined variable: Code C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 93
ERROR - 2012-04-09 15:05:52 --> Severity: Notice  --> Undefined variable: Code C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 105
DEBUG - 2012-04-09 15:05:52 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:05:52 --> Model Class Initialized
ERROR - 2012-04-09 15:05:52 --> Severity: Notice  --> Undefined variable: Code C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 135
DEBUG - 2012-04-09 15:05:52 --> DB Transaction Failure
ERROR - 2012-04-09 15:05:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 15:05:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 15:07:45 --> Config Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:07:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:07:45 --> URI Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Router Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Output Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Security Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Input Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:07:45 --> Language Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Loader Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:07:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Session Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:07:45 --> Session routines successfully run
DEBUG - 2012-04-09 15:07:45 --> Controller Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Model Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Model Class Initialized
DEBUG - 2012-04-09 15:07:45 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:07:45 --> Model Class Initialized
DEBUG - 2012-04-09 15:07:45 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:07:45 --> Final output sent to browser
DEBUG - 2012-04-09 15:07:45 --> Total execution time: 0.0880
DEBUG - 2012-04-09 15:08:03 --> Config Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:08:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:08:03 --> URI Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Router Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Output Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Security Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Input Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:08:03 --> Language Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Loader Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:08:03 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Session Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:08:03 --> Session routines successfully run
DEBUG - 2012-04-09 15:08:03 --> Controller Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Model Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Model Class Initialized
DEBUG - 2012-04-09 15:08:03 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:08:03 --> Model Class Initialized
DEBUG - 2012-04-09 15:08:03 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:08:03 --> Final output sent to browser
DEBUG - 2012-04-09 15:08:03 --> Total execution time: 0.0831
DEBUG - 2012-04-09 15:08:35 --> Config Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:08:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:08:35 --> URI Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Router Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Output Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Security Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Input Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:08:35 --> Language Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Loader Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:08:35 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Session Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:08:35 --> Session routines successfully run
DEBUG - 2012-04-09 15:08:35 --> Controller Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Model Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Model Class Initialized
DEBUG - 2012-04-09 15:08:35 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:08:35 --> Model Class Initialized
DEBUG - 2012-04-09 15:08:35 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:08:35 --> Final output sent to browser
DEBUG - 2012-04-09 15:08:35 --> Total execution time: 0.0843
DEBUG - 2012-04-09 15:09:03 --> Config Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:09:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:09:03 --> URI Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Router Class Initialized
DEBUG - 2012-04-09 15:09:03 --> No URI present. Default controller set.
DEBUG - 2012-04-09 15:09:03 --> Output Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Security Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Input Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:09:03 --> Language Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Loader Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:09:03 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Session Class Initialized
DEBUG - 2012-04-09 15:09:03 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:09:03 --> Session routines successfully run
DEBUG - 2012-04-09 15:09:03 --> Controller Class Initialized
DEBUG - 2012-04-09 15:09:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 15:09:03 --> Final output sent to browser
DEBUG - 2012-04-09 15:09:03 --> Total execution time: 0.0696
DEBUG - 2012-04-09 15:09:11 --> Config Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:09:11 --> URI Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Router Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Output Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Security Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Input Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:09:11 --> Language Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Loader Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:09:11 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Session Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:09:11 --> Session routines successfully run
DEBUG - 2012-04-09 15:09:11 --> Controller Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Model Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Model Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Config Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:09:11 --> URI Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Router Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Output Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Security Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Input Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:09:11 --> Language Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Loader Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:09:11 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Session Class Initialized
DEBUG - 2012-04-09 15:09:11 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:09:11 --> Session routines successfully run
DEBUG - 2012-04-09 15:09:11 --> Controller Class Initialized
DEBUG - 2012-04-09 15:09:11 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 15:09:11 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 15:09:11 --> Final output sent to browser
DEBUG - 2012-04-09 15:09:11 --> Total execution time: 0.0703
DEBUG - 2012-04-09 15:09:13 --> Config Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:09:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:09:13 --> URI Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Router Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Output Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Security Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Input Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:09:13 --> Language Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Loader Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:09:13 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Session Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:09:13 --> Session routines successfully run
DEBUG - 2012-04-09 15:09:13 --> Controller Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Model Class Initialized
DEBUG - 2012-04-09 15:09:13 --> Model Class Initialized
DEBUG - 2012-04-09 15:09:13 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:09:13 --> Final output sent to browser
DEBUG - 2012-04-09 15:09:13 --> Total execution time: 0.0837
DEBUG - 2012-04-09 15:09:16 --> Config Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:09:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:09:16 --> URI Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Router Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Output Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Security Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Input Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:09:16 --> Language Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Loader Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:09:16 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Session Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:09:16 --> Session routines successfully run
DEBUG - 2012-04-09 15:09:16 --> Controller Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Model Class Initialized
DEBUG - 2012-04-09 15:09:16 --> Model Class Initialized
DEBUG - 2012-04-09 15:09:16 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 15:09:16 --> Final output sent to browser
DEBUG - 2012-04-09 15:09:16 --> Total execution time: 0.0751
DEBUG - 2012-04-09 15:09:49 --> Config Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:09:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:09:49 --> URI Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Router Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Output Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Security Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Input Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:09:49 --> Language Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Loader Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:09:49 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Session Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:09:49 --> Session routines successfully run
DEBUG - 2012-04-09 15:09:49 --> Controller Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Model Class Initialized
DEBUG - 2012-04-09 15:09:49 --> Model Class Initialized
DEBUG - 2012-04-09 15:09:49 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:09:49 --> Final output sent to browser
DEBUG - 2012-04-09 15:09:49 --> Total execution time: 0.0759
DEBUG - 2012-04-09 15:10:14 --> Config Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:10:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:10:14 --> URI Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Router Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Output Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Security Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Input Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:10:14 --> Language Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Loader Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:10:14 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Session Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:10:14 --> Session routines successfully run
DEBUG - 2012-04-09 15:10:14 --> Controller Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Model Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Model Class Initialized
DEBUG - 2012-04-09 15:10:14 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:10:14 --> Model Class Initialized
DEBUG - 2012-04-09 15:10:14 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:10:14 --> Final output sent to browser
DEBUG - 2012-04-09 15:10:14 --> Total execution time: 0.0824
DEBUG - 2012-04-09 15:10:45 --> Config Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:10:45 --> URI Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Router Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Output Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Security Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Input Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:10:45 --> Language Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Loader Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:10:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Session Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:10:45 --> Session routines successfully run
DEBUG - 2012-04-09 15:10:45 --> Controller Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Model Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Model Class Initialized
DEBUG - 2012-04-09 15:10:45 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:10:45 --> Model Class Initialized
DEBUG - 2012-04-09 15:10:45 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:10:45 --> Final output sent to browser
DEBUG - 2012-04-09 15:10:45 --> Total execution time: 0.0832
DEBUG - 2012-04-09 15:11:07 --> Config Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:11:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:11:07 --> URI Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Router Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Output Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Security Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Input Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:11:07 --> Language Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Loader Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:11:07 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Session Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:11:07 --> Session routines successfully run
DEBUG - 2012-04-09 15:11:07 --> Controller Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Model Class Initialized
DEBUG - 2012-04-09 15:11:07 --> Model Class Initialized
DEBUG - 2012-04-09 15:11:07 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:11:07 --> Final output sent to browser
DEBUG - 2012-04-09 15:11:07 --> Total execution time: 0.0761
DEBUG - 2012-04-09 15:11:16 --> Config Class Initialized
DEBUG - 2012-04-09 15:11:16 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:11:16 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:11:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:11:16 --> URI Class Initialized
DEBUG - 2012-04-09 15:11:16 --> Router Class Initialized
DEBUG - 2012-04-09 15:11:16 --> Output Class Initialized
DEBUG - 2012-04-09 15:11:16 --> Security Class Initialized
DEBUG - 2012-04-09 15:11:16 --> Input Class Initialized
DEBUG - 2012-04-09 15:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:11:17 --> Language Class Initialized
DEBUG - 2012-04-09 15:11:17 --> Loader Class Initialized
DEBUG - 2012-04-09 15:11:17 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:11:17 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:11:17 --> Session Class Initialized
DEBUG - 2012-04-09 15:11:17 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:11:17 --> Session routines successfully run
DEBUG - 2012-04-09 15:11:17 --> Controller Class Initialized
DEBUG - 2012-04-09 15:11:17 --> Model Class Initialized
DEBUG - 2012-04-09 15:11:17 --> Model Class Initialized
DEBUG - 2012-04-09 15:11:17 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 15:11:17 --> Final output sent to browser
DEBUG - 2012-04-09 15:11:17 --> Total execution time: 0.0755
DEBUG - 2012-04-09 15:11:44 --> Config Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:11:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:11:44 --> URI Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Router Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Output Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Security Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Input Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:11:44 --> Language Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Loader Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:11:44 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Session Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:11:44 --> Session routines successfully run
DEBUG - 2012-04-09 15:11:44 --> Controller Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Model Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Model Class Initialized
DEBUG - 2012-04-09 15:11:44 --> Model Class Initialized
DEBUG - 2012-04-09 15:11:44 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 15:11:44 --> Final output sent to browser
DEBUG - 2012-04-09 15:11:44 --> Total execution time: 0.2395
DEBUG - 2012-04-09 15:11:46 --> Config Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:11:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:11:46 --> URI Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Router Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Output Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Security Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Input Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:11:46 --> Language Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Loader Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:11:46 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Session Class Initialized
DEBUG - 2012-04-09 15:11:46 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:11:46 --> Session routines successfully run
DEBUG - 2012-04-09 15:11:46 --> Controller Class Initialized
DEBUG - 2012-04-09 15:11:46 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 15:11:46 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 15:11:46 --> Final output sent to browser
DEBUG - 2012-04-09 15:11:46 --> Total execution time: 0.0841
DEBUG - 2012-04-09 15:12:12 --> Config Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:12:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:12:12 --> URI Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Router Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Output Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Security Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Input Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:12:12 --> Language Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Loader Class Initialized
DEBUG - 2012-04-09 15:12:12 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:12:13 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Session Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:12:13 --> Session routines successfully run
DEBUG - 2012-04-09 15:12:13 --> Controller Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Config Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:12:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:12:13 --> URI Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Router Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Output Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Security Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Input Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:12:13 --> Language Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Loader Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:12:13 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Session Class Initialized
DEBUG - 2012-04-09 15:12:13 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:12:13 --> A session cookie was not found.
DEBUG - 2012-04-09 15:12:13 --> Session routines successfully run
DEBUG - 2012-04-09 15:12:13 --> Controller Class Initialized
DEBUG - 2012-04-09 15:12:13 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 15:12:13 --> Final output sent to browser
DEBUG - 2012-04-09 15:12:13 --> Total execution time: 0.0686
DEBUG - 2012-04-09 15:12:15 --> Config Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:12:15 --> URI Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Router Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Output Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Security Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Input Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:12:15 --> Language Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Loader Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:12:15 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Session Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:12:15 --> Session routines successfully run
DEBUG - 2012-04-09 15:12:15 --> Controller Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Model Class Initialized
DEBUG - 2012-04-09 15:12:15 --> Model Class Initialized
DEBUG - 2012-04-09 15:12:15 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:12:15 --> Final output sent to browser
DEBUG - 2012-04-09 15:12:15 --> Total execution time: 0.0816
DEBUG - 2012-04-09 15:12:55 --> Config Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:12:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:12:55 --> URI Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Router Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Output Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Security Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Input Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:12:55 --> Language Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Loader Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:12:55 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Session Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:12:55 --> Session routines successfully run
DEBUG - 2012-04-09 15:12:55 --> Controller Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Model Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Model Class Initialized
DEBUG - 2012-04-09 15:12:55 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:12:55 --> Model Class Initialized
DEBUG - 2012-04-09 15:12:55 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:12:55 --> Final output sent to browser
DEBUG - 2012-04-09 15:12:55 --> Total execution time: 0.0820
DEBUG - 2012-04-09 15:13:07 --> Config Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:13:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:13:07 --> URI Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Router Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Output Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Security Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Input Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:13:07 --> Language Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Loader Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:13:07 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Session Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:13:07 --> Session routines successfully run
DEBUG - 2012-04-09 15:13:07 --> Controller Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Model Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Model Class Initialized
DEBUG - 2012-04-09 15:13:07 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:13:07 --> Model Class Initialized
DEBUG - 2012-04-09 15:13:07 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 15:13:07 --> Final output sent to browser
DEBUG - 2012-04-09 15:13:07 --> Total execution time: 0.0828
DEBUG - 2012-04-09 15:13:34 --> Config Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:13:34 --> URI Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Router Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Output Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Security Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Input Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:13:34 --> Language Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Loader Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:13:34 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Session Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:13:34 --> Session routines successfully run
DEBUG - 2012-04-09 15:13:34 --> Controller Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Model Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Model Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Helper loaded: email_helper
DEBUG - 2012-04-09 15:13:34 --> Model Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Config Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:13:34 --> URI Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Router Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Output Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Security Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Input Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:13:34 --> Language Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Loader Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:13:34 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Session Class Initialized
DEBUG - 2012-04-09 15:13:34 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:13:34 --> Session routines successfully run
DEBUG - 2012-04-09 15:13:34 --> Controller Class Initialized
DEBUG - 2012-04-09 15:13:34 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-09 15:13:34 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 15:13:34 --> Final output sent to browser
DEBUG - 2012-04-09 15:13:34 --> Total execution time: 0.0692
DEBUG - 2012-04-09 15:13:37 --> Config Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:13:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:13:37 --> URI Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Router Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Output Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Security Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Input Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:13:37 --> Language Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Loader Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:13:37 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Session Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:13:37 --> Session routines successfully run
DEBUG - 2012-04-09 15:13:37 --> Controller Class Initialized
DEBUG - 2012-04-09 15:13:37 --> Final output sent to browser
DEBUG - 2012-04-09 15:13:37 --> Total execution time: 0.0687
DEBUG - 2012-04-09 15:14:18 --> Config Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:14:18 --> URI Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Router Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Output Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Security Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Input Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:14:18 --> Language Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Loader Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:14:18 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Session Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:14:18 --> Session routines successfully run
DEBUG - 2012-04-09 15:14:18 --> Controller Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Config Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:14:18 --> URI Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Router Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Output Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Security Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Input Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:14:18 --> Language Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Loader Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:14:18 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Session Class Initialized
DEBUG - 2012-04-09 15:14:18 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:14:18 --> A session cookie was not found.
DEBUG - 2012-04-09 15:14:18 --> Session routines successfully run
DEBUG - 2012-04-09 15:14:18 --> Controller Class Initialized
DEBUG - 2012-04-09 15:14:18 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 15:14:18 --> Final output sent to browser
DEBUG - 2012-04-09 15:14:18 --> Total execution time: 0.0696
DEBUG - 2012-04-09 15:42:06 --> Config Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:42:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:42:06 --> URI Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Router Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Output Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Security Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Input Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:42:06 --> Language Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Loader Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:42:06 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Session Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:42:06 --> Session routines successfully run
DEBUG - 2012-04-09 15:42:06 --> Controller Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Config Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:42:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:42:06 --> URI Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Router Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Output Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Security Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Input Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:42:06 --> Language Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Loader Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:42:06 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Session Class Initialized
DEBUG - 2012-04-09 15:42:06 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:42:06 --> Session routines successfully run
DEBUG - 2012-04-09 15:42:06 --> Controller Class Initialized
DEBUG - 2012-04-09 15:42:06 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 15:42:06 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 15:42:06 --> Final output sent to browser
DEBUG - 2012-04-09 15:42:06 --> Total execution time: 0.2447
DEBUG - 2012-04-09 15:42:08 --> Config Class Initialized
DEBUG - 2012-04-09 15:42:08 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:42:08 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:42:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:42:08 --> URI Class Initialized
DEBUG - 2012-04-09 15:42:08 --> Router Class Initialized
DEBUG - 2012-04-09 15:42:08 --> Output Class Initialized
DEBUG - 2012-04-09 15:42:08 --> Security Class Initialized
DEBUG - 2012-04-09 15:42:08 --> Input Class Initialized
DEBUG - 2012-04-09 15:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:42:08 --> Language Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Config Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:42:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:42:33 --> URI Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Router Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Output Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Security Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Input Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:42:33 --> Language Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Loader Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:42:33 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Session Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:42:33 --> Session routines successfully run
DEBUG - 2012-04-09 15:42:33 --> Controller Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:33 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:33 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 15:42:33 --> Final output sent to browser
DEBUG - 2012-04-09 15:42:33 --> Total execution time: 0.2723
DEBUG - 2012-04-09 15:42:46 --> Config Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:42:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:42:46 --> URI Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Router Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Output Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Security Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Input Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:42:46 --> Language Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Loader Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:42:46 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Session Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:42:46 --> Session routines successfully run
DEBUG - 2012-04-09 15:42:46 --> Controller Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:46 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:46 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-09 15:42:46 --> Final output sent to browser
DEBUG - 2012-04-09 15:42:46 --> Total execution time: 0.2769
DEBUG - 2012-04-09 15:42:49 --> Config Class Initialized
DEBUG - 2012-04-09 15:42:49 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:42:49 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:42:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:42:49 --> URI Class Initialized
DEBUG - 2012-04-09 15:42:49 --> Router Class Initialized
DEBUG - 2012-04-09 15:42:49 --> Output Class Initialized
DEBUG - 2012-04-09 15:42:49 --> Security Class Initialized
DEBUG - 2012-04-09 15:42:49 --> Input Class Initialized
DEBUG - 2012-04-09 15:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:42:49 --> Language Class Initialized
DEBUG - 2012-04-09 15:42:50 --> Loader Class Initialized
DEBUG - 2012-04-09 15:42:50 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:42:50 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:42:50 --> Session Class Initialized
DEBUG - 2012-04-09 15:42:50 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:42:50 --> Session routines successfully run
DEBUG - 2012-04-09 15:42:50 --> Controller Class Initialized
DEBUG - 2012-04-09 15:42:50 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:50 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:50 --> Final output sent to browser
DEBUG - 2012-04-09 15:42:50 --> Total execution time: 0.2463
DEBUG - 2012-04-09 15:42:53 --> Config Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:42:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:42:53 --> URI Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Router Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Output Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Security Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Input Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:42:53 --> Language Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Loader Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:42:53 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Session Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:42:53 --> Session routines successfully run
DEBUG - 2012-04-09 15:42:53 --> Controller Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:53 --> Model Class Initialized
DEBUG - 2012-04-09 15:42:53 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 15:42:53 --> Final output sent to browser
DEBUG - 2012-04-09 15:42:53 --> Total execution time: 0.2570
DEBUG - 2012-04-09 15:44:05 --> Config Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:44:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:44:05 --> URI Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Router Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Output Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Security Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Input Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:44:05 --> Language Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Loader Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:44:05 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Session Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:44:05 --> Session routines successfully run
DEBUG - 2012-04-09 15:44:05 --> Controller Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Model Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Model Class Initialized
DEBUG - 2012-04-09 15:44:05 --> Model Class Initialized
DEBUG - 2012-04-09 15:44:05 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 15:44:05 --> Final output sent to browser
DEBUG - 2012-04-09 15:44:05 --> Total execution time: 0.3375
DEBUG - 2012-04-09 15:52:40 --> Config Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:52:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:52:40 --> URI Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Router Class Initialized
DEBUG - 2012-04-09 15:52:40 --> No URI present. Default controller set.
DEBUG - 2012-04-09 15:52:40 --> Output Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Security Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Input Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:52:40 --> Language Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Loader Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:52:40 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Session Class Initialized
DEBUG - 2012-04-09 15:52:40 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:52:40 --> Session routines successfully run
DEBUG - 2012-04-09 15:52:40 --> Controller Class Initialized
DEBUG - 2012-04-09 15:52:40 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 15:52:40 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 15:52:40 --> Final output sent to browser
DEBUG - 2012-04-09 15:52:40 --> Total execution time: 0.2934
DEBUG - 2012-04-09 15:52:41 --> Config Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:52:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:52:41 --> URI Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Router Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Output Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Security Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Input Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:52:41 --> Language Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Loader Class Initialized
DEBUG - 2012-04-09 15:52:41 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:52:42 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:52:42 --> Session Class Initialized
DEBUG - 2012-04-09 15:52:42 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:52:42 --> Session routines successfully run
DEBUG - 2012-04-09 15:52:42 --> Controller Class Initialized
DEBUG - 2012-04-09 15:52:42 --> Model Class Initialized
DEBUG - 2012-04-09 15:52:42 --> Model Class Initialized
DEBUG - 2012-04-09 15:52:42 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 15:52:42 --> Final output sent to browser
DEBUG - 2012-04-09 15:52:42 --> Total execution time: 0.3028
DEBUG - 2012-04-09 15:52:51 --> Config Class Initialized
DEBUG - 2012-04-09 15:52:51 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:52:51 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:52:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:52:51 --> URI Class Initialized
DEBUG - 2012-04-09 15:52:51 --> Router Class Initialized
DEBUG - 2012-04-09 15:52:51 --> Output Class Initialized
DEBUG - 2012-04-09 15:52:51 --> Security Class Initialized
DEBUG - 2012-04-09 15:52:51 --> Input Class Initialized
DEBUG - 2012-04-09 15:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:52:51 --> Language Class Initialized
DEBUG - 2012-04-09 15:52:51 --> Loader Class Initialized
DEBUG - 2012-04-09 15:52:52 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:52:52 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:52:52 --> Session Class Initialized
DEBUG - 2012-04-09 15:52:52 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:52:52 --> Session routines successfully run
DEBUG - 2012-04-09 15:52:52 --> Controller Class Initialized
DEBUG - 2012-04-09 15:52:52 --> Model Class Initialized
DEBUG - 2012-04-09 15:52:52 --> Model Class Initialized
DEBUG - 2012-04-09 15:52:52 --> Model Class Initialized
ERROR - 2012-04-09 15:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\models\block.php 14
DEBUG - 2012-04-09 15:52:52 --> DB Transaction Failure
ERROR - 2012-04-09 15:52:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' 3, 1, 20)' at line 1
DEBUG - 2012-04-09 15:52:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 15:54:41 --> Config Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:54:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:54:41 --> URI Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Router Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Output Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Security Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Input Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:54:41 --> Language Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Loader Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:54:41 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Session Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:54:41 --> Session routines successfully run
DEBUG - 2012-04-09 15:54:41 --> Controller Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Model Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Model Class Initialized
DEBUG - 2012-04-09 15:54:41 --> Model Class Initialized
DEBUG - 2012-04-09 15:54:41 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 15:54:41 --> Final output sent to browser
DEBUG - 2012-04-09 15:54:41 --> Total execution time: 0.4245
DEBUG - 2012-04-09 15:54:46 --> Config Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:54:46 --> URI Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Router Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Output Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Security Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Input Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:54:46 --> Language Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Loader Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:54:46 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Session Class Initialized
DEBUG - 2012-04-09 15:54:46 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:54:46 --> Session routines successfully run
DEBUG - 2012-04-09 15:54:46 --> Controller Class Initialized
DEBUG - 2012-04-09 15:54:46 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 15:54:46 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 15:54:46 --> Final output sent to browser
DEBUG - 2012-04-09 15:54:46 --> Total execution time: 0.2502
DEBUG - 2012-04-09 15:54:57 --> Config Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:54:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:54:57 --> URI Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Router Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Output Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Security Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Input Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:54:57 --> Language Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Loader Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:54:57 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Session Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:54:57 --> Session routines successfully run
DEBUG - 2012-04-09 15:54:57 --> Controller Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Model Class Initialized
DEBUG - 2012-04-09 15:54:57 --> Model Class Initialized
DEBUG - 2012-04-09 15:54:57 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 15:54:57 --> Final output sent to browser
DEBUG - 2012-04-09 15:54:57 --> Total execution time: 0.2535
DEBUG - 2012-04-09 15:55:12 --> Config Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:55:12 --> URI Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Router Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Output Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Security Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Input Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:55:12 --> Language Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Loader Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:55:12 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Session Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:55:12 --> Session routines successfully run
DEBUG - 2012-04-09 15:55:12 --> Controller Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:12 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:12 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-09 15:55:12 --> Final output sent to browser
DEBUG - 2012-04-09 15:55:12 --> Total execution time: 0.2822
DEBUG - 2012-04-09 15:55:14 --> Config Class Initialized
DEBUG - 2012-04-09 15:55:14 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:55:14 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:55:14 --> URI Class Initialized
DEBUG - 2012-04-09 15:55:14 --> Router Class Initialized
DEBUG - 2012-04-09 15:55:14 --> Output Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Security Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Input Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:55:15 --> Language Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Loader Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:55:15 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Session Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:55:15 --> Session routines successfully run
DEBUG - 2012-04-09 15:55:15 --> Controller Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:15 --> Final output sent to browser
DEBUG - 2012-04-09 15:55:15 --> Total execution time: 0.2971
DEBUG - 2012-04-09 15:55:18 --> Config Class Initialized
DEBUG - 2012-04-09 15:55:18 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:55:18 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:55:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:55:18 --> URI Class Initialized
DEBUG - 2012-04-09 15:55:18 --> Router Class Initialized
DEBUG - 2012-04-09 15:55:18 --> Output Class Initialized
DEBUG - 2012-04-09 15:55:18 --> Security Class Initialized
DEBUG - 2012-04-09 15:55:19 --> Input Class Initialized
DEBUG - 2012-04-09 15:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:55:19 --> Language Class Initialized
DEBUG - 2012-04-09 15:55:19 --> Loader Class Initialized
DEBUG - 2012-04-09 15:55:19 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:55:19 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:55:19 --> Session Class Initialized
DEBUG - 2012-04-09 15:55:19 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:55:19 --> Session routines successfully run
DEBUG - 2012-04-09 15:55:19 --> Controller Class Initialized
DEBUG - 2012-04-09 15:55:19 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:19 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:19 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 15:55:19 --> Final output sent to browser
DEBUG - 2012-04-09 15:55:19 --> Total execution time: 0.2761
DEBUG - 2012-04-09 15:55:44 --> Config Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:55:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:55:44 --> URI Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Router Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Output Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Security Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Input Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:55:44 --> Language Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Loader Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:55:44 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Session Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:55:44 --> Session routines successfully run
DEBUG - 2012-04-09 15:55:44 --> Controller Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:44 --> Model Class Initialized
DEBUG - 2012-04-09 15:55:44 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 15:55:44 --> Final output sent to browser
DEBUG - 2012-04-09 15:55:44 --> Total execution time: 0.3932
DEBUG - 2012-04-09 15:56:04 --> Config Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:56:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:56:04 --> URI Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Router Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Output Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Security Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Input Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:56:04 --> Language Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Loader Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:56:04 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Session Class Initialized
DEBUG - 2012-04-09 15:56:04 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:56:04 --> Session routines successfully run
DEBUG - 2012-04-09 15:56:04 --> Controller Class Initialized
DEBUG - 2012-04-09 15:56:04 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 15:56:04 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 15:56:04 --> Final output sent to browser
DEBUG - 2012-04-09 15:56:04 --> Total execution time: 0.2387
DEBUG - 2012-04-09 15:56:13 --> Config Class Initialized
DEBUG - 2012-04-09 15:56:13 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:56:13 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:56:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:56:13 --> URI Class Initialized
DEBUG - 2012-04-09 15:56:13 --> Router Class Initialized
DEBUG - 2012-04-09 15:56:13 --> Output Class Initialized
DEBUG - 2012-04-09 15:56:13 --> Security Class Initialized
DEBUG - 2012-04-09 15:56:13 --> Input Class Initialized
DEBUG - 2012-04-09 15:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:56:13 --> Language Class Initialized
DEBUG - 2012-04-09 15:56:14 --> Loader Class Initialized
DEBUG - 2012-04-09 15:56:14 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:56:14 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:56:14 --> Session Class Initialized
DEBUG - 2012-04-09 15:56:14 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:56:14 --> Session routines successfully run
DEBUG - 2012-04-09 15:56:14 --> Controller Class Initialized
DEBUG - 2012-04-09 15:56:14 --> Model Class Initialized
DEBUG - 2012-04-09 15:56:14 --> Model Class Initialized
DEBUG - 2012-04-09 15:56:14 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 15:56:14 --> Final output sent to browser
DEBUG - 2012-04-09 15:56:14 --> Total execution time: 0.2595
DEBUG - 2012-04-09 15:56:26 --> Config Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:56:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:56:26 --> URI Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Router Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Output Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Security Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Input Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:56:26 --> Language Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Loader Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:56:26 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Session Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:56:26 --> Session routines successfully run
DEBUG - 2012-04-09 15:56:26 --> Controller Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Model Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Model Class Initialized
DEBUG - 2012-04-09 15:56:26 --> Model Class Initialized
DEBUG - 2012-04-09 15:56:26 --> DB Transaction Failure
ERROR - 2012-04-09 15:56:26 --> Query error: Duplicate entry '1' for key 'PRIMARY'
DEBUG - 2012-04-09 15:56:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 15:57:11 --> Config Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Hooks Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Utf8 Class Initialized
DEBUG - 2012-04-09 15:57:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 15:57:11 --> URI Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Router Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Output Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Security Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Input Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 15:57:11 --> Language Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Loader Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Helper loaded: url_helper
DEBUG - 2012-04-09 15:57:11 --> Database Driver Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Session Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Helper loaded: string_helper
DEBUG - 2012-04-09 15:57:11 --> Session routines successfully run
DEBUG - 2012-04-09 15:57:11 --> Controller Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Model Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Model Class Initialized
DEBUG - 2012-04-09 15:57:11 --> Model Class Initialized
DEBUG - 2012-04-09 15:57:11 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 15:57:11 --> Final output sent to browser
DEBUG - 2012-04-09 15:57:11 --> Total execution time: 0.3569
DEBUG - 2012-04-09 16:00:02 --> Config Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:00:02 --> URI Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Router Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Output Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Security Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Input Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:00:02 --> Language Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Loader Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:00:02 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Session Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:00:02 --> Session routines successfully run
DEBUG - 2012-04-09 16:00:02 --> Controller Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Config Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:00:02 --> URI Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Router Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Output Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Security Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Input Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:00:02 --> Language Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Loader Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:00:02 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Session Class Initialized
DEBUG - 2012-04-09 16:00:02 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:00:02 --> A session cookie was not found.
DEBUG - 2012-04-09 16:00:02 --> Session routines successfully run
DEBUG - 2012-04-09 16:00:02 --> Controller Class Initialized
DEBUG - 2012-04-09 16:00:02 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 16:00:02 --> Final output sent to browser
DEBUG - 2012-04-09 16:00:02 --> Total execution time: 0.2455
DEBUG - 2012-04-09 16:00:04 --> Config Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:00:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:00:04 --> URI Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Router Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Output Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Security Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Input Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:00:04 --> Language Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Loader Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:00:04 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Session Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:00:04 --> Session routines successfully run
DEBUG - 2012-04-09 16:00:04 --> Controller Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Model Class Initialized
DEBUG - 2012-04-09 16:00:04 --> Model Class Initialized
DEBUG - 2012-04-09 16:00:04 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:00:04 --> Final output sent to browser
DEBUG - 2012-04-09 16:00:04 --> Total execution time: 0.2501
DEBUG - 2012-04-09 16:00:45 --> Config Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:00:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:00:45 --> URI Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Router Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Output Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Security Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Input Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:00:45 --> Language Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Loader Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:00:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Session Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:00:45 --> Session routines successfully run
DEBUG - 2012-04-09 16:00:45 --> Controller Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Model Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Model Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:00:45 --> Model Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Config Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:00:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:00:45 --> URI Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Router Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Output Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Security Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Input Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:00:45 --> Language Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Loader Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:00:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Session Class Initialized
DEBUG - 2012-04-09 16:00:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:00:45 --> Session routines successfully run
DEBUG - 2012-04-09 16:00:45 --> Controller Class Initialized
DEBUG - 2012-04-09 16:00:45 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-09 16:00:45 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:00:45 --> Final output sent to browser
DEBUG - 2012-04-09 16:00:46 --> Total execution time: 0.2382
DEBUG - 2012-04-09 16:00:58 --> Config Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:00:58 --> URI Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Router Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Output Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Security Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Input Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:00:58 --> Language Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Loader Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:00:58 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Session Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:00:58 --> Session routines successfully run
DEBUG - 2012-04-09 16:00:58 --> Controller Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Config Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:00:58 --> URI Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Router Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Output Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Security Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Input Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:00:58 --> Language Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Loader Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:00:58 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Session Class Initialized
DEBUG - 2012-04-09 16:00:58 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:00:58 --> A session cookie was not found.
DEBUG - 2012-04-09 16:00:58 --> Session routines successfully run
DEBUG - 2012-04-09 16:00:58 --> Controller Class Initialized
DEBUG - 2012-04-09 16:00:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 16:00:58 --> Final output sent to browser
DEBUG - 2012-04-09 16:00:58 --> Total execution time: 0.2399
DEBUG - 2012-04-09 16:07:19 --> Config Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:07:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:07:19 --> URI Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Router Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Output Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Security Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Input Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:07:19 --> Language Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Loader Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:07:19 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Session Class Initialized
DEBUG - 2012-04-09 16:07:19 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:07:19 --> Session routines successfully run
DEBUG - 2012-04-09 16:07:19 --> Controller Class Initialized
DEBUG - 2012-04-09 16:07:19 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 16:07:19 --> Final output sent to browser
DEBUG - 2012-04-09 16:07:19 --> Total execution time: 0.2347
DEBUG - 2012-04-09 16:07:27 --> Config Class Initialized
DEBUG - 2012-04-09 16:07:27 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:07:27 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:07:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:07:27 --> URI Class Initialized
DEBUG - 2012-04-09 16:07:27 --> Router Class Initialized
DEBUG - 2012-04-09 16:07:27 --> Output Class Initialized
DEBUG - 2012-04-09 16:07:27 --> Security Class Initialized
DEBUG - 2012-04-09 16:07:27 --> Input Class Initialized
DEBUG - 2012-04-09 16:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:07:27 --> Language Class Initialized
DEBUG - 2012-04-09 16:07:27 --> Loader Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:07:28 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Session Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:07:28 --> Session routines successfully run
DEBUG - 2012-04-09 16:07:28 --> Controller Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Model Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Model Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Config Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:07:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:07:28 --> URI Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Router Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Output Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Security Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Input Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:07:28 --> Language Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Loader Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:07:28 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Session Class Initialized
DEBUG - 2012-04-09 16:07:28 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:07:28 --> Session routines successfully run
DEBUG - 2012-04-09 16:07:28 --> Controller Class Initialized
DEBUG - 2012-04-09 16:07:28 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:07:28 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:07:28 --> Final output sent to browser
DEBUG - 2012-04-09 16:07:28 --> Total execution time: 0.2556
DEBUG - 2012-04-09 16:08:44 --> Config Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:08:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:08:44 --> URI Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Router Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Output Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Security Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Input Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:08:44 --> Language Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Loader Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:08:44 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Session Class Initialized
DEBUG - 2012-04-09 16:08:44 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:08:44 --> Session routines successfully run
DEBUG - 2012-04-09 16:08:44 --> Controller Class Initialized
DEBUG - 2012-04-09 16:08:44 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:08:44 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:08:44 --> Final output sent to browser
DEBUG - 2012-04-09 16:08:44 --> Total execution time: 0.2401
DEBUG - 2012-04-09 16:08:46 --> Config Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:08:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:08:46 --> URI Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Router Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Output Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Security Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Input Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:08:46 --> Language Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Loader Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:08:46 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Session Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:08:46 --> Session routines successfully run
DEBUG - 2012-04-09 16:08:46 --> Controller Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Model Class Initialized
DEBUG - 2012-04-09 16:08:46 --> Model Class Initialized
DEBUG - 2012-04-09 16:08:46 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-09 16:08:46 --> Final output sent to browser
DEBUG - 2012-04-09 16:08:46 --> Total execution time: 0.3001
DEBUG - 2012-04-09 16:10:18 --> Config Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:10:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:10:18 --> URI Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Router Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Output Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Security Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Input Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:10:18 --> Language Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Loader Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:10:18 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Session Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:10:18 --> Session routines successfully run
DEBUG - 2012-04-09 16:10:18 --> Controller Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Model Class Initialized
DEBUG - 2012-04-09 16:10:18 --> Model Class Initialized
DEBUG - 2012-04-09 16:10:18 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-09 16:10:18 --> Final output sent to browser
DEBUG - 2012-04-09 16:10:18 --> Total execution time: 0.2552
DEBUG - 2012-04-09 16:10:36 --> Config Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:10:36 --> URI Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Router Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Output Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Security Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Input Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:10:36 --> Language Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Loader Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:10:36 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Session Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:10:36 --> Session routines successfully run
DEBUG - 2012-04-09 16:10:36 --> Controller Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Model Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Model Class Initialized
DEBUG - 2012-04-09 16:10:36 --> Final output sent to browser
DEBUG - 2012-04-09 16:10:36 --> Total execution time: 0.2470
DEBUG - 2012-04-09 16:12:02 --> Config Class Initialized
DEBUG - 2012-04-09 16:12:02 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:12:02 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:12:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:12:02 --> URI Class Initialized
DEBUG - 2012-04-09 16:12:02 --> Router Class Initialized
DEBUG - 2012-04-09 16:12:02 --> Output Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Security Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Input Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:12:03 --> Language Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Loader Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:12:03 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Session Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:12:03 --> Session routines successfully run
DEBUG - 2012-04-09 16:12:03 --> Controller Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Model Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Model Class Initialized
DEBUG - 2012-04-09 16:12:03 --> Final output sent to browser
DEBUG - 2012-04-09 16:12:03 --> Total execution time: 0.2495
DEBUG - 2012-04-09 16:17:00 --> Config Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:17:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:17:00 --> URI Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Router Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Output Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Security Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Input Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:17:00 --> Language Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Loader Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:17:00 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Session Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:17:00 --> Session routines successfully run
DEBUG - 2012-04-09 16:17:00 --> Controller Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Model Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Model Class Initialized
DEBUG - 2012-04-09 16:17:00 --> Final output sent to browser
DEBUG - 2012-04-09 16:17:00 --> Total execution time: 0.2598
DEBUG - 2012-04-09 16:20:00 --> Config Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:20:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:20:00 --> URI Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Router Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Output Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Security Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Input Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:20:00 --> Language Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Loader Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:20:00 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Session Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:20:00 --> Session routines successfully run
DEBUG - 2012-04-09 16:20:00 --> Controller Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Model Class Initialized
DEBUG - 2012-04-09 16:20:00 --> Model Class Initialized
DEBUG - 2012-04-09 16:20:00 --> DB Transaction Failure
ERROR - 2012-04-09 16:20:00 --> Query error: Table 'sxccms.blockinfo' doesn't exist
DEBUG - 2012-04-09 16:20:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 16:20:30 --> Config Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:20:30 --> URI Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Router Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Output Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Security Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Input Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:20:30 --> Language Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Loader Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:20:30 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Session Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:20:30 --> Session routines successfully run
DEBUG - 2012-04-09 16:20:30 --> Controller Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Model Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Model Class Initialized
DEBUG - 2012-04-09 16:20:30 --> Final output sent to browser
DEBUG - 2012-04-09 16:20:30 --> Total execution time: 0.2617
DEBUG - 2012-04-09 16:20:32 --> Config Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:20:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:20:32 --> URI Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Router Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Output Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Security Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Input Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:20:32 --> Language Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Loader Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:20:32 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Session Class Initialized
DEBUG - 2012-04-09 16:20:32 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:20:32 --> Session routines successfully run
DEBUG - 2012-04-09 16:20:32 --> Controller Class Initialized
DEBUG - 2012-04-09 16:20:32 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:20:32 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:20:32 --> Final output sent to browser
DEBUG - 2012-04-09 16:20:32 --> Total execution time: 0.2456
DEBUG - 2012-04-09 16:20:45 --> Config Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:20:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:20:45 --> URI Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Router Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Output Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Security Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Input Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:20:45 --> Language Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Loader Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:20:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Session Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:20:45 --> Session routines successfully run
DEBUG - 2012-04-09 16:20:45 --> Controller Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Model Class Initialized
DEBUG - 2012-04-09 16:20:45 --> Model Class Initialized
DEBUG - 2012-04-09 16:20:45 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:20:45 --> Final output sent to browser
DEBUG - 2012-04-09 16:20:45 --> Total execution time: 0.2618
DEBUG - 2012-04-09 16:21:23 --> Config Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:21:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:21:23 --> URI Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Router Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Output Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Security Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Input Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:21:23 --> Language Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Loader Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:21:23 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Session Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:21:23 --> Session routines successfully run
DEBUG - 2012-04-09 16:21:23 --> Controller Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Model Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Model Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:21:23 --> Model Class Initialized
DEBUG - 2012-04-09 16:21:23 --> Final output sent to browser
DEBUG - 2012-04-09 16:21:23 --> Total execution time: 0.2939
DEBUG - 2012-04-09 16:21:25 --> Config Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:21:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:21:25 --> URI Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Router Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Output Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Security Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Input Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:21:25 --> Language Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Loader Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:21:25 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Session Class Initialized
DEBUG - 2012-04-09 16:21:25 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:21:25 --> Session routines successfully run
DEBUG - 2012-04-09 16:21:25 --> Controller Class Initialized
DEBUG - 2012-04-09 16:21:25 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:21:25 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:21:25 --> Final output sent to browser
DEBUG - 2012-04-09 16:21:25 --> Total execution time: 0.1906
DEBUG - 2012-04-09 16:21:30 --> Config Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:21:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:21:30 --> URI Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Router Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Output Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Security Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Input Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:21:30 --> Language Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Loader Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:21:30 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Session Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:21:30 --> Session routines successfully run
DEBUG - 2012-04-09 16:21:30 --> Controller Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Model Class Initialized
DEBUG - 2012-04-09 16:21:30 --> Model Class Initialized
DEBUG - 2012-04-09 16:21:30 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 16:21:30 --> Final output sent to browser
DEBUG - 2012-04-09 16:21:30 --> Total execution time: 0.2573
DEBUG - 2012-04-09 16:22:21 --> Config Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:22:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:22:21 --> URI Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Router Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Output Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Security Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Input Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:22:21 --> Language Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Loader Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:22:21 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Session Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:22:21 --> Session routines successfully run
DEBUG - 2012-04-09 16:22:21 --> Controller Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:22:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:22:21 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 16:22:21 --> Final output sent to browser
DEBUG - 2012-04-09 16:22:21 --> Total execution time: 0.3553
DEBUG - 2012-04-09 16:22:32 --> Config Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:22:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:22:32 --> URI Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Router Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Output Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Security Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Input Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:22:32 --> Language Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Loader Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:22:32 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Session Class Initialized
DEBUG - 2012-04-09 16:22:32 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:22:32 --> Session routines successfully run
DEBUG - 2012-04-09 16:22:32 --> Controller Class Initialized
DEBUG - 2012-04-09 16:22:32 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:22:32 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:22:32 --> Final output sent to browser
DEBUG - 2012-04-09 16:22:32 --> Total execution time: 0.2597
DEBUG - 2012-04-09 16:22:34 --> Config Class Initialized
DEBUG - 2012-04-09 16:22:34 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:22:35 --> URI Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Router Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Output Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Security Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Input Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:22:35 --> Language Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Loader Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:22:35 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Session Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:22:35 --> Session routines successfully run
DEBUG - 2012-04-09 16:22:35 --> Controller Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Config Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:22:35 --> URI Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Router Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Output Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Security Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Input Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:22:35 --> Language Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Loader Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:22:35 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Session Class Initialized
DEBUG - 2012-04-09 16:22:35 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:22:35 --> A session cookie was not found.
DEBUG - 2012-04-09 16:22:35 --> Session routines successfully run
DEBUG - 2012-04-09 16:22:35 --> Controller Class Initialized
DEBUG - 2012-04-09 16:22:35 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 16:22:35 --> Final output sent to browser
DEBUG - 2012-04-09 16:22:35 --> Total execution time: 0.2037
DEBUG - 2012-04-09 16:22:37 --> Config Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:22:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:22:37 --> URI Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Router Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Output Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Security Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Input Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:22:37 --> Language Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Loader Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:22:37 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Session Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:22:37 --> Session routines successfully run
DEBUG - 2012-04-09 16:22:37 --> Controller Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Model Class Initialized
DEBUG - 2012-04-09 16:22:37 --> Model Class Initialized
DEBUG - 2012-04-09 16:22:37 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:22:37 --> Final output sent to browser
DEBUG - 2012-04-09 16:22:37 --> Total execution time: 0.2946
DEBUG - 2012-04-09 16:23:20 --> Config Class Initialized
DEBUG - 2012-04-09 16:23:20 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:23:20 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:23:20 --> URI Class Initialized
DEBUG - 2012-04-09 16:23:20 --> Router Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Output Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Security Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Input Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:23:21 --> Language Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Loader Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:23:21 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Session Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:23:21 --> Session routines successfully run
DEBUG - 2012-04-09 16:23:21 --> Controller Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:23:21 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:23:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:23:21 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:23:21 --> Final output sent to browser
DEBUG - 2012-04-09 16:23:21 --> Total execution time: 0.2936
DEBUG - 2012-04-09 16:23:33 --> Config Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:23:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:23:33 --> URI Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Router Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Output Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Security Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Input Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:23:33 --> Language Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Loader Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:23:33 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Session Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:23:33 --> Session routines successfully run
DEBUG - 2012-04-09 16:23:33 --> Controller Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Model Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Model Class Initialized
DEBUG - 2012-04-09 16:23:33 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:23:33 --> Model Class Initialized
DEBUG - 2012-04-09 16:23:33 --> DB Transaction Failure
ERROR - 2012-04-09 16:23:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 16:23:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 16:26:23 --> Config Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:26:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:26:23 --> URI Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Router Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Output Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Security Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Input Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:26:23 --> Language Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Loader Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:26:23 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Session Class Initialized
DEBUG - 2012-04-09 16:26:23 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:26:23 --> Session routines successfully run
DEBUG - 2012-04-09 16:26:24 --> Controller Class Initialized
DEBUG - 2012-04-09 16:26:24 --> Model Class Initialized
DEBUG - 2012-04-09 16:26:24 --> Model Class Initialized
DEBUG - 2012-04-09 16:26:24 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:26:24 --> Model Class Initialized
DEBUG - 2012-04-09 16:26:24 --> DB Transaction Failure
ERROR - 2012-04-09 16:26:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 16:26:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 16:27:57 --> Config Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:27:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:27:58 --> URI Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Router Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Output Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Security Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Input Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:27:58 --> Language Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Loader Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:27:58 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Session Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:27:58 --> Session routines successfully run
DEBUG - 2012-04-09 16:27:58 --> Controller Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Model Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Model Class Initialized
DEBUG - 2012-04-09 16:27:58 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:27:58 --> Model Class Initialized
DEBUG - 2012-04-09 16:27:58 --> DB Transaction Failure
ERROR - 2012-04-09 16:27:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 16:27:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 16:29:58 --> Config Class Initialized
DEBUG - 2012-04-09 16:29:58 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:29:58 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:29:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:29:58 --> URI Class Initialized
DEBUG - 2012-04-09 16:29:58 --> Router Class Initialized
DEBUG - 2012-04-09 16:29:58 --> Output Class Initialized
DEBUG - 2012-04-09 16:29:58 --> Security Class Initialized
DEBUG - 2012-04-09 16:29:58 --> Input Class Initialized
DEBUG - 2012-04-09 16:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:29:58 --> Language Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Config Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:30:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:30:26 --> URI Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Router Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Output Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Security Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Input Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:30:26 --> Language Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Loader Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:30:26 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Session Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:30:26 --> Session routines successfully run
DEBUG - 2012-04-09 16:30:26 --> Controller Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Model Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Model Class Initialized
DEBUG - 2012-04-09 16:30:26 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:30:26 --> Model Class Initialized
DEBUG - 2012-04-09 16:30:26 --> DB Transaction Failure
ERROR - 2012-04-09 16:30:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2012-04-09 16:30:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-04-09 16:35:56 --> Config Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:35:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:35:56 --> URI Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Router Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Output Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Security Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Input Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:35:56 --> Language Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Loader Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:35:56 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Session Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:35:56 --> Session routines successfully run
DEBUG - 2012-04-09 16:35:56 --> Controller Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Model Class Initialized
DEBUG - 2012-04-09 16:35:56 --> Model Class Initialized
ERROR - 2012-04-09 16:35:56 --> Severity: Notice  --> Undefined variable: Code C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 102
DEBUG - 2012-04-09 16:35:56 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:35:56 --> Final output sent to browser
DEBUG - 2012-04-09 16:35:56 --> Total execution time: 0.2727
DEBUG - 2012-04-09 16:36:37 --> Config Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:36:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:36:37 --> URI Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Router Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Output Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Security Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Input Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:36:37 --> Language Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Loader Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:36:37 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Session Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:36:37 --> Session routines successfully run
DEBUG - 2012-04-09 16:36:37 --> Controller Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Model Class Initialized
DEBUG - 2012-04-09 16:36:37 --> Model Class Initialized
DEBUG - 2012-04-09 16:36:37 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:36:37 --> Final output sent to browser
DEBUG - 2012-04-09 16:36:37 --> Total execution time: 0.2658
DEBUG - 2012-04-09 16:41:46 --> Config Class Initialized
DEBUG - 2012-04-09 16:41:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:41:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:41:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:41:46 --> URI Class Initialized
DEBUG - 2012-04-09 16:41:46 --> Router Class Initialized
DEBUG - 2012-04-09 16:41:46 --> Output Class Initialized
DEBUG - 2012-04-09 16:41:46 --> Security Class Initialized
DEBUG - 2012-04-09 16:41:46 --> Input Class Initialized
DEBUG - 2012-04-09 16:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:41:47 --> Language Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Loader Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:41:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Session Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:41:47 --> Session routines successfully run
DEBUG - 2012-04-09 16:41:47 --> Controller Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Model Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Model Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Config Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:41:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:41:47 --> URI Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Router Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Output Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Security Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Input Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:41:47 --> Language Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Loader Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:41:47 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Session Class Initialized
DEBUG - 2012-04-09 16:41:47 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:41:47 --> Session routines successfully run
DEBUG - 2012-04-09 16:41:47 --> Controller Class Initialized
DEBUG - 2012-04-09 16:41:47 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:41:47 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:41:47 --> Final output sent to browser
DEBUG - 2012-04-09 16:41:47 --> Total execution time: 0.2427
DEBUG - 2012-04-09 16:41:49 --> Config Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:41:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:41:49 --> URI Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Router Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Output Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Security Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Input Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:41:49 --> Language Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Loader Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:41:49 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Session Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:41:49 --> Session routines successfully run
DEBUG - 2012-04-09 16:41:49 --> Controller Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Model Class Initialized
DEBUG - 2012-04-09 16:41:49 --> Model Class Initialized
DEBUG - 2012-04-09 16:41:49 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-09 16:41:49 --> Final output sent to browser
DEBUG - 2012-04-09 16:41:49 --> Total execution time: 0.2449
DEBUG - 2012-04-09 16:41:59 --> Config Class Initialized
DEBUG - 2012-04-09 16:41:59 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:42:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:42:00 --> URI Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Router Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Output Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Security Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Input Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:42:00 --> Language Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Loader Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:42:00 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Session Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:42:00 --> Session routines successfully run
DEBUG - 2012-04-09 16:42:00 --> Controller Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Model Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Model Class Initialized
DEBUG - 2012-04-09 16:42:00 --> Final output sent to browser
DEBUG - 2012-04-09 16:42:00 --> Total execution time: 0.2814
DEBUG - 2012-04-09 16:42:02 --> Config Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:42:02 --> URI Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Router Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Output Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Security Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Input Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:42:02 --> Language Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Loader Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:42:02 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Session Class Initialized
DEBUG - 2012-04-09 16:42:02 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:42:02 --> Session routines successfully run
DEBUG - 2012-04-09 16:42:02 --> Controller Class Initialized
DEBUG - 2012-04-09 16:42:02 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:42:02 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:42:02 --> Final output sent to browser
DEBUG - 2012-04-09 16:42:02 --> Total execution time: 0.2514
DEBUG - 2012-04-09 16:46:55 --> Config Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:46:55 --> URI Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Router Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Output Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Security Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Input Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:46:55 --> Language Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Loader Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:46:55 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Session Class Initialized
DEBUG - 2012-04-09 16:46:55 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:46:55 --> Session routines successfully run
DEBUG - 2012-04-09 16:46:55 --> Controller Class Initialized
DEBUG - 2012-04-09 16:46:55 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:46:56 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:46:56 --> Final output sent to browser
DEBUG - 2012-04-09 16:46:56 --> Total execution time: 0.2484
DEBUG - 2012-04-09 16:46:57 --> Config Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:46:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:46:57 --> URI Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Router Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Output Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Security Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Input Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:46:57 --> Language Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Loader Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:46:57 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Session Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:46:57 --> Session routines successfully run
DEBUG - 2012-04-09 16:46:57 --> Controller Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Model Class Initialized
DEBUG - 2012-04-09 16:46:57 --> Model Class Initialized
DEBUG - 2012-04-09 16:46:57 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 16:46:57 --> Final output sent to browser
DEBUG - 2012-04-09 16:46:57 --> Total execution time: 0.2186
DEBUG - 2012-04-09 16:47:13 --> Config Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:47:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:47:13 --> URI Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Router Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Output Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Security Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Input Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:47:13 --> Language Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Loader Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:47:13 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Session Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:47:13 --> Session routines successfully run
DEBUG - 2012-04-09 16:47:13 --> Controller Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Model Class Initialized
DEBUG - 2012-04-09 16:47:13 --> Model Class Initialized
DEBUG - 2012-04-09 16:47:13 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 16:47:13 --> Final output sent to browser
DEBUG - 2012-04-09 16:47:13 --> Total execution time: 0.3081
DEBUG - 2012-04-09 16:47:25 --> Config Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:47:25 --> URI Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Router Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Output Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Security Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Input Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:47:25 --> Language Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Loader Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:47:25 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Session Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:47:25 --> Session routines successfully run
DEBUG - 2012-04-09 16:47:25 --> Controller Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Model Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Model Class Initialized
DEBUG - 2012-04-09 16:47:25 --> Model Class Initialized
DEBUG - 2012-04-09 16:47:25 --> File loaded: system/views/freeze_view.php
DEBUG - 2012-04-09 16:47:25 --> Final output sent to browser
DEBUG - 2012-04-09 16:47:25 --> Total execution time: 0.2722
DEBUG - 2012-04-09 16:47:28 --> Config Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:47:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:47:28 --> URI Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Router Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Output Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Security Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Input Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:47:28 --> Language Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Loader Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:47:28 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Session Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:47:28 --> Session routines successfully run
DEBUG - 2012-04-09 16:47:28 --> Controller Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Model Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Model Class Initialized
DEBUG - 2012-04-09 16:47:28 --> Final output sent to browser
DEBUG - 2012-04-09 16:47:28 --> Total execution time: 0.2733
DEBUG - 2012-04-09 16:48:16 --> Config Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:48:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:48:16 --> URI Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Router Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Output Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Security Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Input Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:48:16 --> Language Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Loader Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:48:16 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Session Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:48:16 --> Session routines successfully run
DEBUG - 2012-04-09 16:48:16 --> Controller Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Model Class Initialized
DEBUG - 2012-04-09 16:48:16 --> Model Class Initialized
DEBUG - 2012-04-09 16:48:16 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 16:48:16 --> Final output sent to browser
DEBUG - 2012-04-09 16:48:16 --> Total execution time: 0.2391
DEBUG - 2012-04-09 16:48:28 --> Config Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:48:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:48:28 --> URI Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Router Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Output Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Security Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Input Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:48:28 --> Language Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Loader Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:48:28 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Session Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:48:28 --> Session routines successfully run
DEBUG - 2012-04-09 16:48:28 --> Controller Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Model Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Model Class Initialized
DEBUG - 2012-04-09 16:48:28 --> Model Class Initialized
DEBUG - 2012-04-09 16:48:28 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 16:48:28 --> Final output sent to browser
DEBUG - 2012-04-09 16:48:28 --> Total execution time: 0.3022
DEBUG - 2012-04-09 16:48:37 --> Config Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:48:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:48:37 --> URI Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Router Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Output Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Security Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Input Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:48:37 --> Language Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Loader Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:48:37 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Session Class Initialized
DEBUG - 2012-04-09 16:48:37 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:48:37 --> Session routines successfully run
DEBUG - 2012-04-09 16:48:37 --> Controller Class Initialized
DEBUG - 2012-04-09 16:48:37 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:48:37 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:48:37 --> Final output sent to browser
DEBUG - 2012-04-09 16:48:37 --> Total execution time: 0.2420
DEBUG - 2012-04-09 16:48:39 --> Config Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:48:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:48:39 --> URI Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Router Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Output Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Security Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Input Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:48:39 --> Language Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Loader Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:48:39 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Session Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:48:39 --> Session routines successfully run
DEBUG - 2012-04-09 16:48:39 --> Controller Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Config Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:48:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:48:39 --> URI Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Router Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Output Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Security Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Input Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:48:39 --> Language Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Loader Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:48:39 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Session Class Initialized
DEBUG - 2012-04-09 16:48:39 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:48:39 --> A session cookie was not found.
DEBUG - 2012-04-09 16:48:39 --> Session routines successfully run
DEBUG - 2012-04-09 16:48:39 --> Controller Class Initialized
DEBUG - 2012-04-09 16:48:39 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 16:48:39 --> Final output sent to browser
DEBUG - 2012-04-09 16:48:39 --> Total execution time: 0.2219
DEBUG - 2012-04-09 16:48:41 --> Config Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:48:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:48:41 --> URI Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Router Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Output Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Security Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Input Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:48:41 --> Language Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Loader Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:48:41 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Session Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:48:41 --> Session routines successfully run
DEBUG - 2012-04-09 16:48:41 --> Controller Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Model Class Initialized
DEBUG - 2012-04-09 16:48:41 --> Model Class Initialized
DEBUG - 2012-04-09 16:48:41 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:48:41 --> Final output sent to browser
DEBUG - 2012-04-09 16:48:41 --> Total execution time: 0.3017
DEBUG - 2012-04-09 16:49:36 --> Config Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:49:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:49:36 --> URI Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Router Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Output Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Security Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Input Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:49:36 --> Language Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Loader Class Initialized
DEBUG - 2012-04-09 16:49:36 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:49:36 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:49:37 --> Session Class Initialized
DEBUG - 2012-04-09 16:49:37 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:49:37 --> Session routines successfully run
DEBUG - 2012-04-09 16:49:37 --> Controller Class Initialized
DEBUG - 2012-04-09 16:49:37 --> Model Class Initialized
DEBUG - 2012-04-09 16:49:37 --> Model Class Initialized
DEBUG - 2012-04-09 16:49:37 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:49:37 --> Final output sent to browser
DEBUG - 2012-04-09 16:49:37 --> Total execution time: 0.2592
DEBUG - 2012-04-09 16:49:57 --> Config Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:49:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:49:57 --> URI Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Router Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Output Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Security Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Input Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:49:57 --> Language Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Loader Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:49:57 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Session Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:49:57 --> Session routines successfully run
DEBUG - 2012-04-09 16:49:57 --> Controller Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Model Class Initialized
DEBUG - 2012-04-09 16:49:57 --> Model Class Initialized
DEBUG - 2012-04-09 16:49:57 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:49:57 --> Final output sent to browser
DEBUG - 2012-04-09 16:49:57 --> Total execution time: 0.2585
DEBUG - 2012-04-09 16:51:48 --> Config Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:51:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:51:48 --> URI Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Router Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Output Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Security Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Input Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:51:48 --> Language Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Loader Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:51:48 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Session Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:51:48 --> Session routines successfully run
DEBUG - 2012-04-09 16:51:48 --> Controller Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Model Class Initialized
DEBUG - 2012-04-09 16:51:48 --> Model Class Initialized
DEBUG - 2012-04-09 16:51:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:51:48 --> Final output sent to browser
DEBUG - 2012-04-09 16:51:48 --> Total execution time: 0.2148
DEBUG - 2012-04-09 16:51:58 --> Config Class Initialized
DEBUG - 2012-04-09 16:51:58 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:51:58 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:51:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:51:58 --> URI Class Initialized
DEBUG - 2012-04-09 16:51:58 --> Router Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Output Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Security Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Input Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:51:59 --> Language Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Loader Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:51:59 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Session Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:51:59 --> Session routines successfully run
DEBUG - 2012-04-09 16:51:59 --> Controller Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Model Class Initialized
DEBUG - 2012-04-09 16:51:59 --> Model Class Initialized
DEBUG - 2012-04-09 16:51:59 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:51:59 --> Final output sent to browser
DEBUG - 2012-04-09 16:51:59 --> Total execution time: 0.2568
DEBUG - 2012-04-09 16:52:41 --> Config Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:52:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:52:41 --> URI Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Router Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Output Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Security Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Input Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:52:41 --> Language Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Loader Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:52:41 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Session Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:52:41 --> Session routines successfully run
DEBUG - 2012-04-09 16:52:41 --> Controller Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Model Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Model Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:52:41 --> Model Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Config Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:52:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:52:41 --> URI Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Router Class Initialized
DEBUG - 2012-04-09 16:52:41 --> Output Class Initialized
DEBUG - 2012-04-09 16:52:42 --> Security Class Initialized
DEBUG - 2012-04-09 16:52:42 --> Input Class Initialized
DEBUG - 2012-04-09 16:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:52:42 --> Language Class Initialized
DEBUG - 2012-04-09 16:52:42 --> Loader Class Initialized
DEBUG - 2012-04-09 16:52:42 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:52:42 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:52:42 --> Session Class Initialized
DEBUG - 2012-04-09 16:52:42 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:52:42 --> Session routines successfully run
DEBUG - 2012-04-09 16:52:42 --> Controller Class Initialized
DEBUG - 2012-04-09 16:52:42 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-09 16:52:42 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:52:42 --> Final output sent to browser
DEBUG - 2012-04-09 16:52:42 --> Total execution time: 0.2522
DEBUG - 2012-04-09 16:52:44 --> Config Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:52:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:52:44 --> URI Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Router Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Output Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Security Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Input Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:52:44 --> Language Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Loader Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:52:44 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Session Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:52:44 --> Session routines successfully run
DEBUG - 2012-04-09 16:52:44 --> Controller Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Config Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:52:44 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:52:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:52:45 --> URI Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Router Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Output Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Security Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Input Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:52:45 --> Language Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Loader Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:52:45 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Session Class Initialized
DEBUG - 2012-04-09 16:52:45 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:52:45 --> A session cookie was not found.
DEBUG - 2012-04-09 16:52:45 --> Session routines successfully run
DEBUG - 2012-04-09 16:52:45 --> Controller Class Initialized
DEBUG - 2012-04-09 16:52:45 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 16:52:45 --> Final output sent to browser
DEBUG - 2012-04-09 16:52:45 --> Total execution time: 0.2712
DEBUG - 2012-04-09 16:55:04 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:04 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:04 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:04 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:04 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:04 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:04 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:04 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 16:55:04 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:04 --> Total execution time: 0.2384
DEBUG - 2012-04-09 16:55:06 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:06 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:06 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:06 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:06 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:06 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:06 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:06 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:55:06 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:06 --> Total execution time: 0.2873
DEBUG - 2012-04-09 16:55:15 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:15 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:15 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:15 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:15 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:16 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:16 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:16 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:16 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:16 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:16 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:16 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:16 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:16 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:16 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:16 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:55:16 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:55:16 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:16 --> Total execution time: 0.2445
DEBUG - 2012-04-09 16:55:18 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:18 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:18 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:18 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:18 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:18 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:18 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:18 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-09 16:55:18 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:18 --> Total execution time: 0.3525
DEBUG - 2012-04-09 16:55:25 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:25 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:25 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:25 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:25 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:25 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:25 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:25 --> Total execution time: 0.2912
DEBUG - 2012-04-09 16:55:27 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:27 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:27 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:27 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:27 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:27 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:28 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:28 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:28 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:28 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:28 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:28 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:28 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:28 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:28 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:28 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:28 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:55:28 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:55:28 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:28 --> Total execution time: 0.2545
DEBUG - 2012-04-09 16:55:33 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:33 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:33 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:33 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:33 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:34 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:34 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:34 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:34 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:34 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:34 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:34 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-09 16:55:34 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:34 --> Total execution time: 0.2570
DEBUG - 2012-04-09 16:55:43 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:43 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:43 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:44 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:44 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:44 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:44 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:44 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:44 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:44 --> Total execution time: 0.2535
DEBUG - 2012-04-09 16:55:46 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:46 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:46 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:46 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:46 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:46 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:46 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:46 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 16:55:46 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 16:55:46 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:46 --> Total execution time: 0.2268
DEBUG - 2012-04-09 16:55:47 --> Config Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:55:47 --> URI Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Router Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Output Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Security Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Input Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:55:47 --> Language Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Loader Class Initialized
DEBUG - 2012-04-09 16:55:47 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:55:48 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:55:48 --> Session Class Initialized
DEBUG - 2012-04-09 16:55:48 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:55:48 --> Session routines successfully run
DEBUG - 2012-04-09 16:55:48 --> Controller Class Initialized
DEBUG - 2012-04-09 16:55:48 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:48 --> Model Class Initialized
DEBUG - 2012-04-09 16:55:48 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:55:48 --> Final output sent to browser
DEBUG - 2012-04-09 16:55:48 --> Total execution time: 0.2740
DEBUG - 2012-04-09 16:56:30 --> Config Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:56:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:56:30 --> URI Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Router Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Output Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Security Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Input Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:56:30 --> Language Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Loader Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:56:30 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Session Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:56:30 --> Session routines successfully run
DEBUG - 2012-04-09 16:56:30 --> Controller Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Model Class Initialized
DEBUG - 2012-04-09 16:56:30 --> Model Class Initialized
DEBUG - 2012-04-09 16:56:30 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:56:30 --> Final output sent to browser
DEBUG - 2012-04-09 16:56:30 --> Total execution time: 0.2567
DEBUG - 2012-04-09 16:56:43 --> Config Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:56:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:56:43 --> URI Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Router Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Output Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Security Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Input Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:56:43 --> Language Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Loader Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:56:43 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Session Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:56:43 --> Session routines successfully run
DEBUG - 2012-04-09 16:56:43 --> Controller Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Model Class Initialized
DEBUG - 2012-04-09 16:56:43 --> Model Class Initialized
DEBUG - 2012-04-09 16:56:43 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:56:43 --> Final output sent to browser
DEBUG - 2012-04-09 16:56:43 --> Total execution time: 0.2569
DEBUG - 2012-04-09 16:58:21 --> Config Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Hooks Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Utf8 Class Initialized
DEBUG - 2012-04-09 16:58:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 16:58:21 --> URI Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Router Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Output Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Security Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Input Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 16:58:21 --> Language Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Loader Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Helper loaded: url_helper
DEBUG - 2012-04-09 16:58:21 --> Database Driver Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Session Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Helper loaded: string_helper
DEBUG - 2012-04-09 16:58:21 --> Session routines successfully run
DEBUG - 2012-04-09 16:58:21 --> Controller Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:58:21 --> Helper loaded: email_helper
DEBUG - 2012-04-09 16:58:21 --> Model Class Initialized
DEBUG - 2012-04-09 16:58:21 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 16:58:21 --> Final output sent to browser
DEBUG - 2012-04-09 16:58:21 --> Total execution time: 0.3249
DEBUG - 2012-04-09 17:00:20 --> Config Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:00:20 --> URI Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Router Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Output Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Security Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Input Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:00:20 --> Language Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Loader Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:00:20 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Session Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:00:20 --> Session routines successfully run
DEBUG - 2012-04-09 17:00:20 --> Controller Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Model Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Model Class Initialized
DEBUG - 2012-04-09 17:00:20 --> Helper loaded: email_helper
DEBUG - 2012-04-09 17:00:20 --> Model Class Initialized
DEBUG - 2012-04-09 17:00:20 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 17:00:20 --> Final output sent to browser
DEBUG - 2012-04-09 17:00:20 --> Total execution time: 0.2803
DEBUG - 2012-04-09 17:00:54 --> Config Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:00:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:00:54 --> URI Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Router Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Output Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Security Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Input Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:00:54 --> Language Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Loader Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:00:54 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Session Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:00:54 --> Session routines successfully run
DEBUG - 2012-04-09 17:00:54 --> Controller Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Model Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Model Class Initialized
DEBUG - 2012-04-09 17:00:54 --> Helper loaded: email_helper
DEBUG - 2012-04-09 17:00:54 --> Model Class Initialized
DEBUG - 2012-04-09 17:00:54 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 17:00:54 --> Final output sent to browser
DEBUG - 2012-04-09 17:00:54 --> Total execution time: 0.2782
DEBUG - 2012-04-09 17:01:14 --> Config Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:01:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:01:14 --> URI Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Router Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Output Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Security Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Input Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:01:14 --> Language Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Loader Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:01:14 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Session Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:01:14 --> Session routines successfully run
DEBUG - 2012-04-09 17:01:14 --> Controller Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Model Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Model Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Helper loaded: email_helper
DEBUG - 2012-04-09 17:01:14 --> Model Class Initialized
DEBUG - 2012-04-09 17:01:14 --> Final output sent to browser
DEBUG - 2012-04-09 17:01:14 --> Total execution time: 0.2907
DEBUG - 2012-04-09 17:01:16 --> Config Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:01:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:01:16 --> URI Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Router Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Output Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Security Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Input Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:01:16 --> Language Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Loader Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:01:16 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Session Class Initialized
DEBUG - 2012-04-09 17:01:16 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:01:16 --> Session routines successfully run
DEBUG - 2012-04-09 17:01:16 --> Controller Class Initialized
DEBUG - 2012-04-09 17:01:16 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 17:01:16 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 17:01:16 --> Final output sent to browser
DEBUG - 2012-04-09 17:01:16 --> Total execution time: 0.2091
DEBUG - 2012-04-09 17:02:01 --> Config Class Initialized
DEBUG - 2012-04-09 17:02:01 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:02:01 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:02:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:02:01 --> URI Class Initialized
DEBUG - 2012-04-09 17:02:01 --> Router Class Initialized
DEBUG - 2012-04-09 17:02:01 --> Output Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Security Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Input Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:02:02 --> Language Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Loader Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:02:02 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Session Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:02:02 --> Session routines successfully run
DEBUG - 2012-04-09 17:02:02 --> Controller Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Model Class Initialized
DEBUG - 2012-04-09 17:02:02 --> Model Class Initialized
DEBUG - 2012-04-09 17:02:02 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 17:02:02 --> Final output sent to browser
DEBUG - 2012-04-09 17:02:02 --> Total execution time: 0.2575
DEBUG - 2012-04-09 17:02:21 --> Config Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:02:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:02:21 --> URI Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Router Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Output Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Security Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Input Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:02:21 --> Language Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Loader Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:02:21 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Session Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:02:21 --> Session routines successfully run
DEBUG - 2012-04-09 17:02:21 --> Controller Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Model Class Initialized
DEBUG - 2012-04-09 17:02:21 --> Model Class Initialized
DEBUG - 2012-04-09 17:02:22 --> Model Class Initialized
DEBUG - 2012-04-09 17:02:22 --> File loaded: system/views/codes_view.php
DEBUG - 2012-04-09 17:02:22 --> Final output sent to browser
DEBUG - 2012-04-09 17:02:22 --> Total execution time: 0.3639
DEBUG - 2012-04-09 17:02:34 --> Config Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:02:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:02:34 --> URI Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Router Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Output Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Security Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Input Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:02:34 --> Language Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Loader Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:02:34 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Session Class Initialized
DEBUG - 2012-04-09 17:02:34 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:02:34 --> Session routines successfully run
DEBUG - 2012-04-09 17:02:34 --> Controller Class Initialized
DEBUG - 2012-04-09 17:02:34 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-09 17:02:34 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 17:02:34 --> Final output sent to browser
DEBUG - 2012-04-09 17:02:34 --> Total execution time: 0.2463
DEBUG - 2012-04-09 17:02:36 --> Config Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:02:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:02:36 --> URI Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Router Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Output Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Security Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Input Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:02:36 --> Language Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Loader Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:02:36 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Session Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:02:36 --> Session routines successfully run
DEBUG - 2012-04-09 17:02:36 --> Controller Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Config Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:02:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:02:36 --> URI Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Router Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Output Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Security Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Input Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:02:36 --> Language Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Loader Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:02:36 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Session Class Initialized
DEBUG - 2012-04-09 17:02:36 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:02:36 --> A session cookie was not found.
DEBUG - 2012-04-09 17:02:36 --> Session routines successfully run
DEBUG - 2012-04-09 17:02:36 --> Controller Class Initialized
DEBUG - 2012-04-09 17:02:36 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 17:02:36 --> Final output sent to browser
DEBUG - 2012-04-09 17:02:36 --> Total execution time: 0.2743
DEBUG - 2012-04-09 17:02:38 --> Config Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:02:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:02:38 --> URI Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Router Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Output Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Security Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Input Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:02:38 --> Language Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Loader Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:02:38 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Session Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:02:38 --> Session routines successfully run
DEBUG - 2012-04-09 17:02:38 --> Controller Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Model Class Initialized
DEBUG - 2012-04-09 17:02:38 --> Model Class Initialized
DEBUG - 2012-04-09 17:02:38 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 17:02:38 --> Final output sent to browser
DEBUG - 2012-04-09 17:02:38 --> Total execution time: 0.2698
DEBUG - 2012-04-09 17:03:03 --> Config Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:03:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:03:03 --> URI Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Router Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Output Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Security Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Input Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:03:03 --> Language Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Loader Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:03:03 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Session Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:03:03 --> Session routines successfully run
DEBUG - 2012-04-09 17:03:03 --> Controller Class Initialized
DEBUG - 2012-04-09 17:03:03 --> Model Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Model Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Helper loaded: email_helper
DEBUG - 2012-04-09 17:03:04 --> Model Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Config Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Hooks Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Utf8 Class Initialized
DEBUG - 2012-04-09 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 17:03:04 --> URI Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Router Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Output Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Security Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Input Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 17:03:04 --> Language Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Loader Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Helper loaded: url_helper
DEBUG - 2012-04-09 17:03:04 --> Database Driver Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Session Class Initialized
DEBUG - 2012-04-09 17:03:04 --> Helper loaded: string_helper
DEBUG - 2012-04-09 17:03:04 --> Session routines successfully run
DEBUG - 2012-04-09 17:03:04 --> Controller Class Initialized
DEBUG - 2012-04-09 17:03:04 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-09 17:03:04 --> File loaded: system/views/links.php
DEBUG - 2012-04-09 17:03:04 --> Final output sent to browser
DEBUG - 2012-04-09 17:03:04 --> Total execution time: 0.2387
DEBUG - 2012-04-09 21:16:30 --> Config Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Hooks Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Utf8 Class Initialized
DEBUG - 2012-04-09 21:16:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 21:16:30 --> URI Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Router Class Initialized
DEBUG - 2012-04-09 21:16:30 --> No URI present. Default controller set.
DEBUG - 2012-04-09 21:16:30 --> Output Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Security Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Input Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 21:16:30 --> Language Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Loader Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Helper loaded: url_helper
DEBUG - 2012-04-09 21:16:30 --> Database Driver Class Initialized
ERROR - 2012-04-09 21:16:30 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-09 21:16:30 --> Session Class Initialized
DEBUG - 2012-04-09 21:16:30 --> Helper loaded: string_helper
DEBUG - 2012-04-09 21:16:30 --> Session routines successfully run
DEBUG - 2012-04-09 21:16:30 --> Controller Class Initialized
DEBUG - 2012-04-09 21:16:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 21:16:30 --> Final output sent to browser
DEBUG - 2012-04-09 21:16:30 --> Total execution time: 0.1046
DEBUG - 2012-04-09 21:16:34 --> Config Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Hooks Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Utf8 Class Initialized
DEBUG - 2012-04-09 21:16:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 21:16:34 --> URI Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Router Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Output Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Security Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Input Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 21:16:34 --> Language Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Loader Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Helper loaded: url_helper
DEBUG - 2012-04-09 21:16:34 --> Database Driver Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Session Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Helper loaded: string_helper
DEBUG - 2012-04-09 21:16:34 --> Session routines successfully run
DEBUG - 2012-04-09 21:16:34 --> Controller Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Model Class Initialized
DEBUG - 2012-04-09 21:16:34 --> Model Class Initialized
DEBUG - 2012-04-09 21:16:34 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 21:16:34 --> Final output sent to browser
DEBUG - 2012-04-09 21:16:34 --> Total execution time: 0.0768
DEBUG - 2012-04-09 21:16:58 --> Config Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Hooks Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Utf8 Class Initialized
DEBUG - 2012-04-09 21:16:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 21:16:58 --> URI Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Router Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Output Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Security Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Input Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 21:16:58 --> Language Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Loader Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Helper loaded: url_helper
DEBUG - 2012-04-09 21:16:58 --> Database Driver Class Initialized
ERROR - 2012-04-09 21:16:58 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-09 21:16:58 --> Session Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Helper loaded: string_helper
DEBUG - 2012-04-09 21:16:58 --> Session routines successfully run
DEBUG - 2012-04-09 21:16:58 --> Controller Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Model Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Model Class Initialized
DEBUG - 2012-04-09 21:16:58 --> Helper loaded: email_helper
DEBUG - 2012-04-09 21:16:58 --> Model Class Initialized
DEBUG - 2012-04-09 21:16:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-09 21:16:58 --> Final output sent to browser
DEBUG - 2012-04-09 21:16:58 --> Total execution time: 0.1059
DEBUG - 2012-04-09 21:17:39 --> Config Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Hooks Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Utf8 Class Initialized
DEBUG - 2012-04-09 21:17:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 21:17:39 --> URI Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Router Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Output Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Security Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Input Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 21:17:39 --> Language Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Loader Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Helper loaded: url_helper
DEBUG - 2012-04-09 21:17:39 --> Database Driver Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Session Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Helper loaded: string_helper
DEBUG - 2012-04-09 21:17:39 --> Session routines successfully run
DEBUG - 2012-04-09 21:17:39 --> Controller Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Model Class Initialized
DEBUG - 2012-04-09 21:17:39 --> Model Class Initialized
DEBUG - 2012-04-09 21:17:39 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-09 21:17:39 --> Final output sent to browser
DEBUG - 2012-04-09 21:17:39 --> Total execution time: 0.0746
DEBUG - 2012-04-09 21:17:50 --> Config Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Hooks Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Utf8 Class Initialized
DEBUG - 2012-04-09 21:17:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 21:17:50 --> URI Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Router Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Output Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Security Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Input Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 21:17:50 --> Language Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Loader Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Helper loaded: url_helper
DEBUG - 2012-04-09 21:17:50 --> Database Driver Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Session Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Helper loaded: string_helper
DEBUG - 2012-04-09 21:17:50 --> Session routines successfully run
DEBUG - 2012-04-09 21:17:50 --> Controller Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Model Class Initialized
DEBUG - 2012-04-09 21:17:50 --> Model Class Initialized
DEBUG - 2012-04-09 21:17:50 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-09 21:17:50 --> Final output sent to browser
DEBUG - 2012-04-09 21:17:50 --> Total execution time: 0.0741
DEBUG - 2012-04-09 21:18:13 --> Config Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Hooks Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Utf8 Class Initialized
DEBUG - 2012-04-09 21:18:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-09 21:18:13 --> URI Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Router Class Initialized
DEBUG - 2012-04-09 21:18:13 --> No URI present. Default controller set.
DEBUG - 2012-04-09 21:18:13 --> Output Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Security Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Input Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-09 21:18:13 --> Language Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Loader Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Helper loaded: url_helper
DEBUG - 2012-04-09 21:18:13 --> Database Driver Class Initialized
ERROR - 2012-04-09 21:18:13 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-09 21:18:13 --> Session Class Initialized
DEBUG - 2012-04-09 21:18:13 --> Helper loaded: string_helper
DEBUG - 2012-04-09 21:18:13 --> Session routines successfully run
DEBUG - 2012-04-09 21:18:13 --> Controller Class Initialized
DEBUG - 2012-04-09 21:18:13 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-09 21:18:13 --> Final output sent to browser
DEBUG - 2012-04-09 21:18:13 --> Total execution time: 0.1250
