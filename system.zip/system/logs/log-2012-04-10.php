<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-10 15:23:55 --> Config Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Hooks Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Utf8 Class Initialized
DEBUG - 2012-04-10 15:23:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 15:23:55 --> URI Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Router Class Initialized
DEBUG - 2012-04-10 15:23:55 --> No URI present. Default controller set.
DEBUG - 2012-04-10 15:23:55 --> Output Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Security Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Input Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 15:23:55 --> Language Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Loader Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Helper loaded: url_helper
DEBUG - 2012-04-10 15:23:55 --> Database Driver Class Initialized
ERROR - 2012-04-10 15:23:55 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-10 15:23:55 --> Session Class Initialized
DEBUG - 2012-04-10 15:23:55 --> Helper loaded: string_helper
DEBUG - 2012-04-10 15:23:55 --> A session cookie was not found.
DEBUG - 2012-04-10 15:23:55 --> Session routines successfully run
DEBUG - 2012-04-10 15:23:55 --> Controller Class Initialized
DEBUG - 2012-04-10 15:23:55 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-10 15:23:55 --> Final output sent to browser
DEBUG - 2012-04-10 15:23:55 --> Total execution time: 0.1240
DEBUG - 2012-04-10 15:23:59 --> Config Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Hooks Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Utf8 Class Initialized
DEBUG - 2012-04-10 15:23:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 15:23:59 --> URI Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Router Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Output Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Security Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Input Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 15:23:59 --> Language Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Loader Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Helper loaded: url_helper
DEBUG - 2012-04-10 15:23:59 --> Database Driver Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Session Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Helper loaded: string_helper
DEBUG - 2012-04-10 15:23:59 --> Session routines successfully run
DEBUG - 2012-04-10 15:23:59 --> Controller Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Model Class Initialized
DEBUG - 2012-04-10 15:23:59 --> Model Class Initialized
DEBUG - 2012-04-10 15:23:59 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-10 15:23:59 --> Final output sent to browser
DEBUG - 2012-04-10 15:23:59 --> Total execution time: 0.0507
DEBUG - 2012-04-10 16:06:46 --> Config Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:06:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:06:46 --> URI Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Router Class Initialized
DEBUG - 2012-04-10 16:06:46 --> No URI present. Default controller set.
DEBUG - 2012-04-10 16:06:46 --> Output Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Security Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Input Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:06:46 --> Language Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Loader Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:06:46 --> Database Driver Class Initialized
ERROR - 2012-04-10 16:06:46 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-10 16:06:46 --> Session Class Initialized
DEBUG - 2012-04-10 16:06:46 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:06:46 --> Session routines successfully run
DEBUG - 2012-04-10 16:06:46 --> Controller Class Initialized
DEBUG - 2012-04-10 16:06:46 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-10 16:06:46 --> Final output sent to browser
DEBUG - 2012-04-10 16:06:46 --> Total execution time: 0.0859
DEBUG - 2012-04-10 16:06:50 --> Config Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:06:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:06:50 --> URI Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Router Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Output Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Security Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Input Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:06:50 --> Language Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Loader Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:06:50 --> Database Driver Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Session Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:06:50 --> Session routines successfully run
DEBUG - 2012-04-10 16:06:50 --> Controller Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Model Class Initialized
DEBUG - 2012-04-10 16:06:50 --> Model Class Initialized
DEBUG - 2012-04-10 16:06:50 --> File loaded: system/views/newset_view.php
DEBUG - 2012-04-10 16:06:50 --> Final output sent to browser
DEBUG - 2012-04-10 16:06:50 --> Total execution time: 0.0562
DEBUG - 2012-04-10 16:08:00 --> Config Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:08:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:08:00 --> URI Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Router Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Output Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Security Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Input Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:08:00 --> Language Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Loader Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:08:00 --> Database Driver Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Session Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:08:00 --> Session routines successfully run
DEBUG - 2012-04-10 16:08:00 --> Controller Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Config Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:08:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:08:00 --> URI Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Router Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Output Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Security Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Input Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:08:00 --> Language Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Loader Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:08:00 --> Database Driver Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Session Class Initialized
DEBUG - 2012-04-10 16:08:00 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:08:00 --> Session routines successfully run
DEBUG - 2012-04-10 16:08:00 --> Controller Class Initialized
DEBUG - 2012-04-10 16:08:00 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-10 16:08:00 --> Final output sent to browser
DEBUG - 2012-04-10 16:08:00 --> Total execution time: 0.0480
DEBUG - 2012-04-10 16:08:03 --> Config Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:08:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:08:03 --> URI Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Router Class Initialized
DEBUG - 2012-04-10 16:08:03 --> No URI present. Default controller set.
DEBUG - 2012-04-10 16:08:03 --> Output Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Security Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Input Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:08:03 --> Language Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Loader Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:08:03 --> Database Driver Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Session Class Initialized
DEBUG - 2012-04-10 16:08:03 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:08:03 --> Session routines successfully run
DEBUG - 2012-04-10 16:08:03 --> Controller Class Initialized
DEBUG - 2012-04-10 16:08:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-10 16:08:03 --> Final output sent to browser
DEBUG - 2012-04-10 16:08:03 --> Total execution time: 0.0526
DEBUG - 2012-04-10 16:08:05 --> Config Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:08:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:08:05 --> URI Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Router Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Output Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Security Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Input Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:08:05 --> Language Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Loader Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:08:05 --> Database Driver Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Session Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:08:05 --> Session routines successfully run
DEBUG - 2012-04-10 16:08:05 --> Controller Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Config Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:08:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:08:05 --> URI Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Router Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Output Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Security Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Input Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:08:05 --> Language Class Initialized
DEBUG - 2012-04-10 16:08:05 --> Loader Class Initialized
DEBUG - 2012-04-10 16:08:06 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:08:06 --> Database Driver Class Initialized
DEBUG - 2012-04-10 16:08:06 --> Session Class Initialized
DEBUG - 2012-04-10 16:08:06 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:08:06 --> Session routines successfully run
DEBUG - 2012-04-10 16:08:06 --> Controller Class Initialized
DEBUG - 2012-04-10 16:08:06 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-10 16:08:06 --> Final output sent to browser
DEBUG - 2012-04-10 16:08:06 --> Total execution time: 0.0472
DEBUG - 2012-04-10 16:08:15 --> Config Class Initialized
DEBUG - 2012-04-10 16:08:15 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:08:15 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:08:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:08:15 --> URI Class Initialized
DEBUG - 2012-04-10 16:08:15 --> Router Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Output Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Security Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Input Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:08:16 --> Language Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Loader Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:08:16 --> Database Driver Class Initialized
ERROR - 2012-04-10 16:08:16 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-10 16:08:16 --> Session Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:08:16 --> Session routines successfully run
DEBUG - 2012-04-10 16:08:16 --> Controller Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Model Class Initialized
DEBUG - 2012-04-10 16:08:16 --> Model Class Initialized
DEBUG - 2012-04-10 16:08:16 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-10 16:08:16 --> Final output sent to browser
DEBUG - 2012-04-10 16:08:16 --> Total execution time: 0.1168
DEBUG - 2012-04-10 16:08:45 --> Config Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:08:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:08:45 --> URI Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Router Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Output Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Security Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Input Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:08:45 --> Language Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Loader Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:08:45 --> Database Driver Class Initialized
ERROR - 2012-04-10 16:08:45 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-10 16:08:45 --> Session Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:08:45 --> Session routines successfully run
DEBUG - 2012-04-10 16:08:45 --> Controller Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Config Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Hooks Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Utf8 Class Initialized
DEBUG - 2012-04-10 16:08:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-10 16:08:45 --> URI Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Router Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Output Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Security Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Input Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-10 16:08:45 --> Language Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Loader Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Helper loaded: url_helper
DEBUG - 2012-04-10 16:08:45 --> Database Driver Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Session Class Initialized
DEBUG - 2012-04-10 16:08:45 --> Helper loaded: string_helper
DEBUG - 2012-04-10 16:08:45 --> Session routines successfully run
DEBUG - 2012-04-10 16:08:45 --> Controller Class Initialized
DEBUG - 2012-04-10 16:08:45 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-10 16:08:45 --> Final output sent to browser
DEBUG - 2012-04-10 16:08:45 --> Total execution time: 0.0570
