<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-13 12:26:18 --> Config Class Initialized
DEBUG - 2012-04-13 12:26:18 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:26:18 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:26:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:26:18 --> URI Class Initialized
DEBUG - 2012-04-13 12:26:18 --> Router Class Initialized
DEBUG - 2012-04-13 12:26:18 --> No URI present. Default controller set.
DEBUG - 2012-04-13 12:26:18 --> Output Class Initialized
DEBUG - 2012-04-13 12:26:18 --> Security Class Initialized
DEBUG - 2012-04-13 12:26:18 --> Input Class Initialized
DEBUG - 2012-04-13 12:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:26:18 --> Language Class Initialized
DEBUG - 2012-04-13 12:26:18 --> Loader Class Initialized
DEBUG - 2012-04-13 12:26:18 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:26:18 --> Database Driver Class Initialized
ERROR - 2012-04-13 12:26:18 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-13 12:26:21 --> Session Class Initialized
DEBUG - 2012-04-13 12:26:21 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:26:21 --> A session cookie was not found.
DEBUG - 2012-04-13 12:26:21 --> Session routines successfully run
DEBUG - 2012-04-13 12:26:21 --> Controller Class Initialized
DEBUG - 2012-04-13 12:26:21 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:26:21 --> Final output sent to browser
DEBUG - 2012-04-13 12:26:21 --> Total execution time: 3.5569
DEBUG - 2012-04-13 12:26:35 --> Config Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:26:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:26:35 --> URI Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Router Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Output Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Security Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Input Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:26:35 --> Language Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Loader Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:26:35 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Session Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:26:35 --> Session routines successfully run
DEBUG - 2012-04-13 12:26:35 --> Controller Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Model Class Initialized
DEBUG - 2012-04-13 12:26:35 --> Model Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Config Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:26:36 --> URI Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Router Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Output Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Security Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Input Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:26:36 --> Language Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Loader Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:26:36 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Session Class Initialized
DEBUG - 2012-04-13 12:26:36 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:26:36 --> Session routines successfully run
DEBUG - 2012-04-13 12:26:36 --> Controller Class Initialized
DEBUG - 2012-04-13 12:26:36 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:26:36 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:26:36 --> Final output sent to browser
DEBUG - 2012-04-13 12:26:36 --> Total execution time: 0.0583
DEBUG - 2012-04-13 12:33:00 --> Config Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:33:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:33:00 --> URI Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Router Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Output Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Security Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Input Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:33:00 --> Language Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Loader Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:33:00 --> Database Driver Class Initialized
ERROR - 2012-04-13 12:33:00 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-13 12:33:00 --> Session Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:33:00 --> Session routines successfully run
DEBUG - 2012-04-13 12:33:00 --> Controller Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Config Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:33:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:33:00 --> URI Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Router Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Output Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Security Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Input Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:33:00 --> Language Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Loader Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:33:00 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Session Class Initialized
DEBUG - 2012-04-13 12:33:00 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:33:00 --> A session cookie was not found.
DEBUG - 2012-04-13 12:33:00 --> Session routines successfully run
DEBUG - 2012-04-13 12:33:00 --> Controller Class Initialized
DEBUG - 2012-04-13 12:33:00 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:33:00 --> Final output sent to browser
DEBUG - 2012-04-13 12:33:00 --> Total execution time: 0.0563
DEBUG - 2012-04-13 12:33:02 --> Config Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:33:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:33:02 --> URI Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Router Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Output Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Security Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Input Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:33:02 --> Language Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Loader Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:33:02 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Session Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:33:02 --> Session routines successfully run
DEBUG - 2012-04-13 12:33:02 --> Controller Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Model Class Initialized
DEBUG - 2012-04-13 12:33:02 --> Model Class Initialized
DEBUG - 2012-04-13 12:33:02 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:33:02 --> Final output sent to browser
DEBUG - 2012-04-13 12:33:02 --> Total execution time: 0.0696
DEBUG - 2012-04-13 12:33:40 --> Config Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:33:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:33:40 --> URI Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Router Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Output Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Security Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Input Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:33:40 --> Language Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Loader Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:33:40 --> Database Driver Class Initialized
ERROR - 2012-04-13 12:33:40 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-13 12:33:40 --> Session Class Initialized
DEBUG - 2012-04-13 12:33:40 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:33:40 --> Session routines successfully run
DEBUG - 2012-04-13 12:33:41 --> Controller Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Model Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Model Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Helper loaded: email_helper
DEBUG - 2012-04-13 12:33:41 --> Model Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Config Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:33:41 --> URI Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Router Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Output Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Security Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Input Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:33:41 --> Language Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Loader Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:33:41 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Session Class Initialized
DEBUG - 2012-04-13 12:33:41 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:33:41 --> Session routines successfully run
DEBUG - 2012-04-13 12:33:41 --> Controller Class Initialized
DEBUG - 2012-04-13 12:33:41 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 12:33:41 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:33:41 --> Final output sent to browser
DEBUG - 2012-04-13 12:33:41 --> Total execution time: 0.0502
DEBUG - 2012-04-13 12:34:56 --> Config Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:34:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:34:56 --> URI Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Router Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Output Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Security Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Input Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:34:56 --> Language Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Loader Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:34:56 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Session Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:34:56 --> Session routines successfully run
DEBUG - 2012-04-13 12:34:56 --> Controller Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Config Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:34:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:34:56 --> URI Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Router Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Output Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Security Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Input Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:34:56 --> Language Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Loader Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:34:56 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Session Class Initialized
DEBUG - 2012-04-13 12:34:56 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:34:56 --> A session cookie was not found.
DEBUG - 2012-04-13 12:34:56 --> Session routines successfully run
DEBUG - 2012-04-13 12:34:56 --> Controller Class Initialized
DEBUG - 2012-04-13 12:34:56 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:34:56 --> Final output sent to browser
DEBUG - 2012-04-13 12:34:56 --> Total execution time: 0.0528
DEBUG - 2012-04-13 12:34:57 --> Config Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:34:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:34:57 --> URI Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Router Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Output Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Security Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Input Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:34:57 --> Language Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Loader Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:34:57 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Session Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:34:57 --> Session routines successfully run
DEBUG - 2012-04-13 12:34:57 --> Controller Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Model Class Initialized
DEBUG - 2012-04-13 12:34:57 --> Model Class Initialized
DEBUG - 2012-04-13 12:34:57 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:34:57 --> Final output sent to browser
DEBUG - 2012-04-13 12:34:57 --> Total execution time: 0.0568
DEBUG - 2012-04-13 12:35:16 --> Config Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:35:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:35:16 --> URI Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Router Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Output Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Security Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Input Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:35:16 --> Language Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Loader Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:35:16 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Session Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:35:16 --> Session routines successfully run
DEBUG - 2012-04-13 12:35:16 --> Controller Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Model Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Model Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Config Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:35:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:35:16 --> URI Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Router Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Output Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Security Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Input Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:35:16 --> Language Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Loader Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:35:16 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Session Class Initialized
DEBUG - 2012-04-13 12:35:16 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:35:16 --> Session routines successfully run
DEBUG - 2012-04-13 12:35:16 --> Controller Class Initialized
DEBUG - 2012-04-13 12:35:16 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:35:16 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:35:16 --> Final output sent to browser
DEBUG - 2012-04-13 12:35:16 --> Total execution time: 0.0521
DEBUG - 2012-04-13 12:35:19 --> Config Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:35:19 --> URI Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Router Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Output Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Security Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Input Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:35:19 --> Language Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Loader Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:35:19 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Session Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:35:19 --> Session routines successfully run
DEBUG - 2012-04-13 12:35:19 --> Controller Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Model Class Initialized
DEBUG - 2012-04-13 12:35:19 --> Model Class Initialized
DEBUG - 2012-04-13 12:35:19 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:35:19 --> Final output sent to browser
DEBUG - 2012-04-13 12:35:19 --> Total execution time: 0.0594
DEBUG - 2012-04-13 12:36:44 --> Config Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:36:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:36:44 --> URI Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Router Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Output Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Security Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Input Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:36:44 --> Language Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Loader Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:36:44 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Session Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:36:44 --> Session routines successfully run
DEBUG - 2012-04-13 12:36:44 --> Controller Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Model Class Initialized
DEBUG - 2012-04-13 12:36:44 --> Model Class Initialized
DEBUG - 2012-04-13 12:36:44 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:36:44 --> Final output sent to browser
DEBUG - 2012-04-13 12:36:44 --> Total execution time: 0.0628
DEBUG - 2012-04-13 12:36:53 --> Config Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:36:53 --> URI Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Router Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Output Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Security Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Input Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:36:53 --> Language Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Loader Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:36:53 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Session Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:36:53 --> Session routines successfully run
DEBUG - 2012-04-13 12:36:53 --> Controller Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Config Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:36:53 --> URI Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Router Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Output Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Security Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Input Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:36:53 --> Language Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Loader Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:36:53 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Session Class Initialized
DEBUG - 2012-04-13 12:36:53 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:36:53 --> A session cookie was not found.
DEBUG - 2012-04-13 12:36:53 --> Session routines successfully run
DEBUG - 2012-04-13 12:36:53 --> Controller Class Initialized
DEBUG - 2012-04-13 12:36:53 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:36:53 --> Final output sent to browser
DEBUG - 2012-04-13 12:36:53 --> Total execution time: 0.0546
DEBUG - 2012-04-13 12:36:54 --> Config Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:36:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:36:54 --> URI Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Router Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Output Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Security Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Input Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:36:54 --> Language Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Loader Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:36:54 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Session Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:36:54 --> Session routines successfully run
DEBUG - 2012-04-13 12:36:54 --> Controller Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Model Class Initialized
DEBUG - 2012-04-13 12:36:54 --> Model Class Initialized
DEBUG - 2012-04-13 12:36:54 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:36:54 --> Final output sent to browser
DEBUG - 2012-04-13 12:36:54 --> Total execution time: 0.0613
DEBUG - 2012-04-13 12:36:56 --> Config Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:36:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:36:56 --> URI Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Router Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Output Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Security Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Input Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:36:56 --> Language Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Loader Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:36:56 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Session Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:36:56 --> Session routines successfully run
DEBUG - 2012-04-13 12:36:56 --> Controller Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Model Class Initialized
DEBUG - 2012-04-13 12:36:56 --> Model Class Initialized
DEBUG - 2012-04-13 12:36:56 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:36:56 --> Final output sent to browser
DEBUG - 2012-04-13 12:36:56 --> Total execution time: 0.0636
DEBUG - 2012-04-13 12:36:58 --> Config Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:36:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:36:58 --> URI Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Router Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Output Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Security Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Input Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:36:58 --> Language Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Loader Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:36:58 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Session Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:36:58 --> Session routines successfully run
DEBUG - 2012-04-13 12:36:58 --> Controller Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Model Class Initialized
DEBUG - 2012-04-13 12:36:58 --> Model Class Initialized
DEBUG - 2012-04-13 12:36:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:36:58 --> Final output sent to browser
DEBUG - 2012-04-13 12:36:58 --> Total execution time: 0.0665
DEBUG - 2012-04-13 12:37:19 --> Config Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:37:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:37:19 --> URI Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Router Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Output Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Security Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Input Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:37:19 --> Language Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Loader Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:37:19 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Session Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:37:19 --> Session routines successfully run
DEBUG - 2012-04-13 12:37:19 --> Controller Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Model Class Initialized
DEBUG - 2012-04-13 12:37:19 --> Model Class Initialized
DEBUG - 2012-04-13 12:37:19 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:37:19 --> Final output sent to browser
DEBUG - 2012-04-13 12:37:19 --> Total execution time: 0.0615
DEBUG - 2012-04-13 12:37:29 --> Config Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:37:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:37:29 --> URI Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Router Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Output Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Security Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Input Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:37:29 --> Language Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Loader Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:37:29 --> Database Driver Class Initialized
ERROR - 2012-04-13 12:37:29 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-13 12:37:29 --> Session Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:37:29 --> Session routines successfully run
DEBUG - 2012-04-13 12:37:29 --> Controller Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Model Class Initialized
DEBUG - 2012-04-13 12:37:29 --> Model Class Initialized
DEBUG - 2012-04-13 12:37:29 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:37:29 --> Final output sent to browser
DEBUG - 2012-04-13 12:37:29 --> Total execution time: 0.1170
DEBUG - 2012-04-13 12:38:33 --> Config Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:38:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:38:33 --> URI Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Router Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Output Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Security Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Input Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:38:33 --> Language Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Loader Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:38:33 --> Database Driver Class Initialized
ERROR - 2012-04-13 12:38:33 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-13 12:38:33 --> Session Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:38:33 --> Session routines successfully run
DEBUG - 2012-04-13 12:38:33 --> Controller Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Model Class Initialized
DEBUG - 2012-04-13 12:38:33 --> Model Class Initialized
DEBUG - 2012-04-13 12:38:33 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:38:33 --> Final output sent to browser
DEBUG - 2012-04-13 12:38:33 --> Total execution time: 0.1436
DEBUG - 2012-04-13 12:38:53 --> Config Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:38:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:38:53 --> URI Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Router Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Output Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Security Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Input Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:38:53 --> Language Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Loader Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:38:53 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Session Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:38:53 --> Session routines successfully run
DEBUG - 2012-04-13 12:38:53 --> Controller Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Model Class Initialized
DEBUG - 2012-04-13 12:38:53 --> Model Class Initialized
DEBUG - 2012-04-13 12:38:53 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:38:53 --> Final output sent to browser
DEBUG - 2012-04-13 12:38:53 --> Total execution time: 0.0614
DEBUG - 2012-04-13 12:39:29 --> Config Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:39:29 --> URI Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Router Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Output Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Security Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Input Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:39:29 --> Language Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Loader Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:39:29 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Session Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:39:29 --> Session routines successfully run
DEBUG - 2012-04-13 12:39:29 --> Controller Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Model Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Model Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Helper loaded: email_helper
DEBUG - 2012-04-13 12:39:29 --> Model Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Config Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:39:29 --> URI Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Router Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Output Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Security Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Input Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:39:29 --> Language Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Loader Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:39:29 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Session Class Initialized
DEBUG - 2012-04-13 12:39:29 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:39:29 --> Session routines successfully run
DEBUG - 2012-04-13 12:39:29 --> Controller Class Initialized
DEBUG - 2012-04-13 12:39:29 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 12:39:29 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:39:29 --> Final output sent to browser
DEBUG - 2012-04-13 12:39:29 --> Total execution time: 0.0579
DEBUG - 2012-04-13 12:39:35 --> Config Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:39:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:39:35 --> URI Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Router Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Output Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Security Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Input Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:39:35 --> Language Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Loader Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:39:35 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Session Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:39:35 --> Session routines successfully run
DEBUG - 2012-04-13 12:39:35 --> Controller Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Config Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:39:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:39:35 --> URI Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Router Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Output Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Security Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Input Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:39:35 --> Language Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Loader Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:39:35 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Session Class Initialized
DEBUG - 2012-04-13 12:39:35 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:39:35 --> A session cookie was not found.
DEBUG - 2012-04-13 12:39:35 --> Session routines successfully run
DEBUG - 2012-04-13 12:39:35 --> Controller Class Initialized
DEBUG - 2012-04-13 12:39:35 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:39:35 --> Final output sent to browser
DEBUG - 2012-04-13 12:39:35 --> Total execution time: 0.0570
DEBUG - 2012-04-13 12:39:45 --> Config Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:39:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:39:45 --> URI Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Router Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Output Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Security Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Input Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:39:45 --> Language Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Loader Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:39:45 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Session Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:39:45 --> Session routines successfully run
DEBUG - 2012-04-13 12:39:45 --> Controller Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Model Class Initialized
DEBUG - 2012-04-13 12:39:45 --> Model Class Initialized
DEBUG - 2012-04-13 12:39:45 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:39:45 --> Final output sent to browser
DEBUG - 2012-04-13 12:39:45 --> Total execution time: 0.0622
DEBUG - 2012-04-13 12:40:00 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:00 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:00 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:00 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:00 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:00 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Model Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Model Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:00 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:00 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:00 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:00 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:00 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:00 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:00 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:40:00 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:40:00 --> Final output sent to browser
DEBUG - 2012-04-13 12:40:00 --> Total execution time: 0.0593
DEBUG - 2012-04-13 12:40:04 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:04 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:04 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:04 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:04 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:04 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Model Class Initialized
DEBUG - 2012-04-13 12:40:04 --> Model Class Initialized
DEBUG - 2012-04-13 12:40:04 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:40:04 --> Final output sent to browser
DEBUG - 2012-04-13 12:40:04 --> Total execution time: 0.0646
DEBUG - 2012-04-13 12:40:12 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:12 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:12 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:12 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:12 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:12 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:12 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:12 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:12 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:12 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:12 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:12 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:12 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:40:12 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:40:12 --> Final output sent to browser
DEBUG - 2012-04-13 12:40:12 --> Total execution time: 0.0583
DEBUG - 2012-04-13 12:40:15 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:15 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:15 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:15 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:15 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:15 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:15 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:15 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:15 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:15 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:15 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:15 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:15 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:40:15 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:40:15 --> Final output sent to browser
DEBUG - 2012-04-13 12:40:15 --> Total execution time: 0.0583
DEBUG - 2012-04-13 12:40:17 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:17 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:17 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:17 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:17 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:17 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Config Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:40:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:40:17 --> URI Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Router Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Output Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Security Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Input Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:40:17 --> Language Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Loader Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:40:17 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Session Class Initialized
DEBUG - 2012-04-13 12:40:17 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:40:17 --> Session routines successfully run
DEBUG - 2012-04-13 12:40:17 --> Controller Class Initialized
DEBUG - 2012-04-13 12:40:17 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:40:17 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:40:17 --> Final output sent to browser
DEBUG - 2012-04-13 12:40:17 --> Total execution time: 0.0923
DEBUG - 2012-04-13 12:41:26 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:26 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:26 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:26 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:26 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:26 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:26 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:26 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:41:26 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:41:26 --> Final output sent to browser
DEBUG - 2012-04-13 12:41:26 --> Total execution time: 0.0633
DEBUG - 2012-04-13 12:41:27 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:27 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:27 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:27 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:27 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:27 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Model Class Initialized
DEBUG - 2012-04-13 12:41:27 --> Model Class Initialized
DEBUG - 2012-04-13 12:41:27 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-13 12:41:27 --> Final output sent to browser
DEBUG - 2012-04-13 12:41:27 --> Total execution time: 0.1618
DEBUG - 2012-04-13 12:41:30 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:30 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:30 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:30 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:30 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:30 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:30 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:30 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:30 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:30 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:30 --> A session cookie was not found.
DEBUG - 2012-04-13 12:41:30 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:30 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:41:30 --> Final output sent to browser
DEBUG - 2012-04-13 12:41:30 --> Total execution time: 0.0662
DEBUG - 2012-04-13 12:41:37 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:37 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:37 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:37 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:37 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:37 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:37 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:37 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:37 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:37 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:37 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:37 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:41:37 --> Final output sent to browser
DEBUG - 2012-04-13 12:41:37 --> Total execution time: 0.0597
DEBUG - 2012-04-13 12:41:47 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:47 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:47 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:47 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:47 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:47 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Model Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Model Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:47 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:47 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:47 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:47 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:47 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:47 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:47 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 12:41:47 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:41:47 --> Final output sent to browser
DEBUG - 2012-04-13 12:41:47 --> Total execution time: 0.0626
DEBUG - 2012-04-13 12:41:51 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:51 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:51 --> No URI present. Default controller set.
DEBUG - 2012-04-13 12:41:51 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:51 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:51 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:51 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:51 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:51 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:52 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 12:41:52 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:41:52 --> Final output sent to browser
DEBUG - 2012-04-13 12:41:52 --> Total execution time: 0.0620
DEBUG - 2012-04-13 12:41:54 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:54 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:54 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:54 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:54 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:54 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:54 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:54 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:54 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:54 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:54 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:54 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:54 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 12:41:54 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:41:54 --> Final output sent to browser
DEBUG - 2012-04-13 12:41:54 --> Total execution time: 0.0617
DEBUG - 2012-04-13 12:41:58 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:58 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:58 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:58 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:58 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:58 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Config Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:41:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:41:58 --> URI Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Router Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Output Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Security Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Input Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:41:58 --> Language Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Loader Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:41:58 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Session Class Initialized
DEBUG - 2012-04-13 12:41:58 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:41:58 --> A session cookie was not found.
DEBUG - 2012-04-13 12:41:58 --> Session routines successfully run
DEBUG - 2012-04-13 12:41:58 --> Controller Class Initialized
DEBUG - 2012-04-13 12:41:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:41:58 --> Final output sent to browser
DEBUG - 2012-04-13 12:41:58 --> Total execution time: 0.0630
DEBUG - 2012-04-13 12:42:07 --> Config Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:42:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:42:07 --> URI Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Router Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Output Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Security Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Input Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:42:07 --> Language Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Loader Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:42:07 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Session Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:42:07 --> Session routines successfully run
DEBUG - 2012-04-13 12:42:07 --> Controller Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Config Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:42:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:42:07 --> URI Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Router Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Output Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Security Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Input Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:42:07 --> Language Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Loader Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:42:07 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Session Class Initialized
DEBUG - 2012-04-13 12:42:07 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:42:07 --> Session routines successfully run
DEBUG - 2012-04-13 12:42:07 --> Controller Class Initialized
DEBUG - 2012-04-13 12:42:07 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:42:07 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:42:07 --> Final output sent to browser
DEBUG - 2012-04-13 12:42:07 --> Total execution time: 0.0633
DEBUG - 2012-04-13 12:42:09 --> Config Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:42:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:42:09 --> URI Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Router Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Output Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Security Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Input Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:42:09 --> Language Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Loader Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:42:09 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Session Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:42:09 --> Session routines successfully run
DEBUG - 2012-04-13 12:42:09 --> Controller Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:09 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:09 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-13 12:42:09 --> Final output sent to browser
DEBUG - 2012-04-13 12:42:09 --> Total execution time: 0.0711
DEBUG - 2012-04-13 12:42:22 --> Config Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:42:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:42:22 --> URI Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Router Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Output Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Security Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Input Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:42:22 --> Language Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Loader Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:42:22 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Session Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:42:22 --> Session routines successfully run
DEBUG - 2012-04-13 12:42:22 --> Controller Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:22 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:22 --> File loaded: system/views/newblock_view.php
DEBUG - 2012-04-13 12:42:22 --> Final output sent to browser
DEBUG - 2012-04-13 12:42:22 --> Total execution time: 0.0733
DEBUG - 2012-04-13 12:42:54 --> Config Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:42:54 --> URI Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Router Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Output Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Security Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Input Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:42:54 --> Language Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Loader Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:42:54 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Session Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:42:54 --> Session routines successfully run
DEBUG - 2012-04-13 12:42:54 --> Controller Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Model Class Initialized
DEBUG - 2012-04-13 12:42:54 --> Final output sent to browser
DEBUG - 2012-04-13 12:42:54 --> Total execution time: 0.1079
DEBUG - 2012-04-13 12:42:56 --> Config Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:42:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:42:56 --> URI Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Router Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Output Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Security Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Input Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:42:56 --> Language Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Loader Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:42:56 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Session Class Initialized
DEBUG - 2012-04-13 12:42:56 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:42:56 --> Session routines successfully run
DEBUG - 2012-04-13 12:42:56 --> Controller Class Initialized
DEBUG - 2012-04-13 12:42:56 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:42:56 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:42:56 --> Final output sent to browser
DEBUG - 2012-04-13 12:42:56 --> Total execution time: 0.0652
DEBUG - 2012-04-13 12:43:20 --> Config Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:43:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:43:20 --> URI Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Router Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Output Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Security Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Input Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:43:20 --> Language Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Loader Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:43:20 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Session Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:43:20 --> Session routines successfully run
DEBUG - 2012-04-13 12:43:20 --> Controller Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Model Class Initialized
DEBUG - 2012-04-13 12:43:20 --> Model Class Initialized
DEBUG - 2012-04-13 12:43:20 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:43:20 --> Final output sent to browser
DEBUG - 2012-04-13 12:43:20 --> Total execution time: 0.0707
DEBUG - 2012-04-13 12:44:21 --> Config Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:44:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:44:21 --> URI Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Router Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Output Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Security Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Input Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:44:21 --> Language Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Loader Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:44:21 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Session Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:44:21 --> Session routines successfully run
DEBUG - 2012-04-13 12:44:21 --> Controller Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Model Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Model Class Initialized
DEBUG - 2012-04-13 12:44:21 --> Helper loaded: email_helper
DEBUG - 2012-04-13 12:44:21 --> Model Class Initialized
DEBUG - 2012-04-13 12:44:21 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:44:21 --> Final output sent to browser
DEBUG - 2012-04-13 12:44:21 --> Total execution time: 0.0776
DEBUG - 2012-04-13 12:44:39 --> Config Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:44:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:44:39 --> URI Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Router Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Output Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Security Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Input Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:44:39 --> Language Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Loader Class Initialized
DEBUG - 2012-04-13 12:44:39 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:44:40 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:44:40 --> Session Class Initialized
DEBUG - 2012-04-13 12:44:40 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:44:40 --> Session routines successfully run
DEBUG - 2012-04-13 12:44:40 --> Controller Class Initialized
DEBUG - 2012-04-13 12:44:40 --> Model Class Initialized
DEBUG - 2012-04-13 12:44:40 --> Model Class Initialized
DEBUG - 2012-04-13 12:44:40 --> Helper loaded: email_helper
DEBUG - 2012-04-13 12:44:40 --> Model Class Initialized
DEBUG - 2012-04-13 12:44:40 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:44:40 --> Final output sent to browser
DEBUG - 2012-04-13 12:44:40 --> Total execution time: 0.0762
DEBUG - 2012-04-13 12:44:46 --> Config Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:44:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:44:46 --> URI Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Router Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Output Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Security Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Input Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:44:46 --> Language Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Loader Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:44:46 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Session Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:44:46 --> Session routines successfully run
DEBUG - 2012-04-13 12:44:46 --> Controller Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Model Class Initialized
DEBUG - 2012-04-13 12:44:46 --> Model Class Initialized
DEBUG - 2012-04-13 12:44:46 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:44:46 --> Final output sent to browser
DEBUG - 2012-04-13 12:44:46 --> Total execution time: 0.0721
DEBUG - 2012-04-13 12:45:08 --> Config Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:45:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:45:08 --> URI Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Router Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Output Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Security Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Input Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:45:08 --> Language Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Loader Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:45:08 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Session Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:45:08 --> Session routines successfully run
DEBUG - 2012-04-13 12:45:08 --> Controller Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Model Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Model Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Helper loaded: email_helper
DEBUG - 2012-04-13 12:45:08 --> Model Class Initialized
DEBUG - 2012-04-13 12:45:08 --> Final output sent to browser
DEBUG - 2012-04-13 12:45:08 --> Total execution time: 0.1603
DEBUG - 2012-04-13 12:45:10 --> Config Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:45:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:45:10 --> URI Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Router Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Output Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Security Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Input Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:45:10 --> Language Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Loader Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:45:10 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Session Class Initialized
DEBUG - 2012-04-13 12:45:10 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:45:10 --> Session routines successfully run
DEBUG - 2012-04-13 12:45:10 --> Controller Class Initialized
DEBUG - 2012-04-13 12:45:10 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:45:10 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:45:10 --> Final output sent to browser
DEBUG - 2012-04-13 12:45:10 --> Total execution time: 0.0673
DEBUG - 2012-04-13 12:47:25 --> Config Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:47:25 --> URI Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Router Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Output Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Security Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Input Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:47:25 --> Language Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Loader Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:47:25 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Session Class Initialized
DEBUG - 2012-04-13 12:47:25 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:47:25 --> Session routines successfully run
DEBUG - 2012-04-13 12:47:25 --> Controller Class Initialized
DEBUG - 2012-04-13 12:47:25 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 12:47:25 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 12:47:25 --> Final output sent to browser
DEBUG - 2012-04-13 12:47:25 --> Total execution time: 0.0698
DEBUG - 2012-04-13 12:47:26 --> Config Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:47:26 --> URI Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Router Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Output Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Security Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Input Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:47:26 --> Language Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Loader Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:47:26 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Session Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:47:26 --> Session routines successfully run
DEBUG - 2012-04-13 12:47:26 --> Controller Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Config Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:47:26 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:47:27 --> URI Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Router Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Output Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Security Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Input Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:47:27 --> Language Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Loader Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:47:27 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Session Class Initialized
DEBUG - 2012-04-13 12:47:27 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:47:27 --> A session cookie was not found.
DEBUG - 2012-04-13 12:47:27 --> Session routines successfully run
DEBUG - 2012-04-13 12:47:27 --> Controller Class Initialized
DEBUG - 2012-04-13 12:47:27 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:47:27 --> Final output sent to browser
DEBUG - 2012-04-13 12:47:27 --> Total execution time: 0.0924
DEBUG - 2012-04-13 12:47:28 --> Config Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:47:28 --> URI Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Router Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Output Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Security Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Input Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:47:28 --> Language Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Loader Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:47:28 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Session Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:47:28 --> Session routines successfully run
DEBUG - 2012-04-13 12:47:28 --> Controller Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Model Class Initialized
DEBUG - 2012-04-13 12:47:28 --> Model Class Initialized
DEBUG - 2012-04-13 12:47:28 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:47:28 --> Final output sent to browser
DEBUG - 2012-04-13 12:47:28 --> Total execution time: 0.0725
DEBUG - 2012-04-13 12:48:02 --> Config Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:48:02 --> URI Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Router Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Output Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Security Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Input Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:48:02 --> Language Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Loader Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:48:02 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Session Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:48:02 --> Session routines successfully run
DEBUG - 2012-04-13 12:48:02 --> Controller Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Model Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Model Class Initialized
DEBUG - 2012-04-13 12:48:02 --> Helper loaded: email_helper
DEBUG - 2012-04-13 12:48:02 --> Model Class Initialized
DEBUG - 2012-04-13 12:48:02 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:48:02 --> Final output sent to browser
DEBUG - 2012-04-13 12:48:02 --> Total execution time: 0.0814
DEBUG - 2012-04-13 12:51:14 --> Config Class Initialized
DEBUG - 2012-04-13 12:51:14 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:51:14 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:51:15 --> URI Class Initialized
DEBUG - 2012-04-13 12:51:15 --> Router Class Initialized
DEBUG - 2012-04-13 12:51:15 --> No URI present. Default controller set.
DEBUG - 2012-04-13 12:51:15 --> Output Class Initialized
DEBUG - 2012-04-13 12:51:15 --> Security Class Initialized
DEBUG - 2012-04-13 12:51:15 --> Input Class Initialized
DEBUG - 2012-04-13 12:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:51:15 --> Language Class Initialized
DEBUG - 2012-04-13 12:51:15 --> Loader Class Initialized
DEBUG - 2012-04-13 12:51:15 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:51:15 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:51:15 --> Session Class Initialized
DEBUG - 2012-04-13 12:51:15 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:51:15 --> Session routines successfully run
DEBUG - 2012-04-13 12:51:15 --> Controller Class Initialized
DEBUG - 2012-04-13 12:51:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 12:51:15 --> Final output sent to browser
DEBUG - 2012-04-13 12:51:15 --> Total execution time: 0.0687
DEBUG - 2012-04-13 12:51:17 --> Config Class Initialized
DEBUG - 2012-04-13 12:51:17 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:51:17 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:51:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:51:17 --> URI Class Initialized
DEBUG - 2012-04-13 12:51:17 --> Router Class Initialized
DEBUG - 2012-04-13 12:51:17 --> Output Class Initialized
DEBUG - 2012-04-13 12:51:17 --> Security Class Initialized
DEBUG - 2012-04-13 12:51:17 --> Input Class Initialized
DEBUG - 2012-04-13 12:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:51:17 --> Language Class Initialized
DEBUG - 2012-04-13 12:51:17 --> Loader Class Initialized
DEBUG - 2012-04-13 12:51:18 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:51:18 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:51:18 --> Session Class Initialized
DEBUG - 2012-04-13 12:51:18 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:51:18 --> Session routines successfully run
DEBUG - 2012-04-13 12:51:18 --> Controller Class Initialized
DEBUG - 2012-04-13 12:51:18 --> Model Class Initialized
DEBUG - 2012-04-13 12:51:18 --> Model Class Initialized
DEBUG - 2012-04-13 12:51:18 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:51:18 --> Final output sent to browser
DEBUG - 2012-04-13 12:51:18 --> Total execution time: 0.0748
DEBUG - 2012-04-13 12:51:56 --> Config Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Hooks Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Utf8 Class Initialized
DEBUG - 2012-04-13 12:51:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 12:51:56 --> URI Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Router Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Output Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Security Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Input Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 12:51:56 --> Language Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Loader Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Helper loaded: url_helper
DEBUG - 2012-04-13 12:51:56 --> Database Driver Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Session Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Helper loaded: string_helper
DEBUG - 2012-04-13 12:51:56 --> Session routines successfully run
DEBUG - 2012-04-13 12:51:56 --> Controller Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Model Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Model Class Initialized
DEBUG - 2012-04-13 12:51:56 --> Helper loaded: email_helper
DEBUG - 2012-04-13 12:51:56 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 12:51:56 --> Final output sent to browser
DEBUG - 2012-04-13 12:51:56 --> Total execution time: 0.0773
DEBUG - 2012-04-13 13:18:14 --> Config Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:18:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:18:14 --> URI Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Router Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Output Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Security Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Input Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:18:14 --> Language Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Loader Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:18:14 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Session Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:18:14 --> Session routines successfully run
DEBUG - 2012-04-13 13:18:14 --> Controller Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Model Class Initialized
DEBUG - 2012-04-13 13:18:14 --> Model Class Initialized
DEBUG - 2012-04-13 13:18:14 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 13:18:14 --> Final output sent to browser
DEBUG - 2012-04-13 13:18:14 --> Total execution time: 0.0822
DEBUG - 2012-04-13 13:18:25 --> Config Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:18:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:18:25 --> URI Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Router Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Output Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Security Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Input Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:18:25 --> Language Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Loader Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:18:25 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Session Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:18:25 --> Session routines successfully run
DEBUG - 2012-04-13 13:18:25 --> Controller Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Model Class Initialized
DEBUG - 2012-04-13 13:18:25 --> Model Class Initialized
DEBUG - 2012-04-13 13:18:25 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 13:18:25 --> Final output sent to browser
DEBUG - 2012-04-13 13:18:25 --> Total execution time: 0.0734
DEBUG - 2012-04-13 13:24:21 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:21 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:21 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:21 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:21 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:21 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:21 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Model Class Initialized
DEBUG - 2012-04-13 13:24:21 --> Model Class Initialized
DEBUG - 2012-04-13 13:24:21 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 13:24:21 --> Final output sent to browser
DEBUG - 2012-04-13 13:24:21 --> Total execution time: 0.0825
DEBUG - 2012-04-13 13:24:28 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:28 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:28 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:28 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:28 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:28 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Model Class Initialized
DEBUG - 2012-04-13 13:24:28 --> Model Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:29 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:29 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:29 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:29 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:29 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:29 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:29 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 13:24:29 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 13:24:29 --> Final output sent to browser
DEBUG - 2012-04-13 13:24:29 --> Total execution time: 0.0756
DEBUG - 2012-04-13 13:24:34 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:34 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:34 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:34 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:34 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:34 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:34 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:34 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:34 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:34 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:34 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:34 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:34 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 13:24:34 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 13:24:34 --> Final output sent to browser
DEBUG - 2012-04-13 13:24:34 --> Total execution time: 0.0682
DEBUG - 2012-04-13 13:24:41 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:41 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:41 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:41 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:41 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:41 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:41 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:41 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:41 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:41 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:41 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:41 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:41 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 13:24:41 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 13:24:41 --> Final output sent to browser
DEBUG - 2012-04-13 13:24:41 --> Total execution time: 0.0683
DEBUG - 2012-04-13 13:24:51 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:51 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:51 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:51 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:51 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:51 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:51 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:51 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:51 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:51 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:51 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:51 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:51 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-13 13:24:51 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 13:24:51 --> Final output sent to browser
DEBUG - 2012-04-13 13:24:51 --> Total execution time: 0.0724
DEBUG - 2012-04-13 13:24:57 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:57 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:57 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:57 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:57 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:57 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Config Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:24:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:24:57 --> URI Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Router Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Output Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Security Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Input Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:24:57 --> Language Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Loader Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:24:57 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Session Class Initialized
DEBUG - 2012-04-13 13:24:57 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:24:57 --> A session cookie was not found.
DEBUG - 2012-04-13 13:24:57 --> Session routines successfully run
DEBUG - 2012-04-13 13:24:57 --> Controller Class Initialized
DEBUG - 2012-04-13 13:24:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 13:24:57 --> Final output sent to browser
DEBUG - 2012-04-13 13:24:57 --> Total execution time: 0.0705
DEBUG - 2012-04-13 13:29:06 --> Config Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:29:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:29:06 --> URI Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Router Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Output Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Security Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Input Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:29:06 --> Language Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Loader Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:29:06 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Session Class Initialized
DEBUG - 2012-04-13 13:29:06 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:29:06 --> Session routines successfully run
DEBUG - 2012-04-13 13:29:06 --> Controller Class Initialized
DEBUG - 2012-04-13 13:29:06 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-13 13:29:06 --> Final output sent to browser
DEBUG - 2012-04-13 13:29:06 --> Total execution time: 0.0676
DEBUG - 2012-04-13 13:29:14 --> Config Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:29:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:29:14 --> URI Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Router Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Output Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Security Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Input Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:29:14 --> Language Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Loader Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:29:14 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Session Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:29:14 --> Session routines successfully run
DEBUG - 2012-04-13 13:29:14 --> Controller Class Initialized
DEBUG - 2012-04-13 13:29:14 --> Model Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Model Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Config Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:29:15 --> URI Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Router Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Output Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Security Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Input Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:29:15 --> Language Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Loader Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:29:15 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Session Class Initialized
DEBUG - 2012-04-13 13:29:15 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:29:15 --> Session routines successfully run
DEBUG - 2012-04-13 13:29:15 --> Controller Class Initialized
DEBUG - 2012-04-13 13:29:15 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-13 13:29:15 --> File loaded: system/views/links.php
DEBUG - 2012-04-13 13:29:15 --> Final output sent to browser
DEBUG - 2012-04-13 13:29:15 --> Total execution time: 0.0764
DEBUG - 2012-04-13 13:29:19 --> Config Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:29:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:29:19 --> URI Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Router Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Output Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Security Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Input Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:29:19 --> Language Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Loader Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:29:19 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Session Class Initialized
DEBUG - 2012-04-13 13:29:19 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:29:19 --> Session routines successfully run
DEBUG - 2012-04-13 13:29:19 --> Controller Class Initialized
ERROR - 2012-04-13 13:29:19 --> Severity: Notice  --> Undefined property: Admin::$accounts C:\Software\xampp\htdocs\xcms\system\controllers\admin.php 12
DEBUG - 2012-04-13 13:31:18 --> Config Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:31:18 --> URI Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Router Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Output Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Security Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Input Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:31:18 --> Language Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Loader Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:31:18 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Session Class Initialized
DEBUG - 2012-04-13 13:31:18 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:31:18 --> Session routines successfully run
DEBUG - 2012-04-13 13:31:18 --> Controller Class Initialized
ERROR - 2012-04-13 13:31:18 --> Severity: Notice  --> Undefined property: Admin::$accounts C:\Software\xampp\htdocs\xcms\system\controllers\admin.php 12
DEBUG - 2012-04-13 13:31:19 --> Config Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:31:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:31:19 --> URI Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Router Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Output Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Security Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Input Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:31:19 --> Language Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Loader Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:31:19 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Session Class Initialized
DEBUG - 2012-04-13 13:31:19 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:31:19 --> Session routines successfully run
DEBUG - 2012-04-13 13:31:19 --> Controller Class Initialized
ERROR - 2012-04-13 13:31:19 --> Severity: Notice  --> Undefined property: Admin::$accounts C:\Software\xampp\htdocs\xcms\system\controllers\admin.php 12
DEBUG - 2012-04-13 13:31:58 --> Config Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:31:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:31:58 --> URI Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Router Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Output Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Security Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Input Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:31:58 --> Language Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Loader Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:31:58 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Session Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:31:58 --> Session routines successfully run
DEBUG - 2012-04-13 13:31:58 --> Controller Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Config Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:31:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:31:58 --> URI Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Router Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Output Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Security Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Input Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:31:58 --> Language Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Loader Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:31:58 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Session Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:31:58 --> Session routines successfully run
DEBUG - 2012-04-13 13:31:58 --> Controller Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Model Class Initialized
DEBUG - 2012-04-13 13:31:58 --> Model Class Initialized
DEBUG - 2012-04-13 13:31:58 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 13:31:58 --> Final output sent to browser
DEBUG - 2012-04-13 13:31:58 --> Total execution time: 0.0748
DEBUG - 2012-04-13 13:35:49 --> Config Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Hooks Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Utf8 Class Initialized
DEBUG - 2012-04-13 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 13:35:49 --> URI Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Router Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Output Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Security Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Input Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 13:35:49 --> Language Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Loader Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Helper loaded: url_helper
DEBUG - 2012-04-13 13:35:49 --> Database Driver Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Session Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Helper loaded: string_helper
DEBUG - 2012-04-13 13:35:49 --> Session routines successfully run
DEBUG - 2012-04-13 13:35:49 --> Controller Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Model Class Initialized
DEBUG - 2012-04-13 13:35:49 --> Model Class Initialized
DEBUG - 2012-04-13 13:35:49 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 13:35:49 --> Final output sent to browser
DEBUG - 2012-04-13 13:35:49 --> Total execution time: 0.0778
DEBUG - 2012-04-13 14:07:19 --> Config Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Hooks Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Utf8 Class Initialized
DEBUG - 2012-04-13 14:07:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-13 14:07:19 --> URI Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Router Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Output Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Security Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Input Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-13 14:07:19 --> Language Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Loader Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Helper loaded: url_helper
DEBUG - 2012-04-13 14:07:19 --> Database Driver Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Session Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Helper loaded: string_helper
DEBUG - 2012-04-13 14:07:19 --> Session routines successfully run
DEBUG - 2012-04-13 14:07:19 --> Controller Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Model Class Initialized
DEBUG - 2012-04-13 14:07:19 --> Model Class Initialized
DEBUG - 2012-04-13 14:07:19 --> File loaded: system/views/register_view.php
DEBUG - 2012-04-13 14:07:19 --> Final output sent to browser
DEBUG - 2012-04-13 14:07:19 --> Total execution time: 0.0822
