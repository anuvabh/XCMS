<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-04-04 07:17:09 --> Config Class Initialized
DEBUG - 2012-04-04 07:17:09 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:17:09 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:17:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:17:09 --> URI Class Initialized
DEBUG - 2012-04-04 07:17:10 --> Router Class Initialized
DEBUG - 2012-04-04 07:17:10 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:17:10 --> Output Class Initialized
DEBUG - 2012-04-04 07:17:10 --> Security Class Initialized
DEBUG - 2012-04-04 07:17:10 --> Input Class Initialized
DEBUG - 2012-04-04 07:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:17:10 --> Language Class Initialized
DEBUG - 2012-04-04 07:17:10 --> Loader Class Initialized
DEBUG - 2012-04-04 07:17:10 --> Database Driver Class Initialized
ERROR - 2012-04-04 07:17:10 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-04 07:17:10 --> Session Class Initialized
DEBUG - 2012-04-04 07:17:10 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:17:10 --> A session cookie was not found.
DEBUG - 2012-04-04 07:17:10 --> Session routines successfully run
DEBUG - 2012-04-04 07:17:10 --> Controller Class Initialized
DEBUG - 2012-04-04 07:17:10 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:17:10 --> Final output sent to browser
DEBUG - 2012-04-04 07:17:10 --> Total execution time: 0.2582
DEBUG - 2012-04-04 07:17:15 --> Config Class Initialized
DEBUG - 2012-04-04 07:17:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:17:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:17:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:17:15 --> URI Class Initialized
DEBUG - 2012-04-04 07:17:15 --> Router Class Initialized
DEBUG - 2012-04-04 07:17:15 --> Output Class Initialized
DEBUG - 2012-04-04 07:17:15 --> Security Class Initialized
DEBUG - 2012-04-04 07:17:15 --> Input Class Initialized
DEBUG - 2012-04-04 07:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:17:16 --> Language Class Initialized
DEBUG - 2012-04-04 07:17:16 --> Loader Class Initialized
DEBUG - 2012-04-04 07:17:16 --> Database Driver Class Initialized
ERROR - 2012-04-04 07:17:16 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-04 07:17:16 --> Session Class Initialized
DEBUG - 2012-04-04 07:17:16 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:17:16 --> Session routines successfully run
DEBUG - 2012-04-04 07:17:16 --> Controller Class Initialized
DEBUG - 2012-04-04 07:17:16 --> Model Class Initialized
DEBUG - 2012-04-04 07:17:16 --> Model Class Initialized
DEBUG - 2012-04-04 07:17:16 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:17:16 --> Final output sent to browser
DEBUG - 2012-04-04 07:17:16 --> Total execution time: 0.1911
DEBUG - 2012-04-04 07:17:35 --> Config Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:17:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:17:35 --> URI Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Router Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Output Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Security Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Input Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:17:35 --> Language Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Loader Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Session Class Initialized
DEBUG - 2012-04-04 07:17:35 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:17:35 --> Session routines successfully run
DEBUG - 2012-04-04 07:17:35 --> Controller Class Initialized
ERROR - 2012-04-04 07:17:35 --> 404 Page Not Found --> accounts/index
DEBUG - 2012-04-04 07:18:04 --> Config Class Initialized
DEBUG - 2012-04-04 07:18:04 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:18:04 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:18:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:18:04 --> URI Class Initialized
DEBUG - 2012-04-04 07:18:04 --> Router Class Initialized
DEBUG - 2012-04-04 07:18:04 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:18:04 --> Output Class Initialized
DEBUG - 2012-04-04 07:18:04 --> Security Class Initialized
DEBUG - 2012-04-04 07:18:04 --> Input Class Initialized
DEBUG - 2012-04-04 07:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:18:05 --> Language Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Loader Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Session Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:18:05 --> Session routines successfully run
DEBUG - 2012-04-04 07:18:05 --> Controller Class Initialized
DEBUG - 2012-04-04 07:18:05 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:18:05 --> Final output sent to browser
DEBUG - 2012-04-04 07:18:05 --> Total execution time: 0.1748
DEBUG - 2012-04-04 07:18:05 --> Config Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:18:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:18:05 --> URI Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Router Class Initialized
DEBUG - 2012-04-04 07:18:05 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:18:05 --> Output Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Security Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Input Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:18:05 --> Language Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Loader Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Session Class Initialized
DEBUG - 2012-04-04 07:18:05 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:18:05 --> Session routines successfully run
DEBUG - 2012-04-04 07:18:05 --> Controller Class Initialized
DEBUG - 2012-04-04 07:18:05 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:18:05 --> Final output sent to browser
DEBUG - 2012-04-04 07:18:05 --> Total execution time: 0.1826
DEBUG - 2012-04-04 07:18:14 --> Config Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:18:14 --> URI Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Router Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Output Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Security Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Input Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:18:14 --> Language Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Loader Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Database Driver Class Initialized
ERROR - 2012-04-04 07:18:14 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-04 07:18:14 --> Session Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:18:14 --> Session routines successfully run
DEBUG - 2012-04-04 07:18:14 --> Controller Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Model Class Initialized
DEBUG - 2012-04-04 07:18:14 --> Model Class Initialized
DEBUG - 2012-04-04 07:18:14 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:18:14 --> Final output sent to browser
DEBUG - 2012-04-04 07:18:14 --> Total execution time: 0.1821
DEBUG - 2012-04-04 07:21:48 --> Config Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:21:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:21:48 --> URI Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Router Class Initialized
DEBUG - 2012-04-04 07:21:48 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:21:48 --> Output Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Security Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Input Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:21:48 --> Language Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Loader Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Database Driver Class Initialized
ERROR - 2012-04-04 07:21:48 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-04 07:21:48 --> Session Class Initialized
DEBUG - 2012-04-04 07:21:48 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:21:48 --> Session routines successfully run
DEBUG - 2012-04-04 07:21:48 --> Controller Class Initialized
DEBUG - 2012-04-04 07:21:48 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:21:48 --> Final output sent to browser
DEBUG - 2012-04-04 07:21:48 --> Total execution time: 0.1589
DEBUG - 2012-04-04 07:21:50 --> Config Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:21:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:21:50 --> URI Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Router Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Output Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Security Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Input Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:21:50 --> Language Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Loader Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Session Class Initialized
DEBUG - 2012-04-04 07:21:50 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:21:50 --> Session routines successfully run
DEBUG - 2012-04-04 07:21:50 --> Controller Class Initialized
ERROR - 2012-04-04 07:21:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 42
ERROR - 2012-04-04 07:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 42
DEBUG - 2012-04-04 07:21:50 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:21:50 --> Final output sent to browser
DEBUG - 2012-04-04 07:21:50 --> Total execution time: 0.1590
DEBUG - 2012-04-04 07:22:53 --> Config Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:22:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:22:54 --> URI Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Router Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Output Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Security Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Input Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:22:54 --> Language Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Loader Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Database Driver Class Initialized
ERROR - 2012-04-04 07:22:54 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-04 07:22:54 --> Session Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:22:54 --> Session routines successfully run
DEBUG - 2012-04-04 07:22:54 --> Controller Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Model Class Initialized
DEBUG - 2012-04-04 07:22:54 --> Model Class Initialized
DEBUG - 2012-04-04 07:22:54 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:22:54 --> Final output sent to browser
DEBUG - 2012-04-04 07:22:54 --> Total execution time: 0.1997
DEBUG - 2012-04-04 07:23:00 --> Config Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:23:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:23:00 --> URI Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Router Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Output Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Security Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Input Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:23:00 --> Language Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Loader Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Session Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:23:00 --> Session routines successfully run
DEBUG - 2012-04-04 07:23:00 --> Controller Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Model Class Initialized
DEBUG - 2012-04-04 07:23:00 --> Model Class Initialized
DEBUG - 2012-04-04 07:23:00 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:23:00 --> Final output sent to browser
DEBUG - 2012-04-04 07:23:00 --> Total execution time: 0.1805
DEBUG - 2012-04-04 07:23:05 --> Config Class Initialized
DEBUG - 2012-04-04 07:23:05 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:23:05 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:23:05 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:23:05 --> URI Class Initialized
DEBUG - 2012-04-04 07:23:05 --> Router Class Initialized
DEBUG - 2012-04-04 07:23:05 --> Output Class Initialized
DEBUG - 2012-04-04 07:23:05 --> Security Class Initialized
DEBUG - 2012-04-04 07:23:05 --> Input Class Initialized
DEBUG - 2012-04-04 07:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:23:06 --> Language Class Initialized
DEBUG - 2012-04-04 07:23:06 --> Loader Class Initialized
DEBUG - 2012-04-04 07:23:06 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:23:06 --> Session Class Initialized
DEBUG - 2012-04-04 07:23:06 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:23:06 --> Session routines successfully run
DEBUG - 2012-04-04 07:23:06 --> Controller Class Initialized
ERROR - 2012-04-04 07:23:06 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 42
ERROR - 2012-04-04 07:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 42
DEBUG - 2012-04-04 07:23:06 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:23:06 --> Final output sent to browser
DEBUG - 2012-04-04 07:23:06 --> Total execution time: 0.1865
DEBUG - 2012-04-04 07:23:27 --> Config Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:23:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:23:27 --> URI Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Router Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Output Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Security Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Input Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:23:27 --> Language Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Loader Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Session Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:23:27 --> Session routines successfully run
DEBUG - 2012-04-04 07:23:27 --> Controller Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Model Class Initialized
DEBUG - 2012-04-04 07:23:27 --> Model Class Initialized
DEBUG - 2012-04-04 07:23:27 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:23:27 --> Final output sent to browser
DEBUG - 2012-04-04 07:23:27 --> Total execution time: 0.1821
DEBUG - 2012-04-04 07:23:37 --> Config Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:23:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:23:37 --> URI Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Router Class Initialized
DEBUG - 2012-04-04 07:23:37 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:23:37 --> Output Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Security Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Input Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:23:37 --> Language Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Loader Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Session Class Initialized
DEBUG - 2012-04-04 07:23:37 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:23:37 --> Session routines successfully run
DEBUG - 2012-04-04 07:23:37 --> Controller Class Initialized
DEBUG - 2012-04-04 07:23:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:23:37 --> Final output sent to browser
DEBUG - 2012-04-04 07:23:37 --> Total execution time: 0.1663
DEBUG - 2012-04-04 07:26:15 --> Config Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:26:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:26:15 --> URI Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Router Class Initialized
DEBUG - 2012-04-04 07:26:15 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:26:15 --> Output Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Security Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Input Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:26:15 --> Language Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Loader Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Session Class Initialized
DEBUG - 2012-04-04 07:26:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:26:15 --> Session routines successfully run
DEBUG - 2012-04-04 07:26:15 --> Controller Class Initialized
DEBUG - 2012-04-04 07:26:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:26:15 --> Final output sent to browser
DEBUG - 2012-04-04 07:26:15 --> Total execution time: 0.1667
DEBUG - 2012-04-04 07:26:23 --> Config Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:26:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:26:23 --> URI Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Router Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Output Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Security Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Input Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:26:23 --> Language Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Loader Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Session Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:26:23 --> Session routines successfully run
DEBUG - 2012-04-04 07:26:23 --> Controller Class Initialized
DEBUG - 2012-04-04 07:26:23 --> Model Class Initialized
DEBUG - 2012-04-04 07:26:24 --> Model Class Initialized
DEBUG - 2012-04-04 07:26:24 --> Final output sent to browser
DEBUG - 2012-04-04 07:26:24 --> Total execution time: 0.1795
DEBUG - 2012-04-04 07:26:33 --> Config Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:26:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:26:33 --> URI Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Router Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Output Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Security Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Input Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:26:33 --> Language Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Loader Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Session Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:26:33 --> Session routines successfully run
DEBUG - 2012-04-04 07:26:33 --> Controller Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Model Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Model Class Initialized
DEBUG - 2012-04-04 07:26:33 --> Final output sent to browser
DEBUG - 2012-04-04 07:26:33 --> Total execution time: 0.1843
DEBUG - 2012-04-04 07:26:43 --> Config Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:26:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:26:43 --> URI Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Router Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Output Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Security Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Input Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:26:43 --> Language Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Loader Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Session Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:26:43 --> Session routines successfully run
DEBUG - 2012-04-04 07:26:43 --> Controller Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Model Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Model Class Initialized
DEBUG - 2012-04-04 07:26:43 --> Final output sent to browser
DEBUG - 2012-04-04 07:26:43 --> Total execution time: 0.1815
DEBUG - 2012-04-04 07:26:56 --> Config Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:26:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:26:56 --> URI Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Router Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Output Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Security Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Input Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:26:56 --> Language Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Loader Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Session Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:26:56 --> Session routines successfully run
DEBUG - 2012-04-04 07:26:56 --> Controller Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Model Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Model Class Initialized
DEBUG - 2012-04-04 07:26:56 --> Final output sent to browser
DEBUG - 2012-04-04 07:26:56 --> Total execution time: 0.1861
DEBUG - 2012-04-04 07:27:32 --> Config Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:27:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:27:32 --> URI Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Router Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Output Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Security Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Input Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:27:32 --> Language Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Loader Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Session Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:27:32 --> Session routines successfully run
DEBUG - 2012-04-04 07:27:32 --> Controller Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Model Class Initialized
DEBUG - 2012-04-04 07:27:32 --> Model Class Initialized
DEBUG - 2012-04-04 07:27:32 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:27:32 --> Final output sent to browser
DEBUG - 2012-04-04 07:27:32 --> Total execution time: 0.1925
DEBUG - 2012-04-04 07:27:33 --> Config Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:27:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:27:33 --> URI Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Router Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Output Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Security Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Input Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:27:33 --> Language Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Loader Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Session Class Initialized
DEBUG - 2012-04-04 07:27:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:27:33 --> Session routines successfully run
DEBUG - 2012-04-04 07:27:33 --> Controller Class Initialized
ERROR - 2012-04-04 07:27:33 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 42
ERROR - 2012-04-04 07:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 42
DEBUG - 2012-04-04 07:27:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:27:33 --> Final output sent to browser
DEBUG - 2012-04-04 07:27:33 --> Total execution time: 0.1929
DEBUG - 2012-04-04 07:27:41 --> Config Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:27:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:27:41 --> URI Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Router Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Output Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Security Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Input Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:27:41 --> Language Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Loader Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Session Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:27:41 --> Session routines successfully run
DEBUG - 2012-04-04 07:27:41 --> Controller Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Model Class Initialized
DEBUG - 2012-04-04 07:27:41 --> Model Class Initialized
DEBUG - 2012-04-04 07:27:41 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:27:41 --> Final output sent to browser
DEBUG - 2012-04-04 07:27:41 --> Total execution time: 0.1946
DEBUG - 2012-04-04 07:27:47 --> Config Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:27:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:27:47 --> URI Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Router Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Output Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Security Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Input Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:27:47 --> Language Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Loader Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Database Driver Class Initialized
ERROR - 2012-04-04 07:27:47 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\Software\xampp\htdocs\xcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-04 07:27:47 --> Session Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:27:47 --> Session routines successfully run
DEBUG - 2012-04-04 07:27:47 --> Controller Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Model Class Initialized
DEBUG - 2012-04-04 07:27:47 --> Model Class Initialized
DEBUG - 2012-04-04 07:27:47 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:27:47 --> Final output sent to browser
DEBUG - 2012-04-04 07:27:47 --> Total execution time: 0.2325
DEBUG - 2012-04-04 07:27:55 --> Config Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:27:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:27:55 --> URI Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Router Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Output Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Security Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Input Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:27:55 --> Language Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Loader Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Session Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:27:55 --> Session routines successfully run
DEBUG - 2012-04-04 07:27:55 --> Controller Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Model Class Initialized
DEBUG - 2012-04-04 07:27:55 --> Model Class Initialized
DEBUG - 2012-04-04 07:27:55 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:27:55 --> Final output sent to browser
DEBUG - 2012-04-04 07:27:55 --> Total execution time: 0.2097
DEBUG - 2012-04-04 07:46:12 --> Config Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:46:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:46:12 --> URI Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Router Class Initialized
DEBUG - 2012-04-04 07:46:12 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:46:12 --> Output Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Security Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Input Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:46:12 --> Language Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Loader Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Session Class Initialized
DEBUG - 2012-04-04 07:46:12 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:46:12 --> Session routines successfully run
DEBUG - 2012-04-04 07:46:12 --> Controller Class Initialized
DEBUG - 2012-04-04 07:46:12 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:46:12 --> Final output sent to browser
DEBUG - 2012-04-04 07:46:12 --> Total execution time: 0.1759
DEBUG - 2012-04-04 07:46:14 --> Config Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:46:14 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:46:14 --> URI Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Router Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Output Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Security Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Input Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:46:14 --> Language Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Loader Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Session Class Initialized
DEBUG - 2012-04-04 07:46:14 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:46:14 --> Session routines successfully run
DEBUG - 2012-04-04 07:46:14 --> Controller Class Initialized
ERROR - 2012-04-04 07:46:14 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 47
ERROR - 2012-04-04 07:46:14 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\accounts.php 47
DEBUG - 2012-04-04 07:46:14 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:46:14 --> Final output sent to browser
DEBUG - 2012-04-04 07:46:14 --> Total execution time: 0.2414
DEBUG - 2012-04-04 07:47:58 --> Config Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:47:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:47:58 --> URI Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Router Class Initialized
DEBUG - 2012-04-04 07:47:58 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:47:58 --> Output Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Security Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Input Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:47:58 --> Language Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Loader Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Session Class Initialized
DEBUG - 2012-04-04 07:47:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:47:58 --> Session routines successfully run
DEBUG - 2012-04-04 07:47:58 --> Controller Class Initialized
DEBUG - 2012-04-04 07:47:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:47:58 --> Final output sent to browser
DEBUG - 2012-04-04 07:47:58 --> Total execution time: 0.1772
DEBUG - 2012-04-04 07:48:01 --> Config Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:48:01 --> URI Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Router Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Output Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Security Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Input Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:48:01 --> Language Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Loader Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Session Class Initialized
DEBUG - 2012-04-04 07:48:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:48:01 --> Session routines successfully run
DEBUG - 2012-04-04 07:48:01 --> Controller Class Initialized
DEBUG - 2012-04-04 07:48:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:48:01 --> Final output sent to browser
DEBUG - 2012-04-04 07:48:01 --> Total execution time: 0.1725
DEBUG - 2012-04-04 07:48:03 --> Config Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:48:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:48:03 --> URI Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Router Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Output Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Security Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Input Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:48:03 --> Language Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Loader Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Session Class Initialized
DEBUG - 2012-04-04 07:48:03 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:48:03 --> Session routines successfully run
DEBUG - 2012-04-04 07:48:03 --> Controller Class Initialized
DEBUG - 2012-04-04 07:48:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:48:03 --> Final output sent to browser
DEBUG - 2012-04-04 07:48:03 --> Total execution time: 0.1760
DEBUG - 2012-04-04 07:48:09 --> Config Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:48:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:48:09 --> URI Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Router Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Output Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Security Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Input Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:48:09 --> Language Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Loader Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Session Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:48:09 --> Session routines successfully run
DEBUG - 2012-04-04 07:48:09 --> Controller Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Model Class Initialized
DEBUG - 2012-04-04 07:48:09 --> Model Class Initialized
DEBUG - 2012-04-04 07:48:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:48:09 --> Final output sent to browser
DEBUG - 2012-04-04 07:48:09 --> Total execution time: 0.1966
DEBUG - 2012-04-04 07:48:44 --> Config Class Initialized
DEBUG - 2012-04-04 07:48:44 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:48:44 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:48:44 --> URI Class Initialized
DEBUG - 2012-04-04 07:48:44 --> Router Class Initialized
DEBUG - 2012-04-04 07:48:44 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:48:44 --> Output Class Initialized
DEBUG - 2012-04-04 07:48:45 --> Security Class Initialized
DEBUG - 2012-04-04 07:48:45 --> Input Class Initialized
DEBUG - 2012-04-04 07:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:48:45 --> Language Class Initialized
DEBUG - 2012-04-04 07:48:45 --> Loader Class Initialized
DEBUG - 2012-04-04 07:48:45 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:48:45 --> Session Class Initialized
DEBUG - 2012-04-04 07:48:45 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:48:45 --> Session routines successfully run
DEBUG - 2012-04-04 07:48:45 --> Controller Class Initialized
DEBUG - 2012-04-04 07:48:45 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:48:45 --> Final output sent to browser
DEBUG - 2012-04-04 07:48:45 --> Total execution time: 0.2164
DEBUG - 2012-04-04 07:48:49 --> Config Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:48:49 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:48:49 --> URI Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Router Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Output Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Security Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Input Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:48:49 --> Language Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Loader Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Session Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:48:49 --> Session routines successfully run
DEBUG - 2012-04-04 07:48:49 --> Controller Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Model Class Initialized
DEBUG - 2012-04-04 07:48:49 --> Model Class Initialized
DEBUG - 2012-04-04 07:48:49 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:48:49 --> Final output sent to browser
DEBUG - 2012-04-04 07:48:50 --> Total execution time: 0.2116
DEBUG - 2012-04-04 07:48:57 --> Config Class Initialized
DEBUG - 2012-04-04 07:48:57 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:48:57 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:48:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:48:57 --> URI Class Initialized
DEBUG - 2012-04-04 07:48:57 --> Router Class Initialized
DEBUG - 2012-04-04 07:48:57 --> Output Class Initialized
DEBUG - 2012-04-04 07:48:57 --> Security Class Initialized
DEBUG - 2012-04-04 07:48:58 --> Input Class Initialized
DEBUG - 2012-04-04 07:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:48:58 --> Language Class Initialized
DEBUG - 2012-04-04 07:48:58 --> Loader Class Initialized
DEBUG - 2012-04-04 07:48:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:48:58 --> Session Class Initialized
DEBUG - 2012-04-04 07:48:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:48:58 --> Session routines successfully run
DEBUG - 2012-04-04 07:48:58 --> Controller Class Initialized
DEBUG - 2012-04-04 07:48:58 --> Model Class Initialized
DEBUG - 2012-04-04 07:48:58 --> Model Class Initialized
DEBUG - 2012-04-04 07:48:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:48:58 --> Final output sent to browser
DEBUG - 2012-04-04 07:48:58 --> Total execution time: 0.2188
DEBUG - 2012-04-04 07:49:28 --> Config Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:49:28 --> URI Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Router Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Output Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Security Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Input Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:49:28 --> Language Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Loader Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Session Class Initialized
DEBUG - 2012-04-04 07:49:28 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:49:28 --> Session routines successfully run
DEBUG - 2012-04-04 07:49:28 --> Controller Class Initialized
DEBUG - 2012-04-04 07:49:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:49:28 --> Final output sent to browser
DEBUG - 2012-04-04 07:49:28 --> Total execution time: 0.1927
DEBUG - 2012-04-04 07:49:38 --> Config Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:49:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:49:38 --> URI Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Router Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Output Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Security Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Input Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:49:38 --> Language Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Loader Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Session Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:49:38 --> Session routines successfully run
DEBUG - 2012-04-04 07:49:38 --> Controller Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Model Class Initialized
DEBUG - 2012-04-04 07:49:38 --> Model Class Initialized
DEBUG - 2012-04-04 07:49:38 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:49:38 --> Final output sent to browser
DEBUG - 2012-04-04 07:49:38 --> Total execution time: 0.2110
DEBUG - 2012-04-04 07:49:56 --> Config Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:49:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:49:56 --> URI Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Router Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Output Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Security Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Input Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:49:56 --> Language Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Loader Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Session Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:49:56 --> Session routines successfully run
DEBUG - 2012-04-04 07:49:56 --> Controller Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Model Class Initialized
DEBUG - 2012-04-04 07:49:56 --> Model Class Initialized
DEBUG - 2012-04-04 07:49:56 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:49:56 --> Final output sent to browser
DEBUG - 2012-04-04 07:49:56 --> Total execution time: 0.2061
DEBUG - 2012-04-04 07:49:57 --> Config Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:49:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:49:57 --> URI Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Router Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Output Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Security Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Input Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:49:57 --> Language Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Loader Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Session Class Initialized
DEBUG - 2012-04-04 07:49:57 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:49:57 --> Session routines successfully run
DEBUG - 2012-04-04 07:49:57 --> Controller Class Initialized
DEBUG - 2012-04-04 07:49:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:49:57 --> Final output sent to browser
DEBUG - 2012-04-04 07:49:57 --> Total execution time: 0.1933
DEBUG - 2012-04-04 07:50:03 --> Config Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:50:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:50:03 --> URI Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Router Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Output Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Security Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Input Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:50:03 --> Language Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Loader Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Session Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:50:03 --> Session routines successfully run
DEBUG - 2012-04-04 07:50:03 --> Controller Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Model Class Initialized
DEBUG - 2012-04-04 07:50:03 --> Model Class Initialized
DEBUG - 2012-04-04 07:50:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:50:03 --> Final output sent to browser
DEBUG - 2012-04-04 07:50:03 --> Total execution time: 0.2079
DEBUG - 2012-04-04 07:50:09 --> Config Class Initialized
DEBUG - 2012-04-04 07:50:09 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:50:09 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:50:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:50:09 --> URI Class Initialized
DEBUG - 2012-04-04 07:50:09 --> Router Class Initialized
DEBUG - 2012-04-04 07:50:09 --> Output Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Security Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Input Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:50:10 --> Language Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Loader Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Session Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:50:10 --> Session routines successfully run
DEBUG - 2012-04-04 07:50:10 --> Controller Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Model Class Initialized
DEBUG - 2012-04-04 07:50:10 --> Model Class Initialized
DEBUG - 2012-04-04 07:50:10 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:50:10 --> Final output sent to browser
DEBUG - 2012-04-04 07:50:10 --> Total execution time: 0.2086
DEBUG - 2012-04-04 07:51:15 --> Config Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:51:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:51:15 --> URI Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Router Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Output Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Security Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Input Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:51:15 --> Language Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Loader Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Session Class Initialized
DEBUG - 2012-04-04 07:51:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:51:15 --> Session routines successfully run
DEBUG - 2012-04-04 07:51:15 --> Controller Class Initialized
DEBUG - 2012-04-04 07:51:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:51:15 --> Final output sent to browser
DEBUG - 2012-04-04 07:51:15 --> Total execution time: 0.1933
DEBUG - 2012-04-04 07:51:24 --> Config Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:51:24 --> URI Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Router Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Output Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Security Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Input Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:51:24 --> Language Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Loader Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Session Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:51:24 --> Session routines successfully run
DEBUG - 2012-04-04 07:51:24 --> Controller Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Model Class Initialized
DEBUG - 2012-04-04 07:51:24 --> Model Class Initialized
DEBUG - 2012-04-04 07:51:24 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:51:24 --> Final output sent to browser
DEBUG - 2012-04-04 07:51:24 --> Total execution time: 0.2139
DEBUG - 2012-04-04 07:51:59 --> Config Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:51:59 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:51:59 --> URI Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Router Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Output Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Security Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Input Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:51:59 --> Language Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Loader Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Session Class Initialized
DEBUG - 2012-04-04 07:51:59 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:51:59 --> Session routines successfully run
DEBUG - 2012-04-04 07:51:59 --> Controller Class Initialized
DEBUG - 2012-04-04 07:51:59 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:51:59 --> Final output sent to browser
DEBUG - 2012-04-04 07:51:59 --> Total execution time: 0.1944
DEBUG - 2012-04-04 07:52:11 --> Config Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:52:11 --> URI Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Router Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Output Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Security Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Input Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:52:11 --> Language Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Loader Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Session Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:52:11 --> Session routines successfully run
DEBUG - 2012-04-04 07:52:11 --> Controller Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Model Class Initialized
DEBUG - 2012-04-04 07:52:11 --> Model Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Config Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:53:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:53:17 --> URI Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Router Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Output Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Security Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Input Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:53:17 --> Language Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Loader Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Session Class Initialized
DEBUG - 2012-04-04 07:53:17 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:53:17 --> Session routines successfully run
ERROR - 2012-04-04 07:53:17 --> Unable to load the requested class: url
DEBUG - 2012-04-04 07:54:09 --> Config Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:54:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:54:09 --> URI Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Router Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Output Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Security Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Input Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:54:09 --> Language Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Loader Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:54:09 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Session Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:54:09 --> Session routines successfully run
DEBUG - 2012-04-04 07:54:09 --> Controller Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Config Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:54:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:54:09 --> URI Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Router Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Output Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Security Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Input Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:54:09 --> Language Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Loader Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:54:09 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Session Class Initialized
DEBUG - 2012-04-04 07:54:09 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:54:09 --> Session routines successfully run
DEBUG - 2012-04-04 07:54:09 --> Controller Class Initialized
DEBUG - 2012-04-04 07:54:09 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 07:54:09 --> Final output sent to browser
DEBUG - 2012-04-04 07:54:09 --> Total execution time: 0.2084
DEBUG - 2012-04-04 07:54:27 --> Config Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:54:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:54:27 --> URI Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Router Class Initialized
DEBUG - 2012-04-04 07:54:27 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:54:27 --> Output Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Security Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Input Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:54:27 --> Language Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Loader Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:54:27 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Session Class Initialized
DEBUG - 2012-04-04 07:54:27 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:54:27 --> A session cookie was not found.
DEBUG - 2012-04-04 07:54:27 --> Session routines successfully run
DEBUG - 2012-04-04 07:54:27 --> Controller Class Initialized
DEBUG - 2012-04-04 07:54:27 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:54:27 --> Final output sent to browser
DEBUG - 2012-04-04 07:54:27 --> Total execution time: 0.2429
DEBUG - 2012-04-04 07:54:33 --> Config Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:54:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:54:33 --> URI Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Router Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Output Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Security Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Input Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:54:33 --> Language Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Loader Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:54:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Session Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:54:33 --> Session routines successfully run
DEBUG - 2012-04-04 07:54:33 --> Controller Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Model Class Initialized
DEBUG - 2012-04-04 07:54:33 --> Model Class Initialized
DEBUG - 2012-04-04 07:54:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:54:33 --> Final output sent to browser
DEBUG - 2012-04-04 07:54:33 --> Total execution time: 0.2332
DEBUG - 2012-04-04 07:54:41 --> Config Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:54:41 --> URI Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Router Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Output Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Security Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Input Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:54:41 --> Language Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Loader Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:54:41 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Session Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:54:41 --> Session routines successfully run
DEBUG - 2012-04-04 07:54:41 --> Controller Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Model Class Initialized
DEBUG - 2012-04-04 07:54:41 --> Model Class Initialized
DEBUG - 2012-04-04 07:54:41 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:54:41 --> Final output sent to browser
DEBUG - 2012-04-04 07:54:41 --> Total execution time: 0.2527
DEBUG - 2012-04-04 07:54:53 --> Config Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:54:53 --> URI Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Router Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Output Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Security Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Input Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:54:53 --> Language Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Loader Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:54:53 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Session Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:54:53 --> Session routines successfully run
DEBUG - 2012-04-04 07:54:53 --> Controller Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Model Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Model Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Config Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:54:53 --> URI Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Router Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Output Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Security Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Input Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:54:53 --> Language Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Loader Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:54:53 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Session Class Initialized
DEBUG - 2012-04-04 07:54:53 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:54:53 --> Session routines successfully run
DEBUG - 2012-04-04 07:54:53 --> Controller Class Initialized
DEBUG - 2012-04-04 07:54:53 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 07:54:53 --> Final output sent to browser
DEBUG - 2012-04-04 07:54:53 --> Total execution time: 0.2082
DEBUG - 2012-04-04 07:55:54 --> Config Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:55:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:55:54 --> URI Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Router Class Initialized
DEBUG - 2012-04-04 07:55:54 --> No URI present. Default controller set.
DEBUG - 2012-04-04 07:55:54 --> Output Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Security Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Input Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:55:54 --> Language Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Loader Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:55:54 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Session Class Initialized
DEBUG - 2012-04-04 07:55:54 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:55:54 --> A session cookie was not found.
DEBUG - 2012-04-04 07:55:54 --> Session routines successfully run
DEBUG - 2012-04-04 07:55:54 --> Controller Class Initialized
DEBUG - 2012-04-04 07:55:54 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:55:54 --> Final output sent to browser
DEBUG - 2012-04-04 07:55:54 --> Total execution time: 0.2442
DEBUG - 2012-04-04 07:56:02 --> Config Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:56:02 --> URI Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Router Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Output Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Security Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Input Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:56:02 --> Language Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Loader Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:56:02 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Session Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:56:02 --> Session routines successfully run
DEBUG - 2012-04-04 07:56:02 --> Controller Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Model Class Initialized
DEBUG - 2012-04-04 07:56:02 --> Model Class Initialized
DEBUG - 2012-04-04 07:56:02 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:56:02 --> Final output sent to browser
DEBUG - 2012-04-04 07:56:02 --> Total execution time: 0.2361
DEBUG - 2012-04-04 07:56:29 --> Config Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:56:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:56:29 --> URI Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Router Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Output Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Security Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Input Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:56:29 --> Language Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Loader Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:56:29 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Session Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:56:29 --> Session routines successfully run
DEBUG - 2012-04-04 07:56:29 --> Controller Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Model Class Initialized
DEBUG - 2012-04-04 07:56:29 --> Model Class Initialized
DEBUG - 2012-04-04 07:56:29 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:56:29 --> Final output sent to browser
DEBUG - 2012-04-04 07:56:29 --> Total execution time: 0.2574
DEBUG - 2012-04-04 07:56:42 --> Config Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:56:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:56:42 --> URI Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Router Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Output Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Security Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Input Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:56:42 --> Language Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Loader Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:56:42 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Session Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:56:42 --> Session routines successfully run
DEBUG - 2012-04-04 07:56:42 --> Controller Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Model Class Initialized
DEBUG - 2012-04-04 07:56:42 --> Model Class Initialized
DEBUG - 2012-04-04 07:56:42 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 07:56:42 --> Final output sent to browser
DEBUG - 2012-04-04 07:56:42 --> Total execution time: 0.2395
DEBUG - 2012-04-04 07:56:55 --> Config Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:56:55 --> URI Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Router Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Output Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Security Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Input Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:56:55 --> Language Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Loader Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:56:55 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Session Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:56:55 --> Session routines successfully run
DEBUG - 2012-04-04 07:56:55 --> Controller Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Model Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Model Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Config Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Hooks Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Utf8 Class Initialized
DEBUG - 2012-04-04 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 07:56:55 --> URI Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Router Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Output Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Security Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Input Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 07:56:55 --> Language Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Loader Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Helper loaded: url_helper
DEBUG - 2012-04-04 07:56:55 --> Database Driver Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Session Class Initialized
DEBUG - 2012-04-04 07:56:55 --> Helper loaded: string_helper
DEBUG - 2012-04-04 07:56:55 --> Session routines successfully run
DEBUG - 2012-04-04 07:56:55 --> Controller Class Initialized
DEBUG - 2012-04-04 07:56:55 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 07:56:55 --> Final output sent to browser
DEBUG - 2012-04-04 07:56:55 --> Total execution time: 0.2146
DEBUG - 2012-04-04 08:06:42 --> Config Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:06:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:06:42 --> URI Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Router Class Initialized
DEBUG - 2012-04-04 08:06:42 --> No URI present. Default controller set.
DEBUG - 2012-04-04 08:06:42 --> Output Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Security Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Input Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:06:42 --> Language Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Loader Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:06:42 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Session Class Initialized
DEBUG - 2012-04-04 08:06:42 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:06:42 --> A session cookie was not found.
DEBUG - 2012-04-04 08:06:42 --> Session routines successfully run
DEBUG - 2012-04-04 08:06:42 --> Controller Class Initialized
DEBUG - 2012-04-04 08:06:42 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:06:42 --> Final output sent to browser
DEBUG - 2012-04-04 08:06:42 --> Total execution time: 0.2601
DEBUG - 2012-04-04 08:06:54 --> Config Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:06:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:06:54 --> URI Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Router Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Output Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Security Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Input Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:06:54 --> Language Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Loader Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:06:54 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Session Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:06:54 --> Session routines successfully run
DEBUG - 2012-04-04 08:06:54 --> Controller Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Model Class Initialized
DEBUG - 2012-04-04 08:06:54 --> Model Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Config Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:06:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:06:55 --> URI Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Router Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Output Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Security Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Input Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:06:55 --> Language Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Loader Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:06:55 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Session Class Initialized
DEBUG - 2012-04-04 08:06:55 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:06:55 --> Session routines successfully run
DEBUG - 2012-04-04 08:06:55 --> Controller Class Initialized
DEBUG - 2012-04-04 08:06:55 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:06:55 --> Final output sent to browser
DEBUG - 2012-04-04 08:06:55 --> Total execution time: 0.2159
DEBUG - 2012-04-04 08:07:03 --> Config Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:07:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:07:03 --> URI Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Router Class Initialized
DEBUG - 2012-04-04 08:07:03 --> No URI present. Default controller set.
DEBUG - 2012-04-04 08:07:03 --> Output Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Security Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Input Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:07:03 --> Language Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Loader Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:07:03 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Session Class Initialized
DEBUG - 2012-04-04 08:07:03 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:07:03 --> A session cookie was not found.
DEBUG - 2012-04-04 08:07:03 --> Session routines successfully run
DEBUG - 2012-04-04 08:07:03 --> Controller Class Initialized
DEBUG - 2012-04-04 08:07:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:07:03 --> Final output sent to browser
DEBUG - 2012-04-04 08:07:03 --> Total execution time: 0.2573
DEBUG - 2012-04-04 08:07:11 --> Config Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:07:11 --> URI Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Router Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Output Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Security Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Input Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:07:11 --> Language Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Loader Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:07:11 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Session Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:07:11 --> Session routines successfully run
DEBUG - 2012-04-04 08:07:11 --> Controller Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Model Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Model Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Config Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:07:11 --> URI Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Router Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Output Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Security Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Input Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:07:11 --> Language Class Initialized
DEBUG - 2012-04-04 08:07:11 --> Loader Class Initialized
DEBUG - 2012-04-04 08:07:12 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:07:12 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:07:12 --> Session Class Initialized
DEBUG - 2012-04-04 08:07:12 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:07:12 --> Session routines successfully run
DEBUG - 2012-04-04 08:07:12 --> Controller Class Initialized
DEBUG - 2012-04-04 08:07:12 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:07:12 --> Final output sent to browser
DEBUG - 2012-04-04 08:07:12 --> Total execution time: 0.2199
DEBUG - 2012-04-04 08:13:57 --> Config Class Initialized
DEBUG - 2012-04-04 08:13:57 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:13:57 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:13:57 --> URI Class Initialized
DEBUG - 2012-04-04 08:13:57 --> Router Class Initialized
DEBUG - 2012-04-04 08:13:57 --> No URI present. Default controller set.
DEBUG - 2012-04-04 08:13:57 --> Output Class Initialized
DEBUG - 2012-04-04 08:13:57 --> Security Class Initialized
DEBUG - 2012-04-04 08:13:57 --> Input Class Initialized
DEBUG - 2012-04-04 08:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:13:57 --> Language Class Initialized
DEBUG - 2012-04-04 08:13:57 --> Loader Class Initialized
DEBUG - 2012-04-04 08:13:57 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:13:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:13:58 --> Session Class Initialized
DEBUG - 2012-04-04 08:13:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:13:58 --> Session routines successfully run
DEBUG - 2012-04-04 08:13:58 --> Controller Class Initialized
DEBUG - 2012-04-04 08:13:58 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:13:58 --> Final output sent to browser
DEBUG - 2012-04-04 08:13:58 --> Total execution time: 0.2750
DEBUG - 2012-04-04 08:14:10 --> Config Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:14:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:14:10 --> URI Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Router Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Output Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Security Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Input Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:14:10 --> Language Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Loader Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:14:10 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:14:10 --> Session Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:14:11 --> Session routines successfully run
DEBUG - 2012-04-04 08:14:11 --> Controller Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Config Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:14:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:14:11 --> URI Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Router Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Output Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Security Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Input Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:14:11 --> Language Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Loader Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:14:11 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Session Class Initialized
DEBUG - 2012-04-04 08:14:11 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:14:11 --> A session cookie was not found.
DEBUG - 2012-04-04 08:14:11 --> Session routines successfully run
DEBUG - 2012-04-04 08:14:11 --> Controller Class Initialized
DEBUG - 2012-04-04 08:14:11 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:14:11 --> Final output sent to browser
DEBUG - 2012-04-04 08:14:11 --> Total execution time: 0.2358
DEBUG - 2012-04-04 08:14:23 --> Config Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:14:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:14:23 --> URI Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Router Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Output Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Security Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Input Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:14:23 --> Language Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Loader Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:14:23 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Session Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:14:23 --> Session routines successfully run
DEBUG - 2012-04-04 08:14:23 --> Controller Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Model Class Initialized
DEBUG - 2012-04-04 08:14:23 --> Model Class Initialized
DEBUG - 2012-04-04 08:14:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:14:23 --> Final output sent to browser
DEBUG - 2012-04-04 08:14:23 --> Total execution time: 0.2699
DEBUG - 2012-04-04 08:14:36 --> Config Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:14:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:14:36 --> URI Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Router Class Initialized
DEBUG - 2012-04-04 08:14:36 --> No URI present. Default controller set.
DEBUG - 2012-04-04 08:14:36 --> Output Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Security Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Input Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:14:36 --> Language Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Loader Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:14:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Session Class Initialized
DEBUG - 2012-04-04 08:14:36 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:14:36 --> Session routines successfully run
DEBUG - 2012-04-04 08:14:36 --> Controller Class Initialized
DEBUG - 2012-04-04 08:14:36 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:14:36 --> Final output sent to browser
DEBUG - 2012-04-04 08:14:36 --> Total execution time: 0.2300
DEBUG - 2012-04-04 08:14:50 --> Config Class Initialized
DEBUG - 2012-04-04 08:14:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:14:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:14:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:14:51 --> URI Class Initialized
DEBUG - 2012-04-04 08:14:51 --> Router Class Initialized
DEBUG - 2012-04-04 08:14:51 --> No URI present. Default controller set.
DEBUG - 2012-04-04 08:14:51 --> Output Class Initialized
DEBUG - 2012-04-04 08:14:51 --> Security Class Initialized
DEBUG - 2012-04-04 08:14:51 --> Input Class Initialized
DEBUG - 2012-04-04 08:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:14:51 --> Language Class Initialized
DEBUG - 2012-04-04 08:14:51 --> Loader Class Initialized
DEBUG - 2012-04-04 08:14:51 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:14:51 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:14:51 --> Session Class Initialized
DEBUG - 2012-04-04 08:14:51 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:14:51 --> Session routines successfully run
DEBUG - 2012-04-04 08:14:51 --> Controller Class Initialized
DEBUG - 2012-04-04 08:14:51 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:14:51 --> Final output sent to browser
DEBUG - 2012-04-04 08:14:51 --> Total execution time: 0.2230
DEBUG - 2012-04-04 08:15:10 --> Config Class Initialized
DEBUG - 2012-04-04 08:15:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:15:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:15:10 --> URI Class Initialized
DEBUG - 2012-04-04 08:15:10 --> Router Class Initialized
ERROR - 2012-04-04 08:15:10 --> 404 Page Not Found --> user_view.html
DEBUG - 2012-04-04 08:15:31 --> Config Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:15:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:15:31 --> URI Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Router Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Output Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Security Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Input Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:15:31 --> Language Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Loader Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:15:31 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Session Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:15:31 --> Session routines successfully run
DEBUG - 2012-04-04 08:15:31 --> Controller Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Model Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Model Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Config Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:15:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:15:31 --> URI Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Router Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Output Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Security Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Input Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:15:31 --> Language Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Loader Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:15:31 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Session Class Initialized
DEBUG - 2012-04-04 08:15:31 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:15:31 --> Session routines successfully run
DEBUG - 2012-04-04 08:15:31 --> Controller Class Initialized
DEBUG - 2012-04-04 08:15:31 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:15:31 --> Final output sent to browser
DEBUG - 2012-04-04 08:15:31 --> Total execution time: 0.2256
DEBUG - 2012-04-04 08:15:42 --> Config Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:15:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:15:42 --> URI Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Router Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Output Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Security Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Input Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:15:42 --> Language Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Loader Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:15:42 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Session Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:15:42 --> Session routines successfully run
DEBUG - 2012-04-04 08:15:42 --> Controller Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Config Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:15:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:15:42 --> URI Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Router Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Output Class Initialized
DEBUG - 2012-04-04 08:15:42 --> Security Class Initialized
DEBUG - 2012-04-04 08:15:43 --> Input Class Initialized
DEBUG - 2012-04-04 08:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:15:43 --> Language Class Initialized
DEBUG - 2012-04-04 08:15:43 --> Loader Class Initialized
DEBUG - 2012-04-04 08:15:43 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:15:43 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:15:43 --> Session Class Initialized
DEBUG - 2012-04-04 08:15:43 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:15:43 --> Session routines successfully run
DEBUG - 2012-04-04 08:15:43 --> Controller Class Initialized
DEBUG - 2012-04-04 08:15:43 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:15:43 --> Final output sent to browser
DEBUG - 2012-04-04 08:15:43 --> Total execution time: 0.2240
DEBUG - 2012-04-04 08:15:49 --> Config Class Initialized
DEBUG - 2012-04-04 08:15:49 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:15:49 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:15:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:15:50 --> URI Class Initialized
DEBUG - 2012-04-04 08:15:50 --> Router Class Initialized
DEBUG - 2012-04-04 08:15:50 --> No URI present. Default controller set.
DEBUG - 2012-04-04 08:15:50 --> Output Class Initialized
DEBUG - 2012-04-04 08:15:50 --> Security Class Initialized
DEBUG - 2012-04-04 08:15:50 --> Input Class Initialized
DEBUG - 2012-04-04 08:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:15:50 --> Language Class Initialized
DEBUG - 2012-04-04 08:15:50 --> Loader Class Initialized
DEBUG - 2012-04-04 08:15:50 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:15:50 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:15:50 --> Session Class Initialized
DEBUG - 2012-04-04 08:15:50 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:15:50 --> Session routines successfully run
DEBUG - 2012-04-04 08:15:50 --> Controller Class Initialized
DEBUG - 2012-04-04 08:15:50 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:15:50 --> Final output sent to browser
DEBUG - 2012-04-04 08:15:50 --> Total execution time: 0.2339
DEBUG - 2012-04-04 08:15:56 --> Config Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:15:56 --> URI Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Router Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Output Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Security Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Input Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:15:56 --> Language Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Loader Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:15:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Session Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:15:56 --> Session routines successfully run
DEBUG - 2012-04-04 08:15:56 --> Controller Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Config Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:15:56 --> URI Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Router Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Output Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Security Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Input Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:15:56 --> Language Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Loader Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:15:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Session Class Initialized
DEBUG - 2012-04-04 08:15:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:15:56 --> A session cookie was not found.
DEBUG - 2012-04-04 08:15:56 --> Session routines successfully run
DEBUG - 2012-04-04 08:15:56 --> Controller Class Initialized
DEBUG - 2012-04-04 08:15:56 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:15:56 --> Final output sent to browser
DEBUG - 2012-04-04 08:15:56 --> Total execution time: 0.2305
DEBUG - 2012-04-04 08:21:23 --> Config Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:21:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:21:23 --> URI Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Router Class Initialized
DEBUG - 2012-04-04 08:21:23 --> No URI present. Default controller set.
DEBUG - 2012-04-04 08:21:23 --> Output Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Security Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Input Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:21:23 --> Language Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Loader Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:21:23 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Session Class Initialized
DEBUG - 2012-04-04 08:21:23 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:21:23 --> A session cookie was not found.
DEBUG - 2012-04-04 08:21:23 --> Session routines successfully run
DEBUG - 2012-04-04 08:21:23 --> Controller Class Initialized
DEBUG - 2012-04-04 08:21:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:21:23 --> Final output sent to browser
DEBUG - 2012-04-04 08:21:23 --> Total execution time: 0.2706
DEBUG - 2012-04-04 08:21:32 --> Config Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:21:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:21:32 --> URI Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Router Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Output Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Security Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Input Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:21:32 --> Language Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Loader Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:21:32 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Session Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:21:32 --> Session routines successfully run
DEBUG - 2012-04-04 08:21:32 --> Controller Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Model Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Model Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Config Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:21:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:21:32 --> URI Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Router Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Output Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Security Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Input Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:21:32 --> Language Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Loader Class Initialized
DEBUG - 2012-04-04 08:21:32 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:21:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:21:33 --> Session Class Initialized
DEBUG - 2012-04-04 08:21:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:21:33 --> Session routines successfully run
DEBUG - 2012-04-04 08:21:33 --> Controller Class Initialized
DEBUG - 2012-04-04 08:21:33 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:21:33 --> Final output sent to browser
DEBUG - 2012-04-04 08:21:33 --> Total execution time: 0.2399
DEBUG - 2012-04-04 08:21:36 --> Config Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:21:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:21:36 --> URI Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Router Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Output Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Security Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Input Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:21:36 --> Language Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Loader Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:21:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Session Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:21:36 --> Session routines successfully run
DEBUG - 2012-04-04 08:21:36 --> Controller Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Config Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:21:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:21:36 --> URI Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Router Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Output Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Security Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Input Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:21:36 --> Language Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Loader Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:21:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Session Class Initialized
DEBUG - 2012-04-04 08:21:36 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:21:36 --> A session cookie was not found.
DEBUG - 2012-04-04 08:21:36 --> Session routines successfully run
DEBUG - 2012-04-04 08:21:36 --> Controller Class Initialized
DEBUG - 2012-04-04 08:21:36 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:21:36 --> Final output sent to browser
DEBUG - 2012-04-04 08:21:36 --> Total execution time: 0.2032
DEBUG - 2012-04-04 08:21:48 --> Config Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:21:48 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:21:48 --> URI Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Router Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Output Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Security Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Input Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:21:48 --> Language Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Loader Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:21:48 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Session Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:21:48 --> Session routines successfully run
DEBUG - 2012-04-04 08:21:48 --> Controller Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Model Class Initialized
DEBUG - 2012-04-04 08:21:48 --> Model Class Initialized
DEBUG - 2012-04-04 08:21:48 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 08:21:48 --> Final output sent to browser
DEBUG - 2012-04-04 08:21:48 --> Total execution time: 0.2786
DEBUG - 2012-04-04 08:21:58 --> Config Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:21:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:21:58 --> URI Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Router Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Output Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Security Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Input Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:21:58 --> Language Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Loader Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:21:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Session Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:21:58 --> Session routines successfully run
DEBUG - 2012-04-04 08:21:58 --> Controller Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Model Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Model Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Config Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:21:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:21:58 --> URI Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Router Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Output Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Security Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Input Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:21:58 --> Language Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Loader Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:21:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Session Class Initialized
DEBUG - 2012-04-04 08:21:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:21:58 --> Session routines successfully run
DEBUG - 2012-04-04 08:21:58 --> Controller Class Initialized
DEBUG - 2012-04-04 08:21:58 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:21:58 --> Final output sent to browser
DEBUG - 2012-04-04 08:21:58 --> Total execution time: 0.2316
DEBUG - 2012-04-04 08:22:15 --> Config Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:22:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:22:15 --> URI Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Router Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Output Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Security Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Input Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:22:15 --> Language Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Loader Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:22:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Session Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:22:15 --> Session routines successfully run
DEBUG - 2012-04-04 08:22:15 --> Controller Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Config Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 08:22:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 08:22:15 --> URI Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Router Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Output Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Security Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Input Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 08:22:15 --> Language Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Loader Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Helper loaded: url_helper
DEBUG - 2012-04-04 08:22:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Session Class Initialized
DEBUG - 2012-04-04 08:22:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 08:22:15 --> Session routines successfully run
DEBUG - 2012-04-04 08:22:15 --> Controller Class Initialized
DEBUG - 2012-04-04 08:22:15 --> File loaded: system/views/user_view.php
DEBUG - 2012-04-04 08:22:15 --> Final output sent to browser
DEBUG - 2012-04-04 08:22:15 --> Total execution time: 0.2520
DEBUG - 2012-04-04 13:03:03 --> Config Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:03:03 --> URI Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Router Class Initialized
DEBUG - 2012-04-04 13:03:03 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:03:03 --> Output Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Security Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Input Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:03:03 --> Language Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Loader Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:03:03 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Session Class Initialized
DEBUG - 2012-04-04 13:03:03 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:03:03 --> A session cookie was not found.
DEBUG - 2012-04-04 13:03:03 --> Session routines successfully run
DEBUG - 2012-04-04 13:03:03 --> Controller Class Initialized
DEBUG - 2012-04-04 13:03:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:03:03 --> Final output sent to browser
DEBUG - 2012-04-04 13:03:03 --> Total execution time: 0.2282
DEBUG - 2012-04-04 13:03:15 --> Config Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:03:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:03:15 --> URI Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Router Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Output Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Security Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Input Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:03:15 --> Language Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Loader Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:03:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Session Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:03:15 --> Session routines successfully run
DEBUG - 2012-04-04 13:03:15 --> Controller Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Model Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Model Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Config Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:03:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:03:15 --> URI Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Router Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Output Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Security Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Input Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:03:15 --> Language Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Loader Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:03:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Session Class Initialized
DEBUG - 2012-04-04 13:03:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:03:15 --> Session routines successfully run
DEBUG - 2012-04-04 13:03:15 --> Controller Class Initialized
ERROR - 2012-04-04 13:03:15 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:03:15 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:03:15 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:03:15 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:03:15 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:03:15 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:03:15 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:03:15 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:03:15 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:03:15 --> Final output sent to browser
DEBUG - 2012-04-04 13:03:15 --> Total execution time: 0.3018
DEBUG - 2012-04-04 13:03:54 --> Config Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:03:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:03:54 --> URI Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Router Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Output Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Security Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Input Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:03:54 --> Language Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Loader Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:03:54 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Session Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:03:54 --> Session routines successfully run
DEBUG - 2012-04-04 13:03:54 --> Controller Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Config Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:03:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:03:54 --> URI Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Router Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Output Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Security Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Input Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:03:54 --> Language Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Loader Class Initialized
DEBUG - 2012-04-04 13:03:54 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:03:55 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:03:55 --> Session Class Initialized
DEBUG - 2012-04-04 13:03:55 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:03:55 --> Session routines successfully run
DEBUG - 2012-04-04 13:03:55 --> Controller Class Initialized
ERROR - 2012-04-04 13:03:55 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:03:55 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:03:55 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:03:55 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:03:55 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:03:55 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:03:55 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:03:55 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:03:55 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:03:55 --> Final output sent to browser
DEBUG - 2012-04-04 13:03:55 --> Total execution time: 0.3015
DEBUG - 2012-04-04 13:05:30 --> Config Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:05:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:05:30 --> URI Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Router Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Output Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Security Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Input Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:05:30 --> Language Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Loader Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:05:30 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Session Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:05:30 --> Session routines successfully run
DEBUG - 2012-04-04 13:05:30 --> Controller Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Config Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:05:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:05:30 --> URI Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Router Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Output Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Security Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Input Class Initialized
DEBUG - 2012-04-04 13:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:05:30 --> Language Class Initialized
DEBUG - 2012-04-04 13:05:31 --> Loader Class Initialized
DEBUG - 2012-04-04 13:05:31 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:05:31 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:05:31 --> Session Class Initialized
DEBUG - 2012-04-04 13:05:31 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:05:31 --> Session routines successfully run
DEBUG - 2012-04-04 13:05:31 --> Controller Class Initialized
ERROR - 2012-04-04 13:05:31 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:05:31 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:05:31 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:05:31 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:05:31 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:05:31 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:05:31 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:05:31 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:05:31 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:05:31 --> Final output sent to browser
DEBUG - 2012-04-04 13:05:31 --> Total execution time: 0.3043
DEBUG - 2012-04-04 13:09:22 --> Config Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:09:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:09:22 --> URI Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Router Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Output Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Security Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Input Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:09:22 --> Language Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Loader Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:09:22 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Session Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:09:22 --> Session routines successfully run
DEBUG - 2012-04-04 13:09:22 --> Controller Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Config Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:09:22 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:09:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:09:23 --> URI Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Router Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Output Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Security Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Input Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:09:23 --> Language Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Loader Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:09:23 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Session Class Initialized
DEBUG - 2012-04-04 13:09:23 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:09:23 --> A session cookie was not found.
DEBUG - 2012-04-04 13:09:23 --> Session routines successfully run
DEBUG - 2012-04-04 13:09:23 --> Controller Class Initialized
DEBUG - 2012-04-04 13:09:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:09:23 --> Final output sent to browser
DEBUG - 2012-04-04 13:09:23 --> Total execution time: 0.2382
DEBUG - 2012-04-04 13:09:32 --> Config Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:09:32 --> URI Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Router Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Output Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Security Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Input Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:09:32 --> Language Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Loader Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:09:32 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Session Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:09:32 --> Session routines successfully run
DEBUG - 2012-04-04 13:09:32 --> Controller Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Model Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Model Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Config Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:09:32 --> URI Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Router Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Output Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Security Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Input Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:09:32 --> Language Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Loader Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:09:32 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Session Class Initialized
DEBUG - 2012-04-04 13:09:32 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:09:32 --> Session routines successfully run
DEBUG - 2012-04-04 13:09:32 --> Controller Class Initialized
ERROR - 2012-04-04 13:09:32 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:09:32 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:09:32 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:09:32 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:09:32 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:09:32 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:09:32 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:09:32 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:09:32 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:09:32 --> Final output sent to browser
DEBUG - 2012-04-04 13:09:32 --> Total execution time: 0.2983
DEBUG - 2012-04-04 13:13:36 --> Config Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:13:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:13:36 --> URI Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Router Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Output Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Security Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Input Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:13:36 --> Language Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Loader Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:13:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Session Class Initialized
DEBUG - 2012-04-04 13:13:36 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:13:36 --> Session routines successfully run
DEBUG - 2012-04-04 13:13:36 --> Controller Class Initialized
ERROR - 2012-04-04 13:13:36 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:13:36 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:13:36 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:13:36 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:13:36 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:13:36 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:13:36 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:13:36 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:13:36 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:13:36 --> Final output sent to browser
DEBUG - 2012-04-04 13:13:36 --> Total execution time: 0.3133
DEBUG - 2012-04-04 13:13:43 --> Config Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:13:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:13:43 --> URI Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Router Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Output Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Security Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Input Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:13:43 --> Language Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Loader Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:13:43 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Session Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:13:43 --> Session routines successfully run
DEBUG - 2012-04-04 13:13:43 --> Controller Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Config Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:13:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:13:43 --> URI Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Router Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Output Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Security Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Input Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:13:43 --> Language Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Loader Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:13:43 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Session Class Initialized
DEBUG - 2012-04-04 13:13:43 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:13:43 --> Session routines successfully run
DEBUG - 2012-04-04 13:13:43 --> Controller Class Initialized
ERROR - 2012-04-04 13:13:43 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:13:43 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:13:43 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:13:43 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:13:43 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:13:43 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:13:43 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:13:43 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:13:43 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:13:43 --> Final output sent to browser
DEBUG - 2012-04-04 13:13:43 --> Total execution time: 0.3053
DEBUG - 2012-04-04 13:14:50 --> Config Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:14:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:14:50 --> URI Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Router Class Initialized
DEBUG - 2012-04-04 13:14:50 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:14:50 --> Output Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Security Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Input Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:14:50 --> Language Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Loader Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:14:50 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Session Class Initialized
DEBUG - 2012-04-04 13:14:50 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:14:50 --> Session routines successfully run
DEBUG - 2012-04-04 13:14:50 --> Controller Class Initialized
ERROR - 2012-04-04 13:14:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:14:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:14:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:14:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:14:50 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:14:50 --> Final output sent to browser
DEBUG - 2012-04-04 13:14:50 --> Total execution time: 0.2874
DEBUG - 2012-04-04 13:14:55 --> Config Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:14:55 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:14:55 --> URI Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Router Class Initialized
DEBUG - 2012-04-04 13:14:55 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:14:55 --> Output Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Security Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Input Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:14:55 --> Language Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Loader Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:14:55 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Session Class Initialized
DEBUG - 2012-04-04 13:14:55 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:14:55 --> Session routines successfully run
DEBUG - 2012-04-04 13:14:55 --> Controller Class Initialized
ERROR - 2012-04-04 13:14:55 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:14:55 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:14:55 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:14:55 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:14:55 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:14:55 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:14:55 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:14:55 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:14:55 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:14:55 --> Final output sent to browser
DEBUG - 2012-04-04 13:14:55 --> Total execution time: 0.3301
DEBUG - 2012-04-04 13:15:01 --> Config Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:15:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:15:01 --> URI Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Router Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Output Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Security Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Input Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:15:01 --> Language Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Loader Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:15:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Session Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:15:01 --> Session routines successfully run
DEBUG - 2012-04-04 13:15:01 --> Controller Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Config Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:15:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:15:01 --> URI Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Router Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Output Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Security Class Initialized
DEBUG - 2012-04-04 13:15:01 --> Input Class Initialized
DEBUG - 2012-04-04 13:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:15:02 --> Language Class Initialized
DEBUG - 2012-04-04 13:15:02 --> Loader Class Initialized
DEBUG - 2012-04-04 13:15:02 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:15:02 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:15:02 --> Session Class Initialized
DEBUG - 2012-04-04 13:15:02 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:15:02 --> A session cookie was not found.
DEBUG - 2012-04-04 13:15:02 --> Session routines successfully run
DEBUG - 2012-04-04 13:15:02 --> Controller Class Initialized
DEBUG - 2012-04-04 13:15:02 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:15:02 --> Final output sent to browser
DEBUG - 2012-04-04 13:15:02 --> Total execution time: 0.2433
DEBUG - 2012-04-04 13:15:10 --> Config Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:15:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:15:10 --> URI Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Router Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Output Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Security Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Input Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:15:10 --> Language Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Loader Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:15:10 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:15:10 --> Session Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:15:11 --> Session routines successfully run
DEBUG - 2012-04-04 13:15:11 --> Controller Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Model Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Model Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Config Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:15:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:15:11 --> URI Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Router Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Output Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Security Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Input Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:15:11 --> Language Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Loader Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:15:11 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Session Class Initialized
DEBUG - 2012-04-04 13:15:11 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:15:11 --> Session routines successfully run
DEBUG - 2012-04-04 13:15:11 --> Controller Class Initialized
ERROR - 2012-04-04 13:15:11 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:15:11 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:15:11 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:15:11 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:15:11 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:15:11 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:15:11 --> Final output sent to browser
DEBUG - 2012-04-04 13:15:11 --> Total execution time: 0.2968
DEBUG - 2012-04-04 13:16:33 --> Config Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:16:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:16:33 --> URI Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Router Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Output Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Security Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Input Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:16:33 --> Language Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Loader Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:16:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Session Class Initialized
DEBUG - 2012-04-04 13:16:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:16:33 --> Session routines successfully run
DEBUG - 2012-04-04 13:16:33 --> Controller Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Config Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:16:34 --> URI Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Router Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Output Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Security Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Input Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:16:34 --> Language Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Loader Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:16:34 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Session Class Initialized
DEBUG - 2012-04-04 13:16:34 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:16:34 --> A session cookie was not found.
DEBUG - 2012-04-04 13:16:34 --> Session routines successfully run
DEBUG - 2012-04-04 13:16:34 --> Controller Class Initialized
DEBUG - 2012-04-04 13:16:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:16:34 --> Final output sent to browser
DEBUG - 2012-04-04 13:16:34 --> Total execution time: 0.2394
DEBUG - 2012-04-04 13:16:52 --> Config Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:16:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:16:52 --> URI Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Router Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Output Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Security Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Input Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:16:52 --> Language Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Loader Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:16:52 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Session Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:16:52 --> Session routines successfully run
DEBUG - 2012-04-04 13:16:52 --> Controller Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Model Class Initialized
DEBUG - 2012-04-04 13:16:52 --> Model Class Initialized
ERROR - 2012-04-04 13:16:52 --> Severity: Notice  --> Undefined property: Accounts::$UserID C:\Software\xampp\htdocs\xcms\system\core\Model.php 51
DEBUG - 2012-04-04 13:16:52 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:16:52 --> Final output sent to browser
DEBUG - 2012-04-04 13:16:52 --> Total execution time: 0.2637
DEBUG - 2012-04-04 13:23:30 --> Config Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:23:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:23:30 --> URI Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Router Class Initialized
DEBUG - 2012-04-04 13:23:30 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:23:30 --> Output Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Security Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Input Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:23:30 --> Language Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Loader Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:23:30 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Session Class Initialized
DEBUG - 2012-04-04 13:23:30 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:23:30 --> Session routines successfully run
DEBUG - 2012-04-04 13:23:30 --> Controller Class Initialized
DEBUG - 2012-04-04 13:23:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:23:30 --> Final output sent to browser
DEBUG - 2012-04-04 13:23:30 --> Total execution time: 0.2390
DEBUG - 2012-04-04 13:23:39 --> Config Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:23:39 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:23:39 --> URI Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Router Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Output Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Security Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Input Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:23:39 --> Language Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Loader Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:23:39 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Session Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:23:39 --> Session routines successfully run
DEBUG - 2012-04-04 13:23:39 --> Controller Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Model Class Initialized
DEBUG - 2012-04-04 13:23:39 --> Model Class Initialized
ERROR - 2012-04-04 13:23:39 --> Severity: Notice  --> Undefined property: Accounts::$UserID C:\Software\xampp\htdocs\xcms\system\core\Model.php 51
ERROR - 2012-04-04 13:23:39 --> Severity: Notice  --> Undefined property: Accounts::$FirstName C:\Software\xampp\htdocs\xcms\system\core\Model.php 51
DEBUG - 2012-04-04 13:23:39 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:23:39 --> Final output sent to browser
DEBUG - 2012-04-04 13:23:39 --> Total execution time: 0.2713
DEBUG - 2012-04-04 13:24:10 --> Config Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:24:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:24:10 --> URI Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Router Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Output Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Security Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Input Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:24:10 --> Language Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Loader Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:24:10 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Session Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:24:10 --> Session routines successfully run
DEBUG - 2012-04-04 13:24:10 --> Controller Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Model Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Model Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Config Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:24:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:24:10 --> URI Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Router Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Output Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Security Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Input Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:24:10 --> Language Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Loader Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:24:10 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Session Class Initialized
DEBUG - 2012-04-04 13:24:10 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:24:10 --> Session routines successfully run
DEBUG - 2012-04-04 13:24:10 --> Controller Class Initialized
ERROR - 2012-04-04 13:24:10 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:24:10 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:24:10 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:24:10 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:24:10 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:24:10 --> Final output sent to browser
DEBUG - 2012-04-04 13:24:10 --> Total execution time: 0.3015
DEBUG - 2012-04-04 13:24:29 --> Config Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:24:29 --> URI Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Router Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Output Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Security Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Input Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:24:29 --> Language Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Loader Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:24:29 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Session Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:24:29 --> Session routines successfully run
DEBUG - 2012-04-04 13:24:29 --> Controller Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Config Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:24:29 --> URI Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Router Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Output Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Security Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Input Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:24:29 --> Language Class Initialized
DEBUG - 2012-04-04 13:24:29 --> Loader Class Initialized
DEBUG - 2012-04-04 13:24:30 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:24:30 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:24:30 --> Session Class Initialized
DEBUG - 2012-04-04 13:24:30 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:24:30 --> A session cookie was not found.
DEBUG - 2012-04-04 13:24:30 --> Session routines successfully run
DEBUG - 2012-04-04 13:24:30 --> Controller Class Initialized
DEBUG - 2012-04-04 13:24:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:24:30 --> Final output sent to browser
DEBUG - 2012-04-04 13:24:30 --> Total execution time: 0.2349
DEBUG - 2012-04-04 13:25:20 --> Config Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:25:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:25:20 --> URI Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Router Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Output Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Security Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Input Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:25:20 --> Language Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Loader Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:25:20 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Session Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:25:20 --> Session routines successfully run
DEBUG - 2012-04-04 13:25:20 --> Controller Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Model Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Model Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Config Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:25:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:25:20 --> URI Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Router Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Output Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Security Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Input Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:25:20 --> Language Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Loader Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:25:20 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Session Class Initialized
DEBUG - 2012-04-04 13:25:20 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:25:20 --> Session routines successfully run
DEBUG - 2012-04-04 13:25:20 --> Controller Class Initialized
ERROR - 2012-04-04 13:25:20 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:25:20 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:25:20 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:25:20 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:25:20 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:25:20 --> Final output sent to browser
DEBUG - 2012-04-04 13:25:20 --> Total execution time: 0.3002
DEBUG - 2012-04-04 13:47:29 --> Config Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:47:29 --> URI Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Router Class Initialized
DEBUG - 2012-04-04 13:47:29 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:47:29 --> Output Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Security Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Input Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:47:29 --> Language Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Loader Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:47:29 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Session Class Initialized
DEBUG - 2012-04-04 13:47:29 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:47:29 --> A session cookie was not found.
DEBUG - 2012-04-04 13:47:29 --> Session routines successfully run
DEBUG - 2012-04-04 13:47:29 --> Controller Class Initialized
DEBUG - 2012-04-04 13:47:29 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:47:29 --> Final output sent to browser
DEBUG - 2012-04-04 13:47:29 --> Total execution time: 0.0796
DEBUG - 2012-04-04 13:47:40 --> Config Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:47:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:47:40 --> URI Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Router Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Output Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Security Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Input Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:47:40 --> Language Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Loader Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:47:40 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Session Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:47:40 --> Session routines successfully run
DEBUG - 2012-04-04 13:47:40 --> Controller Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Model Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Model Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Config Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:47:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:47:40 --> URI Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Router Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Output Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Security Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Input Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:47:40 --> Language Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Loader Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:47:40 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Session Class Initialized
DEBUG - 2012-04-04 13:47:40 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:47:40 --> Session routines successfully run
DEBUG - 2012-04-04 13:47:40 --> Controller Class Initialized
ERROR - 2012-04-04 13:47:40 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:47:40 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:47:40 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:47:40 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:47:40 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:47:40 --> Final output sent to browser
DEBUG - 2012-04-04 13:47:40 --> Total execution time: 0.0876
DEBUG - 2012-04-04 13:48:23 --> Config Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:48:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:48:23 --> URI Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Router Class Initialized
DEBUG - 2012-04-04 13:48:23 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:48:23 --> Output Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Security Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Input Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:48:23 --> Language Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Loader Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:48:23 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Session Class Initialized
DEBUG - 2012-04-04 13:48:23 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:48:23 --> Session routines successfully run
DEBUG - 2012-04-04 13:48:23 --> Controller Class Initialized
ERROR - 2012-04-04 13:48:23 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:48:23 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:48:23 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:48:23 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:48:23 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:48:23 --> Final output sent to browser
DEBUG - 2012-04-04 13:48:23 --> Total execution time: 0.1262
DEBUG - 2012-04-04 13:48:32 --> Config Class Initialized
DEBUG - 2012-04-04 13:48:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:48:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:48:33 --> URI Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Router Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Output Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Security Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Input Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:48:33 --> Language Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Loader Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:48:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Session Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:48:33 --> Session routines successfully run
DEBUG - 2012-04-04 13:48:33 --> Controller Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Config Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:48:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:48:33 --> URI Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Router Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Output Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Security Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Input Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:48:33 --> Language Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Loader Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:48:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Session Class Initialized
DEBUG - 2012-04-04 13:48:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:48:33 --> A session cookie was not found.
DEBUG - 2012-04-04 13:48:33 --> Session routines successfully run
DEBUG - 2012-04-04 13:48:33 --> Controller Class Initialized
DEBUG - 2012-04-04 13:48:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:48:33 --> Final output sent to browser
DEBUG - 2012-04-04 13:48:33 --> Total execution time: 0.0688
DEBUG - 2012-04-04 13:48:44 --> Config Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:48:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:48:44 --> URI Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Router Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Output Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Security Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Input Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:48:44 --> Language Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Loader Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:48:44 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Session Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:48:44 --> Session routines successfully run
DEBUG - 2012-04-04 13:48:44 --> Controller Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Model Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Model Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Config Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:48:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:48:44 --> URI Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Router Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Output Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Security Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Input Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:48:44 --> Language Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Loader Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:48:44 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Session Class Initialized
DEBUG - 2012-04-04 13:48:44 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:48:44 --> Session routines successfully run
DEBUG - 2012-04-04 13:48:44 --> Controller Class Initialized
ERROR - 2012-04-04 13:48:44 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:48:44 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:48:44 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:48:44 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:48:44 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:48:44 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:48:44 --> Final output sent to browser
DEBUG - 2012-04-04 13:48:44 --> Total execution time: 0.0861
DEBUG - 2012-04-04 13:49:29 --> Config Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:49:29 --> URI Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Router Class Initialized
DEBUG - 2012-04-04 13:49:29 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:49:29 --> Output Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Security Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Input Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:49:29 --> Language Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Loader Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:49:29 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Session Class Initialized
DEBUG - 2012-04-04 13:49:29 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:49:29 --> Session routines successfully run
DEBUG - 2012-04-04 13:49:29 --> Controller Class Initialized
ERROR - 2012-04-04 13:49:29 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:49:29 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:49:29 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:49:29 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:49:29 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:49:29 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:49:29 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:49:29 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:49:29 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:49:29 --> Final output sent to browser
DEBUG - 2012-04-04 13:49:29 --> Total execution time: 0.0902
DEBUG - 2012-04-04 13:49:33 --> Config Class Initialized
DEBUG - 2012-04-04 13:49:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:49:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:49:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:49:33 --> URI Class Initialized
DEBUG - 2012-04-04 13:49:33 --> Router Class Initialized
DEBUG - 2012-04-04 13:49:33 --> Output Class Initialized
DEBUG - 2012-04-04 13:49:33 --> Security Class Initialized
DEBUG - 2012-04-04 13:49:33 --> Input Class Initialized
DEBUG - 2012-04-04 13:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:49:33 --> Language Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Loader Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:49:34 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Session Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:49:34 --> Session routines successfully run
DEBUG - 2012-04-04 13:49:34 --> Controller Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Config Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:49:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:49:34 --> URI Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Router Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Output Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Security Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Input Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:49:34 --> Language Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Loader Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:49:34 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Session Class Initialized
DEBUG - 2012-04-04 13:49:34 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:49:34 --> A session cookie was not found.
DEBUG - 2012-04-04 13:49:34 --> Session routines successfully run
DEBUG - 2012-04-04 13:49:34 --> Controller Class Initialized
DEBUG - 2012-04-04 13:49:34 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:49:34 --> Final output sent to browser
DEBUG - 2012-04-04 13:49:34 --> Total execution time: 0.0759
DEBUG - 2012-04-04 13:49:37 --> Config Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:49:37 --> URI Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Router Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Output Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Security Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Input Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:49:37 --> Language Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Loader Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:49:37 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Session Class Initialized
DEBUG - 2012-04-04 13:49:37 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:49:37 --> Session routines successfully run
DEBUG - 2012-04-04 13:49:37 --> Controller Class Initialized
DEBUG - 2012-04-04 13:49:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:49:37 --> Final output sent to browser
DEBUG - 2012-04-04 13:49:37 --> Total execution time: 0.0671
DEBUG - 2012-04-04 13:49:50 --> Config Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:49:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:49:50 --> URI Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Router Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Output Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Security Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Input Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:49:50 --> Language Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Loader Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:49:50 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Session Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:49:50 --> Session routines successfully run
DEBUG - 2012-04-04 13:49:50 --> Controller Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Model Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Model Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Config Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:49:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:49:50 --> URI Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Router Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Output Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Security Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Input Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:49:50 --> Language Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Loader Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:49:50 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Session Class Initialized
DEBUG - 2012-04-04 13:49:50 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:49:50 --> Session routines successfully run
DEBUG - 2012-04-04 13:49:50 --> Controller Class Initialized
ERROR - 2012-04-04 13:49:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:49:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:49:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:49:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:49:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:49:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:49:50 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:49:50 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:49:50 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:49:50 --> Final output sent to browser
DEBUG - 2012-04-04 13:49:51 --> Total execution time: 0.0873
DEBUG - 2012-04-04 13:52:33 --> Config Class Initialized
DEBUG - 2012-04-04 13:52:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:52:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:52:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:52:33 --> URI Class Initialized
DEBUG - 2012-04-04 13:52:33 --> Router Class Initialized
DEBUG - 2012-04-04 13:52:33 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:52:33 --> Output Class Initialized
DEBUG - 2012-04-04 13:52:33 --> Security Class Initialized
DEBUG - 2012-04-04 13:52:33 --> Input Class Initialized
DEBUG - 2012-04-04 13:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:52:33 --> Language Class Initialized
DEBUG - 2012-04-04 13:52:33 --> Loader Class Initialized
DEBUG - 2012-04-04 13:52:34 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:52:34 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:52:34 --> Session Class Initialized
DEBUG - 2012-04-04 13:52:34 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:52:34 --> Session routines successfully run
DEBUG - 2012-04-04 13:52:34 --> Controller Class Initialized
ERROR - 2012-04-04 13:52:34 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:52:34 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:52:34 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:52:34 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:52:34 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:52:34 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:52:34 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:52:34 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:52:34 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:52:34 --> Final output sent to browser
DEBUG - 2012-04-04 13:52:34 --> Total execution time: 0.0956
DEBUG - 2012-04-04 13:52:38 --> Config Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:52:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:52:38 --> URI Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Router Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Output Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Security Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Input Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:52:38 --> Language Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Loader Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:52:38 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Session Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:52:38 --> Session routines successfully run
DEBUG - 2012-04-04 13:52:38 --> Controller Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Config Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:52:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:52:38 --> URI Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Router Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Output Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Security Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Input Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:52:38 --> Language Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Loader Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:52:38 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Session Class Initialized
DEBUG - 2012-04-04 13:52:38 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:52:38 --> A session cookie was not found.
DEBUG - 2012-04-04 13:52:38 --> Session routines successfully run
DEBUG - 2012-04-04 13:52:38 --> Controller Class Initialized
DEBUG - 2012-04-04 13:52:38 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:52:38 --> Final output sent to browser
DEBUG - 2012-04-04 13:52:38 --> Total execution time: 0.0692
DEBUG - 2012-04-04 13:52:41 --> Config Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:52:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:52:41 --> URI Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Router Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Output Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Security Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Input Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:52:41 --> Language Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Loader Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:52:41 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Session Class Initialized
DEBUG - 2012-04-04 13:52:41 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:52:41 --> Session routines successfully run
DEBUG - 2012-04-04 13:52:41 --> Controller Class Initialized
DEBUG - 2012-04-04 13:52:41 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:52:41 --> Final output sent to browser
DEBUG - 2012-04-04 13:52:41 --> Total execution time: 0.0683
DEBUG - 2012-04-04 13:52:52 --> Config Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:52:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:52:52 --> URI Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Router Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Output Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Security Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Input Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:52:52 --> Language Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Loader Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:52:52 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Session Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:52:52 --> Session routines successfully run
DEBUG - 2012-04-04 13:52:52 --> Controller Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Model Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Model Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Config Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:52:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:52:52 --> URI Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Router Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Output Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Security Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Input Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:52:52 --> Language Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Loader Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:52:52 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Session Class Initialized
DEBUG - 2012-04-04 13:52:52 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:52:52 --> Session routines successfully run
DEBUG - 2012-04-04 13:52:52 --> Controller Class Initialized
ERROR - 2012-04-04 13:52:52 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:52:52 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:52:52 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:52:52 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:52:52 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:52:52 --> Final output sent to browser
DEBUG - 2012-04-04 13:52:52 --> Total execution time: 0.0862
DEBUG - 2012-04-04 13:57:54 --> Config Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:57:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:57:54 --> URI Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Router Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Output Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Security Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Input Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:57:54 --> Language Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Loader Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:57:54 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Session Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:57:54 --> Session routines successfully run
DEBUG - 2012-04-04 13:57:54 --> Controller Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Config Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:57:54 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:57:54 --> URI Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Router Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Output Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Security Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Input Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:57:54 --> Language Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Loader Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:57:54 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Session Class Initialized
DEBUG - 2012-04-04 13:57:54 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:57:54 --> A session cookie was not found.
DEBUG - 2012-04-04 13:57:54 --> Session routines successfully run
DEBUG - 2012-04-04 13:57:54 --> Controller Class Initialized
DEBUG - 2012-04-04 13:57:54 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:57:54 --> Final output sent to browser
DEBUG - 2012-04-04 13:57:54 --> Total execution time: 0.0696
DEBUG - 2012-04-04 13:57:55 --> Config Class Initialized
DEBUG - 2012-04-04 13:57:55 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:57:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:57:56 --> URI Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Router Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Output Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Security Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Input Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:57:56 --> Language Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Loader Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:57:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Session Class Initialized
DEBUG - 2012-04-04 13:57:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:57:56 --> Session routines successfully run
DEBUG - 2012-04-04 13:57:56 --> Controller Class Initialized
DEBUG - 2012-04-04 13:57:56 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:57:56 --> Final output sent to browser
DEBUG - 2012-04-04 13:57:56 --> Total execution time: 0.0689
DEBUG - 2012-04-04 13:58:02 --> Config Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:58:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:58:02 --> URI Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Router Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Output Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Security Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Input Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:58:02 --> Language Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Loader Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:58:02 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Session Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:58:02 --> Session routines successfully run
DEBUG - 2012-04-04 13:58:02 --> Controller Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Model Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Model Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Config Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:58:02 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:58:02 --> URI Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Router Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Output Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Security Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Input Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:58:02 --> Language Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Loader Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:58:02 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Session Class Initialized
DEBUG - 2012-04-04 13:58:02 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:58:02 --> Session routines successfully run
DEBUG - 2012-04-04 13:58:02 --> Controller Class Initialized
ERROR - 2012-04-04 13:58:02 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 13:58:02 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 13:58:02 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 13:58:02 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 13:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 13:58:02 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 13:58:02 --> Final output sent to browser
DEBUG - 2012-04-04 13:58:02 --> Total execution time: 0.0861
DEBUG - 2012-04-04 13:59:09 --> Config Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:59:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:59:09 --> URI Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Router Class Initialized
DEBUG - 2012-04-04 13:59:09 --> No URI present. Default controller set.
DEBUG - 2012-04-04 13:59:09 --> Output Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Security Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Input Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:59:09 --> Language Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Loader Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:59:09 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Session Class Initialized
DEBUG - 2012-04-04 13:59:09 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:59:09 --> A session cookie was not found.
DEBUG - 2012-04-04 13:59:09 --> Session routines successfully run
DEBUG - 2012-04-04 13:59:09 --> Controller Class Initialized
DEBUG - 2012-04-04 13:59:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:59:09 --> Final output sent to browser
DEBUG - 2012-04-04 13:59:09 --> Total execution time: 0.1317
DEBUG - 2012-04-04 13:59:13 --> Config Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:59:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:59:13 --> URI Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Router Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Output Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Security Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Input Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:59:13 --> Language Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Loader Class Initialized
DEBUG - 2012-04-04 13:59:13 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:59:14 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:59:14 --> Session Class Initialized
DEBUG - 2012-04-04 13:59:14 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:59:14 --> Session routines successfully run
DEBUG - 2012-04-04 13:59:14 --> Controller Class Initialized
DEBUG - 2012-04-04 13:59:14 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:59:14 --> Final output sent to browser
DEBUG - 2012-04-04 13:59:14 --> Total execution time: 0.0792
DEBUG - 2012-04-04 13:59:17 --> Config Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Hooks Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Utf8 Class Initialized
DEBUG - 2012-04-04 13:59:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 13:59:17 --> URI Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Router Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Output Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Security Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Input Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 13:59:17 --> Language Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Loader Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Helper loaded: url_helper
DEBUG - 2012-04-04 13:59:17 --> Database Driver Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Session Class Initialized
DEBUG - 2012-04-04 13:59:17 --> Helper loaded: string_helper
DEBUG - 2012-04-04 13:59:17 --> Session routines successfully run
DEBUG - 2012-04-04 13:59:17 --> Controller Class Initialized
DEBUG - 2012-04-04 13:59:17 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 13:59:17 --> Final output sent to browser
DEBUG - 2012-04-04 13:59:17 --> Total execution time: 0.0757
DEBUG - 2012-04-04 14:00:17 --> Config Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:00:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:00:17 --> URI Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Router Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Output Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Security Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Input Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:00:17 --> Language Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Loader Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:00:17 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Session Class Initialized
DEBUG - 2012-04-04 14:00:17 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:00:17 --> Session routines successfully run
DEBUG - 2012-04-04 14:00:17 --> Controller Class Initialized
DEBUG - 2012-04-04 14:00:17 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 14:00:17 --> Final output sent to browser
DEBUG - 2012-04-04 14:00:17 --> Total execution time: 0.0735
DEBUG - 2012-04-04 14:00:23 --> Config Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:00:23 --> URI Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Router Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Output Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Security Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Input Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:00:23 --> Language Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Loader Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:00:23 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Session Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:00:23 --> Session routines successfully run
DEBUG - 2012-04-04 14:00:23 --> Controller Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Model Class Initialized
DEBUG - 2012-04-04 14:00:23 --> Model Class Initialized
DEBUG - 2012-04-04 14:00:23 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 14:00:23 --> Final output sent to browser
DEBUG - 2012-04-04 14:00:23 --> Total execution time: 0.0776
DEBUG - 2012-04-04 14:00:36 --> Config Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:00:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:00:36 --> URI Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Router Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Output Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Security Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Input Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:00:36 --> Language Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Loader Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:00:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Session Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:00:36 --> Session routines successfully run
DEBUG - 2012-04-04 14:00:36 --> Controller Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Model Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Model Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Config Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:00:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:00:36 --> URI Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Router Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Output Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Security Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Input Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:00:36 --> Language Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Loader Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:00:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Session Class Initialized
DEBUG - 2012-04-04 14:00:36 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:00:36 --> Session routines successfully run
DEBUG - 2012-04-04 14:00:36 --> Controller Class Initialized
ERROR - 2012-04-04 14:00:36 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 14:00:36 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 14:00:36 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 14:00:36 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 14:00:36 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 14:00:36 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 14:00:36 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 14:00:36 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 14:00:36 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 14:00:36 --> Final output sent to browser
DEBUG - 2012-04-04 14:00:36 --> Total execution time: 0.0880
DEBUG - 2012-04-04 14:01:29 --> Config Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:01:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:01:29 --> URI Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Router Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Output Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Security Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Input Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:01:29 --> Language Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Loader Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:01:29 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Session Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:01:29 --> Session routines successfully run
DEBUG - 2012-04-04 14:01:29 --> Controller Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Config Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:01:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:01:29 --> URI Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Router Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Output Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Security Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Input Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:01:29 --> Language Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Loader Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:01:29 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Session Class Initialized
DEBUG - 2012-04-04 14:01:29 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:01:29 --> A session cookie was not found.
DEBUG - 2012-04-04 14:01:29 --> Session routines successfully run
DEBUG - 2012-04-04 14:01:29 --> Controller Class Initialized
DEBUG - 2012-04-04 14:01:29 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 14:01:29 --> Final output sent to browser
DEBUG - 2012-04-04 14:01:29 --> Total execution time: 0.2539
DEBUG - 2012-04-04 14:02:12 --> Config Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:02:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:02:12 --> URI Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Router Class Initialized
DEBUG - 2012-04-04 14:02:12 --> No URI present. Default controller set.
DEBUG - 2012-04-04 14:02:12 --> Output Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Security Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Input Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:02:12 --> Language Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Loader Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:02:12 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Session Class Initialized
DEBUG - 2012-04-04 14:02:12 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:02:12 --> Session routines successfully run
DEBUG - 2012-04-04 14:02:12 --> Controller Class Initialized
DEBUG - 2012-04-04 14:02:12 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 14:02:12 --> Final output sent to browser
DEBUG - 2012-04-04 14:02:12 --> Total execution time: 0.2029
DEBUG - 2012-04-04 14:02:19 --> Config Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:02:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:02:19 --> URI Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Router Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Output Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Security Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Input Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:02:19 --> Language Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Loader Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:02:19 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Session Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:02:19 --> Session routines successfully run
DEBUG - 2012-04-04 14:02:19 --> Controller Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Model Class Initialized
DEBUG - 2012-04-04 14:02:19 --> Model Class Initialized
DEBUG - 2012-04-04 14:02:19 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 14:02:19 --> Final output sent to browser
DEBUG - 2012-04-04 14:02:19 --> Total execution time: 0.2932
DEBUG - 2012-04-04 14:02:27 --> Config Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:02:27 --> URI Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Router Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Output Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Security Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Input Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:02:27 --> Language Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Loader Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:02:27 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Session Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:02:27 --> Session routines successfully run
DEBUG - 2012-04-04 14:02:27 --> Controller Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Model Class Initialized
DEBUG - 2012-04-04 14:02:27 --> Model Class Initialized
DEBUG - 2012-04-04 14:02:27 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 14:02:27 --> Final output sent to browser
DEBUG - 2012-04-04 14:02:27 --> Total execution time: 0.2598
DEBUG - 2012-04-04 14:02:51 --> Config Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:02:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:02:51 --> URI Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Router Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Output Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Security Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Input Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:02:51 --> Language Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Loader Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:02:51 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Session Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:02:51 --> Session routines successfully run
DEBUG - 2012-04-04 14:02:51 --> Controller Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Model Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Model Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Config Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Hooks Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Utf8 Class Initialized
DEBUG - 2012-04-04 14:02:51 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 14:02:51 --> URI Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Router Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Output Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Security Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Input Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 14:02:51 --> Language Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Loader Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Helper loaded: url_helper
DEBUG - 2012-04-04 14:02:51 --> Database Driver Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Session Class Initialized
DEBUG - 2012-04-04 14:02:51 --> Helper loaded: string_helper
DEBUG - 2012-04-04 14:02:51 --> Session routines successfully run
DEBUG - 2012-04-04 14:02:51 --> Controller Class Initialized
ERROR - 2012-04-04 14:02:51 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 14:02:51 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 18
ERROR - 2012-04-04 14:02:51 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 14:02:51 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 19
ERROR - 2012-04-04 14:02:51 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 14:02:51 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 20
ERROR - 2012-04-04 14:02:51 --> Severity: Notice  --> Undefined variable: check C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
ERROR - 2012-04-04 14:02:51 --> Severity: Notice  --> Trying to get property of non-object C:\Software\xampp\htdocs\xcms\system\controllers\main.php 21
DEBUG - 2012-04-04 14:02:51 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 14:02:51 --> Final output sent to browser
DEBUG - 2012-04-04 14:02:51 --> Total execution time: 0.3009
DEBUG - 2012-04-04 16:32:19 --> Config Class Initialized
DEBUG - 2012-04-04 16:32:19 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:32:19 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:32:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:32:20 --> URI Class Initialized
DEBUG - 2012-04-04 16:32:20 --> Router Class Initialized
DEBUG - 2012-04-04 16:32:20 --> No URI present. Default controller set.
DEBUG - 2012-04-04 16:32:20 --> Output Class Initialized
DEBUG - 2012-04-04 16:32:20 --> Security Class Initialized
DEBUG - 2012-04-04 16:32:20 --> Input Class Initialized
DEBUG - 2012-04-04 16:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:32:20 --> Language Class Initialized
DEBUG - 2012-04-04 16:32:20 --> Loader Class Initialized
DEBUG - 2012-04-04 16:32:20 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:32:20 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:32:22 --> Session Class Initialized
DEBUG - 2012-04-04 16:32:22 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:32:22 --> A session cookie was not found.
DEBUG - 2012-04-04 16:32:22 --> Session routines successfully run
DEBUG - 2012-04-04 16:32:22 --> Controller Class Initialized
DEBUG - 2012-04-04 16:32:22 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:32:22 --> Final output sent to browser
DEBUG - 2012-04-04 16:32:22 --> Total execution time: 2.9753
DEBUG - 2012-04-04 16:39:07 --> Config Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:39:07 --> URI Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Router Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Output Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Security Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Input Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:39:07 --> Language Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Loader Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:39:07 --> Database Driver Class Initialized
ERROR - 2012-04-04 16:39:07 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\XCMS\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2012-04-04 16:39:07 --> Session Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:39:07 --> Session routines successfully run
DEBUG - 2012-04-04 16:39:07 --> Controller Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Model Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Model Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Config Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:39:07 --> URI Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Router Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Output Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Security Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Input Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:39:07 --> Language Class Initialized
DEBUG - 2012-04-04 16:39:07 --> Loader Class Initialized
DEBUG - 2012-04-04 16:39:08 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:39:08 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:39:08 --> Session Class Initialized
DEBUG - 2012-04-04 16:39:08 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:39:08 --> Session routines successfully run
DEBUG - 2012-04-04 16:39:08 --> Controller Class Initialized
ERROR - 2012-04-04 16:39:08 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\XCMS\system\controllers\main.php 18
ERROR - 2012-04-04 16:39:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\XCMS\system\controllers\main.php 18
ERROR - 2012-04-04 16:39:08 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\XCMS\system\controllers\main.php 19
ERROR - 2012-04-04 16:39:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\XCMS\system\controllers\main.php 19
ERROR - 2012-04-04 16:39:08 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\XCMS\system\controllers\main.php 20
ERROR - 2012-04-04 16:39:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\XCMS\system\controllers\main.php 20
ERROR - 2012-04-04 16:39:08 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\XCMS\system\controllers\main.php 21
ERROR - 2012-04-04 16:39:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\XCMS\system\controllers\main.php 21
DEBUG - 2012-04-04 16:39:08 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 16:39:08 --> Final output sent to browser
DEBUG - 2012-04-04 16:39:08 --> Total execution time: 0.3333
DEBUG - 2012-04-04 16:39:11 --> Config Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:39:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:39:11 --> URI Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Router Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Output Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Security Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Input Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:39:11 --> Language Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Loader Class Initialized
DEBUG - 2012-04-04 16:39:11 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:39:12 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Session Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:39:12 --> Session routines successfully run
DEBUG - 2012-04-04 16:39:12 --> Controller Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Config Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:39:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:39:12 --> URI Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Router Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Output Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Security Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Input Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:39:12 --> Language Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Loader Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:39:12 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Session Class Initialized
DEBUG - 2012-04-04 16:39:12 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:39:12 --> A session cookie was not found.
DEBUG - 2012-04-04 16:39:12 --> Session routines successfully run
DEBUG - 2012-04-04 16:39:12 --> Controller Class Initialized
DEBUG - 2012-04-04 16:39:12 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:39:12 --> Final output sent to browser
DEBUG - 2012-04-04 16:39:12 --> Total execution time: 0.2319
DEBUG - 2012-04-04 16:45:33 --> Config Class Initialized
DEBUG - 2012-04-04 16:45:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:45:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:45:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:45:33 --> URI Class Initialized
DEBUG - 2012-04-04 16:45:33 --> Router Class Initialized
DEBUG - 2012-04-04 16:45:33 --> Output Class Initialized
DEBUG - 2012-04-04 16:45:33 --> Security Class Initialized
DEBUG - 2012-04-04 16:45:33 --> Input Class Initialized
DEBUG - 2012-04-04 16:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:45:33 --> Language Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Loader Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:45:34 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Session Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:45:34 --> Session routines successfully run
DEBUG - 2012-04-04 16:45:34 --> Controller Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Model Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Model Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Config Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:45:34 --> URI Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Router Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Output Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Security Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Input Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:45:34 --> Language Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Loader Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:45:34 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Session Class Initialized
DEBUG - 2012-04-04 16:45:34 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:45:34 --> Session routines successfully run
DEBUG - 2012-04-04 16:45:34 --> Controller Class Initialized
ERROR - 2012-04-04 16:45:34 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\XCMS\system\controllers\main.php 18
ERROR - 2012-04-04 16:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\XCMS\system\controllers\main.php 18
ERROR - 2012-04-04 16:45:34 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\XCMS\system\controllers\main.php 19
ERROR - 2012-04-04 16:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\XCMS\system\controllers\main.php 19
ERROR - 2012-04-04 16:45:34 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\XCMS\system\controllers\main.php 20
ERROR - 2012-04-04 16:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\XCMS\system\controllers\main.php 20
ERROR - 2012-04-04 16:45:34 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\XCMS\system\controllers\main.php 21
ERROR - 2012-04-04 16:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\XCMS\system\controllers\main.php 21
DEBUG - 2012-04-04 16:45:34 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 16:45:34 --> Final output sent to browser
DEBUG - 2012-04-04 16:45:34 --> Total execution time: 0.3891
DEBUG - 2012-04-04 16:46:45 --> Config Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:46:45 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:46:45 --> URI Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Router Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Output Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Security Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Input Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:46:45 --> Language Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Loader Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:46:45 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Session Class Initialized
DEBUG - 2012-04-04 16:46:45 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:46:45 --> Session routines successfully run
DEBUG - 2012-04-04 16:46:45 --> Controller Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Config Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:46:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:46:46 --> URI Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Router Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Output Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Security Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Input Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:46:46 --> Language Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Loader Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:46:46 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Session Class Initialized
DEBUG - 2012-04-04 16:46:46 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:46:46 --> A session cookie was not found.
DEBUG - 2012-04-04 16:46:46 --> Session routines successfully run
DEBUG - 2012-04-04 16:46:46 --> Controller Class Initialized
DEBUG - 2012-04-04 16:46:46 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:46:46 --> Final output sent to browser
DEBUG - 2012-04-04 16:46:46 --> Total execution time: 0.2556
DEBUG - 2012-04-04 16:46:47 --> Config Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:46:47 --> URI Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Router Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Output Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Security Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Input Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:46:47 --> Language Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Loader Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:46:47 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:46:47 --> Session Class Initialized
DEBUG - 2012-04-04 16:46:48 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:46:48 --> Session routines successfully run
DEBUG - 2012-04-04 16:46:48 --> Controller Class Initialized
DEBUG - 2012-04-04 16:46:48 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:46:48 --> Final output sent to browser
DEBUG - 2012-04-04 16:46:48 --> Total execution time: 0.4727
DEBUG - 2012-04-04 16:46:56 --> Config Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:46:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:46:56 --> URI Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Router Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Output Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Security Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Input Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:46:56 --> Language Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Loader Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:46:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Session Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:46:56 --> Session routines successfully run
DEBUG - 2012-04-04 16:46:56 --> Controller Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Model Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Model Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Config Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:46:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:46:56 --> URI Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Router Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Output Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Security Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Input Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:46:56 --> Language Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Loader Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:46:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Session Class Initialized
DEBUG - 2012-04-04 16:46:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:46:56 --> Session routines successfully run
DEBUG - 2012-04-04 16:46:56 --> Controller Class Initialized
DEBUG - 2012-04-04 16:46:56 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 16:46:56 --> Final output sent to browser
DEBUG - 2012-04-04 16:46:56 --> Total execution time: 0.2307
DEBUG - 2012-04-04 16:47:33 --> Config Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:47:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:47:33 --> URI Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Router Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Output Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Security Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Input Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:47:33 --> Language Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Loader Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:47:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Session Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:47:33 --> Session routines successfully run
DEBUG - 2012-04-04 16:47:33 --> Controller Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Config Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:47:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:47:33 --> URI Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Router Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Output Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Security Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Input Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:47:33 --> Language Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Loader Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:47:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Session Class Initialized
DEBUG - 2012-04-04 16:47:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:47:33 --> A session cookie was not found.
DEBUG - 2012-04-04 16:47:33 --> Session routines successfully run
DEBUG - 2012-04-04 16:47:33 --> Controller Class Initialized
DEBUG - 2012-04-04 16:47:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:47:33 --> Final output sent to browser
DEBUG - 2012-04-04 16:47:33 --> Total execution time: 0.2417
DEBUG - 2012-04-04 16:49:50 --> Config Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:49:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:49:50 --> URI Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Router Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Output Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Security Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Input Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:49:50 --> Language Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Loader Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:49:50 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Session Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:49:50 --> Session routines successfully run
DEBUG - 2012-04-04 16:49:50 --> Controller Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Model Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Model Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Config Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:49:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:49:50 --> URI Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Router Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Output Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Security Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Input Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:49:50 --> Language Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Loader Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:49:50 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Session Class Initialized
DEBUG - 2012-04-04 16:49:50 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:49:50 --> Session routines successfully run
DEBUG - 2012-04-04 16:49:50 --> Controller Class Initialized
DEBUG - 2012-04-04 16:49:50 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 16:49:50 --> Final output sent to browser
DEBUG - 2012-04-04 16:49:50 --> Total execution time: 0.2399
DEBUG - 2012-04-04 16:49:57 --> Config Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:49:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:49:57 --> URI Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Router Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Output Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Security Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Input Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:49:57 --> Language Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Loader Class Initialized
DEBUG - 2012-04-04 16:49:57 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:49:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Session Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:49:58 --> Session routines successfully run
DEBUG - 2012-04-04 16:49:58 --> Controller Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Config Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:49:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:49:58 --> URI Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Router Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Output Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Security Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Input Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:49:58 --> Language Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Loader Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:49:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Session Class Initialized
DEBUG - 2012-04-04 16:49:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:49:58 --> A session cookie was not found.
DEBUG - 2012-04-04 16:49:58 --> Session routines successfully run
DEBUG - 2012-04-04 16:49:58 --> Controller Class Initialized
DEBUG - 2012-04-04 16:49:58 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:49:58 --> Final output sent to browser
DEBUG - 2012-04-04 16:49:58 --> Total execution time: 0.2540
DEBUG - 2012-04-04 16:52:25 --> Config Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:52:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:52:25 --> URI Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Router Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Output Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Security Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Input Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:52:25 --> Language Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Loader Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:52:25 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Session Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:52:25 --> Session routines successfully run
DEBUG - 2012-04-04 16:52:25 --> Controller Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Model Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Model Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Config Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:52:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:52:25 --> URI Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Router Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Output Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Security Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Input Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:52:25 --> Language Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Loader Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:52:25 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Session Class Initialized
DEBUG - 2012-04-04 16:52:25 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:52:25 --> Session routines successfully run
DEBUG - 2012-04-04 16:52:25 --> Controller Class Initialized
ERROR - 2012-04-04 16:52:25 --> Severity: Notice  --> Undefined variable: FirstName C:\xampp\htdocs\XCMS\system\views\admin_view.php 5
ERROR - 2012-04-04 16:52:25 --> Severity: Notice  --> Undefined variable: LastName C:\xampp\htdocs\XCMS\system\views\admin_view.php 5
DEBUG - 2012-04-04 16:52:25 --> File loaded: system/views/admin_view.php
DEBUG - 2012-04-04 16:52:25 --> Final output sent to browser
DEBUG - 2012-04-04 16:52:25 --> Total execution time: 0.2340
DEBUG - 2012-04-04 16:53:03 --> Config Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:53:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:53:03 --> URI Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Router Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Output Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Security Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Input Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:53:03 --> Language Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Loader Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:53:03 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Session Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:53:03 --> Session routines successfully run
DEBUG - 2012-04-04 16:53:03 --> Controller Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Config Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:53:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:53:03 --> URI Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Router Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Output Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Security Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Input Class Initialized
DEBUG - 2012-04-04 16:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:53:03 --> Language Class Initialized
DEBUG - 2012-04-04 16:53:04 --> Loader Class Initialized
DEBUG - 2012-04-04 16:53:04 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:53:04 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:53:04 --> Session Class Initialized
DEBUG - 2012-04-04 16:53:04 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:53:04 --> A session cookie was not found.
DEBUG - 2012-04-04 16:53:04 --> Session routines successfully run
DEBUG - 2012-04-04 16:53:04 --> Controller Class Initialized
DEBUG - 2012-04-04 16:53:04 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:53:04 --> Final output sent to browser
DEBUG - 2012-04-04 16:53:04 --> Total execution time: 0.5211
DEBUG - 2012-04-04 16:53:10 --> Config Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:53:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:53:10 --> URI Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Router Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Output Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Security Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Input Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:53:10 --> Language Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Loader Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:53:10 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Session Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:53:10 --> Session routines successfully run
DEBUG - 2012-04-04 16:53:10 --> Controller Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Model Class Initialized
DEBUG - 2012-04-04 16:53:10 --> Model Class Initialized
DEBUG - 2012-04-04 16:53:10 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:53:10 --> Final output sent to browser
DEBUG - 2012-04-04 16:53:10 --> Total execution time: 0.2487
DEBUG - 2012-04-04 16:53:53 --> Config Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:53:53 --> URI Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Router Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Output Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Security Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Input Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:53:53 --> Language Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Loader Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:53:53 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Session Class Initialized
DEBUG - 2012-04-04 16:53:53 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:53:53 --> Session routines successfully run
DEBUG - 2012-04-04 16:53:53 --> Controller Class Initialized
DEBUG - 2012-04-04 16:53:53 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:53:53 --> Final output sent to browser
DEBUG - 2012-04-04 16:53:53 --> Total execution time: 0.2571
DEBUG - 2012-04-04 16:54:00 --> Config Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:54:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:54:00 --> URI Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Router Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Output Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Security Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Input Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:54:00 --> Language Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Loader Class Initialized
DEBUG - 2012-04-04 16:54:00 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:54:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:54:01 --> Session Class Initialized
DEBUG - 2012-04-04 16:54:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:54:01 --> Session routines successfully run
DEBUG - 2012-04-04 16:54:01 --> Controller Class Initialized
DEBUG - 2012-04-04 16:54:01 --> Model Class Initialized
DEBUG - 2012-04-04 16:54:01 --> Model Class Initialized
DEBUG - 2012-04-04 16:54:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:54:01 --> Final output sent to browser
DEBUG - 2012-04-04 16:54:01 --> Total execution time: 0.2827
DEBUG - 2012-04-04 16:54:06 --> Config Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:54:06 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:54:06 --> URI Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Router Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Output Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Security Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Input Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:54:06 --> Language Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Loader Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:54:06 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Session Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:54:06 --> Session routines successfully run
DEBUG - 2012-04-04 16:54:06 --> Controller Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Model Class Initialized
DEBUG - 2012-04-04 16:54:06 --> Model Class Initialized
DEBUG - 2012-04-04 16:54:06 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:54:06 --> Final output sent to browser
DEBUG - 2012-04-04 16:54:06 --> Total execution time: 0.2553
DEBUG - 2012-04-04 16:54:19 --> Config Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:54:19 --> URI Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Router Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Output Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Security Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Input Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:54:19 --> Language Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Loader Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:54:19 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Session Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:54:19 --> Session routines successfully run
DEBUG - 2012-04-04 16:54:19 --> Controller Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Model Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Model Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Config Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:54:19 --> URI Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Router Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Output Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Security Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Input Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:54:19 --> Language Class Initialized
DEBUG - 2012-04-04 16:54:19 --> Loader Class Initialized
DEBUG - 2012-04-04 16:54:20 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:54:20 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:54:20 --> Session Class Initialized
DEBUG - 2012-04-04 16:54:20 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:54:20 --> Session routines successfully run
DEBUG - 2012-04-04 16:54:20 --> Controller Class Initialized
DEBUG - 2012-04-04 16:54:20 --> File loaded: system/views/admin_view.php
DEBUG - 2012-04-04 16:54:20 --> Final output sent to browser
DEBUG - 2012-04-04 16:54:20 --> Total execution time: 0.2821
DEBUG - 2012-04-04 16:54:24 --> Config Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:54:24 --> URI Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Router Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Output Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Security Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Input Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:54:24 --> Language Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Loader Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:54:24 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Session Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:54:24 --> Session routines successfully run
DEBUG - 2012-04-04 16:54:24 --> Controller Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Config Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Hooks Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Utf8 Class Initialized
DEBUG - 2012-04-04 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 16:54:24 --> URI Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Router Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Output Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Security Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Input Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 16:54:24 --> Language Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Loader Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Helper loaded: url_helper
DEBUG - 2012-04-04 16:54:24 --> Database Driver Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Session Class Initialized
DEBUG - 2012-04-04 16:54:24 --> Helper loaded: string_helper
DEBUG - 2012-04-04 16:54:24 --> A session cookie was not found.
DEBUG - 2012-04-04 16:54:24 --> Session routines successfully run
DEBUG - 2012-04-04 16:54:24 --> Controller Class Initialized
DEBUG - 2012-04-04 16:54:24 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 16:54:24 --> Final output sent to browser
DEBUG - 2012-04-04 16:54:24 --> Total execution time: 0.2251
DEBUG - 2012-04-04 17:15:28 --> Config Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:15:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:15:28 --> URI Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Router Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Output Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Security Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Input Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:15:28 --> Language Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Loader Class Initialized
DEBUG - 2012-04-04 17:15:28 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:15:29 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:15:29 --> Session Class Initialized
DEBUG - 2012-04-04 17:15:29 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:15:29 --> Session routines successfully run
DEBUG - 2012-04-04 17:15:29 --> Controller Class Initialized
DEBUG - 2012-04-04 17:15:29 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:15:29 --> Final output sent to browser
DEBUG - 2012-04-04 17:15:29 --> Total execution time: 0.9173
DEBUG - 2012-04-04 17:15:35 --> Config Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:15:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:15:35 --> URI Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Router Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Output Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Security Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Input Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:15:35 --> Language Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Loader Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:15:35 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Session Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:15:35 --> Session routines successfully run
DEBUG - 2012-04-04 17:15:35 --> Controller Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Model Class Initialized
DEBUG - 2012-04-04 17:15:35 --> Model Class Initialized
DEBUG - 2012-04-04 17:15:35 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:15:35 --> Final output sent to browser
DEBUG - 2012-04-04 17:15:35 --> Total execution time: 0.3816
DEBUG - 2012-04-04 17:15:46 --> Config Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:15:46 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:15:46 --> URI Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Router Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Output Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Security Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Input Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:15:46 --> Language Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Loader Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:15:46 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Session Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:15:46 --> Session routines successfully run
DEBUG - 2012-04-04 17:15:46 --> Controller Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Model Class Initialized
DEBUG - 2012-04-04 17:15:46 --> Model Class Initialized
DEBUG - 2012-04-04 17:15:46 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:15:46 --> Final output sent to browser
DEBUG - 2012-04-04 17:15:46 --> Total execution time: 0.3453
DEBUG - 2012-04-04 17:15:53 --> Config Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:15:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:15:53 --> URI Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Router Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Output Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Security Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Input Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:15:53 --> Language Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Loader Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:15:53 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Session Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:15:53 --> Session routines successfully run
DEBUG - 2012-04-04 17:15:53 --> Controller Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Model Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Model Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Config Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:15:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:15:53 --> URI Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Router Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Output Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Security Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Input Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:15:53 --> Language Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Loader Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:15:53 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Session Class Initialized
DEBUG - 2012-04-04 17:15:53 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:15:53 --> Session routines successfully run
DEBUG - 2012-04-04 17:15:53 --> Controller Class Initialized
DEBUG - 2012-04-04 17:15:53 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 17:15:53 --> Final output sent to browser
DEBUG - 2012-04-04 17:15:53 --> Total execution time: 0.2392
DEBUG - 2012-04-04 17:15:56 --> Config Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:15:56 --> URI Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Router Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Output Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Security Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Input Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:15:56 --> Language Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Loader Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:15:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Session Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:15:56 --> Session routines successfully run
DEBUG - 2012-04-04 17:15:56 --> Controller Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Config Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:15:56 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:15:56 --> URI Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Router Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Output Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Security Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Input Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:15:56 --> Language Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Loader Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:15:56 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Session Class Initialized
DEBUG - 2012-04-04 17:15:56 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:15:56 --> A session cookie was not found.
DEBUG - 2012-04-04 17:15:56 --> Session routines successfully run
DEBUG - 2012-04-04 17:15:56 --> Controller Class Initialized
DEBUG - 2012-04-04 17:15:56 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:15:56 --> Final output sent to browser
DEBUG - 2012-04-04 17:15:56 --> Total execution time: 0.3075
DEBUG - 2012-04-04 17:25:31 --> Config Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:25:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:25:31 --> URI Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Router Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Output Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Security Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Input Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:25:31 --> Language Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Loader Class Initialized
DEBUG - 2012-04-04 17:25:31 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:25:32 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:25:32 --> Session Class Initialized
DEBUG - 2012-04-04 17:25:32 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:25:32 --> Session routines successfully run
DEBUG - 2012-04-04 17:25:32 --> Controller Class Initialized
DEBUG - 2012-04-04 17:25:32 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:25:32 --> Final output sent to browser
DEBUG - 2012-04-04 17:25:32 --> Total execution time: 0.8790
DEBUG - 2012-04-04 17:25:43 --> Config Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:25:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:25:43 --> URI Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Router Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Output Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Security Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Input Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:25:43 --> Language Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Loader Class Initialized
DEBUG - 2012-04-04 17:25:43 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:25:44 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:25:44 --> Session Class Initialized
DEBUG - 2012-04-04 17:25:44 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:25:44 --> Session routines successfully run
DEBUG - 2012-04-04 17:25:44 --> Controller Class Initialized
DEBUG - 2012-04-04 17:25:44 --> Model Class Initialized
DEBUG - 2012-04-04 17:25:44 --> Model Class Initialized
DEBUG - 2012-04-04 17:25:44 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:25:44 --> Final output sent to browser
DEBUG - 2012-04-04 17:25:44 --> Total execution time: 0.5031
DEBUG - 2012-04-04 17:34:17 --> Config Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:34:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:34:17 --> URI Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Router Class Initialized
DEBUG - 2012-04-04 17:34:17 --> No URI present. Default controller set.
DEBUG - 2012-04-04 17:34:17 --> Output Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Security Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Input Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:34:17 --> Language Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Loader Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:34:17 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Session Class Initialized
DEBUG - 2012-04-04 17:34:17 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:34:17 --> A session cookie was not found.
DEBUG - 2012-04-04 17:34:17 --> Session routines successfully run
DEBUG - 2012-04-04 17:34:17 --> Controller Class Initialized
DEBUG - 2012-04-04 17:34:17 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:34:17 --> Final output sent to browser
DEBUG - 2012-04-04 17:34:17 --> Total execution time: 0.3871
DEBUG - 2012-04-04 17:35:01 --> Config Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:35:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:35:01 --> URI Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Router Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Output Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Security Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Input Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:35:01 --> Language Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Loader Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:35:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Session Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:35:01 --> Session routines successfully run
DEBUG - 2012-04-04 17:35:01 --> Controller Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:01 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:35:01 --> Final output sent to browser
DEBUG - 2012-04-04 17:35:01 --> Total execution time: 0.3826
DEBUG - 2012-04-04 17:35:08 --> Config Class Initialized
DEBUG - 2012-04-04 17:35:08 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:35:08 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:35:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:35:08 --> URI Class Initialized
DEBUG - 2012-04-04 17:35:08 --> Router Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Output Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Security Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Input Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:35:09 --> Language Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Loader Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:35:09 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Session Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:35:09 --> Session routines successfully run
DEBUG - 2012-04-04 17:35:09 --> Controller Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:09 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:35:09 --> Final output sent to browser
DEBUG - 2012-04-04 17:35:09 --> Total execution time: 0.2811
DEBUG - 2012-04-04 17:35:13 --> Config Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:35:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:35:13 --> URI Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Router Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Output Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Security Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Input Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:35:13 --> Language Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Loader Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:35:13 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Session Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:35:13 --> Session routines successfully run
DEBUG - 2012-04-04 17:35:13 --> Controller Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:13 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:13 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:35:13 --> Final output sent to browser
DEBUG - 2012-04-04 17:35:13 --> Total execution time: 0.2938
DEBUG - 2012-04-04 17:35:22 --> Config Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:35:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:35:22 --> URI Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Router Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Output Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Security Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Input Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:35:22 --> Language Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Loader Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:35:22 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Session Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:35:22 --> Session routines successfully run
DEBUG - 2012-04-04 17:35:22 --> Controller Class Initialized
DEBUG - 2012-04-04 17:35:22 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Config Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:35:23 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:35:23 --> URI Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Router Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Output Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Security Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Input Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:35:23 --> Language Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Loader Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:35:23 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Session Class Initialized
DEBUG - 2012-04-04 17:35:23 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:35:23 --> Session routines successfully run
DEBUG - 2012-04-04 17:35:23 --> Controller Class Initialized
DEBUG - 2012-04-04 17:35:23 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-04 17:35:23 --> Final output sent to browser
DEBUG - 2012-04-04 17:35:23 --> Total execution time: 0.2447
DEBUG - 2012-04-04 17:35:28 --> Config Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:35:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:35:28 --> URI Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Router Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Output Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Security Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Input Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:35:28 --> Language Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Loader Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:35:28 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Session Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:35:28 --> Session routines successfully run
DEBUG - 2012-04-04 17:35:28 --> Controller Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Config Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:35:28 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:35:28 --> URI Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Router Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Output Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Security Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Input Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:35:28 --> Language Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Loader Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:35:28 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Session Class Initialized
DEBUG - 2012-04-04 17:35:28 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:35:28 --> A session cookie was not found.
DEBUG - 2012-04-04 17:35:28 --> Session routines successfully run
DEBUG - 2012-04-04 17:35:28 --> Controller Class Initialized
DEBUG - 2012-04-04 17:35:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:35:29 --> Final output sent to browser
DEBUG - 2012-04-04 17:35:29 --> Total execution time: 0.2568
DEBUG - 2012-04-04 17:35:52 --> Config Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Hooks Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Utf8 Class Initialized
DEBUG - 2012-04-04 17:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 17:35:52 --> URI Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Router Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Output Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Security Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Input Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 17:35:52 --> Language Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Loader Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Helper loaded: url_helper
DEBUG - 2012-04-04 17:35:52 --> Database Driver Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Session Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Helper loaded: string_helper
DEBUG - 2012-04-04 17:35:52 --> Session routines successfully run
DEBUG - 2012-04-04 17:35:52 --> Controller Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:52 --> Model Class Initialized
DEBUG - 2012-04-04 17:35:52 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 17:35:52 --> Final output sent to browser
DEBUG - 2012-04-04 17:35:52 --> Total execution time: 0.3051
DEBUG - 2012-04-04 18:47:20 --> Config Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:47:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:47:20 --> URI Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Router Class Initialized
DEBUG - 2012-04-04 18:47:20 --> No URI present. Default controller set.
DEBUG - 2012-04-04 18:47:20 --> Output Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Security Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Input Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:47:20 --> Language Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Loader Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:47:20 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Session Class Initialized
DEBUG - 2012-04-04 18:47:20 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:47:20 --> A session cookie was not found.
DEBUG - 2012-04-04 18:47:20 --> Session routines successfully run
DEBUG - 2012-04-04 18:47:20 --> Controller Class Initialized
DEBUG - 2012-04-04 18:47:20 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:47:20 --> Final output sent to browser
DEBUG - 2012-04-04 18:47:20 --> Total execution time: 0.3047
DEBUG - 2012-04-04 18:47:29 --> Config Class Initialized
DEBUG - 2012-04-04 18:47:29 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:47:29 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:47:29 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:47:29 --> URI Class Initialized
DEBUG - 2012-04-04 18:47:29 --> Router Class Initialized
DEBUG - 2012-04-04 18:47:29 --> Output Class Initialized
DEBUG - 2012-04-04 18:47:29 --> Security Class Initialized
DEBUG - 2012-04-04 18:47:30 --> Input Class Initialized
DEBUG - 2012-04-04 18:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:47:30 --> Language Class Initialized
DEBUG - 2012-04-04 18:47:30 --> Loader Class Initialized
DEBUG - 2012-04-04 18:47:30 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:47:30 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:47:30 --> Session Class Initialized
DEBUG - 2012-04-04 18:47:30 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:47:30 --> Session routines successfully run
DEBUG - 2012-04-04 18:47:30 --> Controller Class Initialized
DEBUG - 2012-04-04 18:47:30 --> Model Class Initialized
DEBUG - 2012-04-04 18:47:30 --> Model Class Initialized
DEBUG - 2012-04-04 18:47:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:47:30 --> Final output sent to browser
DEBUG - 2012-04-04 18:47:30 --> Total execution time: 0.4611
DEBUG - 2012-04-04 18:47:42 --> Config Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:47:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:47:42 --> URI Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Router Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Output Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Security Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Input Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:47:42 --> Language Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Loader Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:47:42 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Session Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:47:42 --> Session routines successfully run
DEBUG - 2012-04-04 18:47:42 --> Controller Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Model Class Initialized
DEBUG - 2012-04-04 18:47:42 --> Model Class Initialized
DEBUG - 2012-04-04 18:47:42 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:47:42 --> Final output sent to browser
DEBUG - 2012-04-04 18:47:42 --> Total execution time: 0.2702
DEBUG - 2012-04-04 18:47:58 --> Config Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:47:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:47:58 --> URI Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Router Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Output Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Security Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Input Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:47:58 --> Language Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Loader Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:47:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Session Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:47:58 --> Session routines successfully run
DEBUG - 2012-04-04 18:47:58 --> Controller Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Model Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Model Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Config Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:47:58 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:47:58 --> URI Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Router Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Output Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Security Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Input Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:47:58 --> Language Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Loader Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:47:58 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Session Class Initialized
DEBUG - 2012-04-04 18:47:58 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:47:58 --> Session routines successfully run
DEBUG - 2012-04-04 18:47:58 --> Controller Class Initialized
DEBUG - 2012-04-04 18:47:58 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-04 18:47:58 --> Final output sent to browser
DEBUG - 2012-04-04 18:47:58 --> Total execution time: 0.2391
DEBUG - 2012-04-04 18:48:01 --> Config Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:48:01 --> URI Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Router Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Output Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Security Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Input Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:48:01 --> Language Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Loader Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:48:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Session Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:48:01 --> Session routines successfully run
DEBUG - 2012-04-04 18:48:01 --> Controller Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Config Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:48:01 --> URI Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Router Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Output Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Security Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Input Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:48:01 --> Language Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Loader Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:48:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Session Class Initialized
DEBUG - 2012-04-04 18:48:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:48:01 --> A session cookie was not found.
DEBUG - 2012-04-04 18:48:01 --> Session routines successfully run
DEBUG - 2012-04-04 18:48:01 --> Controller Class Initialized
DEBUG - 2012-04-04 18:48:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:48:01 --> Final output sent to browser
DEBUG - 2012-04-04 18:48:01 --> Total execution time: 0.2384
DEBUG - 2012-04-04 18:48:09 --> Config Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:48:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:48:09 --> URI Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Router Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Output Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Security Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Input Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:48:09 --> Language Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Loader Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:48:09 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Session Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:48:09 --> Session routines successfully run
DEBUG - 2012-04-04 18:48:09 --> Controller Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Model Class Initialized
DEBUG - 2012-04-04 18:48:09 --> Model Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Config Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:48:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:48:10 --> URI Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Router Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Output Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Security Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Input Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:48:10 --> Language Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Loader Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:48:10 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Session Class Initialized
DEBUG - 2012-04-04 18:48:10 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:48:10 --> Session routines successfully run
DEBUG - 2012-04-04 18:48:10 --> Controller Class Initialized
DEBUG - 2012-04-04 18:48:10 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-04 18:48:10 --> Final output sent to browser
DEBUG - 2012-04-04 18:48:10 --> Total execution time: 0.2282
DEBUG - 2012-04-04 18:49:37 --> Config Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:49:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:49:37 --> URI Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Router Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Output Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Security Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Input Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:49:37 --> Language Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Loader Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:49:37 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Session Class Initialized
DEBUG - 2012-04-04 18:49:37 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:49:37 --> Session routines successfully run
DEBUG - 2012-04-04 18:49:37 --> Controller Class Initialized
DEBUG - 2012-04-04 18:49:37 --> File loaded: system/views/sysadmin_view.php
DEBUG - 2012-04-04 18:49:37 --> Final output sent to browser
DEBUG - 2012-04-04 18:49:37 --> Total execution time: 0.2766
DEBUG - 2012-04-04 18:50:11 --> Config Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:50:11 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:50:11 --> URI Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Router Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Output Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Security Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Input Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:50:11 --> Language Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Loader Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:50:11 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:50:11 --> Session Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:50:12 --> Session routines successfully run
DEBUG - 2012-04-04 18:50:12 --> Controller Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Config Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:50:12 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:50:12 --> URI Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Router Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Output Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Security Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Input Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:50:12 --> Language Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Loader Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:50:12 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Session Class Initialized
DEBUG - 2012-04-04 18:50:12 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:50:12 --> A session cookie was not found.
DEBUG - 2012-04-04 18:50:12 --> Session routines successfully run
DEBUG - 2012-04-04 18:50:12 --> Controller Class Initialized
DEBUG - 2012-04-04 18:50:12 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:50:12 --> Final output sent to browser
DEBUG - 2012-04-04 18:50:12 --> Total execution time: 0.2584
DEBUG - 2012-04-04 18:50:19 --> Config Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:50:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:50:19 --> URI Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Router Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Output Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Security Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Input Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:50:19 --> Language Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Loader Class Initialized
DEBUG - 2012-04-04 18:50:19 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:50:19 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Session Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:50:20 --> Session routines successfully run
DEBUG - 2012-04-04 18:50:20 --> Controller Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Model Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Model Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Config Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:50:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:50:20 --> URI Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Router Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Output Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Security Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Input Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:50:20 --> Language Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Loader Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:50:20 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Session Class Initialized
DEBUG - 2012-04-04 18:50:20 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:50:20 --> Session routines successfully run
DEBUG - 2012-04-04 18:50:20 --> Controller Class Initialized
DEBUG - 2012-04-04 18:50:20 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 18:50:20 --> Final output sent to browser
DEBUG - 2012-04-04 18:50:20 --> Total execution time: 0.2362
DEBUG - 2012-04-04 18:51:07 --> Config Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:51:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:51:07 --> URI Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Router Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Output Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Security Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Input Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:51:07 --> Language Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Loader Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:51:07 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Session Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:51:07 --> Session routines successfully run
DEBUG - 2012-04-04 18:51:07 --> Controller Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Config Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:51:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:51:07 --> URI Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Router Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Output Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Security Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Input Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:51:07 --> Language Class Initialized
DEBUG - 2012-04-04 18:51:07 --> Loader Class Initialized
DEBUG - 2012-04-04 18:51:08 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:51:08 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:51:08 --> Session Class Initialized
DEBUG - 2012-04-04 18:51:08 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:51:08 --> A session cookie was not found.
DEBUG - 2012-04-04 18:51:08 --> Session routines successfully run
DEBUG - 2012-04-04 18:51:08 --> Controller Class Initialized
DEBUG - 2012-04-04 18:51:08 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:51:08 --> Final output sent to browser
DEBUG - 2012-04-04 18:51:08 --> Total execution time: 0.2570
DEBUG - 2012-04-04 18:51:09 --> Config Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:51:09 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:51:09 --> URI Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Router Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Output Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Security Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Input Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:51:09 --> Language Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Loader Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:51:09 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Session Class Initialized
DEBUG - 2012-04-04 18:51:09 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:51:09 --> Session routines successfully run
DEBUG - 2012-04-04 18:51:09 --> Controller Class Initialized
DEBUG - 2012-04-04 18:51:09 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:51:09 --> Final output sent to browser
DEBUG - 2012-04-04 18:51:09 --> Total execution time: 0.2755
DEBUG - 2012-04-04 18:51:16 --> Config Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:51:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:51:16 --> URI Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Router Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Output Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Security Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Input Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:51:16 --> Language Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Loader Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:51:16 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Session Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:51:16 --> Session routines successfully run
DEBUG - 2012-04-04 18:51:16 --> Controller Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Model Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Model Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Config Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:51:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:51:16 --> URI Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Router Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Output Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Security Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Input Class Initialized
DEBUG - 2012-04-04 18:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:51:16 --> Language Class Initialized
DEBUG - 2012-04-04 18:51:17 --> Loader Class Initialized
DEBUG - 2012-04-04 18:51:17 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:51:17 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:51:17 --> Session Class Initialized
DEBUG - 2012-04-04 18:51:17 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:51:17 --> Session routines successfully run
DEBUG - 2012-04-04 18:51:17 --> Controller Class Initialized
DEBUG - 2012-04-04 18:51:17 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 18:51:17 --> Final output sent to browser
DEBUG - 2012-04-04 18:51:17 --> Total execution time: 0.2489
DEBUG - 2012-04-04 18:51:19 --> Config Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:51:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:51:19 --> URI Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Router Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Output Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Security Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Input Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:51:19 --> Language Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Loader Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:51:19 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Session Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:51:19 --> Session routines successfully run
DEBUG - 2012-04-04 18:51:19 --> Controller Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Config Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:51:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:51:19 --> URI Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Router Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Output Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Security Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Input Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:51:19 --> Language Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Loader Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:51:19 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Session Class Initialized
DEBUG - 2012-04-04 18:51:19 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:51:19 --> A session cookie was not found.
DEBUG - 2012-04-04 18:51:19 --> Session routines successfully run
DEBUG - 2012-04-04 18:51:19 --> Controller Class Initialized
DEBUG - 2012-04-04 18:51:19 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:51:19 --> Final output sent to browser
DEBUG - 2012-04-04 18:51:19 --> Total execution time: 0.2684
DEBUG - 2012-04-04 18:51:37 --> Config Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:51:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:51:37 --> URI Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Router Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Output Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Security Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Input Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:51:37 --> Language Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Loader Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:51:37 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Session Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:51:37 --> Session routines successfully run
DEBUG - 2012-04-04 18:51:37 --> Controller Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Model Class Initialized
DEBUG - 2012-04-04 18:51:37 --> Model Class Initialized
DEBUG - 2012-04-04 18:51:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:51:37 --> Final output sent to browser
DEBUG - 2012-04-04 18:51:37 --> Total execution time: 0.3100
DEBUG - 2012-04-04 18:54:03 --> Config Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:54:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:54:03 --> URI Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Router Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Output Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Security Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Input Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:54:03 --> Language Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Loader Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:54:03 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Session Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:54:03 --> Session routines successfully run
DEBUG - 2012-04-04 18:54:03 --> Controller Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Model Class Initialized
DEBUG - 2012-04-04 18:54:03 --> Model Class Initialized
DEBUG - 2012-04-04 18:54:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 18:54:03 --> Final output sent to browser
DEBUG - 2012-04-04 18:54:03 --> Total execution time: 0.3067
DEBUG - 2012-04-04 18:54:24 --> Config Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:54:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:54:24 --> URI Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Router Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Output Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Security Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Input Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:54:24 --> Language Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Loader Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:54:24 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Session Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:54:24 --> Session routines successfully run
DEBUG - 2012-04-04 18:54:24 --> Controller Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Model Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Model Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Config Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:54:24 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:54:25 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:54:25 --> URI Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Router Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Output Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Security Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Input Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:54:25 --> Language Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Loader Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:54:25 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Session Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:54:25 --> Session routines successfully run
DEBUG - 2012-04-04 18:54:25 --> Controller Class Initialized
DEBUG - 2012-04-04 18:54:25 --> Final output sent to browser
DEBUG - 2012-04-04 18:54:25 --> Total execution time: 0.2395
DEBUG - 2012-04-04 18:57:13 --> Config Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:57:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:57:13 --> URI Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Router Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Output Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Security Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Input Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:57:13 --> Language Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Loader Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:57:13 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Session Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:57:13 --> Session routines successfully run
DEBUG - 2012-04-04 18:57:13 --> Controller Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Config Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Hooks Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Utf8 Class Initialized
DEBUG - 2012-04-04 18:57:13 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 18:57:13 --> URI Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Router Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Output Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Security Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Input Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 18:57:13 --> Language Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Loader Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Helper loaded: url_helper
DEBUG - 2012-04-04 18:57:13 --> Database Driver Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Session Class Initialized
DEBUG - 2012-04-04 18:57:13 --> Helper loaded: string_helper
DEBUG - 2012-04-04 18:57:14 --> Session routines successfully run
DEBUG - 2012-04-04 18:57:14 --> Controller Class Initialized
DEBUG - 2012-04-04 18:57:14 --> Final output sent to browser
DEBUG - 2012-04-04 18:57:14 --> Total execution time: 0.2322
DEBUG - 2012-04-04 19:00:03 --> Config Class Initialized
DEBUG - 2012-04-04 19:00:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:00:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:00:03 --> URI Class Initialized
DEBUG - 2012-04-04 19:00:03 --> Router Class Initialized
ERROR - 2012-04-04 19:00:03 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:00:41 --> Config Class Initialized
DEBUG - 2012-04-04 19:00:41 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:00:41 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:00:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:00:41 --> URI Class Initialized
DEBUG - 2012-04-04 19:00:41 --> Router Class Initialized
ERROR - 2012-04-04 19:00:41 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:00:42 --> Config Class Initialized
DEBUG - 2012-04-04 19:00:42 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:00:42 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:00:42 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:00:42 --> URI Class Initialized
DEBUG - 2012-04-04 19:00:42 --> Router Class Initialized
ERROR - 2012-04-04 19:00:42 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:02:30 --> Config Class Initialized
DEBUG - 2012-04-04 19:02:30 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:02:30 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:02:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:02:30 --> URI Class Initialized
DEBUG - 2012-04-04 19:02:30 --> Router Class Initialized
ERROR - 2012-04-04 19:02:30 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:02:40 --> Config Class Initialized
DEBUG - 2012-04-04 19:02:40 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:02:40 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:02:40 --> URI Class Initialized
DEBUG - 2012-04-04 19:02:40 --> Router Class Initialized
ERROR - 2012-04-04 19:02:40 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:05:41 --> Config Class Initialized
DEBUG - 2012-04-04 19:05:41 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:05:41 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:05:41 --> URI Class Initialized
DEBUG - 2012-04-04 19:05:41 --> Router Class Initialized
ERROR - 2012-04-04 19:05:41 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:05:43 --> Config Class Initialized
DEBUG - 2012-04-04 19:05:43 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:05:43 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:05:43 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:05:43 --> URI Class Initialized
DEBUG - 2012-04-04 19:05:43 --> Router Class Initialized
ERROR - 2012-04-04 19:05:43 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:05:44 --> Config Class Initialized
DEBUG - 2012-04-04 19:05:44 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:05:44 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:05:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:05:44 --> URI Class Initialized
DEBUG - 2012-04-04 19:05:44 --> Router Class Initialized
ERROR - 2012-04-04 19:05:44 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:06:16 --> Config Class Initialized
DEBUG - 2012-04-04 19:06:16 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:06:16 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:06:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:06:16 --> URI Class Initialized
DEBUG - 2012-04-04 19:06:16 --> Router Class Initialized
ERROR - 2012-04-04 19:06:16 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:06:17 --> Config Class Initialized
DEBUG - 2012-04-04 19:06:17 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:06:17 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:06:17 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:06:17 --> URI Class Initialized
DEBUG - 2012-04-04 19:06:17 --> Router Class Initialized
ERROR - 2012-04-04 19:06:17 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:14:15 --> Config Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:14:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:14:15 --> URI Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Router Class Initialized
DEBUG - 2012-04-04 19:14:15 --> No URI present. Default controller set.
DEBUG - 2012-04-04 19:14:15 --> Output Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Security Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Input Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:14:15 --> Language Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Loader Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:14:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Session Class Initialized
DEBUG - 2012-04-04 19:14:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:14:15 --> A session cookie was not found.
DEBUG - 2012-04-04 19:14:15 --> Session routines successfully run
DEBUG - 2012-04-04 19:14:15 --> Controller Class Initialized
DEBUG - 2012-04-04 19:14:15 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:14:15 --> Final output sent to browser
DEBUG - 2012-04-04 19:14:15 --> Total execution time: 0.2588
DEBUG - 2012-04-04 19:14:18 --> Config Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:14:19 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:14:19 --> URI Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Router Class Initialized
DEBUG - 2012-04-04 19:14:19 --> No URI present. Default controller set.
DEBUG - 2012-04-04 19:14:19 --> Output Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Security Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Input Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:14:19 --> Language Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Loader Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:14:19 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Session Class Initialized
DEBUG - 2012-04-04 19:14:19 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:14:19 --> Session routines successfully run
DEBUG - 2012-04-04 19:14:19 --> Controller Class Initialized
DEBUG - 2012-04-04 19:14:19 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:14:19 --> Final output sent to browser
DEBUG - 2012-04-04 19:14:19 --> Total execution time: 0.2638
DEBUG - 2012-04-04 19:14:20 --> Config Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:14:20 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:14:20 --> URI Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Router Class Initialized
DEBUG - 2012-04-04 19:14:20 --> No URI present. Default controller set.
DEBUG - 2012-04-04 19:14:20 --> Output Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Security Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Input Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:14:20 --> Language Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Loader Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:14:20 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Session Class Initialized
DEBUG - 2012-04-04 19:14:20 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:14:20 --> Session routines successfully run
DEBUG - 2012-04-04 19:14:20 --> Controller Class Initialized
DEBUG - 2012-04-04 19:14:20 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:14:20 --> Final output sent to browser
DEBUG - 2012-04-04 19:14:20 --> Total execution time: 0.2732
DEBUG - 2012-04-04 19:14:22 --> Config Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:14:22 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:14:22 --> URI Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Router Class Initialized
DEBUG - 2012-04-04 19:14:22 --> No URI present. Default controller set.
DEBUG - 2012-04-04 19:14:22 --> Output Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Security Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Input Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:14:22 --> Language Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Loader Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:14:22 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Session Class Initialized
DEBUG - 2012-04-04 19:14:22 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:14:22 --> Session routines successfully run
DEBUG - 2012-04-04 19:14:22 --> Controller Class Initialized
DEBUG - 2012-04-04 19:14:22 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:14:22 --> Final output sent to browser
DEBUG - 2012-04-04 19:14:22 --> Total execution time: 0.2503
DEBUG - 2012-04-04 19:14:32 --> Config Class Initialized
DEBUG - 2012-04-04 19:14:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:14:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:14:32 --> URI Class Initialized
DEBUG - 2012-04-04 19:14:32 --> Router Class Initialized
ERROR - 2012-04-04 19:14:32 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:14:40 --> Config Class Initialized
DEBUG - 2012-04-04 19:14:40 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:14:40 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:14:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:14:40 --> URI Class Initialized
DEBUG - 2012-04-04 19:14:40 --> Router Class Initialized
ERROR - 2012-04-04 19:14:40 --> 404 Page Not Found --> XCMS
DEBUG - 2012-04-04 19:15:24 --> Config Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:15:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:15:24 --> URI Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Router Class Initialized
DEBUG - 2012-04-04 19:15:24 --> No URI present. Default controller set.
DEBUG - 2012-04-04 19:15:24 --> Output Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Security Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Input Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:15:24 --> Language Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Loader Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:15:24 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Session Class Initialized
DEBUG - 2012-04-04 19:15:24 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:15:24 --> Session routines successfully run
DEBUG - 2012-04-04 19:15:24 --> Controller Class Initialized
DEBUG - 2012-04-04 19:15:24 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:15:24 --> Final output sent to browser
DEBUG - 2012-04-04 19:15:24 --> Total execution time: 0.2703
DEBUG - 2012-04-04 19:15:33 --> Config Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:15:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:15:33 --> URI Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Router Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Output Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Security Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Input Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:15:33 --> Language Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Loader Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:15:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Session Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:15:33 --> Session routines successfully run
DEBUG - 2012-04-04 19:15:33 --> Controller Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Model Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Model Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Config Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:15:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:15:33 --> URI Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Router Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Output Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Security Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Input Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:15:33 --> Language Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Loader Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:15:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Session Class Initialized
DEBUG - 2012-04-04 19:15:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:15:33 --> Session routines successfully run
DEBUG - 2012-04-04 19:15:33 --> Controller Class Initialized
ERROR - 2012-04-04 19:15:33 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\xcms\system\controllers\main.php 31
ERROR - 2012-04-04 19:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\xcms\system\controllers\main.php 31
ERROR - 2012-04-04 19:15:33 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\xcms\system\controllers\main.php 32
ERROR - 2012-04-04 19:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\xcms\system\controllers\main.php 32
ERROR - 2012-04-04 19:15:33 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\xcms\system\controllers\main.php 33
ERROR - 2012-04-04 19:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\xcms\system\controllers\main.php 33
ERROR - 2012-04-04 19:15:33 --> Severity: Notice  --> Undefined variable: check C:\xampp\htdocs\xcms\system\controllers\main.php 34
ERROR - 2012-04-04 19:15:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\xcms\system\controllers\main.php 34
DEBUG - 2012-04-04 19:15:33 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 19:15:33 --> Final output sent to browser
DEBUG - 2012-04-04 19:15:33 --> Total execution time: 0.2864
DEBUG - 2012-04-04 19:18:01 --> Config Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:18:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:18:01 --> URI Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Router Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Output Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Security Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Input Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:18:01 --> Language Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Loader Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:18:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Session Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:18:01 --> Session routines successfully run
DEBUG - 2012-04-04 19:18:01 --> Controller Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Config Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:18:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:18:01 --> URI Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Router Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Output Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Security Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Input Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:18:01 --> Language Class Initialized
DEBUG - 2012-04-04 19:18:01 --> Loader Class Initialized
DEBUG - 2012-04-04 19:18:02 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:18:02 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:18:02 --> Session Class Initialized
DEBUG - 2012-04-04 19:18:02 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:18:02 --> A session cookie was not found.
DEBUG - 2012-04-04 19:18:02 --> Session routines successfully run
DEBUG - 2012-04-04 19:18:02 --> Controller Class Initialized
DEBUG - 2012-04-04 19:18:02 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:18:02 --> Final output sent to browser
DEBUG - 2012-04-04 19:18:02 --> Total execution time: 0.2793
DEBUG - 2012-04-04 19:18:15 --> Config Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:18:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:18:15 --> URI Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Router Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Output Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Security Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Input Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:18:15 --> Language Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Loader Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:18:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Session Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:18:15 --> Session routines successfully run
DEBUG - 2012-04-04 19:18:15 --> Controller Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Model Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Model Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Config Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:18:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:18:15 --> URI Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Router Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Output Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Security Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Input Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:18:15 --> Language Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Loader Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:18:15 --> Config Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:18:15 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:18:15 --> URI Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Session Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Router Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:18:15 --> Session routines successfully run
DEBUG - 2012-04-04 19:18:15 --> Controller Class Initialized
DEBUG - 2012-04-04 19:18:15 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 19:18:15 --> Final output sent to browser
DEBUG - 2012-04-04 19:18:15 --> Total execution time: 0.3489
DEBUG - 2012-04-04 19:18:15 --> Output Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Security Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Input Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:18:15 --> Language Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Loader Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:18:15 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Session Class Initialized
DEBUG - 2012-04-04 19:18:15 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:18:15 --> Session routines successfully run
DEBUG - 2012-04-04 19:18:15 --> Controller Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Config Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:18:16 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:18:16 --> URI Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Router Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Output Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Security Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Input Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:18:16 --> Language Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Loader Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:18:16 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Session Class Initialized
DEBUG - 2012-04-04 19:18:16 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:18:16 --> Session routines successfully run
DEBUG - 2012-04-04 19:18:16 --> Controller Class Initialized
DEBUG - 2012-04-04 19:18:16 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 19:18:16 --> Final output sent to browser
DEBUG - 2012-04-04 19:18:16 --> Total execution time: 0.2669
DEBUG - 2012-04-04 19:18:18 --> Config Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:18:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:18:18 --> URI Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Router Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Output Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Security Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Input Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:18:18 --> Language Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Loader Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:18:18 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Session Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:18:18 --> Session routines successfully run
DEBUG - 2012-04-04 19:18:18 --> Controller Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Config Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:18:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:18:18 --> URI Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Router Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Output Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Security Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Input Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:18:18 --> Language Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Loader Class Initialized
DEBUG - 2012-04-04 19:18:18 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:18:19 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:18:19 --> Session Class Initialized
DEBUG - 2012-04-04 19:18:19 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:18:19 --> A session cookie was not found.
DEBUG - 2012-04-04 19:18:19 --> Session routines successfully run
DEBUG - 2012-04-04 19:18:19 --> Controller Class Initialized
DEBUG - 2012-04-04 19:18:19 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:18:19 --> Final output sent to browser
DEBUG - 2012-04-04 19:18:19 --> Total execution time: 0.2976
DEBUG - 2012-04-04 19:20:30 --> Config Class Initialized
DEBUG - 2012-04-04 19:20:30 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:20:30 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:20:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:20:30 --> URI Class Initialized
DEBUG - 2012-04-04 19:20:30 --> Router Class Initialized
DEBUG - 2012-04-04 19:20:30 --> Output Class Initialized
DEBUG - 2012-04-04 19:20:30 --> Security Class Initialized
DEBUG - 2012-04-04 19:20:30 --> Input Class Initialized
DEBUG - 2012-04-04 19:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:20:30 --> Language Class Initialized
DEBUG - 2012-04-04 19:20:30 --> Loader Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:20:31 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Session Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:20:31 --> Session routines successfully run
DEBUG - 2012-04-04 19:20:31 --> Controller Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Model Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Model Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Config Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:20:31 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:20:31 --> URI Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Router Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Output Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Security Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Input Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:20:31 --> Language Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Loader Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:20:31 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Session Class Initialized
DEBUG - 2012-04-04 19:20:31 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:20:31 --> Session routines successfully run
DEBUG - 2012-04-04 19:20:31 --> Controller Class Initialized
DEBUG - 2012-04-04 19:20:31 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-04 19:20:31 --> Final output sent to browser
DEBUG - 2012-04-04 19:20:31 --> Total execution time: 0.2541
DEBUG - 2012-04-04 19:20:36 --> Config Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:20:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:20:36 --> URI Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Router Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Output Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Security Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Input Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:20:36 --> Language Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Loader Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:20:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Session Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:20:36 --> Session routines successfully run
DEBUG - 2012-04-04 19:20:36 --> Controller Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Config Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:20:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:20:36 --> URI Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Router Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Output Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Security Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Input Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:20:36 --> Language Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Loader Class Initialized
DEBUG - 2012-04-04 19:20:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:20:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:20:37 --> Session Class Initialized
DEBUG - 2012-04-04 19:20:37 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:20:37 --> A session cookie was not found.
DEBUG - 2012-04-04 19:20:37 --> Session routines successfully run
DEBUG - 2012-04-04 19:20:37 --> Controller Class Initialized
DEBUG - 2012-04-04 19:20:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:20:37 --> Final output sent to browser
DEBUG - 2012-04-04 19:20:37 --> Total execution time: 0.2636
DEBUG - 2012-04-04 19:27:52 --> Config Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:27:52 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:27:52 --> URI Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Router Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Output Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Security Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Input Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:27:52 --> Language Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Loader Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:27:52 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Session Class Initialized
DEBUG - 2012-04-04 19:27:52 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:27:52 --> Session routines successfully run
DEBUG - 2012-04-04 19:27:52 --> Controller Class Initialized
DEBUG - 2012-04-04 19:27:52 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:27:52 --> Final output sent to browser
DEBUG - 2012-04-04 19:27:52 --> Total execution time: 0.2771
DEBUG - 2012-04-04 19:28:33 --> Config Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:28:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:28:33 --> URI Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Router Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Output Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Security Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Input Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:28:33 --> Language Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Loader Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:28:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Session Class Initialized
DEBUG - 2012-04-04 19:28:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:28:33 --> Session routines successfully run
DEBUG - 2012-04-04 19:28:33 --> Controller Class Initialized
DEBUG - 2012-04-04 19:28:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:28:33 --> Final output sent to browser
DEBUG - 2012-04-04 19:28:33 --> Total execution time: 0.2850
DEBUG - 2012-04-04 19:28:47 --> Config Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:28:47 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:28:47 --> URI Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Router Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Output Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Security Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Input Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:28:47 --> Language Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Loader Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:28:47 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Session Class Initialized
DEBUG - 2012-04-04 19:28:47 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:28:47 --> Session routines successfully run
DEBUG - 2012-04-04 19:28:47 --> Controller Class Initialized
DEBUG - 2012-04-04 19:28:47 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:28:47 --> Final output sent to browser
DEBUG - 2012-04-04 19:28:47 --> Total execution time: 0.2900
DEBUG - 2012-04-04 19:28:50 --> Config Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:28:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:28:50 --> URI Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Router Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Output Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Security Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Input Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:28:50 --> Language Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Loader Class Initialized
DEBUG - 2012-04-04 19:28:50 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:28:50 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:28:51 --> Session Class Initialized
DEBUG - 2012-04-04 19:28:51 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:28:51 --> Session routines successfully run
DEBUG - 2012-04-04 19:28:51 --> Controller Class Initialized
DEBUG - 2012-04-04 19:28:51 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:28:51 --> Final output sent to browser
DEBUG - 2012-04-04 19:28:51 --> Total execution time: 0.2741
DEBUG - 2012-04-04 19:28:57 --> Config Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:28:57 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:28:57 --> URI Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Router Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Output Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Security Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Input Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:28:57 --> Language Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Loader Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:28:57 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Session Class Initialized
DEBUG - 2012-04-04 19:28:57 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:28:57 --> Session routines successfully run
DEBUG - 2012-04-04 19:28:57 --> Controller Class Initialized
DEBUG - 2012-04-04 19:28:57 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:28:57 --> Final output sent to browser
DEBUG - 2012-04-04 19:28:57 --> Total execution time: 0.3115
DEBUG - 2012-04-04 19:29:07 --> Config Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:29:07 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:29:07 --> URI Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Router Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Output Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Security Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Input Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:29:07 --> Language Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Loader Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:29:07 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:29:07 --> Session Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:29:08 --> Session routines successfully run
DEBUG - 2012-04-04 19:29:08 --> Controller Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Model Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Model Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Config Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:29:08 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:29:08 --> URI Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Router Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Output Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Security Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Input Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:29:08 --> Language Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Loader Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:29:08 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Session Class Initialized
DEBUG - 2012-04-04 19:29:08 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:29:08 --> Session routines successfully run
DEBUG - 2012-04-04 19:29:08 --> Controller Class Initialized
DEBUG - 2012-04-04 19:29:08 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 19:29:08 --> Final output sent to browser
DEBUG - 2012-04-04 19:29:08 --> Total execution time: 0.2526
DEBUG - 2012-04-04 19:29:10 --> Config Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:29:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:29:10 --> URI Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Router Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Output Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Security Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Input Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:29:10 --> Language Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Loader Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:29:10 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Session Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:29:10 --> Session routines successfully run
DEBUG - 2012-04-04 19:29:10 --> Controller Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Config Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:29:10 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:29:10 --> URI Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Router Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Output Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Security Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Input Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:29:10 --> Language Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Loader Class Initialized
DEBUG - 2012-04-04 19:29:10 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:29:11 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:29:11 --> Session Class Initialized
DEBUG - 2012-04-04 19:29:11 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:29:11 --> A session cookie was not found.
DEBUG - 2012-04-04 19:29:11 --> Session routines successfully run
DEBUG - 2012-04-04 19:29:11 --> Controller Class Initialized
DEBUG - 2012-04-04 19:29:11 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:29:11 --> Final output sent to browser
DEBUG - 2012-04-04 19:29:11 --> Total execution time: 0.2730
DEBUG - 2012-04-04 19:29:18 --> Config Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:29:18 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:29:18 --> URI Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Router Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Output Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Security Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Input Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:29:18 --> Language Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Loader Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:29:18 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Session Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:29:18 --> Session routines successfully run
DEBUG - 2012-04-04 19:29:18 --> Controller Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Model Class Initialized
DEBUG - 2012-04-04 19:29:18 --> Model Class Initialized
DEBUG - 2012-04-04 19:29:18 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:29:18 --> Final output sent to browser
DEBUG - 2012-04-04 19:29:18 --> Total execution time: 0.3047
DEBUG - 2012-04-04 19:30:24 --> Config Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:30:24 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:30:24 --> URI Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Router Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Output Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Security Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Input Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:30:24 --> Language Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Loader Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:30:24 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Session Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:30:24 --> Session routines successfully run
DEBUG - 2012-04-04 19:30:24 --> Controller Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Model Class Initialized
DEBUG - 2012-04-04 19:30:24 --> Model Class Initialized
DEBUG - 2012-04-04 19:30:24 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:30:24 --> Final output sent to browser
DEBUG - 2012-04-04 19:30:24 --> Total execution time: 0.2904
DEBUG - 2012-04-04 19:30:38 --> Config Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:30:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:30:38 --> URI Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Router Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Output Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Security Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Input Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:30:38 --> Language Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Loader Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:30:38 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Session Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:30:38 --> Session routines successfully run
DEBUG - 2012-04-04 19:30:38 --> Controller Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Model Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Model Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Config Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:30:38 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:30:38 --> URI Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Router Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Output Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Security Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Input Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:30:38 --> Language Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Loader Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:30:38 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Session Class Initialized
DEBUG - 2012-04-04 19:30:38 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:30:38 --> Session routines successfully run
DEBUG - 2012-04-04 19:30:38 --> Controller Class Initialized
DEBUG - 2012-04-04 19:30:38 --> File loaded: system/views/cr_view.php
DEBUG - 2012-04-04 19:30:38 --> Final output sent to browser
DEBUG - 2012-04-04 19:30:39 --> Total execution time: 0.2442
DEBUG - 2012-04-04 19:30:41 --> Config Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:30:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:30:41 --> URI Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Router Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Output Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Security Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Input Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:30:41 --> Language Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Loader Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:30:41 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Session Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:30:41 --> Session routines successfully run
DEBUG - 2012-04-04 19:30:41 --> Controller Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Config Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:30:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:30:41 --> URI Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Router Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Output Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Security Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Input Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:30:41 --> Language Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Loader Class Initialized
DEBUG - 2012-04-04 19:30:41 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:30:41 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:30:42 --> Session Class Initialized
DEBUG - 2012-04-04 19:30:42 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:30:42 --> A session cookie was not found.
DEBUG - 2012-04-04 19:30:42 --> Session routines successfully run
DEBUG - 2012-04-04 19:30:42 --> Controller Class Initialized
DEBUG - 2012-04-04 19:30:42 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:30:42 --> Final output sent to browser
DEBUG - 2012-04-04 19:30:42 --> Total execution time: 0.2595
DEBUG - 2012-04-04 19:32:27 --> Config Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:32:27 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:32:27 --> URI Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Router Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Output Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Security Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Input Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:32:27 --> Language Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Loader Class Initialized
DEBUG - 2012-04-04 19:32:27 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:32:27 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:32:28 --> Session Class Initialized
DEBUG - 2012-04-04 19:32:28 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:32:28 --> Session routines successfully run
DEBUG - 2012-04-04 19:32:28 --> Controller Class Initialized
DEBUG - 2012-04-04 19:32:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:32:28 --> Final output sent to browser
DEBUG - 2012-04-04 19:32:28 --> Total execution time: 0.3270
DEBUG - 2012-04-04 19:32:30 --> Config Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:32:30 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:32:30 --> URI Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Router Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Output Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Security Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Input Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:32:30 --> Language Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Loader Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:32:30 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Session Class Initialized
DEBUG - 2012-04-04 19:32:30 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:32:30 --> Session routines successfully run
DEBUG - 2012-04-04 19:32:30 --> Controller Class Initialized
DEBUG - 2012-04-04 19:32:30 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:32:30 --> Final output sent to browser
DEBUG - 2012-04-04 19:32:30 --> Total execution time: 0.3991
DEBUG - 2012-04-04 19:32:33 --> Config Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:32:33 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:32:33 --> URI Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Router Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Output Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Security Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Input Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:32:33 --> Language Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Loader Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:32:33 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Session Class Initialized
DEBUG - 2012-04-04 19:32:33 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:32:33 --> Session routines successfully run
DEBUG - 2012-04-04 19:32:33 --> Controller Class Initialized
DEBUG - 2012-04-04 19:32:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:32:33 --> Final output sent to browser
DEBUG - 2012-04-04 19:32:33 --> Total execution time: 0.2472
DEBUG - 2012-04-04 19:32:34 --> Config Class Initialized
DEBUG - 2012-04-04 19:32:34 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:32:34 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:32:35 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:32:35 --> URI Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Router Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Output Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Security Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Input Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:32:35 --> Language Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Loader Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:32:35 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Session Class Initialized
DEBUG - 2012-04-04 19:32:35 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:32:35 --> Session routines successfully run
DEBUG - 2012-04-04 19:32:35 --> Controller Class Initialized
DEBUG - 2012-04-04 19:32:35 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:32:35 --> Final output sent to browser
DEBUG - 2012-04-04 19:32:35 --> Total execution time: 0.2630
DEBUG - 2012-04-04 19:32:53 --> Config Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:32:53 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:32:53 --> URI Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Router Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Output Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Security Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Input Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:32:53 --> Language Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Loader Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:32:53 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Session Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:32:53 --> Session routines successfully run
DEBUG - 2012-04-04 19:32:53 --> Controller Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Model Class Initialized
DEBUG - 2012-04-04 19:32:53 --> Model Class Initialized
DEBUG - 2012-04-04 19:32:53 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:32:53 --> Final output sent to browser
DEBUG - 2012-04-04 19:32:53 --> Total execution time: 0.3122
DEBUG - 2012-04-04 19:33:00 --> Config Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:33:00 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:33:00 --> URI Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Router Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Output Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Security Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Input Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:33:00 --> Language Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Loader Class Initialized
DEBUG - 2012-04-04 19:33:00 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:33:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Session Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:33:01 --> Session routines successfully run
DEBUG - 2012-04-04 19:33:01 --> Controller Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Model Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Model Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Config Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:33:01 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:33:01 --> URI Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Router Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Output Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Security Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Input Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:33:01 --> Language Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Loader Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:33:01 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Session Class Initialized
DEBUG - 2012-04-04 19:33:01 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:33:01 --> Session routines successfully run
DEBUG - 2012-04-04 19:33:01 --> Controller Class Initialized
DEBUG - 2012-04-04 19:33:01 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 19:33:01 --> Final output sent to browser
DEBUG - 2012-04-04 19:33:01 --> Total execution time: 0.2584
DEBUG - 2012-04-04 19:33:03 --> Config Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:33:03 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:33:03 --> URI Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Router Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Output Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Security Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Input Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:33:03 --> Language Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Loader Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:33:03 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Session Class Initialized
DEBUG - 2012-04-04 19:33:03 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:33:03 --> Session routines successfully run
DEBUG - 2012-04-04 19:33:03 --> Controller Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Config Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:33:04 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:33:04 --> URI Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Router Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Output Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Security Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Input Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:33:04 --> Language Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Loader Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:33:04 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Session Class Initialized
DEBUG - 2012-04-04 19:33:04 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:33:04 --> A session cookie was not found.
DEBUG - 2012-04-04 19:33:04 --> Session routines successfully run
DEBUG - 2012-04-04 19:33:04 --> Controller Class Initialized
DEBUG - 2012-04-04 19:33:04 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:33:04 --> Final output sent to browser
DEBUG - 2012-04-04 19:33:04 --> Total execution time: 0.2561
DEBUG - 2012-04-04 19:33:41 --> Config Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:33:41 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:33:41 --> URI Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Router Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Output Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Security Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Input Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:33:41 --> Language Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Loader Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:33:41 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Session Class Initialized
DEBUG - 2012-04-04 19:33:41 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:33:41 --> Session routines successfully run
DEBUG - 2012-04-04 19:33:41 --> Controller Class Initialized
DEBUG - 2012-04-04 19:33:41 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:33:41 --> Final output sent to browser
DEBUG - 2012-04-04 19:33:41 --> Total execution time: 0.2570
DEBUG - 2012-04-04 19:33:44 --> Config Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:33:44 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:33:44 --> URI Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Router Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Output Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Security Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Input Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:33:44 --> Language Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Loader Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:33:44 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Session Class Initialized
DEBUG - 2012-04-04 19:33:44 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:33:44 --> Session routines successfully run
DEBUG - 2012-04-04 19:33:44 --> Controller Class Initialized
DEBUG - 2012-04-04 19:33:44 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:33:44 --> Final output sent to browser
DEBUG - 2012-04-04 19:33:44 --> Total execution time: 0.2600
DEBUG - 2012-04-04 19:33:50 --> Config Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:33:50 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:33:50 --> URI Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Router Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Output Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Security Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Input Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:33:50 --> Language Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Loader Class Initialized
DEBUG - 2012-04-04 19:33:50 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:33:51 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:33:51 --> Session Class Initialized
DEBUG - 2012-04-04 19:33:51 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:33:51 --> Session routines successfully run
DEBUG - 2012-04-04 19:33:51 --> Controller Class Initialized
DEBUG - 2012-04-04 19:33:51 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:33:51 --> Final output sent to browser
DEBUG - 2012-04-04 19:33:51 --> Total execution time: 0.2510
DEBUG - 2012-04-04 19:38:32 --> Config Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:38:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:38:32 --> URI Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Router Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Output Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Security Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Input Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:38:32 --> Language Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Loader Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:38:32 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Session Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:38:32 --> Session routines successfully run
DEBUG - 2012-04-04 19:38:32 --> Controller Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Model Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Model Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Config Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:38:32 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:38:32 --> URI Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Router Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Output Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Security Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Input Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:38:32 --> Language Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Loader Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:38:32 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Session Class Initialized
DEBUG - 2012-04-04 19:38:32 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:38:32 --> Session routines successfully run
DEBUG - 2012-04-04 19:38:32 --> Controller Class Initialized
DEBUG - 2012-04-04 19:38:32 --> File loaded: system/views/student_view.php
DEBUG - 2012-04-04 19:38:32 --> Final output sent to browser
DEBUG - 2012-04-04 19:38:32 --> Total execution time: 0.2394
DEBUG - 2012-04-04 19:38:36 --> Config Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:38:36 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:38:36 --> URI Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Router Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Output Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Security Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Input Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:38:36 --> Language Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Loader Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:38:36 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Session Class Initialized
DEBUG - 2012-04-04 19:38:36 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:38:36 --> Session routines successfully run
DEBUG - 2012-04-04 19:38:36 --> Controller Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Config Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:38:37 --> URI Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Router Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Output Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Security Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Input Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:38:37 --> Language Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Loader Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:38:37 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Session Class Initialized
DEBUG - 2012-04-04 19:38:37 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:38:37 --> A session cookie was not found.
DEBUG - 2012-04-04 19:38:37 --> Session routines successfully run
DEBUG - 2012-04-04 19:38:37 --> Controller Class Initialized
DEBUG - 2012-04-04 19:38:37 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:38:37 --> Final output sent to browser
DEBUG - 2012-04-04 19:38:37 --> Total execution time: 0.3495
DEBUG - 2012-04-04 19:38:40 --> Config Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Hooks Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Utf8 Class Initialized
DEBUG - 2012-04-04 19:38:40 --> UTF-8 Support Enabled
DEBUG - 2012-04-04 19:38:40 --> URI Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Router Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Output Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Security Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Input Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-04-04 19:38:40 --> Language Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Loader Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Helper loaded: url_helper
DEBUG - 2012-04-04 19:38:40 --> Database Driver Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Session Class Initialized
DEBUG - 2012-04-04 19:38:40 --> Helper loaded: string_helper
DEBUG - 2012-04-04 19:38:40 --> Session routines successfully run
DEBUG - 2012-04-04 19:38:40 --> Controller Class Initialized
DEBUG - 2012-04-04 19:38:40 --> File loaded: system/views/main_view.php
DEBUG - 2012-04-04 19:38:40 --> Final output sent to browser
DEBUG - 2012-04-04 19:38:40 --> Total execution time: 0.2590
