<html>
SYS ADMIN VIEW PAGE
<br />
<?php
    echo "Welcome, ".$FirstName." ".$LastName;
    echo "<br />";
?>
    <br />
    
    <a href="http://localhost/xcms/blocks/generateSet">Generate Codes</a><br/>
    <a href="http://localhost/xcms/admin/createCR">Create new CR</a><br/>
    <a href="http://localhost/xcms/blocks/create">Create Block</a><br/>
</html>