<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Events extends CI_Controller {

	public function create(){}
	public function view(){}
	public function delete(){}
	public function edit(){}
	public function viewById($EID=-1){}
	public function register($EID=-1){}
	public function close(){}
	public function viewAssociated($EID=-1){}
	public function accredit(){}
}
