<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-03-29 17:54:25 --> Config Class Initialized
DEBUG - 2012-03-29 17:54:25 --> Hooks Class Initialized
DEBUG - 2012-03-29 17:54:25 --> Utf8 Class Initialized
DEBUG - 2012-03-29 17:54:25 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 17:54:25 --> URI Class Initialized
DEBUG - 2012-03-29 17:54:25 --> Router Class Initialized
DEBUG - 2012-03-29 17:54:25 --> No URI present. Default controller set.
DEBUG - 2012-03-29 17:54:25 --> Output Class Initialized
DEBUG - 2012-03-29 17:54:25 --> Security Class Initialized
DEBUG - 2012-03-29 17:54:25 --> Input Class Initialized
DEBUG - 2012-03-29 17:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 17:54:25 --> Language Class Initialized
DEBUG - 2012-03-29 17:54:25 --> Loader Class Initialized
DEBUG - 2012-03-29 17:54:25 --> Controller Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Config Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Hooks Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Utf8 Class Initialized
DEBUG - 2012-03-29 17:54:31 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 17:54:31 --> URI Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Router Class Initialized
DEBUG - 2012-03-29 17:54:31 --> No URI present. Default controller set.
DEBUG - 2012-03-29 17:54:31 --> Output Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Security Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Input Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 17:54:31 --> Language Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Loader Class Initialized
DEBUG - 2012-03-29 17:54:31 --> Controller Class Initialized
DEBUG - 2012-03-29 17:55:41 --> Config Class Initialized
DEBUG - 2012-03-29 17:55:41 --> Hooks Class Initialized
DEBUG - 2012-03-29 17:55:41 --> Utf8 Class Initialized
DEBUG - 2012-03-29 17:55:41 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 17:55:41 --> URI Class Initialized
DEBUG - 2012-03-29 17:55:41 --> Router Class Initialized
ERROR - 2012-03-29 17:55:41 --> 404 Page Not Found --> xcms
DEBUG - 2012-03-29 17:55:43 --> Config Class Initialized
DEBUG - 2012-03-29 17:55:43 --> Hooks Class Initialized
DEBUG - 2012-03-29 17:55:43 --> Utf8 Class Initialized
DEBUG - 2012-03-29 17:55:43 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 17:55:43 --> URI Class Initialized
DEBUG - 2012-03-29 17:55:43 --> Router Class Initialized
ERROR - 2012-03-29 17:55:43 --> 404 Page Not Found --> xcms
DEBUG - 2012-03-29 17:55:58 --> Config Class Initialized
DEBUG - 2012-03-29 17:55:58 --> Hooks Class Initialized
DEBUG - 2012-03-29 17:55:58 --> Utf8 Class Initialized
DEBUG - 2012-03-29 17:55:58 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 17:55:58 --> URI Class Initialized
DEBUG - 2012-03-29 17:55:58 --> Router Class Initialized
DEBUG - 2012-03-29 17:55:58 --> No URI present. Default controller set.
DEBUG - 2012-03-29 17:55:58 --> Output Class Initialized
DEBUG - 2012-03-29 17:55:58 --> Security Class Initialized
DEBUG - 2012-03-29 17:55:58 --> Input Class Initialized
DEBUG - 2012-03-29 17:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 17:55:58 --> Language Class Initialized
DEBUG - 2012-03-29 17:55:58 --> Loader Class Initialized
DEBUG - 2012-03-29 17:55:58 --> Controller Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Config Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:04:10 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:04:10 --> URI Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Router Class Initialized
DEBUG - 2012-03-29 18:04:10 --> No URI present. Default controller set.
DEBUG - 2012-03-29 18:04:10 --> Output Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Security Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Input Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 18:04:10 --> Language Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Loader Class Initialized
DEBUG - 2012-03-29 18:04:10 --> Controller Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Config Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:12:41 --> URI Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Router Class Initialized
DEBUG - 2012-03-29 18:12:41 --> No URI present. Default controller set.
DEBUG - 2012-03-29 18:12:41 --> Output Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Security Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Input Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 18:12:41 --> Language Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Loader Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Controller Class Initialized
DEBUG - 2012-03-29 18:12:41 --> File loaded: system/views/index_view.php
DEBUG - 2012-03-29 18:12:41 --> Final output sent to browser
DEBUG - 2012-03-29 18:12:41 --> Total execution time: 0.0240
DEBUG - 2012-03-29 18:12:41 --> Config Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:12:41 --> URI Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Router Class Initialized
ERROR - 2012-03-29 18:12:41 --> 404 Page Not Found --> styles
DEBUG - 2012-03-29 18:12:41 --> Config Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:12:41 --> URI Class Initialized
DEBUG - 2012-03-29 18:12:41 --> Router Class Initialized
ERROR - 2012-03-29 18:12:41 --> 404 Page Not Found --> styles
DEBUG - 2012-03-29 18:13:03 --> Config Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:13:03 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:13:03 --> URI Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Router Class Initialized
DEBUG - 2012-03-29 18:13:03 --> No URI present. Default controller set.
DEBUG - 2012-03-29 18:13:03 --> Output Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Security Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Input Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 18:13:03 --> Language Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Loader Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Controller Class Initialized
DEBUG - 2012-03-29 18:13:03 --> File loaded: system/views/index_view.php
DEBUG - 2012-03-29 18:13:03 --> Final output sent to browser
DEBUG - 2012-03-29 18:13:03 --> Total execution time: 0.0280
DEBUG - 2012-03-29 18:13:03 --> Config Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:13:03 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:13:03 --> URI Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Router Class Initialized
ERROR - 2012-03-29 18:13:03 --> 404 Page Not Found --> styles
DEBUG - 2012-03-29 18:13:03 --> Config Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:13:03 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:13:03 --> URI Class Initialized
DEBUG - 2012-03-29 18:13:03 --> Router Class Initialized
ERROR - 2012-03-29 18:13:03 --> 404 Page Not Found --> styles
DEBUG - 2012-03-29 18:13:40 --> Config Class Initialized
DEBUG - 2012-03-29 18:13:40 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:13:40 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:13:40 --> URI Class Initialized
DEBUG - 2012-03-29 18:13:40 --> Router Class Initialized
DEBUG - 2012-03-29 18:13:40 --> No URI present. Default controller set.
DEBUG - 2012-03-29 18:13:40 --> Output Class Initialized
DEBUG - 2012-03-29 18:13:40 --> Security Class Initialized
DEBUG - 2012-03-29 18:13:40 --> Input Class Initialized
DEBUG - 2012-03-29 18:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 18:13:40 --> Language Class Initialized
DEBUG - 2012-03-29 18:13:40 --> Loader Class Initialized
DEBUG - 2012-03-29 18:13:40 --> Controller Class Initialized
DEBUG - 2012-03-29 18:13:40 --> File loaded: system/views/index_view.php
DEBUG - 2012-03-29 18:13:40 --> Final output sent to browser
DEBUG - 2012-03-29 18:13:40 --> Total execution time: 0.0275
DEBUG - 2012-03-29 18:17:25 --> Config Class Initialized
DEBUG - 2012-03-29 18:17:25 --> Hooks Class Initialized
DEBUG - 2012-03-29 18:17:25 --> Utf8 Class Initialized
DEBUG - 2012-03-29 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 18:17:25 --> URI Class Initialized
DEBUG - 2012-03-29 18:17:25 --> Router Class Initialized
DEBUG - 2012-03-29 18:17:25 --> No URI present. Default controller set.
DEBUG - 2012-03-29 18:17:25 --> Output Class Initialized
DEBUG - 2012-03-29 18:17:25 --> Security Class Initialized
DEBUG - 2012-03-29 18:17:25 --> Input Class Initialized
DEBUG - 2012-03-29 18:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 18:17:25 --> Language Class Initialized
DEBUG - 2012-03-29 18:17:25 --> Loader Class Initialized
DEBUG - 2012-03-29 18:17:25 --> Controller Class Initialized
DEBUG - 2012-03-29 18:17:25 --> File loaded: system/views/index_view.php
DEBUG - 2012-03-29 18:17:25 --> Final output sent to browser
DEBUG - 2012-03-29 18:17:25 --> Total execution time: 0.0342
DEBUG - 2012-03-29 20:33:25 --> Config Class Initialized
DEBUG - 2012-03-29 20:33:25 --> Hooks Class Initialized
DEBUG - 2012-03-29 20:33:25 --> Utf8 Class Initialized
DEBUG - 2012-03-29 20:33:25 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 20:33:25 --> URI Class Initialized
DEBUG - 2012-03-29 20:33:25 --> Router Class Initialized
DEBUG - 2012-03-29 20:33:25 --> No URI present. Default controller set.
DEBUG - 2012-03-29 20:33:25 --> Output Class Initialized
DEBUG - 2012-03-29 20:33:25 --> Security Class Initialized
DEBUG - 2012-03-29 20:33:25 --> Input Class Initialized
DEBUG - 2012-03-29 20:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 20:33:25 --> Language Class Initialized
DEBUG - 2012-03-29 20:33:25 --> Loader Class Initialized
DEBUG - 2012-03-29 20:33:25 --> Controller Class Initialized
DEBUG - 2012-03-29 20:33:25 --> File loaded: system/views/main_view.php
DEBUG - 2012-03-29 20:33:25 --> Final output sent to browser
DEBUG - 2012-03-29 20:33:25 --> Total execution time: 0.0282
DEBUG - 2012-03-29 20:33:28 --> Config Class Initialized
DEBUG - 2012-03-29 20:33:28 --> Hooks Class Initialized
DEBUG - 2012-03-29 20:33:28 --> Utf8 Class Initialized
DEBUG - 2012-03-29 20:33:28 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 20:33:28 --> URI Class Initialized
DEBUG - 2012-03-29 20:33:28 --> Router Class Initialized
DEBUG - 2012-03-29 20:33:28 --> No URI present. Default controller set.
DEBUG - 2012-03-29 20:33:28 --> Output Class Initialized
DEBUG - 2012-03-29 20:33:28 --> Security Class Initialized
DEBUG - 2012-03-29 20:33:28 --> Input Class Initialized
DEBUG - 2012-03-29 20:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 20:33:28 --> Language Class Initialized
DEBUG - 2012-03-29 20:33:28 --> Loader Class Initialized
DEBUG - 2012-03-29 20:33:28 --> Controller Class Initialized
DEBUG - 2012-03-29 20:33:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-03-29 20:33:28 --> Final output sent to browser
DEBUG - 2012-03-29 20:33:28 --> Total execution time: 0.0277
DEBUG - 2012-03-29 20:37:01 --> Config Class Initialized
DEBUG - 2012-03-29 20:37:01 --> Hooks Class Initialized
DEBUG - 2012-03-29 20:37:01 --> Utf8 Class Initialized
DEBUG - 2012-03-29 20:37:01 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 20:37:01 --> URI Class Initialized
DEBUG - 2012-03-29 20:37:01 --> Router Class Initialized
DEBUG - 2012-03-29 20:37:01 --> No URI present. Default controller set.
DEBUG - 2012-03-29 20:37:01 --> Output Class Initialized
DEBUG - 2012-03-29 20:37:01 --> Security Class Initialized
DEBUG - 2012-03-29 20:37:01 --> Input Class Initialized
DEBUG - 2012-03-29 20:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 20:37:01 --> Language Class Initialized
DEBUG - 2012-03-29 20:37:01 --> Loader Class Initialized
DEBUG - 2012-03-29 20:37:01 --> Controller Class Initialized
DEBUG - 2012-03-29 20:37:01 --> File loaded: system/views/main_view.php
DEBUG - 2012-03-29 20:37:01 --> Final output sent to browser
DEBUG - 2012-03-29 20:37:01 --> Total execution time: 0.0322
DEBUG - 2012-03-29 20:37:02 --> Config Class Initialized
DEBUG - 2012-03-29 20:37:02 --> Hooks Class Initialized
DEBUG - 2012-03-29 20:37:02 --> Utf8 Class Initialized
DEBUG - 2012-03-29 20:37:02 --> UTF-8 Support Enabled
DEBUG - 2012-03-29 20:37:02 --> URI Class Initialized
DEBUG - 2012-03-29 20:37:02 --> Router Class Initialized
DEBUG - 2012-03-29 20:37:02 --> No URI present. Default controller set.
DEBUG - 2012-03-29 20:37:02 --> Output Class Initialized
DEBUG - 2012-03-29 20:37:02 --> Security Class Initialized
DEBUG - 2012-03-29 20:37:02 --> Input Class Initialized
DEBUG - 2012-03-29 20:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-29 20:37:02 --> Language Class Initialized
DEBUG - 2012-03-29 20:37:02 --> Loader Class Initialized
DEBUG - 2012-03-29 20:37:02 --> Controller Class Initialized
DEBUG - 2012-03-29 20:37:03 --> File loaded: system/views/main_view.php
DEBUG - 2012-03-29 20:37:03 --> Final output sent to browser
DEBUG - 2012-03-29 20:37:03 --> Total execution time: 0.0300
