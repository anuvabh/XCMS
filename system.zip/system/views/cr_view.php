<html>
STUDENT(CR) VIEW PAGE
<br />
<?php
    echo "Welcome, ".$FirstName." ".$LastName;
    echo "<br />";
?>
    <br />
    <a href = "http://localhost/xcms/main/myCredits">Click to view Credits</a>
    <br />
    <a href = "http://localhost/xcms/Events/register">Click to view Events</a>
 
</html>