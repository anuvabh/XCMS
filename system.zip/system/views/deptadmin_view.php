<html>
DEPARTMENT ADMIN VIEW PAGE
<br />
<?php
    echo "Welcome, ".$FirstName." ".$LastName;
    echo "<br />";
?>
    <br />
   
    <br />
    <a href="http://localhost/xcms/accounts/logout">Click to logout</a>
</html>