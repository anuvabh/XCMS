<html>
    <body>
        <br/>
        <a href="http://localhost/xcms/accounts/changePassword">Click to change password</a>
        <br />
        <a href="http://localhost/xcms/accounts/logout">Click to logout</a>
    </body>
</html>