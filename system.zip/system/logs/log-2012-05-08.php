<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-05-08 16:20:27 --> Config Class Initialized
DEBUG - 2012-05-08 16:20:27 --> Hooks Class Initialized
DEBUG - 2012-05-08 16:20:27 --> Utf8 Class Initialized
DEBUG - 2012-05-08 16:20:27 --> UTF-8 Support Enabled
DEBUG - 2012-05-08 16:20:27 --> URI Class Initialized
DEBUG - 2012-05-08 16:20:27 --> Router Class Initialized
DEBUG - 2012-05-08 16:20:27 --> No URI present. Default controller set.
DEBUG - 2012-05-08 16:20:27 --> Output Class Initialized
DEBUG - 2012-05-08 16:20:27 --> Security Class Initialized
DEBUG - 2012-05-08 16:20:27 --> Input Class Initialized
DEBUG - 2012-05-08 16:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-08 16:20:27 --> Language Class Initialized
DEBUG - 2012-05-08 16:20:27 --> Loader Class Initialized
DEBUG - 2012-05-08 16:20:27 --> Helper loaded: url_helper
DEBUG - 2012-05-08 16:20:27 --> Database Driver Class Initialized
DEBUG - 2012-05-08 16:20:28 --> Session Class Initialized
DEBUG - 2012-05-08 16:20:28 --> Helper loaded: string_helper
DEBUG - 2012-05-08 16:20:28 --> A session cookie was not found.
DEBUG - 2012-05-08 16:20:28 --> Session routines successfully run
DEBUG - 2012-05-08 16:20:28 --> Controller Class Initialized
DEBUG - 2012-05-08 16:20:28 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-08 16:20:28 --> Final output sent to browser
DEBUG - 2012-05-08 16:20:28 --> Total execution time: 0.9774
DEBUG - 2012-05-08 16:20:33 --> Config Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Hooks Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Utf8 Class Initialized
DEBUG - 2012-05-08 16:20:33 --> UTF-8 Support Enabled
DEBUG - 2012-05-08 16:20:33 --> URI Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Router Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Output Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Security Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Input Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-08 16:20:33 --> Language Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Loader Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Helper loaded: url_helper
DEBUG - 2012-05-08 16:20:33 --> Database Driver Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Session Class Initialized
DEBUG - 2012-05-08 16:20:33 --> Helper loaded: string_helper
DEBUG - 2012-05-08 16:20:33 --> Session routines successfully run
DEBUG - 2012-05-08 16:20:33 --> Controller Class Initialized
DEBUG - 2012-05-08 16:20:33 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-08 16:20:33 --> Final output sent to browser
DEBUG - 2012-05-08 16:20:33 --> Total execution time: 0.0524
DEBUG - 2012-05-08 16:21:29 --> Config Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Hooks Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Utf8 Class Initialized
DEBUG - 2012-05-08 16:21:29 --> UTF-8 Support Enabled
DEBUG - 2012-05-08 16:21:29 --> URI Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Router Class Initialized
DEBUG - 2012-05-08 16:21:29 --> No URI present. Default controller set.
DEBUG - 2012-05-08 16:21:29 --> Output Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Security Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Input Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-05-08 16:21:29 --> Language Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Loader Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Helper loaded: url_helper
DEBUG - 2012-05-08 16:21:29 --> Database Driver Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Session Class Initialized
DEBUG - 2012-05-08 16:21:29 --> Helper loaded: string_helper
DEBUG - 2012-05-08 16:21:29 --> A session cookie was not found.
DEBUG - 2012-05-08 16:21:29 --> Session routines successfully run
DEBUG - 2012-05-08 16:21:29 --> Controller Class Initialized
DEBUG - 2012-05-08 16:21:29 --> File loaded: system/views/main_view.php
DEBUG - 2012-05-08 16:21:29 --> Final output sent to browser
DEBUG - 2012-05-08 16:21:29 --> Total execution time: 0.0543
